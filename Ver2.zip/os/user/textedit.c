#include "libc/font.h"
#include "libc/gui.h"
#include "libc/stdio.h"
#include "libc/stdlib.h"
#include "libc/string.h"

#define WIN_W 820
#define WIN_H 500
#define TEXT_MAX 16384
#define MAX_LINE_MAP 2048

#define COLOR_BG       0xF8F7F4
#define COLOR_HEADER   0x4A5D73
#define COLOR_TEXT     0x1E2832
#define COLOR_TOOL     0xD9E1EA
#define COLOR_BUTTON   0xA7BED3
#define COLOR_PATH_BG  0xFFFFFF
#define COLOR_PATH_EDIT 0xFFF6D8
#define COLOR_AREA     0xFFFFFF
#define COLOR_STATUS   0xD2DBE5

static uint32_t framebuffer[WIN_W * WIN_H];
static char path_buf[MAX_PATH] = "/notes.txt";
static char path_input[MAX_PATH];
static int path_input_len = 0;
static int path_edit_mode = 0;

static char text_buf[TEXT_MAX + 1];
static size_t text_len = 0;
static int scroll_line = 0;
static int dirty = 0;
static char status_line[96] = "Ready";

static size_t line_map[MAX_LINE_MAP];
static int line_count = 1;

static void draw_rect(int x, int y, int w, int h, uint32_t color) {
    for (int j = y; j < y + h && j < WIN_H; j++) {
        if (j < 0) continue;
        for (int i = x; i < x + w && i < WIN_W; i++) {
            if (i < 0) continue;
            framebuffer[j * WIN_W + i] = color;
        }
    }
}

static void set_status(const char *msg) {
    if (!msg) return;
    strncpy(status_line, msg, sizeof(status_line) - 1);
    status_line[sizeof(status_line) - 1] = '\0';
}

static void rebuild_line_map(void) {
    line_count = 1;
    line_map[0] = 0;

    for (size_t i = 0; i < text_len; i++) {
        if (text_buf[i] == '\n') {
            if (line_count < MAX_LINE_MAP) {
                line_map[line_count++] = i + 1;
            }
        }
    }

    int visible_rows = (WIN_H - 122) / (FONT_HEIGHT + 2);
    if (visible_rows < 1) visible_rows = 1;

    int max_scroll = line_count - visible_rows;
    if (max_scroll < 0) max_scroll = 0;
    if (scroll_line < 0) scroll_line = 0;
    if (scroll_line > max_scroll) scroll_line = max_scroll;
}

static void clear_text(void) {
    text_len = 0;
    text_buf[0] = '\0';
    scroll_line = 0;
    dirty = 0;
    rebuild_line_map();
}

static void load_file(const char *path) {
    if (!path || !*path) return;

    int fd = open(path, O_RDONLY);
    if (fd < 0) {
        clear_text();
        set_status("New file");
        return;
    }

    text_len = 0;
    ssize_t n;
    while ((n = read(fd, text_buf + text_len, TEXT_MAX - text_len)) > 0) {
        text_len += (size_t)n;
        if (text_len >= TEXT_MAX) break;
    }
    close(fd);

    text_buf[text_len] = '\0';
    dirty = 0;
    rebuild_line_map();

    if (text_len >= TEXT_MAX) {
        set_status("Loaded (truncated)");
    } else {
        char msg[96];
        snprintf(msg, sizeof(msg), "Loaded %u bytes", (unsigned)text_len);
        set_status(msg);
    }
}

static void save_file(void) {
    int fd = open(path_buf, O_CREAT | O_TRUNC | O_WRONLY);
    if (fd < 0) {
        set_status("Save failed");
        return;
    }

    size_t written = 0;
    while (written < text_len) {
        ssize_t n = write(fd, text_buf + written, text_len - written);
        if (n <= 0) break;
        written += (size_t)n;
    }
    close(fd);

    if (written != text_len) {
        set_status("Save failed (short write)");
        return;
    }

    dirty = 0;
    char msg[96];
    snprintf(msg, sizeof(msg), "Saved %u bytes", (unsigned)written);
    set_status(msg);
}

static void start_path_edit(void) {
    path_edit_mode = 1;
    strncpy(path_input, path_buf, sizeof(path_input) - 1);
    path_input[sizeof(path_input) - 1] = '\0';
    path_input_len = (int)strlen(path_input);
    set_status("Path edit mode: Enter=open  Esc=cancel");
}

static void commit_path_edit(void) {
    if (path_input_len <= 0) {
        set_status("Open failed: empty path");
        path_edit_mode = 0;
        return;
    }

    strncpy(path_buf, path_input, sizeof(path_buf) - 1);
    path_buf[sizeof(path_buf) - 1] = '\0';
    path_edit_mode = 0;
    load_file(path_buf);
}

static void insert_char(char c) {
    if (text_len >= TEXT_MAX) {
        set_status("Buffer full");
        return;
    }

    text_buf[text_len++] = c;
    text_buf[text_len] = '\0';
    dirty = 1;
    rebuild_line_map();
}

static void backspace_text(void) {
    if (text_len == 0) return;
    text_len--;
    text_buf[text_len] = '\0';
    dirty = 1;
    rebuild_line_map();
}

static void render(void) {
    draw_rect(0, 0, WIN_W, WIN_H, COLOR_BG);
    draw_rect(0, 0, WIN_W, 34, COLOR_HEADER);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     12, 11, "Text Editor", 0xFFFFFF, COLOR_HEADER);

    draw_rect(0, 34, WIN_W, 32, COLOR_TOOL);

    draw_rect(10, 40, 56, 20, COLOR_BUTTON);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     20, 45, "Open", 0x1D2A36, COLOR_BUTTON);

    draw_rect(74, 40, 56, 20, COLOR_BUTTON);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     86, 45, "Save", 0x1D2A36, COLOR_BUTTON);

    draw_rect(138, 40, 56, 20, COLOR_BUTTON);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     152, 45, "New", 0x1D2A36, COLOR_BUTTON);

    uint32_t path_bg = path_edit_mode ? COLOR_PATH_EDIT : COLOR_PATH_BG;
    draw_rect(206, 40, WIN_W - 216, 20, path_bg);

    char shown_path[MAX_PATH + 4];
    if (path_edit_mode) {
        snprintf(shown_path, sizeof(shown_path), "%s_", path_input);
    } else {
        snprintf(shown_path, sizeof(shown_path), "%s", path_buf);
    }

    font_draw_string(framebuffer, WIN_W, WIN_H,
                     212, 45, shown_path, COLOR_TEXT, path_bg);

    draw_rect(10, 72, WIN_W - 20, WIN_H - 102, COLOR_AREA);

    int visible_rows = (WIN_H - 122) / (FONT_HEIGHT + 2);
    if (visible_rows < 1) visible_rows = 1;

    for (int row = 0; row < visible_rows; row++) {
        int line_idx = scroll_line + row;
        if (line_idx >= line_count) break;

        size_t start = line_map[line_idx];
        size_t end = text_len;
        if (line_idx + 1 < line_count) {
            end = line_map[line_idx + 1];
            if (end > 0 && text_buf[end - 1] == '\n') end--;
        }

        char line[160];
        int n = 0;
        size_t max_cols = (size_t)((WIN_W - 34) / FONT_WIDTH);
        if (max_cols > sizeof(line) - 1) max_cols = sizeof(line) - 1;

        for (size_t i = start; i < end && n < (int)max_cols; i++) {
            char c = text_buf[i];
            if ((unsigned char)c < 32 || (unsigned char)c > 126) c = ' ';
            line[n++] = c;
        }
        line[n] = '\0';

        int y = 78 + row * (FONT_HEIGHT + 2);
        font_draw_string(framebuffer, WIN_W, WIN_H,
                         14, y, line, COLOR_TEXT, COLOR_AREA);
    }

    draw_rect(0, WIN_H - 26, WIN_W, 26, COLOR_STATUS);
    char footer[96];
    snprintf(footer, sizeof(footer), "%s%s", status_line, dirty ? "  *modified" : "");
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     10, WIN_H - 18, footer, COLOR_TEXT, COLOR_STATUS);
}

int main(void) {
    int wid = win_create(88, 64, WIN_W, WIN_H, "Text Editor");
    if (wid < 0) {
        printf("textedit: failed to create window\n");
        return 1;
    }

    load_file(path_buf);
    render();
    win_update(wid, framebuffer);

    int running = 1;
    while (running) {
        struct gui_event ev;
        if (win_event(&ev) > 0) {
            if (ev.type == GUI_EVENT_WIN_CLOSE) {
                running = 0;
            } else if (ev.type == GUI_EVENT_MOUSE_DOWN) {
                if (ev.y >= 40 && ev.y < 60) {
                    if (ev.x >= 10 && ev.x < 66) {
                        start_path_edit();
                    } else if (ev.x >= 74 && ev.x < 130) {
                        save_file();
                    } else if (ev.x >= 138 && ev.x < 194) {
                        clear_text();
                        set_status("New buffer");
                    } else if (ev.x >= 206 && ev.x < WIN_W - 10) {
                        start_path_edit();
                    }
                }
            } else if (ev.type == GUI_EVENT_KEY_PRESS) {
                uint32_t kc = ev.keycode;

                if (path_edit_mode) {
                    if (kc == '\r' || kc == '\n') {
                        commit_path_edit();
                    } else if (kc == 27) {
                        path_edit_mode = 0;
                        set_status("Path edit cancelled");
                    } else if (kc == '\b' || kc == 127) {
                        if (path_input_len > 0) {
                            path_input[--path_input_len] = '\0';
                        }
                    } else if (kc >= 32 && kc <= 126) {
                        if (path_input_len < MAX_PATH - 1) {
                            path_input[path_input_len++] = (char)kc;
                            path_input[path_input_len] = '\0';
                        }
                    }
                } else {
                    if (kc == 27) {
                        running = 0;
                    } else if (kc == '\b' || kc == 127) {
                        backspace_text();
                    } else if (kc == '\r' || kc == '\n') {
                        insert_char('\n');
                    } else if (kc == 0x82) {
                        scroll_line--;
                        rebuild_line_map();
                    } else if (kc == 0x83) {
                        scroll_line++;
                        rebuild_line_map();
                    } else if (kc >= 32 && kc <= 126) {
                        insert_char((char)kc);
                    }
                }
            }

            render();
            win_update(wid, framebuffer);
        }

        yield();
    }

    win_destroy(wid);
    return 0;
}
