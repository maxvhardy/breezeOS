#include "libc/font.h"
#include "libc/gui.h"
#include "libc/stdio.h"
#include "libc/stdlib.h"
#include "libc/string.h"

#define WIN_W 700
#define WIN_H 430
#define MAX_LINES 220
#define LINE_LEN  120

#define COLOR_BG      0x121722
#define COLOR_HEADER  0x31405C
#define COLOR_TEXT    0xDDE8FF
#define COLOR_PROMPT  0xFFD166
#define COLOR_PANEL   0x0E1420
#define COLOR_STATUS  0x1A2436

static uint32_t framebuffer[WIN_W * WIN_H];
static char lines[MAX_LINES][LINE_LEN];
static int line_start = 0;
static int line_count = 0;
static char input_buf[96];
static int input_len = 0;
static char status_line[96] = "Ready";

static void draw_rect(int x, int y, int w, int h, uint32_t color) {
    for (int j = y; j < y + h && j < WIN_H; j++) {
        if (j < 0) continue;
        for (int i = x; i < x + w && i < WIN_W; i++) {
            if (i < 0) continue;
            framebuffer[j * WIN_W + i] = color;
        }
    }
}

static void set_status(const char *msg) {
    if (!msg) return;
    strncpy(status_line, msg, sizeof(status_line) - 1);
    status_line[sizeof(status_line) - 1] = '\0';
}

static void append_line(const char *s) {
    if (!s) return;

    int slot = (line_start + line_count) % MAX_LINES;
    if (line_count == MAX_LINES) {
        line_start = (line_start + 1) % MAX_LINES;
        slot = (line_start + line_count - 1) % MAX_LINES;
    } else {
        line_count++;
    }

    int n = 0;
    while (s[n] && n < LINE_LEN - 1) {
        char c = s[n];
        if ((unsigned char)c < 32 || (unsigned char)c > 126) c = '?';
        lines[slot][n++] = c;
    }
    lines[slot][n] = '\0';
}

static int is_space(char c) {
    return c == ' ' || c == '\t';
}

static void skip_spaces(const char **p) {
    while (p && *p && is_space(**p)) (*p)++;
}

static int parse_expr(const char **p, int *out, char *err, size_t err_sz);

static int parse_factor(const char **p, int *out, char *err, size_t err_sz) {
    skip_spaces(p);
    if (!p || !*p || !out) return 0;

    int sign = 1;
    while (**p == '+' || **p == '-') {
        if (**p == '-') sign = -sign;
        (*p)++;
        skip_spaces(p);
    }

    if (**p == '(') {
        (*p)++;
        int value = 0;
        if (!parse_expr(p, &value, err, err_sz)) return 0;
        skip_spaces(p);
        if (**p != ')') {
            snprintf(err, err_sz, "expected ')'");
            return 0;
        }
        (*p)++;
        *out = sign * value;
        return 1;
    }

    if (**p < '0' || **p > '9') {
        snprintf(err, err_sz, "expected number");
        return 0;
    }

    int value = 0;
    while (**p >= '0' && **p <= '9') {
        value = value * 10 + (**p - '0');
        (*p)++;
    }

    *out = sign * value;
    return 1;
}

static int parse_term(const char **p, int *out, char *err, size_t err_sz) {
    int value = 0;
    if (!parse_factor(p, &value, err, err_sz)) return 0;

    while (1) {
        skip_spaces(p);
        char op = **p;
        if (op != '*' && op != '/' && op != '%') break;
        (*p)++;

        int rhs = 0;
        if (!parse_factor(p, &rhs, err, err_sz)) return 0;

        if ((op == '/' || op == '%') && rhs == 0) {
            snprintf(err, err_sz, "division by zero");
            return 0;
        }

        if (op == '*') value *= rhs;
        else if (op == '/') value /= rhs;
        else value %= rhs;
    }

    *out = value;
    return 1;
}

static int parse_expr(const char **p, int *out, char *err, size_t err_sz) {
    int value = 0;
    if (!parse_term(p, &value, err, err_sz)) return 0;

    while (1) {
        skip_spaces(p);
        char op = **p;
        if (op != '+' && op != '-') break;
        (*p)++;

        int rhs = 0;
        if (!parse_term(p, &rhs, err, err_sz)) return 0;
        if (op == '+') value += rhs;
        else value -= rhs;
    }

    *out = value;
    return 1;
}

static int eval_expr(const char *src, int *out, char *err, size_t err_sz) {
    if (!src || !out || !err || err_sz == 0) return 0;
    err[0] = '\0';

    const char *p = src;
    if (!parse_expr(&p, out, err, err_sz)) {
        if (!err[0]) snprintf(err, err_sz, "invalid expression");
        return 0;
    }

    skip_spaces(&p);
    if (*p != '\0') {
        snprintf(err, err_sz, "unexpected '%c'", *p);
        return 0;
    }

    return 1;
}

static int starts_with(const char *s, const char *prefix) {
    if (!s || !prefix) return 0;
    while (*prefix) {
        if (*s++ != *prefix++) return 0;
    }
    return 1;
}

static void run_command(const char *line) {
    if (!line || !*line) return;

    if (strcmp(line, "help") == 0) {
        append_line("DoorPy help:");
        append_line("  expression         -> evaluates integer arithmetic");
        append_line("  print(expr)        -> prints evaluated value");
        append_line("  print(\"text\")      -> prints text");
        append_line("  clear              -> clears output");
        return;
    }

    if (strcmp(line, "clear") == 0) {
        line_start = 0;
        line_count = 0;
        return;
    }

    if (starts_with(line, "print(")) {
        size_t len = strlen(line);
        if (len < 7 || line[len - 1] != ')') {
            append_line("SyntaxError: expected ')' ");
            return;
        }

        char body[96];
        size_t body_len = len - 7;
        if (body_len >= sizeof(body)) body_len = sizeof(body) - 1;
        memcpy(body, line + 6, body_len);
        body[body_len] = '\0';

        if (body_len >= 2 && body[0] == '"' && body[body_len - 1] == '"') {
            body[body_len - 1] = '\0';
            append_line(body + 1);
            return;
        }

        int value = 0;
        char err[64];
        if (!eval_expr(body, &value, err, sizeof(err))) {
            char msg[96];
            snprintf(msg, sizeof(msg), "ValueError: %s", err);
            append_line(msg);
            return;
        }

        char out[64];
        snprintf(out, sizeof(out), "%d", value);
        append_line(out);
        return;
    }

    int value = 0;
    char err[64];
    if (!eval_expr(line, &value, err, sizeof(err))) {
        char msg[96];
        snprintf(msg, sizeof(msg), "SyntaxError: %s", err);
        append_line(msg);
        return;
    }

    char out[64];
    snprintf(out, sizeof(out), "%d", value);
    append_line(out);
}

static void render(void) {
    draw_rect(0, 0, WIN_W, WIN_H, COLOR_BG);
    draw_rect(0, 0, WIN_W, 34, COLOR_HEADER);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     12, 11, "Python 3 (DoorPy)", 0xFFFFFF, COLOR_HEADER);

    draw_rect(8, 42, WIN_W - 16, WIN_H - 110, COLOR_PANEL);

    int max_rows = (WIN_H - 122) / (FONT_HEIGHT + 2);
    if (max_rows < 1) max_rows = 1;

    int start = line_count - max_rows;
    if (start < 0) start = 0;

    int y = 50;
    for (int i = start; i < line_count; i++) {
        int idx = (line_start + i) % MAX_LINES;
        font_draw_string(framebuffer, WIN_W, WIN_H,
                         14, y, lines[idx], COLOR_TEXT, COLOR_PANEL);
        y += FONT_HEIGHT + 2;
    }

    draw_rect(8, WIN_H - 62, WIN_W - 16, 24, 0x0A1320);
    char prompt[112];
    snprintf(prompt, sizeof(prompt), ">>> %s", input_buf);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     14, WIN_H - 55, prompt, COLOR_PROMPT, 0x0A1320);

    draw_rect(0, WIN_H - 26, WIN_W, 26, COLOR_STATUS);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     10, WIN_H - 18, status_line, COLOR_TEXT, COLOR_STATUS);
}

int main(void) {
    int wid = win_create(126, 78, WIN_W, WIN_H, "Python");
    if (wid < 0) {
        printf("python: failed to create window\n");
        return 1;
    }

    append_line("DoorPy 0.1");
    append_line("Type help for usage.");

    int running = 1;
    while (running) {
        struct gui_event ev;
        if (win_event(&ev) > 0) {
            if (ev.type == GUI_EVENT_WIN_CLOSE) {
                running = 0;
            } else if (ev.type == GUI_EVENT_KEY_PRESS) {
                uint32_t kc = ev.keycode;

                if (kc == 27) {
                    running = 0;
                } else if (kc == '\r' || kc == '\n') {
                    char cmd[96];
                    strncpy(cmd, input_buf, sizeof(cmd) - 1);
                    cmd[sizeof(cmd) - 1] = '\0';

                    if (cmd[0]) {
                        char echo[112];
                        snprintf(echo, sizeof(echo), ">>> %s", cmd);
                        append_line(echo);
                        run_command(cmd);
                    }

                    input_len = 0;
                    input_buf[0] = '\0';
                    set_status("OK");
                } else if (kc == '\b' || kc == 127) {
                    if (input_len > 0) {
                        input_len--;
                        input_buf[input_len] = '\0';
                    }
                } else if (kc >= 32 && kc <= 126) {
                    if (input_len < (int)sizeof(input_buf) - 1) {
                        input_buf[input_len++] = (char)kc;
                        input_buf[input_len] = '\0';
                    }
                }
            }

            render();
            win_update(wid, framebuffer);
        }

        yield();
    }

    win_destroy(wid);
    return 0;
}
