#include "libc/stdio.h"
#include "libc/process.h"
#include "libc/stdlib.h"
#include "libc/string.h"

struct service {
    const char *name;
    const char *path;
    int respawn;
    int pid;
};

static struct service services[] = {
    {"shell", "/bin/shell", 1, -1},
};

static int start_service(struct service *svc) {
    if (!svc || !svc->path) return -1;

    int pid = spawn(svc->path);
    if (pid < 0) {
        printf("init: failed to start %s (%s)\n", svc->name, svc->path);
        return -1;
    }

    svc->pid = pid;
    printf("init: service %s started as PID %d\n", svc->name, pid);
    return 0;
}

int main(void) {
    printf("DoorOS init/service manager started (PID %d)\n", getpid());

    for (size_t i = 0; i < sizeof(services) / sizeof(services[0]); i++) {
        start_service(&services[i]);
    }

    while (1) {
        int status = 0;
        int dead_pid = waitpid(-1, &status);

        if (dead_pid < 0) {
            for (size_t i = 0; i < sizeof(services) / sizeof(services[0]); i++) {
                if (services[i].pid <= 0) {
                    start_service(&services[i]);
                }
            }
            sleep(100);
            continue;
        }

        int handled = 0;
        for (size_t i = 0; i < sizeof(services) / sizeof(services[0]); i++) {
            if (services[i].pid != dead_pid) continue;

            handled = 1;
            services[i].pid = -1;
            printf("init: service %s (PID %d) exited status %d\n",
                   services[i].name, dead_pid, status);

            if (services[i].respawn) {
                sleep(250);
                start_service(&services[i]);
            }
            break;
        }

        if (!handled) {
            printf("init: child PID %d exited status %d\n", dead_pid, status);
        }
    }

    return 0;
}
