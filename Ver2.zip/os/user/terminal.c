#include "libc/font.h"
#include "libc/gui.h"
#include "libc/process.h"
#include "libc/stdio.h"
#include "libc/stdlib.h"
#include "libc/string.h"

#define WIN_W 760
#define WIN_H 430

#define MAX_LINES 256
#define LINE_LEN  120
#define MAX_ARGS  16

#define COLOR_BG       0x0F1621
#define COLOR_HEADER   0x1D2A3A
#define COLOR_TEXT     0xD7DEE7
#define COLOR_PROMPT   0xA6E3A1
#define COLOR_PANEL    0x101C2B
#define COLOR_STATUS   0x16283B

static uint32_t framebuffer[WIN_W * WIN_H];
static char lines[MAX_LINES][LINE_LEN];
static int line_start = 0;
static int line_count = 0;
static char input_buf[LINE_LEN];
static int input_len = 0;
static char status_line[96] = "Ready";

static void draw_rect(int x, int y, int w, int h, uint32_t color) {
    for (int j = y; j < y + h && j < WIN_H; j++) {
        if (j < 0) continue;
        for (int i = x; i < x + w && i < WIN_W; i++) {
            if (i < 0) continue;
            framebuffer[j * WIN_W + i] = color;
        }
    }
}

static void set_status(const char *msg) {
    if (!msg) return;
    strncpy(status_line, msg, sizeof(status_line) - 1);
    status_line[sizeof(status_line) - 1] = '\0';
}

static void append_line(const char *text) {
    if (!text) return;

    int slot = (line_start + line_count) % MAX_LINES;
    if (line_count == MAX_LINES) {
        line_start = (line_start + 1) % MAX_LINES;
        slot = (line_start + line_count - 1) % MAX_LINES;
    } else {
        line_count++;
    }

    int n = 0;
    while (text[n] && n < LINE_LEN - 1) {
        char c = text[n];
        if ((unsigned char)c < 32 || (unsigned char)c > 126) c = '?';
        lines[slot][n++] = c;
    }
    lines[slot][n] = '\0';
}

static int parse_int(const char *s, int *out) {
    if (!s || !*s || !out) return 0;

    int sign = 1;
    int i = 0;
    if (s[i] == '-') {
        sign = -1;
        i++;
    }

    if (!s[i]) return 0;

    int value = 0;
    while (s[i]) {
        if (s[i] < '0' || s[i] > '9') return 0;
        value = value * 10 + (s[i] - '0');
        i++;
    }

    *out = value * sign;
    return 1;
}

static int split_args(char *line, char *argv[], int max_args) {
    int argc = 0;
    char *p = line;

    while (*p && argc < max_args - 1) {
        while (*p == ' ' || *p == '\t') p++;
        if (!*p) break;

        argv[argc++] = p;
        while (*p && *p != ' ' && *p != '\t') p++;
        if (*p) *p++ = '\0';
    }
    argv[argc] = NULL;
    return argc;
}

static void cmd_help(void) {
    append_line("Built-ins: help clear ps kill run ls cat cd pwd echo apps exit");
}

static void cmd_ps(void) {
    struct proc_info infos[64];
    size_t total = 0;
    ssize_t n = proc_list(infos, 64, &total);
    if (n < 0) {
        append_line("ps: proc_list failed");
        return;
    }

    char line[LINE_LEN];
    snprintf(line, sizeof(line), "PID  PPID  STATE  NAME  (showing %d/%u)", (int)n, (unsigned)total);
    append_line(line);

    for (ssize_t i = 0; i < n; i++) {
        const char *state = "UNUSED";
        switch (infos[i].state) {
            case 1: state = "READY"; break;
            case 2: state = "RUN"; break;
            case 3: state = "BLOCK"; break;
            case 4: state = "SLEEP"; break;
            case 5: state = "ZOMB"; break;
            default: break;
        }

        snprintf(line, sizeof(line), "%3d  %4d  %-5s  %.72s",
                 infos[i].pid, infos[i].ppid, state, infos[i].name);
        append_line(line);
    }
}

static void cmd_ls(const char *path) {
    int fd = open(path && *path ? path : ".", O_RDONLY);
    if (fd < 0) {
        append_line("ls: cannot open directory");
        return;
    }

    struct dirent ent;
    while (readdir(fd, &ent) == 0) {
        char line[LINE_LEN];
        const char *tag = (ent.type == 2) ? "[D]" : "[F]";
        snprintf(line, sizeof(line), "%s %s", tag, ent.name);
        append_line(line);
    }

    close(fd);
}

static void cmd_cat(const char *path) {
    if (!path || !*path) {
        append_line("cat: missing path");
        return;
    }

    int fd = open(path, O_RDONLY);
    if (fd < 0) {
        append_line("cat: cannot open file");
        return;
    }

    char buf[256];
    ssize_t n;
    while ((n = read(fd, buf, sizeof(buf) - 1)) > 0) {
        buf[n] = '\0';

        char *p = buf;
        while (*p) {
            char line[LINE_LEN];
            int idx = 0;
            while (*p && *p != '\n' && idx < LINE_LEN - 1) {
                line[idx++] = *p++;
            }
            line[idx] = '\0';
            append_line(line);
            if (*p == '\n') p++;
        }
    }

    close(fd);
}

static void cmd_cd(const char *path) {
    if (!path || !*path) {
        append_line("cd: missing path");
        return;
    }

    if (chdir(path) < 0) {
        append_line("cd: failed");
    } else {
        char cwd[MAX_PATH];
        if (getcwd(cwd, sizeof(cwd))) {
            char line[LINE_LEN];
            snprintf(line, sizeof(line), "cwd = %s", cwd);
            append_line(line);
        }
    }
}

static void launch_default_app(const char *name) {
    char path[MAX_PATH];
    snprintf(path, sizeof(path), "/bin/%s", name);

    int pid = spawn(path);
    if (pid < 0) {
        append_line("run: spawn failed");
        return;
    }

    char line[LINE_LEN];
    snprintf(line, sizeof(line), "launched %s as PID %d", path, pid);
    append_line(line);
}

static int execute_command(char *line) {
    char *argv[MAX_ARGS];
    int argc = split_args(line, argv, MAX_ARGS);
    if (argc == 0) return 1;

    if (strcmp(argv[0], "help") == 0) {
        cmd_help();
        return 1;
    }
    if (strcmp(argv[0], "clear") == 0) {
        line_start = 0;
        line_count = 0;
        return 1;
    }
    if (strcmp(argv[0], "ps") == 0) {
        cmd_ps();
        return 1;
    }
    if (strcmp(argv[0], "kill") == 0) {
        if (argc < 2) {
            append_line("kill: missing pid");
            return 1;
        }
        int pid = 0;
        if (!parse_int(argv[1], &pid)) {
            append_line("kill: invalid pid");
            return 1;
        }
        if (kill(pid) < 0) {
            append_line("kill: failed");
        } else {
            append_line("kill: signal sent");
        }
        return 1;
    }
    if (strcmp(argv[0], "run") == 0) {
        if (argc < 2) {
            append_line("run: missing path");
            return 1;
        }
        int pid = spawn(argv[1]);
        if (pid < 0) {
            append_line("run: spawn failed");
        } else {
            char out[LINE_LEN];
            snprintf(out, sizeof(out), "launched %s as PID %d", argv[1], pid);
            append_line(out);
        }
        return 1;
    }
    if (strcmp(argv[0], "ls") == 0) {
        cmd_ls(argc > 1 ? argv[1] : ".");
        return 1;
    }
    if (strcmp(argv[0], "cat") == 0) {
        cmd_cat(argc > 1 ? argv[1] : "");
        return 1;
    }
    if (strcmp(argv[0], "cd") == 0) {
        cmd_cd(argc > 1 ? argv[1] : "");
        return 1;
    }
    if (strcmp(argv[0], "pwd") == 0) {
        char cwd[MAX_PATH];
        if (getcwd(cwd, sizeof(cwd))) append_line(cwd);
        else append_line("pwd: failed");
        return 1;
    }
    if (strcmp(argv[0], "echo") == 0) {
        char out[LINE_LEN];
        out[0] = '\0';
        for (int i = 1; i < argc; i++) {
            if (i > 1 && strlen(out) + 1 < sizeof(out) - 1) strcat(out, " ");
            strncat(out, argv[i], sizeof(out) - strlen(out) - 1);
        }
        append_line(out);
        return 1;
    }
    if (strcmp(argv[0], "apps") == 0) {
        append_line("apps: action calculator textedit fileman settings python game");
        return 1;
    }
    if (strcmp(argv[0], "exit") == 0 || strcmp(argv[0], "quit") == 0) {
        return 0;
    }

    if (strchr(argv[0], '/')) {
        int pid = spawn(argv[0]);
        if (pid < 0) {
            append_line("spawn failed");
        } else {
            char out[LINE_LEN];
            snprintf(out, sizeof(out), "launched %s as PID %d", argv[0], pid);
            append_line(out);
        }
        return 1;
    }

    launch_default_app(argv[0]);
    return 1;
}

static void render(void) {
    draw_rect(0, 0, WIN_W, WIN_H, COLOR_BG);
    draw_rect(0, 0, WIN_W, 34, COLOR_HEADER);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     12, 11, "Terminal", COLOR_TEXT, COLOR_HEADER);

    draw_rect(8, 42, WIN_W - 16, WIN_H - 110, COLOR_PANEL);

    int max_rows = (WIN_H - 122) / (FONT_HEIGHT + 2);
    if (max_rows < 1) max_rows = 1;

    int start = line_count - max_rows;
    if (start < 0) start = 0;

    int y = 50;
    for (int i = start; i < line_count; i++) {
        int idx = (line_start + i) % MAX_LINES;
        font_draw_string(framebuffer, WIN_W, WIN_H,
                         14, y, lines[idx], COLOR_TEXT, COLOR_PANEL);
        y += FONT_HEIGHT + 2;
    }

    draw_rect(8, WIN_H - 62, WIN_W - 16, 24, 0x0A1320);
    char prompt[LINE_LEN + 8];
    snprintf(prompt, sizeof(prompt), "> %s", input_buf);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     14, WIN_H - 55, prompt, COLOR_PROMPT, 0x0A1320);

    draw_rect(0, WIN_H - 26, WIN_W, 26, COLOR_STATUS);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     10, WIN_H - 18, status_line, COLOR_TEXT, COLOR_STATUS);
}

int main(void) {
    int wid = win_create(94, 72, WIN_W, WIN_H, "Terminal - DoorOS");
    if (wid < 0) {
        printf("terminal: failed to create window\n");
        return 1;
    }

    append_line("DoorOS Terminal");
    append_line("Type 'help' for commands.");

    int running = 1;
    while (running) {
        struct gui_event ev;
        if (win_event(&ev) > 0) {
            if (ev.type == GUI_EVENT_WIN_CLOSE) {
                running = 0;
            } else if (ev.type == GUI_EVENT_KEY_PRESS) {
                uint32_t kc = ev.keycode;

                if (kc == 27) {
                    running = 0;
                } else if (kc == '\r' || kc == '\n') {
                    char cmd[LINE_LEN];
                    strncpy(cmd, input_buf, sizeof(cmd) - 1);
                    cmd[sizeof(cmd) - 1] = '\0';

                    char echo_line[LINE_LEN + 4];
                    snprintf(echo_line, sizeof(echo_line), "> %s", cmd);
                    append_line(echo_line);

                    if (!execute_command(cmd)) running = 0;
                    input_len = 0;
                    input_buf[0] = '\0';
                    set_status("OK");
                } else if (kc == '\b' || kc == 127) {
                    if (input_len > 0) {
                        input_len--;
                        input_buf[input_len] = '\0';
                    }
                } else if (kc >= 32 && kc <= 126) {
                    if (input_len < LINE_LEN - 1) {
                        input_buf[input_len++] = (char)kc;
                        input_buf[input_len] = '\0';
                    }
                }
            }

            render();
            win_update(wid, framebuffer);
        }

        yield();
    }

    win_destroy(wid);
    return 0;
}
