#include "libc/font.h"
#include "libc/gui.h"
#include "libc/process.h"
#include "libc/stdio.h"
#include "libc/stdlib.h"
#include "libc/string.h"

#define WIN_W 720
#define WIN_H 430
#define MAX_PROCS 96

#define COLOR_BG       0x131A24
#define COLOR_HEADER   0x2A3B52
#define COLOR_TEXT     0xE7EEF7
#define COLOR_SUBTEXT  0xAFC4DE
#define COLOR_ROW_A    0x1A2433
#define COLOR_ROW_B    0x202C3D
#define COLOR_ROW_SEL  0x2F557C
#define COLOR_STATUS   0x223247
#define COLOR_BUTTON   0x2E8B61

#define TABLE_Y 96
#define ROW_H   (FONT_HEIGHT + 4)

static uint32_t framebuffer[WIN_W * WIN_H];
static struct proc_info infos[MAX_PROCS];
static ssize_t info_count = 0;
static size_t info_total = 0;
static int scroll = 0;
static int selected_pid = -1;
static char status_line[96] = "Ready";
static uint64_t last_refresh_ms = 0;

static void draw_rect(int x, int y, int w, int h, uint32_t color) {
    for (int j = y; j < y + h && j < WIN_H; j++) {
        if (j < 0) continue;
        for (int i = x; i < x + w && i < WIN_W; i++) {
            if (i < 0) continue;
            framebuffer[j * WIN_W + i] = color;
        }
    }
}

static const char *proc_state_name(uint32_t state) {
    switch (state) {
        case 1: return "READY";
        case 2: return "RUN";
        case 3: return "BLOCK";
        case 4: return "SLEEP";
        case 5: return "ZOMB";
        default: return "UNUSED";
    }
}

static int visible_rows(void) {
    int rows = (WIN_H - TABLE_Y - 34) / ROW_H;
    if (rows < 3) rows = 3;
    return rows;
}

static void clamp_scroll(void) {
    int rows = visible_rows();
    int max_scroll = (int)info_count - rows;
    if (max_scroll < 0) max_scroll = 0;
    if (scroll < 0) scroll = 0;
    if (scroll > max_scroll) scroll = max_scroll;
}

static int find_index_by_pid(int pid) {
    for (ssize_t i = 0; i < info_count; i++) {
        if (infos[i].pid == pid) return (int)i;
    }
    return -1;
}

static void refresh_processes(void) {
    info_count = proc_list(infos, MAX_PROCS, &info_total);
    if (info_count < 0) {
        info_count = 0;
        info_total = 0;
        strncpy(status_line, "proc_list syscall failed", sizeof(status_line) - 1);
        status_line[sizeof(status_line) - 1] = '\0';
        return;
    }

    if (selected_pid >= 0 && find_index_by_pid(selected_pid) < 0) {
        selected_pid = -1;
    }

    clamp_scroll();
    uint64_t now = (uint64_t)syscall0(SYS_TICKS);
    last_refresh_ms = now;
    snprintf(status_line, sizeof(status_line), "Showing %d of %u processes",
             (int)info_count, (unsigned)info_total);
}

static void render(void) {
    draw_rect(0, 0, WIN_W, WIN_H, COLOR_BG);
    draw_rect(0, 0, WIN_W, 34, COLOR_HEADER);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     12, 11, "Macrohard Action Employee", COLOR_TEXT, COLOR_HEADER);

    draw_rect(WIN_W - 120, 48, 100, 24, COLOR_BUTTON);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     WIN_W - 96, 56, "Refresh", 0xFFFFFF, COLOR_BUTTON);

    font_draw_string(framebuffer, WIN_W, WIN_H,
                     14, 46, "R=refresh  X=kill selected  J/K=scroll", COLOR_SUBTEXT, COLOR_BG);

    char top_line[96];
    snprintf(top_line, sizeof(top_line), "Processes: %u", (unsigned)info_total);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     14, 62, top_line, COLOR_SUBTEXT, COLOR_BG);

    draw_rect(10, TABLE_Y, WIN_W - 20, 18, COLOR_HEADER);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     18, TABLE_Y + 6, "PID  PPID  STATE  TYPE  CPU(ms)  NAME", COLOR_TEXT, COLOR_HEADER);

    int rows = visible_rows();
    for (int row = 0; row < rows; row++) {
        int idx = scroll + row;
        if (idx >= (int)info_count) break;

        int y = TABLE_Y + 20 + row * ROW_H;
        uint32_t bg = (row & 1) ? COLOR_ROW_B : COLOR_ROW_A;
        if (infos[idx].pid == selected_pid) bg = COLOR_ROW_SEL;

        draw_rect(10, y, WIN_W - 20, ROW_H, bg);

        char line[128];
        const char *ptype = (infos[idx].flags & PROC_FLAG_USER) ? "user" : "kern";
        unsigned cpu_ms = (unsigned)(infos[idx].cpu_ticks * 10ULL);
        snprintf(line, sizeof(line), "%3d  %4d  %-5s  %-4s  %7u  %.24s",
                 infos[idx].pid,
                 infos[idx].ppid,
                 proc_state_name(infos[idx].state),
                 ptype,
                 cpu_ms,
                 infos[idx].name);
        font_draw_string(framebuffer, WIN_W, WIN_H,
                         16, y + 2, line, COLOR_TEXT, bg);
    }

    draw_rect(0, WIN_H - 26, WIN_W, 26, COLOR_STATUS);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     10, WIN_H - 18, status_line, COLOR_SUBTEXT, COLOR_STATUS);
}

static void select_row_from_click(int x, int y) {
    if (x < 10 || x >= WIN_W - 10) return;
    if (y < TABLE_Y + 20) return;

    int row = (y - (TABLE_Y + 20)) / ROW_H;
    int idx = scroll + row;
    if (idx < 0 || idx >= (int)info_count) return;

    selected_pid = infos[idx].pid;
    snprintf(status_line, sizeof(status_line), "Selected PID %d", selected_pid);
}

static void kill_selected(void) {
    if (selected_pid < 0) {
        strncpy(status_line, "No selected process", sizeof(status_line) - 1);
        status_line[sizeof(status_line) - 1] = '\0';
        return;
    }

    if (selected_pid <= 1) {
        strncpy(status_line, "Refusing to kill PID 0/1", sizeof(status_line) - 1);
        status_line[sizeof(status_line) - 1] = '\0';
        return;
    }

    if (kill(selected_pid) < 0) {
        snprintf(status_line, sizeof(status_line), "Failed to kill PID %d", selected_pid);
        return;
    }

    snprintf(status_line, sizeof(status_line), "Terminate signal sent to PID %d", selected_pid);
    refresh_processes();
}

int main(void) {
    int wid = win_create(124, 78, WIN_W, WIN_H, "Macrohard Action Employee");
    if (wid < 0) {
        printf("action: failed to create window\n");
        return 1;
    }

    refresh_processes();
    render();
    win_update(wid, framebuffer);

    int running = 1;
    while (running) {
        struct gui_event ev;
        int got = win_event(&ev);
        if (got > 0) {
            if (ev.type == GUI_EVENT_WIN_CLOSE) {
                running = 0;
            } else if (ev.type == GUI_EVENT_MOUSE_DOWN) {
                if (ev.x >= WIN_W - 120 && ev.x < WIN_W - 20 &&
                    ev.y >= 48 && ev.y < 72) {
                    refresh_processes();
                } else {
                    select_row_from_click(ev.x, ev.y);
                }
                render();
                win_update(wid, framebuffer);
            } else if (ev.type == GUI_EVENT_KEY_PRESS) {
                if (ev.keycode == 27 || ev.keycode == 'q' || ev.keycode == 'Q') {
                    running = 0;
                } else if (ev.keycode == 'r' || ev.keycode == 'R') {
                    refresh_processes();
                } else if (ev.keycode == 'x' || ev.keycode == 'X') {
                    kill_selected();
                } else if (ev.keycode == 'j' || ev.keycode == 'J') {
                    scroll++;
                    clamp_scroll();
                } else if (ev.keycode == 'k' || ev.keycode == 'K') {
                    scroll--;
                    clamp_scroll();
                }
                render();
                win_update(wid, framebuffer);
            }
        }

        uint64_t now = (uint64_t)syscall0(SYS_TICKS);
        if (now - last_refresh_ms >= 1000ULL) {
            refresh_processes();
            render();
            win_update(wid, framebuffer);
        }

        yield();
    }

    win_destroy(wid);
    return 0;
}
