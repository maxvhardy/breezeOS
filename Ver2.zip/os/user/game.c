#include "libc/font.h"
#include "libc/gui.h"
#include "libc/stdio.h"
#include "libc/stdlib.h"
#include "libc/string.h"

#define WIN_W 620
#define WIN_H 430

#define GRID_W 24
#define GRID_H 16
#define CELL   20
#define BOARD_X 70
#define BOARD_Y 60

#define COLOR_BG       0x0B1A24
#define COLOR_HEADER   0x1E3852
#define COLOR_BOARD    0x102534
#define COLOR_PLAYER   0x4A9BD9
#define COLOR_COIN     0xF4D03F
#define COLOR_GRID     0x1A3449
#define COLOR_STATUS   0x132A3C
#define COLOR_TEXT     0xDDEBFF

static uint32_t framebuffer[WIN_W * WIN_H];

static int player_x = GRID_W / 2;
static int player_y = GRID_H / 2;
static int dir_x = 1;
static int dir_y = 0;
static int coin_x = 3;
static int coin_y = 3;
static int score = 0;
static int game_over = 0;
static uint64_t last_step_ms = 0;
static char status_line[96] = "WASD or arrows to move";

static void draw_rect(int x, int y, int w, int h, uint32_t color) {
    for (int j = y; j < y + h && j < WIN_H; j++) {
        if (j < 0) continue;
        for (int i = x; i < x + w && i < WIN_W; i++) {
            if (i < 0) continue;
            framebuffer[j * WIN_W + i] = color;
        }
    }
}

static void set_status(const char *msg) {
    if (!msg) return;
    strncpy(status_line, msg, sizeof(status_line) - 1);
    status_line[sizeof(status_line) - 1] = '\0';
}

static int abs_i(int v) {
    return v < 0 ? -v : v;
}

static void place_coin(void) {
    uint64_t seed = (uint64_t)syscall0(SYS_TICKS) + (uint64_t)score * 7919ULL;
    int nx = (int)(seed % GRID_W);
    int ny = (int)((seed / 13ULL) % GRID_H);

    if (nx == player_x && ny == player_y) {
        nx = (nx + 5) % GRID_W;
        ny = (ny + 7) % GRID_H;
    }

    coin_x = nx;
    coin_y = ny;
}

static void reset_game(void) {
    player_x = GRID_W / 2;
    player_y = GRID_H / 2;
    dir_x = 1;
    dir_y = 0;
    score = 0;
    game_over = 0;
    place_coin();
    set_status("Collect coins. Avoid walls.");
    last_step_ms = (uint64_t)syscall0(SYS_TICKS);
}

static void step_game(void) {
    if (game_over) return;

    player_x += dir_x;
    player_y += dir_y;

    if (player_x < 0 || player_x >= GRID_W || player_y < 0 || player_y >= GRID_H) {
        game_over = 1;
        set_status("Game over. Press R to restart.");
        return;
    }

    if (player_x == coin_x && player_y == coin_y) {
        score++;
        place_coin();
        char msg[96];
        snprintf(msg, sizeof(msg), "Score %d", score);
        set_status(msg);
    }
}

static void render(void) {
    draw_rect(0, 0, WIN_W, WIN_H, COLOR_BG);
    draw_rect(0, 0, WIN_W, 34, COLOR_HEADER);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     12, 11, "Game Room: Coin Dash", 0xFFFFFF, COLOR_HEADER);

    draw_rect(BOARD_X - 2, BOARD_Y - 2, GRID_W * CELL + 4, GRID_H * CELL + 4, COLOR_GRID);
    draw_rect(BOARD_X, BOARD_Y, GRID_W * CELL, GRID_H * CELL, COLOR_BOARD);

    for (int y = 0; y < GRID_H; y++) {
        for (int x = 0; x < GRID_W; x++) {
            int px = BOARD_X + x * CELL;
            int py = BOARD_Y + y * CELL;
            draw_rect(px, py, CELL - 1, CELL - 1, COLOR_BOARD);
        }
    }

    draw_rect(BOARD_X + coin_x * CELL + 4,
              BOARD_Y + coin_y * CELL + 4,
              CELL - 9, CELL - 9, COLOR_COIN);

    draw_rect(BOARD_X + player_x * CELL + 2,
              BOARD_Y + player_y * CELL + 2,
              CELL - 5, CELL - 5, COLOR_PLAYER);

    char score_line[64];
    snprintf(score_line, sizeof(score_line), "Score: %d", score);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     12, 42, score_line, COLOR_TEXT, COLOR_BG);

    font_draw_string(framebuffer, WIN_W, WIN_H,
                     146, 42, "R=restart Q=quit", COLOR_TEXT, COLOR_BG);

    if (game_over) {
        draw_rect(200, 180, 220, 34, 0x3A2430);
        font_draw_string(framebuffer, WIN_W, WIN_H,
                         236, 191, "GAME OVER", 0xFFD3D8, 0x3A2430);
    }

    draw_rect(0, WIN_H - 26, WIN_W, 26, COLOR_STATUS);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     10, WIN_H - 18, status_line, COLOR_TEXT, COLOR_STATUS);
}

int main(void) {
    int wid = win_create(120, 70, WIN_W, WIN_H, "Game Room");
    if (wid < 0) {
        printf("game: failed to create window\n");
        return 1;
    }

    reset_game();
    render();
    win_update(wid, framebuffer);

    int running = 1;
    while (running) {
        struct gui_event ev;
        if (win_event(&ev) > 0) {
            if (ev.type == GUI_EVENT_WIN_CLOSE) {
                running = 0;
            } else if (ev.type == GUI_EVENT_KEY_PRESS) {
                uint32_t kc = ev.keycode;

                if (kc == 27 || kc == 'q' || kc == 'Q') {
                    running = 0;
                } else if (kc == 'r' || kc == 'R') {
                    reset_game();
                } else if (kc == 'w' || kc == 'W' || kc == 0x82) {
                    if (!(dir_y == 1 && abs_i(dir_x) == 0)) {
                        dir_x = 0;
                        dir_y = -1;
                    }
                } else if (kc == 's' || kc == 'S' || kc == 0x83) {
                    if (!(dir_y == -1 && abs_i(dir_x) == 0)) {
                        dir_x = 0;
                        dir_y = 1;
                    }
                } else if (kc == 'a' || kc == 'A' || kc == 0x80) {
                    if (!(dir_x == 1 && abs_i(dir_y) == 0)) {
                        dir_x = -1;
                        dir_y = 0;
                    }
                } else if (kc == 'd' || kc == 'D' || kc == 0x81) {
                    if (!(dir_x == -1 && abs_i(dir_y) == 0)) {
                        dir_x = 1;
                        dir_y = 0;
                    }
                }
            }

            render();
            win_update(wid, framebuffer);
        }

        uint64_t now = (uint64_t)syscall0(SYS_TICKS);
        if (now - last_step_ms >= 120ULL) {
            last_step_ms = now;
            step_game();
            render();
            win_update(wid, framebuffer);
        }

        yield();
    }

    win_destroy(wid);
    return 0;
}
