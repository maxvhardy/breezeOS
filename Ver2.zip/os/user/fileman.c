#include "libc/font.h"
#include "libc/gui.h"
#include "libc/process.h"
#include "libc/stdio.h"
#include "libc/stdlib.h"
#include "libc/string.h"

#define WIN_W 700
#define WIN_H 430
#define MAX_ENTRIES 160

#define COLOR_BG      0xEEF3F8
#define COLOR_HEADER  0x355C7D
#define COLOR_TEXT    0x253443
#define COLOR_ROW_A   0xF7FAFD
#define COLOR_ROW_B   0xEDF3F8
#define COLOR_SEL     0xC9E3FF
#define COLOR_STATUS  0xDCE6F0

struct entry {
    char name[60];
    uint8_t type;
};

static uint32_t framebuffer[WIN_W * WIN_H];
static struct entry entries[MAX_ENTRIES];
static int entry_count = 0;
static int selected = -1;
static int scroll = 0;
static char cwd[MAX_PATH] = "/";
static char status_line[96] = "Ready";

static void draw_rect(int x, int y, int w, int h, uint32_t color) {
    for (int j = y; j < y + h && j < WIN_H; j++) {
        if (j < 0) continue;
        for (int i = x; i < x + w && i < WIN_W; i++) {
            if (i < 0) continue;
            framebuffer[j * WIN_W + i] = color;
        }
    }
}

static void set_status(const char *msg) {
    if (!msg) return;
    strncpy(status_line, msg, sizeof(status_line) - 1);
    status_line[sizeof(status_line) - 1] = '\0';
}

static int is_dir_type(uint8_t t) {
    return t == 2;
}

static int path_join(const char *base, const char *name, char *out, size_t out_sz) {
    if (!base || !name || !out || out_sz < 2) return -1;

    if (name[0] == '/') {
        strncpy(out, name, out_sz - 1);
        out[out_sz - 1] = '\0';
        return 0;
    }

    if (strcmp(base, "/") == 0) {
        snprintf(out, out_sz, "/%s", name);
    } else {
        snprintf(out, out_sz, "%s/%s", base, name);
    }
    return 0;
}

static void path_parent(const char *path, char *out, size_t out_sz) {
    if (!path || !out || out_sz == 0) return;

    if (strcmp(path, "/") == 0) {
        strncpy(out, "/", out_sz - 1);
        out[out_sz - 1] = '\0';
        return;
    }

    strncpy(out, path, out_sz - 1);
    out[out_sz - 1] = '\0';

    size_t len = strlen(out);
    while (len > 1 && out[len - 1] == '/') {
        out[--len] = '\0';
    }

    while (len > 1 && out[len - 1] != '/') {
        out[--len] = '\0';
    }

    if (len == 1) out[1] = '\0';
}

static void clamp_selection(void) {
    if (entry_count <= 0) {
        selected = -1;
        scroll = 0;
        return;
    }

    if (selected < 0) selected = 0;
    if (selected >= entry_count) selected = entry_count - 1;

    int rows = (WIN_H - 112) / (FONT_HEIGHT + 4);
    if (rows < 1) rows = 1;

    if (selected < scroll) scroll = selected;
    if (selected >= scroll + rows) scroll = selected - rows + 1;

    int max_scroll = entry_count - rows;
    if (max_scroll < 0) max_scroll = 0;
    if (scroll < 0) scroll = 0;
    if (scroll > max_scroll) scroll = max_scroll;
}

static void load_entries(void) {
    entry_count = 0;

    int fd = open(cwd, O_RDONLY);
    if (fd < 0) {
        set_status("Failed to open directory");
        selected = -1;
        return;
    }

    struct dirent ent;
    while (entry_count < MAX_ENTRIES && readdir(fd, &ent) == 0) {
        strncpy(entries[entry_count].name, ent.name, sizeof(entries[entry_count].name) - 1);
        entries[entry_count].name[sizeof(entries[entry_count].name) - 1] = '\0';
        entries[entry_count].type = ent.type;
        entry_count++;
    }

    close(fd);

    char msg[96];
    snprintf(msg, sizeof(msg), "%d entries", entry_count);
    set_status(msg);

    if (entry_count == 0) {
        selected = -1;
        scroll = 0;
    } else {
        if (selected < 0) selected = 0;
        clamp_selection();
    }
}

static void open_selected(void) {
    if (selected < 0 || selected >= entry_count) return;

    char full[MAX_PATH];
    if (path_join(cwd, entries[selected].name, full, sizeof(full)) < 0) {
        set_status("Invalid path");
        return;
    }

    if (is_dir_type(entries[selected].type)) {
        strncpy(cwd, full, sizeof(cwd) - 1);
        cwd[sizeof(cwd) - 1] = '\0';
        selected = 0;
        scroll = 0;
        load_entries();
        return;
    }

    int pid = spawn(full);
    if (pid < 0) {
        set_status("Run failed (tip: use textedit for documents)");
    } else {
        char msg[96];
        snprintf(msg, sizeof(msg), "Launched %s (PID %d)", entries[selected].name, pid);
        set_status(msg);
    }
}

static void launch_textedit(void) {
    int pid = spawn("/bin/textedit");
    if (pid < 0) {
        set_status("Failed to launch textedit");
    } else {
        set_status("Text editor opened (use Open to pick file)");
    }
}

static void render(void) {
    draw_rect(0, 0, WIN_W, WIN_H, COLOR_BG);
    draw_rect(0, 0, WIN_W, 34, COLOR_HEADER);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     12, 11, "File Manager", 0xFFFFFF, COLOR_HEADER);

    draw_rect(10, 42, WIN_W - 20, 20, 0xD6E2EE);
    char path_line[96];
    snprintf(path_line, sizeof(path_line), "Path: %s", cwd);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     14, 48, path_line, 0x2B4058, 0xD6E2EE);

    font_draw_string(framebuffer, WIN_W, WIN_H,
                     14, 70, "Enter=open  Backspace=parent  E=textedit  R=refresh", 0x3B5874, COLOR_BG);

    int row_y = 92;
    int row_h = FONT_HEIGHT + 4;
    int rows = (WIN_H - 112) / row_h;
    if (rows < 1) rows = 1;

    for (int i = 0; i < rows; i++) {
        int idx = scroll + i;
        if (idx >= entry_count) break;

        int y = row_y + i * row_h;
        uint32_t bg = (i & 1) ? COLOR_ROW_B : COLOR_ROW_A;
        if (idx == selected) bg = COLOR_SEL;
        draw_rect(10, y, WIN_W - 20, row_h, bg);

        char line[96];
        snprintf(line, sizeof(line), "%s %s", is_dir_type(entries[idx].type) ? "[D]" : "[F]", entries[idx].name);
        font_draw_string(framebuffer, WIN_W, WIN_H, 14, y + 2, line, COLOR_TEXT, bg);
    }

    draw_rect(0, WIN_H - 26, WIN_W, 26, COLOR_STATUS);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     10, WIN_H - 18, status_line, COLOR_TEXT, COLOR_STATUS);
}

int main(void) {
    int wid = win_create(112, 84, WIN_W, WIN_H, "Files");
    if (wid < 0) {
        printf("fileman: failed to create window\n");
        return 1;
    }

    load_entries();
    render();
    win_update(wid, framebuffer);

    int running = 1;
    while (running) {
        struct gui_event ev;
        if (win_event(&ev) > 0) {
            if (ev.type == GUI_EVENT_WIN_CLOSE) {
                running = 0;
            } else if (ev.type == GUI_EVENT_MOUSE_DOWN) {
                int row_h = FONT_HEIGHT + 4;
                int row = (ev.y - 92) / row_h;
                if (ev.y >= 92 && row >= 0) {
                    int idx = scroll + row;
                    if (idx >= 0 && idx < entry_count) {
                        if (selected == idx) {
                            open_selected();
                        } else {
                            selected = idx;
                            clamp_selection();
                        }
                    }
                }
            } else if (ev.type == GUI_EVENT_KEY_PRESS) {
                if (ev.keycode == 27 || ev.keycode == 'q' || ev.keycode == 'Q') {
                    running = 0;
                } else if (ev.keycode == 'j' || ev.keycode == 'J' || ev.keycode == 0x83) {
                    selected++;
                    clamp_selection();
                } else if (ev.keycode == 'k' || ev.keycode == 'K' || ev.keycode == 0x82) {
                    selected--;
                    clamp_selection();
                } else if (ev.keycode == '\r' || ev.keycode == '\n') {
                    open_selected();
                } else if (ev.keycode == '\b' || ev.keycode == 127) {
                    char parent[MAX_PATH];
                    path_parent(cwd, parent, sizeof(parent));
                    strncpy(cwd, parent, sizeof(cwd) - 1);
                    cwd[sizeof(cwd) - 1] = '\0';
                    selected = 0;
                    scroll = 0;
                    load_entries();
                } else if (ev.keycode == 'r' || ev.keycode == 'R') {
                    load_entries();
                } else if (ev.keycode == 'e' || ev.keycode == 'E') {
                    launch_textedit();
                }
            }

            render();
            win_update(wid, framebuffer);
        }

        yield();
    }

    win_destroy(wid);
    return 0;
}
