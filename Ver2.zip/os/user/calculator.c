#include "libc/font.h"
#include "libc/gui.h"
#include "libc/stdio.h"
#include "libc/stdlib.h"
#include "libc/string.h"

#define WIN_W 360
#define WIN_H 430

#define COLOR_BG        0xF3F5F8
#define COLOR_HEADER    0x3A5270
#define COLOR_DISPLAY   0xFFFFFF
#define COLOR_TEXT      0x11253A
#define COLOR_BTN       0xDCE4EE
#define COLOR_BTN_OP    0x9EC3E6
#define COLOR_BTN_EQ    0x4A9BD9
#define COLOR_BTN_CLR   0xD98585
#define COLOR_STATUS_BG 0xD6DFEA
#define COLOR_STATUS_TX 0x1F3044

struct calc_button {
    const char *label;
    uint32_t color;
};

static const struct calc_button buttons[5][4] = {
    {{"7", COLOR_BTN}, {"8", COLOR_BTN}, {"9", COLOR_BTN}, {"/", COLOR_BTN_OP}},
    {{"4", COLOR_BTN}, {"5", COLOR_BTN}, {"6", COLOR_BTN}, {"*", COLOR_BTN_OP}},
    {{"1", COLOR_BTN}, {"2", COLOR_BTN}, {"3", COLOR_BTN}, {"-", COLOR_BTN_OP}},
    {{"0", COLOR_BTN}, {"(", COLOR_BTN}, {")", COLOR_BTN}, {"+", COLOR_BTN_OP}},
    {{"C", COLOR_BTN_CLR}, {"<-", COLOR_BTN_CLR}, {"=", COLOR_BTN_EQ}, {"%", COLOR_BTN_OP}},
};

static uint32_t framebuffer[WIN_W * WIN_H];
static char expr[96];
static int expr_len = 0;
static int has_result = 0;
static int result_value = 0;
static char status_line[96] = "Ready";

static void draw_rect(int x, int y, int w, int h, uint32_t color) {
    for (int j = y; j < y + h && j < WIN_H; j++) {
        if (j < 0) continue;
        for (int i = x; i < x + w && i < WIN_W; i++) {
            if (i < 0) continue;
            framebuffer[j * WIN_W + i] = color;
        }
    }
}

static void set_status(const char *msg) {
    if (!msg) return;
    strncpy(status_line, msg, sizeof(status_line) - 1);
    status_line[sizeof(status_line) - 1] = '\0';
}

static int calc_is_space(char c) {
    return c == ' ' || c == '\t';
}

static void calc_skip_spaces(const char **p) {
    while (p && *p && calc_is_space(**p)) (*p)++;
}

static int calc_parse_expr(const char **p, int *out, char *err, size_t err_sz);

static int calc_parse_factor(const char **p, int *out, char *err, size_t err_sz) {
    calc_skip_spaces(p);
    if (!p || !*p || !out) return 0;

    int sign = 1;
    while (**p == '+' || **p == '-') {
        if (**p == '-') sign = -sign;
        (*p)++;
        calc_skip_spaces(p);
    }

    if (**p == '(') {
        (*p)++;
        int value = 0;
        if (!calc_parse_expr(p, &value, err, err_sz)) return 0;
        calc_skip_spaces(p);
        if (**p != ')') {
            snprintf(err, err_sz, "expected ')'");
            return 0;
        }
        (*p)++;
        *out = sign * value;
        return 1;
    }

    if (**p < '0' || **p > '9') {
        snprintf(err, err_sz, "expected number");
        return 0;
    }

    int value = 0;
    while (**p >= '0' && **p <= '9') {
        value = value * 10 + (**p - '0');
        (*p)++;
    }

    *out = sign * value;
    return 1;
}

static int calc_parse_term(const char **p, int *out, char *err, size_t err_sz) {
    int value = 0;
    if (!calc_parse_factor(p, &value, err, err_sz)) return 0;

    while (1) {
        calc_skip_spaces(p);
        char op = **p;
        if (op != '*' && op != '/' && op != '%') break;
        (*p)++;

        int rhs = 0;
        if (!calc_parse_factor(p, &rhs, err, err_sz)) return 0;

        if ((op == '/' || op == '%') && rhs == 0) {
            snprintf(err, err_sz, "division by zero");
            return 0;
        }

        if (op == '*') value *= rhs;
        else if (op == '/') value /= rhs;
        else value %= rhs;
    }

    *out = value;
    return 1;
}

static int calc_parse_expr(const char **p, int *out, char *err, size_t err_sz) {
    int value = 0;
    if (!calc_parse_term(p, &value, err, err_sz)) return 0;

    while (1) {
        calc_skip_spaces(p);
        char op = **p;
        if (op != '+' && op != '-') break;
        (*p)++;

        int rhs = 0;
        if (!calc_parse_term(p, &rhs, err, err_sz)) return 0;
        if (op == '+') value += rhs;
        else value -= rhs;
    }

    *out = value;
    return 1;
}

static int calc_eval(const char *input, int *out, char *err, size_t err_sz) {
    if (!input || !out || !err || err_sz == 0) return 0;
    err[0] = '\0';

    const char *p = input;
    if (!calc_parse_expr(&p, out, err, err_sz)) {
        if (err[0] == '\0') snprintf(err, err_sz, "invalid expression");
        return 0;
    }

    calc_skip_spaces(&p);
    if (*p != '\0') {
        snprintf(err, err_sz, "unexpected token '%c'", *p);
        return 0;
    }

    return 1;
}

static void clear_expr(void) {
    expr_len = 0;
    expr[0] = '\0';
    has_result = 0;
    result_value = 0;
    set_status("Cleared");
}

static void backspace(void) {
    if (expr_len <= 0) return;
    expr_len--;
    expr[expr_len] = '\0';
    has_result = 0;
    set_status("Backspace");
}

static void append_token(const char *tok) {
    if (!tok) return;
    while (*tok && expr_len < (int)sizeof(expr) - 1) {
        expr[expr_len++] = *tok++;
    }
    expr[expr_len] = '\0';
    has_result = 0;
    set_status("Editing expression");
}

static void evaluate(void) {
    if (expr_len <= 0) {
        set_status("Enter an expression");
        return;
    }

    int value = 0;
    char err[64];
    if (!calc_eval(expr, &value, err, sizeof(err))) {
        char msg[96];
        snprintf(msg, sizeof(msg), "Error: %s", err);
        set_status(msg);
        has_result = 0;
        return;
    }

    has_result = 1;
    result_value = value;
    char msg[96];
    snprintf(msg, sizeof(msg), "Result = %d", value);
    set_status(msg);
}

static void button_geometry(int row, int col, int *x, int *y, int *w, int *h) {
    int pad = 12;
    int spacing = 8;
    int grid_y = 132;
    int cols = 4;
    int rows = 5;

    int bw = (WIN_W - pad * 2 - spacing * (cols - 1)) / cols;
    int bh = (WIN_H - grid_y - 42 - spacing * (rows - 1)) / rows;
    if (bh < 24) bh = 24;

    *x = pad + col * (bw + spacing);
    *y = grid_y + row * (bh + spacing);
    *w = bw;
    *h = bh;
}

static void render(void) {
    draw_rect(0, 0, WIN_W, WIN_H, COLOR_BG);
    draw_rect(0, 0, WIN_W, 34, COLOR_HEADER);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     12, 11, "Calculator", 0xFFFFFF, COLOR_HEADER);

    draw_rect(12, 46, WIN_W - 24, 72, COLOR_DISPLAY);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     20, 58, expr_len > 0 ? expr : "0", COLOR_TEXT, COLOR_DISPLAY);

    if (has_result) {
        char line[64];
        snprintf(line, sizeof(line), "= %d", result_value);
        font_draw_string(framebuffer, WIN_W, WIN_H,
                         20, 82, line, COLOR_TEXT, COLOR_DISPLAY);
    } else {
        font_draw_string(framebuffer, WIN_W, WIN_H,
                         20, 82, "Type or click buttons", 0x4A5D73, COLOR_DISPLAY);
    }

    for (int row = 0; row < 5; row++) {
        for (int col = 0; col < 4; col++) {
            int x, y, w, h;
            button_geometry(row, col, &x, &y, &w, &h);
            draw_rect(x, y, w, h, buttons[row][col].color);

            int lw = font_string_width(buttons[row][col].label);
            int lx = x + (w - lw) / 2;
            int ly = y + (h - FONT_HEIGHT) / 2;
            font_draw_string(framebuffer, WIN_W, WIN_H,
                             lx, ly, buttons[row][col].label, 0x102338, buttons[row][col].color);
        }
    }

    draw_rect(0, WIN_H - 26, WIN_W, 26, COLOR_STATUS_BG);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     10, WIN_H - 18, status_line, COLOR_STATUS_TX, COLOR_STATUS_BG);
}

static void apply_label(const char *label) {
    if (!label) return;

    if (strcmp(label, "C") == 0) {
        clear_expr();
        return;
    }
    if (strcmp(label, "<-") == 0) {
        backspace();
        return;
    }
    if (strcmp(label, "=") == 0) {
        evaluate();
        return;
    }

    append_token(label);
}

static void handle_click(int x, int y) {
    for (int row = 0; row < 5; row++) {
        for (int col = 0; col < 4; col++) {
            int bx, by, bw, bh;
            button_geometry(row, col, &bx, &by, &bw, &bh);
            if (x >= bx && x < bx + bw && y >= by && y < by + bh) {
                apply_label(buttons[row][col].label);
                return;
            }
        }
    }
}

static void handle_key(uint32_t keycode) {
    char ch = (char)keycode;

    if (keycode == '\r' || keycode == '\n') {
        evaluate();
        return;
    }
    if (keycode == '\b' || keycode == 127) {
        backspace();
        return;
    }
    if (ch == 'c' || ch == 'C' || keycode == 27) {
        clear_expr();
        return;
    }

    if ((ch >= '0' && ch <= '9') ||
        ch == '+' || ch == '-' || ch == '*' || ch == '/' ||
        ch == '%' || ch == '(' || ch == ')') {
        char token[2] = {ch, '\0'};
        append_token(token);
    }
}

int main(void) {
    int wid = win_create(168, 96, WIN_W, WIN_H, "Calculator");
    if (wid < 0) {
        printf("calculator: failed to create window\n");
        return 1;
    }

    clear_expr();
    set_status("Ready");
    render();
    win_update(wid, framebuffer);

    int running = 1;
    while (running) {
        struct gui_event ev;
        int got = win_event(&ev);
        if (got > 0) {
            if (ev.type == GUI_EVENT_WIN_CLOSE) {
                running = 0;
            } else if (ev.type == GUI_EVENT_MOUSE_DOWN) {
                handle_click(ev.x, ev.y);
                render();
                win_update(wid, framebuffer);
            } else if (ev.type == GUI_EVENT_KEY_PRESS) {
                if (ev.keycode == 'q' || ev.keycode == 'Q') {
                    running = 0;
                } else {
                    handle_key(ev.keycode);
                    render();
                    win_update(wid, framebuffer);
                }
            }
        }

        yield();
    }

    win_destroy(wid);
    return 0;
}
