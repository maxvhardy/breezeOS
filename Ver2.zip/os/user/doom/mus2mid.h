#ifndef MUS2MID_H
#define MUS2MID_H

#include "doomtype.h"
#include "memio.h"

boolean mus2mid(MEMFILE *musinput, MEMFILE *midioutput);

#endif /* #ifndef MUS2MID_H */