#include "doom_driver_dooros.h"

#include "doomkeys.h"

#include "libc/stdlib.h"
#include "libc/string.h"

struct gui_event {
    uint32_t type;
    uint32_t window_id;
    int32_t x;
    int32_t y;
    uint32_t keycode;
    uint32_t buttons;
};

#define GUI_EVENT_KEY_PRESS   1
#define GUI_EVENT_KEY_RELEASE 2
#define GUI_EVENT_WIN_CLOSE   6

#define DOOR_KEY_LEFT  0x80
#define DOOR_KEY_RIGHT 0x81
#define DOOR_KEY_UP    0x82
#define DOOR_KEY_DOWN  0x83

#define DG_SYS_TICKS 28

static int g_window_id = -1;

static int win_create(int x, int y, int w, int h, const char *title) {
    return (int)syscall5(SYS_WIN_CREATE,
                         (uint64_t)x, (uint64_t)y,
                         (uint64_t)w, (uint64_t)h,
                         (uint64_t)title);
}

static void win_destroy(int wid) {
    syscall1(SYS_WIN_DESTROY, (uint64_t)wid);
}

static int win_update(int wid, uint32_t *pixels) {
    return (int)syscall2(SYS_WIN_UPDATE, (uint64_t)wid, (uint64_t)pixels);
}

static int win_event(struct gui_event *ev) {
    return (int)syscall1(SYS_WIN_EVENT, (uint64_t)ev);
}

static unsigned char map_key(uint32_t keycode) {
    switch (keycode) {
        case DOOR_KEY_LEFT:  return KEY_LEFTARROW;
        case DOOR_KEY_RIGHT: return KEY_RIGHTARROW;
        case DOOR_KEY_UP:    return KEY_UPARROW;
        case DOOR_KEY_DOWN:  return KEY_DOWNARROW;
        case 27:             return KEY_ESCAPE;
        case '\r':
        case '\n':           return KEY_ENTER;
        case '\t':           return KEY_TAB;
        case '\b':
        case 127:            return KEY_BACKSPACE;
        default: break;
    }

    unsigned char c = (unsigned char)keycode;
    if (c >= 'A' && c <= 'Z') c = (unsigned char)(c - 'A' + 'a');

    switch (c) {
        case 'w': return KEY_UPARROW;
        case 's': return KEY_DOWNARROW;
        case 'a': return KEY_LEFTARROW;
        case 'd': return KEY_RIGHTARROW;
        case 'q': return KEY_STRAFE_L;
        case 'e': return KEY_STRAFE_R;
        case ',': return KEY_STRAFE_L;
        case '.': return KEY_STRAFE_R;
        case ' ': return KEY_USE;
        case 'f': return KEY_FIRE;
        case ';': return KEY_FIRE;
        default:  return c;
    }
}

int dooros_dg_driver_init(int x, int y, int w, int h, const char *title) {
    if (g_window_id >= 0) {
        return 0;
    }

    g_window_id = win_create(x, y, w, h, title);
    return g_window_id >= 0 ? 0 : -1;
}

void dooros_dg_driver_shutdown(void) {
    if (g_window_id >= 0) {
        win_destroy(g_window_id);
        g_window_id = -1;
    }
}

void dooros_dg_driver_present(uint32_t *pixels) {
    if (g_window_id >= 0 && pixels) {
        win_update(g_window_id, pixels);
    }
}

uint32_t dooros_dg_driver_ticks_ms(void) {
    return (uint32_t)syscall0(DG_SYS_TICKS);
}

void dooros_dg_driver_sleep_ms(uint32_t ms) {
    sleep(ms);
}

int dooros_dg_driver_poll_event(struct dooros_dg_event *ev) {
    if (!ev || g_window_id < 0) return 0;

    struct gui_event raw;
    while (win_event(&raw) == 1) {
        if ((int)raw.window_id != g_window_id) {
            continue;
        }

        if (raw.type == GUI_EVENT_WIN_CLOSE) {
            ev->type = DOOROS_DG_EVENT_CLOSE;
            ev->pressed = 0;
            ev->key = 0;
            return 1;
        }

        if (raw.type == GUI_EVENT_KEY_PRESS || raw.type == GUI_EVENT_KEY_RELEASE) {
            unsigned char key = map_key(raw.keycode);
            if (!key) continue;

            ev->type = DOOROS_DG_EVENT_KEY;
            ev->pressed = (raw.type == GUI_EVENT_KEY_PRESS) ? 1 : 0;
            ev->key = key;
            return 1;
        }
    }

    return 0;
}
