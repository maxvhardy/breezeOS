#pragma once

#include "libc/syscall.h"

#define DOOROS_DG_EVENT_NONE  0
#define DOOROS_DG_EVENT_KEY   1
#define DOOROS_DG_EVENT_CLOSE 2

struct dooros_dg_event {
    int type;
    int pressed;
    unsigned char key;
};

int dooros_dg_driver_init(int x, int y, int w, int h, const char *title);
void dooros_dg_driver_shutdown(void);
void dooros_dg_driver_present(uint32_t *pixels);
uint32_t dooros_dg_driver_ticks_ms(void);
void dooros_dg_driver_sleep_ms(uint32_t ms);
int dooros_dg_driver_poll_event(struct dooros_dg_event *ev);
