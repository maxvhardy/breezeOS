#include "doomkeys.h"
#include "doomgeneric.h"
#include "doom_driver_dooros.h"

#include "libc/stdio.h"
#include "libc/stdlib.h"
#include "libc/string.h"
static int g_running = 1;

#define KEYQ_CAP 256
struct key_event {
    int pressed;
    unsigned char key;
};

static struct key_event keyq[KEYQ_CAP];
static int keyq_r = 0;
static int keyq_w = 0;

#define HOLD_CAP 64
#define HOLD_MS  180
struct held_key {
    int active;
    unsigned char key;
    uint32_t release_at;
};

static struct held_key held[HOLD_CAP];

static void keyq_push(int pressed, unsigned char key) {
    int next = (keyq_w + 1) % KEYQ_CAP;
    if (next == keyq_r) {
        keyq_r = (keyq_r + 1) % KEYQ_CAP;
    }

    keyq[keyq_w].pressed = pressed;
    keyq[keyq_w].key = key;
    keyq_w = next;
}

static int keyq_pop(int *pressed, unsigned char *key) {
    if (keyq_r == keyq_w) return 0;

    *pressed = keyq[keyq_r].pressed;
    *key = keyq[keyq_r].key;
    keyq_r = (keyq_r + 1) % KEYQ_CAP;
    return 1;
}

static int ticks_after_or_eq(uint32_t now, uint32_t then) {
    return (int32_t)(now - then) >= 0;
}

static struct held_key *held_find(unsigned char key) {
    for (int i = 0; i < HOLD_CAP; i++) {
        if (held[i].active && held[i].key == key) return &held[i];
    }
    return NULL;
}

static struct held_key *held_alloc(void) {
    for (int i = 0; i < HOLD_CAP; i++) {
        if (!held[i].active) return &held[i];
    }
    return NULL;
}

static void held_release_expired(uint32_t now) {
    for (int i = 0; i < HOLD_CAP; i++) {
        if (!held[i].active) continue;
        if (ticks_after_or_eq(now, held[i].release_at)) {
            keyq_push(0, held[i].key);
            held[i].active = 0;
        }
    }
}

static void held_note_press(unsigned char key, uint32_t now) {
    struct held_key *slot = held_find(key);
    if (!slot) {
        slot = held_alloc();
        if (!slot) {
            // Fallback: generate a short tap if hold table is saturated.
            keyq_push(1, key);
            keyq_push(0, key);
            return;
        }
        keyq_push(1, key);
        slot->active = 1;
        slot->key = key;
    }

    slot->release_at = now + HOLD_MS;
}

static void held_note_release(unsigned char key) {
    struct held_key *slot = held_find(key);
    if (!slot) return;

    keyq_push(0, key);
    slot->active = 0;
}

static void held_release_all(void) {
    for (int i = 0; i < HOLD_CAP; i++) {
        if (!held[i].active) continue;
        keyq_push(0, held[i].key);
        held[i].active = 0;
    }
}

static void pump_events(void) {
    struct dooros_dg_event ev;
    int guard = 0;
    uint32_t now = DG_GetTicksMs();
    held_release_expired(now);

    while (guard++ < 256 && dooros_dg_driver_poll_event(&ev)) {
        if (ev.type == DOOROS_DG_EVENT_CLOSE) {
            g_running = 0;
            held_release_all();
            keyq_push(1, KEY_ESCAPE);
            keyq_push(0, KEY_ESCAPE);
            continue;
        }

        if (ev.type == DOOROS_DG_EVENT_KEY) {
            if (ev.pressed) {
                held_note_press(ev.key, now);
            } else {
                held_note_release(ev.key);
            }
        }
    }

    now = DG_GetTicksMs();
    held_release_expired(now);
}

static int has_iwad_magic(const char *path) {
    if (!path || !path[0]) return 0;

    struct stat st;
    if (stat(path, &st) != 0 || st.size < 1024) return 0;

    int fd = open(path, O_RDONLY);
    if (fd < 0) return 0;

    unsigned char magic[4];
    ssize_t n = read(fd, magic, sizeof(magic));
    close(fd);
    if (n != (ssize_t)sizeof(magic)) return 0;

    if (magic[0] == 'I' && magic[1] == 'W' && magic[2] == 'A' && magic[3] == 'D') return 1;
    if (magic[0] == 'P' && magic[1] == 'W' && magic[2] == 'A' && magic[3] == 'D') return 1;
    return 0;
}

static int has_wad_extension(const char *name) {
    if (!name) return 0;
    size_t n = strlen(name);
    if (n < 4) return 0;
    return strcasecmp(name + n - 4, ".wad") == 0;
}

static const char *scan_bin_for_iwad(void) {
    static char found[MAX_PATH];
    int fd = open("/bin", O_RDONLY);
    if (fd < 0) return NULL;

    struct dirent ent;
    while (readdir(fd, &ent) == 0) {
        if (ent.type != 1) continue;
        if (!has_wad_extension(ent.name)) continue;
        if (snprintf(found, sizeof(found), "/bin/%s", ent.name) >= (int)sizeof(found)) {
            continue;
        }
        if (has_iwad_magic(found)) {
            close(fd);
            return found;
        }
    }

    close(fd);
    return NULL;
}

static const char *find_iwad(void) {
    static const char *candidates[] = {
        "/bin/doom1.wad",
        "/bin/DOOM1.WAD",
        "/bin/freedoom1.wad",
        "/bin/FREEDOOM1.WAD",
        "/bin/freedoom2.wad",
        "/bin/FREEDOOM2.WAD",
        "/bin/freedm.wad",
        "/bin/FREEDM.WAD",
        "/bin/doom.wad",
        "/bin/DOOM.WAD",
        "/bin/doom2.wad",
        "/bin/DOOM2.WAD",
        "/bin/doom1",
        "/bin/DOOM1",
        "/bin/doom2",
        "/bin/DOOM2",
        "/bin/doom",
        "/bin/DOOM",
        "/bin/freedoom1",
        "/bin/FREEDOOM1",
        "/bin/freedoom2",
        "/bin/FREEDOOM2",
        "/bin/freedm",
        "/bin/FREEDM",
        "/doom1.wad",
        "/freedoom1.wad",
        "/freedoom2.wad",
        "/freedm.wad",
        "/doom.wad",
        "/doom2.wad",
        "DOOM1.WAD",
        "DOOM2.WAD",
        "DOOM.WAD",
        "freedoom1.wad",
        "FREEDOOM1.WAD",
        "freedoom2.wad",
        "FREEDOOM2.WAD",
        "freedm.wad",
        "FREEDM.WAD",
        "doom1.wad",
        "doom.wad",
        "doom2.wad",
    };

    for (size_t i = 0; i < sizeof(candidates) / sizeof(candidates[0]); i++) {
        if (has_iwad_magic(candidates[i])) {
            return candidates[i];
        }
    }

    return scan_bin_for_iwad();
}

static void print_missing_iwad_help(void) {
    printf("doom: missing IWAD (looked in /bin and cwd)\n");
    printf("doom: add one of: /bin/doom.wad  /bin/doom1.wad  /bin/freedoom1.wad\n");
    printf("doom: tip: place assets/doom.wad (or assets/DOOM1.WAD) before make\n");
}

static void print_controls_hint(void) {
    printf("doom controls: arrows/WASD move, Q/E strafe, F or ; fire, Space use, Esc menu\n");
}

static void shutdown_window(void) {
    dooros_dg_driver_shutdown();
}

static void run_doom_with_iwad(const char *iwad) {
    char *argv[] = {
        "doom",
        "-iwad", (char *)iwad,
        "-nosound",
        "-nomusic",
        NULL
    };
    doomgeneric_Create(5, argv);
}

static void tick_loop(void) {
    while (g_running) {
        doomgeneric_Tick();
        DG_SleepMs(1);
    }
}

void DG_Init(void) {
    if (dooros_dg_driver_init(48, 30, DOOMGENERIC_RESX, DOOMGENERIC_RESY, "DOOM - DoorOS") < 0) {
        printf("doom: failed to create window\n");
        exit(1);
    }

    keyq_r = 0;
    keyq_w = 0;
    memset(held, 0, sizeof(held));
    g_running = 1;
}

void DG_DrawFrame(void) {
    dooros_dg_driver_present((uint32_t *)DG_ScreenBuffer);
    pump_events();
}

void DG_SleepMs(uint32_t ms) {
    dooros_dg_driver_sleep_ms(ms);
}

uint32_t DG_GetTicksMs(void) {
    return dooros_dg_driver_ticks_ms();
}

int DG_GetKey(int *pressed, unsigned char *doomKey) {
    if (!pressed || !doomKey) return 0;

    if (!keyq_pop(pressed, doomKey)) {
        pump_events();
        if (!keyq_pop(pressed, doomKey)) {
            return 0;
        }
    }

    return 1;
}

void DG_SetWindowTitle(const char *title) {
    (void)title;
}

int main(void) {
    const char *iwad = find_iwad();
    if (!iwad) {
        print_missing_iwad_help();
        return 1;
    }

    print_controls_hint();
    printf("doom: using IWAD %s\n", iwad);
    run_doom_with_iwad(iwad);
    tick_loop();
    shutdown_window();
    return 0;
}
