#pragma once

#include "syscall.h"

#define PROC_FLAG_USER   0x1u
#define PROC_FLAG_KERNEL 0x2u

struct proc_info {
    int32_t  pid;
    int32_t  ppid;
    uint32_t state;
    uint32_t flags;
    int32_t  exit_code;
    uint32_t _reserved;
    uint64_t start_ticks;
    uint64_t cpu_ticks;
    char     name[64];
    char     cwd[256];
};

int getppid(void);
int spawn(const char *path);
ssize_t proc_list(struct proc_info *buf, size_t cap, size_t *total);
