#include "stdlib.h"
#include "string.h"

#define ALLOC_MAGIC 0xBEEFBEEF

struct alloc_header {
    uint32_t magic;
    uint32_t _pad;
    size_t size;
};

static void *heap_ptr = NULL;
static void *heap_end = NULL;
char **environ = NULL;

static int startup_argc = 0;
static char **startup_argv = NULL;

#define ATEXIT_MAX 64
static void (*atexit_handlers[ATEXIT_MAX])(void);
static int atexit_count = 0;

static size_t align_up_16(size_t size) {
    return (size + 15ULL) & ~15ULL;
}

void __libc_init(int argc, char **argv, char **envp) {
    startup_argc = argc;
    startup_argv = argv;
    environ = envp;
}

void exit(int code) {
    for (int i = atexit_count - 1; i >= 0; i--) {
        if (atexit_handlers[i]) {
            atexit_handlers[i]();
        }
    }

    syscall1(SYS_EXIT, (uint64_t)code);
    while (1) {
    }
}

int fork(void) {
    return (int)syscall0(SYS_FORK);
}

int exec(const char *path) {
    if (!path) return -1;
    char *const argv_local[] = {(char *)path, NULL};
    return execve(path, argv_local, environ);
}

int execve(const char *path, char *const argv[], char *const envp[]) {
    return (int)syscall3(SYS_EXECVE, (uint64_t)path, (uint64_t)argv, (uint64_t)envp);
}

int waitpid(int pid, int *status) {
    return (int)syscall2(SYS_WAITPID, (uint64_t)pid, (uint64_t)status);
}

int getpid(void) {
    return (int)syscall0(SYS_GETPID);
}

int kill(int pid) {
    return (int)syscall1(SYS_KILL, (uint64_t)pid);
}

void *sbrk(int64_t incr) {
    int64_t result = syscall1(SYS_SBRK, (uint64_t)incr);
    if (result < 0) return NULL;
    return (void *)(uint64_t)result;
}

void yield(void) {
    syscall0(SYS_YIELD);
}

void sleep(uint64_t ms) {
    syscall1(SYS_SLEEP, ms);
}

void reboot(void) {
    syscall0(SYS_REBOOT);
    while (1) {
        yield();
    }
}

void *malloc(size_t size) {
    if (size == 0) size = 1;

    size_t payload = align_up_16(size);
    size_t total = payload + sizeof(struct alloc_header);

    if (!heap_ptr) {
        heap_ptr = sbrk(0);
        heap_end = heap_ptr;
    }

    if ((uint8_t *)heap_ptr + total > (uint8_t *)heap_end) {
        size_t grow = total;
        if (grow < 4096) grow = 4096;
        void *old_end = sbrk((int64_t)grow);
        if (!old_end) return NULL;
        heap_end = (uint8_t *)heap_end + grow;
    }

    struct alloc_header *hdr = (struct alloc_header *)heap_ptr;
    hdr->magic = ALLOC_MAGIC;
    hdr->_pad = 0;
    hdr->size = payload;

    heap_ptr = (uint8_t *)heap_ptr + total;
    return (void *)(hdr + 1);
}

void free(void *ptr) {
    (void)ptr;
}

void *calloc(size_t nmemb, size_t size) {
    if (nmemb == 0 || size == 0) return malloc(1);
    size_t total = nmemb * size;
    void *p = malloc(total);
    if (!p) return NULL;
    memset(p, 0, total);
    return p;
}

void *realloc(void *ptr, size_t size) {
    if (!ptr) return malloc(size);
    if (size == 0) {
        free(ptr);
        return NULL;
    }

    struct alloc_header *hdr = ((struct alloc_header *)ptr) - 1;
    size_t old_size = 0;
    if (hdr->magic == ALLOC_MAGIC) {
        old_size = hdr->size;
    }

    void *n = malloc(size);
    if (!n) return NULL;

    size_t copy = old_size;
    if (copy > size) copy = size;
    if (copy > 0) {
        memcpy(n, ptr, copy);
    }

    free(ptr);
    return n;
}

int abs(int v) {
    return v < 0 ? -v : v;
}

long labs(long v) {
    return v < 0 ? -v : v;
}

static int is_space(char c) {
    return c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f' || c == '\v';
}

double atof(const char *s) {
    if (!s) return 0.0;

    while (is_space(*s)) s++;

    int sign = 1;
    if (*s == '-') {
        sign = -1;
        s++;
    } else if (*s == '+') {
        s++;
    }

    double value = 0.0;
    while (*s >= '0' && *s <= '9') {
        value = value * 10.0 + (double)(*s - '0');
        s++;
    }

    if (*s == '.') {
        s++;
        double scale = 1.0;
        while (*s >= '0' && *s <= '9') {
            scale *= 10.0;
            value += (double)(*s - '0') / scale;
            s++;
        }
    }

    return sign < 0 ? -value : value;
}

char *getenv(const char *name) {
    if (!name || !*name || !environ) return NULL;

    size_t nlen = strlen(name);
    for (char **p = environ; *p; p++) {
        char *entry = *p;
        if (!entry) continue;
        if (strncmp(entry, name, nlen) == 0 && entry[nlen] == '=') {
            return entry + nlen + 1;
        }
    }

    return NULL;
}

int putenv(char *string) {
    if (!string || !environ) return -1;

    char *eq = strchr(string, '=');
    if (!eq || eq == string) return -1;
    size_t nlen = (size_t)(eq - string);

    char **slot = NULL;
    for (char **p = environ; *p; p++) {
        char *entry = *p;
        if (!entry) continue;
        if (strncmp(entry, string, nlen) == 0 && entry[nlen] == '=') {
            slot = p;
            break;
        }
    }

    if (slot) {
        *slot = string;
        return 0;
    }

    // Keep this implementation simple: replacement supported, append is not.
    return -1;
}

int system(const char *command) {
    (void)command;
    return -1;
}

void abort(void) {
    exit(1);
}

int atexit(void (*func)(void)) {
    if (atexit_count >= ATEXIT_MAX) return -1;
    atexit_handlers[atexit_count++] = func;
    return 0;
}
