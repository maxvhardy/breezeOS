#pragma once

#include "syscall.h"

#define GUI_EVENT_NONE        0
#define GUI_EVENT_KEY_PRESS   1
#define GUI_EVENT_KEY_RELEASE 2
#define GUI_EVENT_MOUSE_MOVE  3
#define GUI_EVENT_MOUSE_DOWN  4
#define GUI_EVENT_MOUSE_UP    5
#define GUI_EVENT_WIN_CLOSE   6
#define GUI_EVENT_WIN_FOCUS   7
#define GUI_EVENT_REPAINT     8

struct gui_event {
    uint32_t type;
    uint32_t window_id;
    int32_t  x;
    int32_t  y;
    uint32_t keycode;
    uint32_t buttons;
};

int win_create(int x, int y, int w, int h, const char *title);
int win_destroy(int wid);
int win_update(int wid, uint32_t *pixels);
int win_event(struct gui_event *ev);
