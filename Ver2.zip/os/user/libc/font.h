#pragma once

#include "syscall.h"

#define FONT_WIDTH  8
#define FONT_HEIGHT 16

const uint8_t *font_get_glyph(char c);
void font_draw_char(uint32_t *buf, int buf_w, int buf_h, int x, int y, char c,
                    uint32_t fg, uint32_t bg);
void font_draw_string(uint32_t *buf, int buf_w, int buf_h, int x, int y,
                      const char *s, uint32_t fg, uint32_t bg);
int font_string_width(const char *s);
