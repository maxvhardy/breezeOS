#pragma once

#include "syscall.h"

#ifndef NULL
#define NULL ((void *)0)
#endif
