#pragma once

#include "stdlib.h"

#define assert(expr) do { if (!(expr)) abort(); } while (0)
