#include "gui.h"

int win_create(int x, int y, int w, int h, const char *title) {
    return (int)syscall5(SYS_WIN_CREATE,
                         (uint64_t)x,
                         (uint64_t)y,
                         (uint64_t)w,
                         (uint64_t)h,
                         (uint64_t)title);
}

int win_destroy(int wid) {
    return (int)syscall1(SYS_WIN_DESTROY, (uint64_t)wid);
}

int win_update(int wid, uint32_t *pixels) {
    return (int)syscall2(SYS_WIN_UPDATE, (uint64_t)wid, (uint64_t)pixels);
}

int win_event(struct gui_event *ev) {
    return (int)syscall1(SYS_WIN_EVENT, (uint64_t)ev);
}
