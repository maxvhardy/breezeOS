#pragma once

#include "syscall.h"

typedef int64_t intptr_t;
typedef uint64_t uintptr_t;
