#include "process.h"

int getppid(void) {
    return (int)syscall0(SYS_GETPPID);
}

int spawn(const char *path) {
    return (int)syscall1(SYS_SPAWN, (uint64_t)path);
}

ssize_t proc_list(struct proc_info *buf, size_t cap, size_t *total) {
    return (ssize_t)syscall3(SYS_PROCLIST, (uint64_t)buf, (uint64_t)cap, (uint64_t)total);
}
