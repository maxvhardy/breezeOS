#include "libc/font.h"
#include "libc/gui.h"
#include "libc/process.h"
#include "libc/stdio.h"
#include "libc/stdlib.h"
#include "libc/string.h"

#define WIN_W 640
#define WIN_H 420

#define COLOR_BG      0xEEF3FB
#define COLOR_HEADER  0x345679
#define COLOR_CARD    0xF5F8FC
#define COLOR_TEXT    0x1C344D
#define COLOR_BTN     0x4D78AA
#define COLOR_BTN_ALT 0x2E8B61
#define COLOR_STATUS  0xC9D6E8

struct button {
    int x;
    int y;
    int w;
    int h;
    const char *label;
    const char *path;
    uint32_t color;
};

static struct button buttons[] = {
    {22, 146, 116, 34, "Action", "/bin/action", COLOR_BTN},
    {154, 146, 116, 34, "Calculator", "/bin/calculator", COLOR_BTN},
    {286, 146, 116, 34, "Python", "/bin/python", COLOR_BTN_ALT},
    {418, 146, 116, 34, "Game", "/bin/game", COLOR_BTN_ALT},
    {22, 190, 116, 34, "Editor", "/bin/textedit", COLOR_BTN},
    {154, 190, 116, 34, "Files", "/bin/fileman", COLOR_BTN},
    {286, 190, 116, 34, "Terminal", "/bin/terminal", COLOR_BTN},
};

static uint32_t framebuffer[WIN_W * WIN_H];
static char status_line[96] = "Ready";
static uint64_t last_refresh_ms = 0;
static size_t proc_total = 0;

static void draw_rect(int x, int y, int w, int h, uint32_t color) {
    for (int j = y; j < y + h && j < WIN_H; j++) {
        if (j < 0) continue;
        for (int i = x; i < x + w && i < WIN_W; i++) {
            if (i < 0) continue;
            framebuffer[j * WIN_W + i] = color;
        }
    }
}

static void set_status(const char *msg) {
    if (!msg) return;
    strncpy(status_line, msg, sizeof(status_line) - 1);
    status_line[sizeof(status_line) - 1] = '\0';
}

static void refresh_stats(void) {
    struct proc_info infos[64];
    proc_total = 0;
    if (proc_list(infos, 64, &proc_total) < 0) {
        proc_total = 0;
    }
    last_refresh_ms = (uint64_t)syscall0(SYS_TICKS);
}

static void launch_button(const struct button *b) {
    if (!b || !b->path) return;

    int pid = spawn(b->path);
    if (pid < 0) {
        set_status("Launch failed");
    } else {
        char msg[96];
        snprintf(msg, sizeof(msg), "Launched %s (PID %d)", b->label, pid);
        set_status(msg);
    }
}

static void render(void) {
    draw_rect(0, 0, WIN_W, WIN_H, COLOR_BG);
    draw_rect(0, 0, WIN_W, 36, COLOR_HEADER);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     12, 12, "Macrohard FreedomBlock", 0xFFFFFF, COLOR_HEADER);

    draw_rect(16, 52, WIN_W - 32, 80, COLOR_CARD);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     24, 62, "System Overview", COLOR_TEXT, COLOR_CARD);

    char line1[96];
    snprintf(line1, sizeof(line1), "Running processes: %u", (unsigned)proc_total);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     24, 84, line1, COLOR_TEXT, COLOR_CARD);

    font_draw_string(framebuffer, WIN_W, WIN_H,
                     24, 104, "Each desktop app runs as a separate user process.", COLOR_TEXT, COLOR_CARD);

    font_draw_string(framebuffer, WIN_W, WIN_H,
                     18, 126, "Quick Launch", COLOR_TEXT, COLOR_BG);

    int count = (int)(sizeof(buttons) / sizeof(buttons[0]));
    for (int i = 0; i < count; i++) {
        draw_rect(buttons[i].x, buttons[i].y, buttons[i].w, buttons[i].h, buttons[i].color);
        int lw = font_string_width(buttons[i].label);
        int lx = buttons[i].x + (buttons[i].w - lw) / 2;
        int ly = buttons[i].y + (buttons[i].h - FONT_HEIGHT) / 2;
        font_draw_string(framebuffer, WIN_W, WIN_H,
                         lx, ly, buttons[i].label, 0xFFFFFF, buttons[i].color);
    }

    draw_rect(0, WIN_H - 26, WIN_W, 26, COLOR_STATUS);
    font_draw_string(framebuffer, WIN_W, WIN_H,
                     10, WIN_H - 18, status_line, COLOR_TEXT, COLOR_STATUS);
}

int main(void) {
    int wid = win_create(134, 86, WIN_W, WIN_H, "Settings");
    if (wid < 0) {
        printf("settings: failed to create window\n");
        return 1;
    }

    refresh_stats();
    render();
    win_update(wid, framebuffer);

    int running = 1;
    while (running) {
        struct gui_event ev;
        if (win_event(&ev) > 0) {
            if (ev.type == GUI_EVENT_WIN_CLOSE) {
                running = 0;
            } else if (ev.type == GUI_EVENT_MOUSE_DOWN) {
                int count = (int)(sizeof(buttons) / sizeof(buttons[0]));
                for (int i = 0; i < count; i++) {
                    const struct button *b = &buttons[i];
                    if (ev.x >= b->x && ev.x < b->x + b->w &&
                        ev.y >= b->y && ev.y < b->y + b->h) {
                        launch_button(b);
                        break;
                    }
                }
            } else if (ev.type == GUI_EVENT_KEY_PRESS) {
                if (ev.keycode == 27 || ev.keycode == 'q' || ev.keycode == 'Q') {
                    running = 0;
                } else if (ev.keycode == 'r' || ev.keycode == 'R') {
                    refresh_stats();
                    set_status("Refreshed");
                }
            }

            render();
            win_update(wid, framebuffer);
        }

        uint64_t now = (uint64_t)syscall0(SYS_TICKS);
        if (now - last_refresh_ms > 1000ULL) {
            refresh_stats();
            render();
            win_update(wid, framebuffer);
        }

        yield();
    }

    win_destroy(wid);
    return 0;
}
