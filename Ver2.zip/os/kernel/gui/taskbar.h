#pragma once
#include "include/types.h"

// --- macOS-style Dock ---
#define DOCK_ICON_SIZE     44
#define DOCK_ICON_SPACING  8
#define DOCK_BAR_PADDING   10
#define DOCK_MARGIN_BOTTOM 8
#define DOCK_BAR_HEIGHT    (DOCK_ICON_SIZE + DOCK_BAR_PADDING * 2)
#define DOCK_INDICATOR_SIZE 4
#define DOCK_INDICATOR_GAP  4

// --- Top Menu Bar ---
#define MENUBAR_HEIGHT 24

// Legacy: dock floats over the desktop, no reserved strip needed.
#define TASKBAR_HEIGHT 0

void taskbar_init(void);
void taskbar_render(uint32_t *buf, int screen_w, int screen_h);
bool taskbar_handle_click(int x, int y, int screen_w, int screen_h);
bool taskbar_handle_key(uint32_t keycode);
bool taskbar_is_menu_open(void);
void taskbar_set_style(int style);
int taskbar_get_style(void);
