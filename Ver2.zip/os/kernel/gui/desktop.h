#pragma once
#include "include/types.h"

void desktop_init(void);
void desktop_render(uint32_t *buf, int width, int height);
void desktop_handle_mouse(int x, int y, int buttons);
void desktop_handle_key(uint32_t keycode);

void desktop_set_theme(int theme_id);
int desktop_get_theme(void);
int desktop_get_theme_count(void);
