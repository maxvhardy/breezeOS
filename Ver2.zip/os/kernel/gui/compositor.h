#pragma once
#include "include/types.h"

void compositor_init(void);
void compositor_render(void);
void compositor_set_wallpaper(uint32_t color);
void compositor_set_corner_radius(int radius);
int compositor_get_corner_radius(void);
void compositor_set_chrome_style(int style);
int compositor_get_chrome_style(void);
