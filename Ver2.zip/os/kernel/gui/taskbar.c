#include "gui/taskbar.h"
#include "gui/window.h"
#include "gui/font.h"
#include "gui/apps.h"
#include "drivers/pit.h"
#include "lib/string.h"
#include "lib/printf.h"

struct taskbar_palette {
    uint32_t menubar_bg;
    uint32_t menubar_border;
    uint32_t menubar_text;
    uint32_t menubar_text_dim;
    uint32_t dock_bg;
    uint32_t dock_border;
    uint32_t dock_label;
    uint32_t dock_separator;
    uint32_t launchpad_overlay;
    uint32_t launchpad_title;
    uint32_t launchpad_label;
};

static const struct taskbar_palette taskbar_palettes[] = {
    {0x141C2A, 0x0B1018, 0xE2ECF8, 0xA6B7CA, 0x1C2737, 0x3E5373, 0xC8D6E8, 0x5F7496, 0x091525, 0xEAF3FF, 0xE0ECFA},
    {0x1E3558, 0x101C31, 0xF3F8FF, 0xBED0E6, 0x27416A, 0x668AB8, 0xDCE8F6, 0x8EA9CB, 0x102038, 0xF3F8FF, 0xEDF4FE},
};

#define LP_ICON_SIZE        72
#define LP_ICON_SPACING     40
#define LP_LABEL_GAP        6
#define LP_COLS             3
#define LP_ROWS             4

// =====================================================================
//  Dock app definitions
// =====================================================================

enum dock_action {
    DOCK_LAUNCHPAD = 0,
    DOCK_TERMINAL,
    DOCK_FILES,
    DOCK_EDITOR,
    DOCK_SETTINGS,
    DOCK_ACTION,
    DOCK_CALCULATOR,
    DOCK_PYTHON,
    DOCK_GAME,
    DOCK_APP_COUNT
};

struct dock_app_def {
    const char *label;
    char icon_char;
    uint32_t color;
    int app_type;           // APP_TYPE_* or -1 for special
};

static const struct dock_app_def dock_apps[DOCK_APP_COUNT] = {
    {"Apps",     0,   0x6E6E82, -1},                  // Launchpad (special icon)
    {"Terminal", '>', 0x2D3436, APP_TYPE_TERMINAL},
    {"Files",    'F', 0x4A9BD9, APP_TYPE_FILE_MANAGER},
    {"Editor",   'E', 0xD4A843, APP_TYPE_TEXT_EDITOR},
    {"Settings", 'S', 0x5A7EBD, APP_TYPE_SETTINGS},
    {"Action",   'A', 0xCC3333, APP_TYPE_ACTION_EMPLOYEE},
    {"Calc",     'C', 0x2E8B61, APP_TYPE_CALCULATOR},
    {"Python",   'P', 0xF39C12, APP_TYPE_PYTHON},
    {"Games",    'G', 0x7DCEA0, APP_TYPE_GAME},
};

// =====================================================================
//  Launchpad item definitions
// =====================================================================

enum lp_action {
    LP_TERMINAL = 0,
    LP_FILE_MANAGER,
    LP_TEXT_EDITOR,
    LP_SETTINGS,
    LP_ACTION_EMPLOYEE,
    LP_CALCULATOR,
    LP_PYTHON,
    LP_GAME,
    LP_ABOUT,
    LP_CLOSE_FOCUSED,
    LP_ITEM_COUNT
};

static const struct {
    const char *label;
    char icon_char;
    uint32_t color;
} lp_items[LP_ITEM_COUNT] = {
    {"Terminal",    '>', 0x2D3436},
    {"Files",       'F', 0x4A9BD9},
    {"Editor",      'E', 0xD4A843},
    {"FreedomBlock",'S', 0x5A7EBD},
    {"Action",      'A', 0xCC3333},
    {"Calculator",  'C', 0x2E8B61},
    {"Python",      'P', 0xF39C12},
    {"Game Room",   'G', 0x7DCEA0},
    {"About",       'i', 0x5A7EBD},
    {"Close App",   'X', 0x8E5050},
};

// =====================================================================
//  State
// =====================================================================

static bool launchpad_open = false;
static int taskbar_style = 0;

// =====================================================================
//  Helpers
// =====================================================================

static void draw_rect(uint32_t *buf, int bw, int bh,
                      int x, int y, int w, int h, uint32_t color) {
    for (int j = y; j < y + h && j < bh; j++) {
        if (j < 0) continue;
        for (int i = x; i < x + w && i < bw; i++) {
            if (i < 0) continue;
            buf[j * bw + i] = color;
        }
    }
}

static const struct taskbar_palette *active_palette(void) {
    int count = (int)(sizeof(taskbar_palettes) / sizeof(taskbar_palettes[0]));
    if (taskbar_style < 0 || taskbar_style >= count) {
        taskbar_style = 0;
    }
    return &taskbar_palettes[taskbar_style];
}

static int point_in_round_rect_local(int lx, int ly, int w, int h, int radius) {
    if (lx < 0 || ly < 0 || lx >= w || ly >= h) return 0;
    if (radius <= 0) return 1;

    int r = radius;
    int max_r = w < h ? w / 2 : h / 2;
    if (r > max_r) r = max_r;
    if (r <= 0) return 1;

    if (lx >= r && lx < w - r) return 1;
    if (ly >= r && ly < h - r) return 1;

    int cx = (lx < r) ? (r - 1) : (w - r);
    int cy = (ly < r) ? (r - 1) : (h - r);
    int dx = lx - cx;
    int dy = ly - cy;
    return (dx * dx + dy * dy) <= (r * r);
}

static void draw_round_rect(uint32_t *buf, int bw, int bh,
                            int x, int y, int w, int h, int radius, uint32_t color) {
    for (int j = 0; j < h; j++) {
        int py = y + j;
        if (py < 0 || py >= bh) continue;
        for (int i = 0; i < w; i++) {
            int px = x + i;
            if (px < 0 || px >= bw) continue;
            if (!point_in_round_rect_local(i, j, w, h, radius)) continue;
            buf[py * bw + px] = color;
        }
    }
}

static int point_in_rect(int px, int py, int x, int y, int w, int h) {
    return px >= x && px < x + w && py >= y && py < y + h;
}

static uint32_t darken_color(uint32_t c, int amount) {
    int r = (c >> 16) & 0xFF;
    int g = (c >> 8) & 0xFF;
    int b = c & 0xFF;
    r = (r > amount) ? r - amount : 0;
    g = (g > amount) ? g - amount : 0;
    b = (b > amount) ? b - amount : 0;
    return ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
}

static uint32_t lighten_color(uint32_t c, int amount) {
    int r = (c >> 16) & 0xFF;
    int g = (c >> 8) & 0xFF;
    int b = c & 0xFF;
    r = (r + amount < 255) ? r + amount : 255;
    g = (g + amount < 255) ? g + amount : 255;
    b = (b + amount < 255) ? b + amount : 255;
    return ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
}

static uint32_t alpha_blend(uint32_t bg, uint32_t fg, int alpha) {
    int br = (bg >> 16) & 0xFF, bg_g = (bg >> 8) & 0xFF, bb = bg & 0xFF;
    int fr = (fg >> 16) & 0xFF, fg_g = (fg >> 8) & 0xFF, fb = fg & 0xFF;
    int r = (fr * alpha + br * (255 - alpha)) / 255;
    int g = (fg_g * alpha + bg_g * (255 - alpha)) / 255;
    int b = (fb * alpha + bb * (255 - alpha)) / 255;
    return ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
}

// =====================================================================
//  Dock geometry helpers
// =====================================================================

// Count non-app-managed visible windows (for the "other" section)
static int count_other_windows(void) {
    struct window *sorted[MAX_WINDOWS];
    int count;
    window_get_sorted(sorted, &count);
    int others = 0;
    for (int i = 0; i < count; i++) {
        if (!gui_apps_is_managed(sorted[i]->id)) {
            others++;
            if (others >= 4) break;
        }
    }
    return others;
}

static void dock_geometry(int screen_w, int screen_h,
                          int *dx, int *dy, int *dw, int *dh) {
    int n_other = count_other_windows();
    int fixed_w = DOCK_APP_COUNT * DOCK_ICON_SIZE +
                  (DOCK_APP_COUNT - 1) * DOCK_ICON_SPACING;
    int sep_w = (n_other > 0) ? (DOCK_ICON_SPACING + 2 + DOCK_ICON_SPACING) : 0;
    int other_w = (n_other > 0) ?
                  n_other * DOCK_ICON_SIZE + (n_other - 1) * DOCK_ICON_SPACING : 0;
    int total_w = DOCK_BAR_PADDING + fixed_w + sep_w + other_w + DOCK_BAR_PADDING;

    *dw = total_w;
    *dh = DOCK_BAR_HEIGHT;
    *dx = (screen_w - total_w) / 2;
    *dy = screen_h - DOCK_BAR_HEIGHT - DOCK_MARGIN_BOTTOM;
}

// =====================================================================
//  Dock icon drawing
// =====================================================================

static void draw_dock_icon(uint32_t *buf, int bw, int bh,
                           int x, int y, char ch, uint32_t color) {
    uint32_t border = darken_color(color, 40);
    draw_round_rect(buf, bw, bh, x, y, DOCK_ICON_SIZE, DOCK_ICON_SIZE, 10, border);
    draw_round_rect(buf, bw, bh, x + 1, y + 1, DOCK_ICON_SIZE - 2, DOCK_ICON_SIZE - 2, 9, color);

    int cx = x + (DOCK_ICON_SIZE - FONT_WIDTH) / 2;
    int cy = y + (DOCK_ICON_SIZE - FONT_HEIGHT) / 2;
    font_draw_char(buf, bw, bh, cx, cy, ch, 0xFFFFFF, color);
}

// Launchpad icon: 3x3 grid of colored squares
static void draw_launchpad_icon(uint32_t *buf, int bw, int bh,
                                int x, int y, uint32_t bg) {
    static const uint32_t grid_colors[9] = {
        0xFF5F57, 0xFFBD2E, 0x27C93F,
        0x4A9BD9, 0xAF52DE, 0xFF6B6B,
        0xF4D03F, 0x48DBFB, 0xFF9F43,
    };

    uint32_t border = darken_color(bg, 40);
    draw_round_rect(buf, bw, bh, x, y, DOCK_ICON_SIZE, DOCK_ICON_SIZE, 10, border);
    draw_round_rect(buf, bw, bh, x + 1, y + 1, DOCK_ICON_SIZE - 2, DOCK_ICON_SIZE - 2, 9, bg);

    int sq = 10;
    int gap = 3;
    int grid_w = sq * 3 + gap * 2;
    int ox = x + (DOCK_ICON_SIZE - grid_w) / 2;
    int oy = y + (DOCK_ICON_SIZE - grid_w) / 2;

    for (int r = 0; r < 3; r++) {
        for (int c = 0; c < 3; c++) {
            draw_rect(buf, bw, bh,
                      ox + c * (sq + gap),
                      oy + r * (sq + gap),
                      sq, sq, grid_colors[r * 3 + c]);
        }
    }
}

static void draw_indicator_dot(uint32_t *buf, int bw, int bh,
                               int icon_x, int dock_bottom_y) {
    int dot_x = icon_x + DOCK_ICON_SIZE / 2 - DOCK_INDICATOR_SIZE / 2;
    int dot_y = dock_bottom_y + DOCK_INDICATOR_GAP;
    draw_rect(buf, bw, bh, dot_x, dot_y,
              DOCK_INDICATOR_SIZE, DOCK_INDICATOR_SIZE, 0xFFFFFF);
}

// =====================================================================
//  Menu bar rendering
// =====================================================================

static void render_menubar(uint32_t *buf, int screen_w, int screen_h) {
    (void)screen_h;
    const struct taskbar_palette *pal = active_palette();

    draw_rect(buf, screen_w, screen_h, 0, 0, screen_w, MENUBAR_HEIGHT, pal->menubar_bg);
    draw_rect(buf, screen_w, screen_h, 0, 0, screen_w, 1, lighten_color(pal->menubar_bg, 20));
    draw_rect(buf, screen_w, screen_h, 0, MENUBAR_HEIGHT - 1, screen_w, 1, pal->menubar_border);

    // Left: OS name
    font_draw_string(buf, screen_w, screen_h, 12, 5,
                     "DoorOS", pal->menubar_text, pal->menubar_bg);

    // Center: focused window title
    struct window *focused = window_get_focused();
    if (focused) {
        int tw = font_string_width(focused->title);
        int tx = (screen_w - tw) / 2;
        font_draw_string(buf, screen_w, screen_h, tx, 5,
                         focused->title, pal->menubar_text_dim, pal->menubar_bg);
    }

    // Right: clock
    uint64_t ticks = pit_get_ticks();
    uint64_t seconds = ticks / 100;
    uint64_t minutes = seconds / 60;
    uint64_t hours = minutes / 60;

    char clock[16];
    snprintf(clock, sizeof(clock), "%02d:%02d:%02d",
             (int)(hours % 24), (int)(minutes % 60), (int)(seconds % 60));
    int cw = font_string_width(clock);
    font_draw_string(buf, screen_w, screen_h,
                     screen_w - cw - 12, 5, clock, pal->menubar_text, pal->menubar_bg);
}

// =====================================================================
//  Dock rendering
// =====================================================================

static void render_dock(uint32_t *buf, int screen_w, int screen_h) {
    const struct taskbar_palette *pal = active_palette();
    int dx, dy, dw, dh;
    dock_geometry(screen_w, screen_h, &dx, &dy, &dw, &dh);

    // Dock bar background with border
    draw_round_rect(buf, screen_w, screen_h, dx - 1, dy - 1, dw + 2, dh + 2, 14, pal->dock_border);
    draw_round_rect(buf, screen_w, screen_h, dx, dy, dw, dh, 13, pal->dock_bg);
    draw_rect(buf, screen_w, screen_h, dx + 10, dy + 4, dw - 20, 1, lighten_color(pal->dock_bg, 22));

    int icon_x = dx + DOCK_BAR_PADDING;
    int icon_y = dy + DOCK_BAR_PADDING;

    // Fixed dock apps
    for (int i = 0; i < DOCK_APP_COUNT; i++) {
        if (i == DOCK_LAUNCHPAD) {
            draw_launchpad_icon(buf, screen_w, screen_h,
                                icon_x, icon_y, dock_apps[i].color);
        } else {
            draw_dock_icon(buf, screen_w, screen_h,
                           icon_x, icon_y,
                           dock_apps[i].icon_char, dock_apps[i].color);
        }

        // Label below dock bar
        const char *label = dock_apps[i].label;
        int lw = font_string_width(label);
        int lx = icon_x + (DOCK_ICON_SIZE - lw) / 2;
        int ly = dy + dh + DOCK_INDICATOR_GAP + DOCK_INDICATOR_SIZE + 2;
        font_draw_string(buf, screen_w, screen_h, lx, ly,
                         label, pal->dock_label, pal->dock_bg);
        // Background behind label is whatever the desktop drew -- we just
        // over-draw with a matching dark color for legibility.

        // Running indicator
        bool running = false;
        if (dock_apps[i].app_type >= 0) {
            running = gui_apps_is_type_running(dock_apps[i].app_type);
        }
        if (running) {
            draw_indicator_dot(buf, screen_w, screen_h, icon_x, dy + dh);
        }

        icon_x += DOCK_ICON_SIZE + DOCK_ICON_SPACING;
    }

    // Separator + other (non-app) windows
    struct window *sorted[MAX_WINDOWS];
    int wcount;
    window_get_sorted(sorted, &wcount);

    int n_other = 0;
    int other_ids[4];
    for (int i = 0; i < wcount && n_other < 4; i++) {
        if (!gui_apps_is_managed(sorted[i]->id)) {
            other_ids[n_other++] = sorted[i]->id;
        }
    }

    if (n_other > 0) {
        // Draw separator
        int sep_x = icon_x + DOCK_ICON_SPACING / 2;
        draw_rect(buf, screen_w, screen_h,
                  sep_x, icon_y + 6, 2, DOCK_ICON_SIZE - 12, pal->dock_separator);
        icon_x += DOCK_ICON_SPACING + 2 + DOCK_ICON_SPACING;

        // Draw other window icons
        for (int i = 0; i < n_other; i++) {
            struct window *win = window_get(other_ids[i]);
            if (!win) continue;

            char ch = win->title[0];
            if (ch < 32 || ch > 126) ch = '?';

            uint32_t wcolor = (win->flags & WIN_FLAG_FOCUSED) ? 0x4A6A8A : 0x3A4A5A;
            draw_dock_icon(buf, screen_w, screen_h, icon_x, icon_y, ch, wcolor);

            // Focused dot
            if (win->flags & WIN_FLAG_FOCUSED) {
                draw_indicator_dot(buf, screen_w, screen_h, icon_x, dy + dh);
            }

            icon_x += DOCK_ICON_SIZE + DOCK_ICON_SPACING;
        }
    }
}

// =====================================================================
//  Launchpad overlay rendering
// =====================================================================

static void render_launchpad(uint32_t *buf, int screen_w, int screen_h) {
    if (!launchpad_open) return;
    const struct taskbar_palette *pal = active_palette();

    // Semi-transparent dark overlay via alpha blend
    for (int y = 0; y < screen_h; y++) {
        for (int x = 0; x < screen_w; x++) {
            uint32_t bg = buf[y * screen_w + x];
            buf[y * screen_w + x] = alpha_blend(bg, pal->launchpad_overlay, 180);
        }
    }

    // Title
    const char *title = "Launchpad";
    int tw = font_string_width(title);
    font_draw_string(buf, screen_w, screen_h,
                     (screen_w - tw) / 2, 60,
                     title, pal->launchpad_title, alpha_blend(0x000000, pal->launchpad_overlay, 180));

    // Grid geometry
    int grid_w = LP_COLS * LP_ICON_SIZE + (LP_COLS - 1) * LP_ICON_SPACING;
    int grid_h = LP_ROWS * (LP_ICON_SIZE + FONT_HEIGHT + LP_LABEL_GAP) +
                 (LP_ROWS - 1) * LP_ICON_SPACING;
    int grid_x = (screen_w - grid_w) / 2;
    int grid_y = (screen_h - grid_h) / 2;

    for (int r = 0; r < LP_ROWS; r++) {
        for (int c = 0; c < LP_COLS; c++) {
            int idx = r * LP_COLS + c;
            if (idx >= LP_ITEM_COUNT) break;

            int ix = grid_x + c * (LP_ICON_SIZE + LP_ICON_SPACING);
            int iy = grid_y + r * (LP_ICON_SIZE + FONT_HEIGHT + LP_LABEL_GAP + LP_ICON_SPACING);

            uint32_t color = lp_items[idx].color;
            uint32_t border = darken_color(color, 40);

            draw_round_rect(buf, screen_w, screen_h, ix, iy,
                            LP_ICON_SIZE, LP_ICON_SIZE, 14, border);
            draw_round_rect(buf, screen_w, screen_h, ix + 2, iy + 2,
                            LP_ICON_SIZE - 4, LP_ICON_SIZE - 4, 12, color);

            // Icon character centered
            int cx = ix + (LP_ICON_SIZE - FONT_WIDTH) / 2;
            int cy = iy + (LP_ICON_SIZE - FONT_HEIGHT) / 2;
            font_draw_char(buf, screen_w, screen_h, cx, cy,
                           lp_items[idx].icon_char, 0xFFFFFF, color);

            // Label below icon
            const char *label = lp_items[idx].label;
            int lw = font_string_width(label);
            int lx = ix + (LP_ICON_SIZE - lw) / 2;
            int ly = iy + LP_ICON_SIZE + LP_LABEL_GAP;
            // Draw label bg rect for readability
            uint32_t label_bg = alpha_blend(0x000000, pal->launchpad_overlay, 180);
            font_draw_string(buf, screen_w, screen_h, lx, ly,
                             label, pal->launchpad_label, label_bg);
        }
    }
}

// =====================================================================
//  Launchpad action dispatch
// =====================================================================

static void run_lp_action(int action) {
    switch (action) {
        case LP_TERMINAL:
            gui_apps_spawn_terminal();
            break;
        case LP_FILE_MANAGER:
            gui_apps_spawn_file_manager();
            break;
        case LP_TEXT_EDITOR:
            gui_apps_spawn_text_editor();
            break;
        case LP_SETTINGS:
            gui_apps_spawn_settings_panel();
            break;
        case LP_ACTION_EMPLOYEE:
            gui_apps_spawn_action_employee();
            break;
        case LP_CALCULATOR:
            gui_apps_spawn_calculator();
            break;
        case LP_PYTHON:
            gui_apps_spawn_python();
            break;
        case LP_GAME:
            gui_apps_spawn_game();
            break;
        case LP_ABOUT: {
            int wid = window_create(140, 120, 420, 220, "About DoorOS");
            if (wid < 0) break;
            struct window *win = window_get(wid);
            if (!win || !win->framebuffer) break;
            for (int y = 0; y < win->height; y++)
                for (int x = 0; x < win->width; x++)
                    win->framebuffer[y * win->width + x] = 0x1F2A38;
            draw_rect(win->framebuffer, win->width, win->height,
                      0, 0, win->width, 34, 0x314A67);
            font_draw_string(win->framebuffer, win->width, win->height,
                             12, 11, "DoorOS", 0xFFFFFF, 0x314A67);
            font_draw_string(win->framebuffer, win->width, win->height,
                             18, 56, "A hobby OS with a macOS-style GUI.",
                             0xD9E6F2, 0x1F2A38);
            font_draw_string(win->framebuffer, win->width, win->height,
                             18, 80, "MACROHARD DoorOS presents: Conjure La Fridge.",
                             0xBFD2E6, 0x1F2A38);
            font_draw_string(win->framebuffer, win->width, win->height,
                             18, 104, "The Lemon Man says: 'debug first, snack second.'",
                             0xBFD2E6, 0x1F2A38);
            font_draw_string(win->framebuffer, win->width, win->height,
                             18, 128, "Use the Dock or Launchpad to open apps.",
                             0xBFD2E6, 0x1F2A38);
            font_draw_string(win->framebuffer, win->width, win->height,
                             18, 152, "Click the red button to close.",
                             0xBFD2E6, 0x1F2A38);
            break;
        }
        case LP_CLOSE_FOCUSED: {
            struct window *focused = window_get_focused();
            if (focused) window_destroy(focused->id);
            break;
        }
        default:
            break;
    }
}

// =====================================================================
//  Launchpad hit test (returns item index or -1)
// =====================================================================

static int launchpad_hit_test(int mx, int my, int screen_w, int screen_h) {
    int grid_w = LP_COLS * LP_ICON_SIZE + (LP_COLS - 1) * LP_ICON_SPACING;
    int grid_h = LP_ROWS * (LP_ICON_SIZE + FONT_HEIGHT + LP_LABEL_GAP) +
                 (LP_ROWS - 1) * LP_ICON_SPACING;
    int grid_x = (screen_w - grid_w) / 2;
    int grid_y = (screen_h - grid_h) / 2;

    for (int r = 0; r < LP_ROWS; r++) {
        for (int c = 0; c < LP_COLS; c++) {
            int idx = r * LP_COLS + c;
            if (idx >= LP_ITEM_COUNT) break;

            int ix = grid_x + c * (LP_ICON_SIZE + LP_ICON_SPACING);
            int iy = grid_y + r * (LP_ICON_SIZE + FONT_HEIGHT + LP_LABEL_GAP + LP_ICON_SPACING);

            if (point_in_rect(mx, my, ix, iy, LP_ICON_SIZE, LP_ICON_SIZE)) {
                return idx;
            }
        }
    }
    return -1;
}

// =====================================================================
//  Dock click handling
// =====================================================================

static void handle_dock_click(int mx, int my, int screen_w, int screen_h) {
    int dx, dy, dw, dh;
    dock_geometry(screen_w, screen_h, &dx, &dy, &dw, &dh);

    int icon_x = dx + DOCK_BAR_PADDING;
    int icon_y = dy + DOCK_BAR_PADDING;

    // Check fixed dock apps
    for (int i = 0; i < DOCK_APP_COUNT; i++) {
        if (point_in_rect(mx, my, icon_x, icon_y,
                          DOCK_ICON_SIZE, DOCK_ICON_SIZE)) {
            switch (i) {
                case DOCK_LAUNCHPAD:
                    launchpad_open = !launchpad_open;
                    break;
                case DOCK_TERMINAL:
                    gui_apps_spawn_terminal();
                    break;
                case DOCK_FILES:
                    gui_apps_spawn_file_manager();
                    break;
                case DOCK_EDITOR:
                    gui_apps_spawn_text_editor();
                    break;
                case DOCK_SETTINGS:
                    gui_apps_spawn_settings_panel();
                    break;
                case DOCK_ACTION:
                    gui_apps_spawn_action_employee();
                    break;
                case DOCK_CALCULATOR:
                    gui_apps_spawn_calculator();
                    break;
                case DOCK_PYTHON:
                    gui_apps_spawn_python();
                    break;
                case DOCK_GAME:
                    gui_apps_spawn_game();
                    break;
            }
            return;
        }
        icon_x += DOCK_ICON_SIZE + DOCK_ICON_SPACING;
    }

    // Check "other" window icons (after separator)
    struct window *sorted[MAX_WINDOWS];
    int wcount;
    window_get_sorted(sorted, &wcount);

    int n_other = 0;
    int other_ids[4];
    for (int i = 0; i < wcount && n_other < 4; i++) {
        if (!gui_apps_is_managed(sorted[i]->id)) {
            other_ids[n_other++] = sorted[i]->id;
        }
    }

    if (n_other > 0) {
        icon_x += DOCK_ICON_SPACING + 2 + DOCK_ICON_SPACING;

        for (int i = 0; i < n_other; i++) {
            if (point_in_rect(mx, my, icon_x, icon_y,
                              DOCK_ICON_SIZE, DOCK_ICON_SIZE)) {
                window_set_focused(other_ids[i]);
                return;
            }
            icon_x += DOCK_ICON_SIZE + DOCK_ICON_SPACING;
        }
    }
}

// =====================================================================
//  Public API
// =====================================================================

void taskbar_init(void) {
    launchpad_open = false;
    taskbar_style = 0;
}

void taskbar_render(uint32_t *buf, int screen_w, int screen_h) {
    // 1. Menu bar (always on top)
    render_menubar(buf, screen_w, screen_h);

    // 2. Dock bar (floating at bottom center)
    render_dock(buf, screen_w, screen_h);

    // 3. Launchpad overlay (on top of everything when open)
    render_launchpad(buf, screen_w, screen_h);
}

bool taskbar_handle_click(int x, int y, int screen_w, int screen_h) {
    // 1. Launchpad overlay consumes all clicks when open
    if (launchpad_open) {
        int item = launchpad_hit_test(x, y, screen_w, screen_h);
        if (item >= 0) {
            run_lp_action(item);
        }
        launchpad_open = false;
        return true;
    }

    // 2. Menu bar area
    if (y < MENUBAR_HEIGHT) {
        return true;
    }

    // 3. Dock area
    int dx, dy, dw, dh;
    dock_geometry(screen_w, screen_h, &dx, &dy, &dw, &dh);
    if (point_in_rect(x, y, dx, dy, dw, dh)) {
        handle_dock_click(x, y, screen_w, screen_h);
        return true;
    }

    return false;
}

bool taskbar_handle_key(uint32_t keycode) {
    // ESC (27) closes launchpad
    if (keycode == 27 && launchpad_open) {
        launchpad_open = false;
        return true;
    }
    return false;
}

bool taskbar_is_menu_open(void) {
    return launchpad_open;
}

void taskbar_set_style(int style) {
    if (style < 0) style = 0;
    if (style >= (int)(sizeof(taskbar_palettes) / sizeof(taskbar_palettes[0]))) {
        style = (int)(sizeof(taskbar_palettes) / sizeof(taskbar_palettes[0])) - 1;
    }
    taskbar_style = style;
}

int taskbar_get_style(void) {
    return taskbar_style;
}
