#include "gui/desktop.h"
#include "gui/apps.h"
#include "gui/font.h"
#include "drivers/mouse.h"
#include "include/types.h"

struct desktop_theme {
    uint32_t top;
    uint32_t bottom;
    uint32_t blob_a;
    uint32_t blob_b;
    uint32_t title;
};

static const struct desktop_theme desktop_themes[] = {
    {0x0B1F36, 0x17345A, 0x3F86FF, 0x31C7B3, 0xD6E9FF}, // Midnight
    {0x0E251C, 0x205346, 0x5ED6A0, 0x2DAA87, 0xDBF5E8}, // Aurora
    {0x2A1710, 0x573122, 0xF0A14F, 0xCC6140, 0xFFE0C4}, // Copper
};

static int desktop_theme_id = 0;
static int desktop_w = 0;
static int desktop_h = 0;

struct desktop_icon {
    const char *label;
    char glyph;
    uint32_t color;
    int app_type;
    int x;
    int y;
};

#define DESKTOP_ICON_SIZE  52
#define DESKTOP_ICON_CELL_W 108
#define DESKTOP_ICON_CELL_H 92
#define DESKTOP_ICON_START_X 22
#define DESKTOP_ICON_START_Y 44

static struct desktop_icon desktop_icons[] = {
    {"Terminal", '>', 0x2D3436, APP_TYPE_TERMINAL, 0, 0},
    {"Files",    'F', 0x4A9BD9, APP_TYPE_FILE_MANAGER, 0, 0},
    {"Editor",   'E', 0xD4A843, APP_TYPE_TEXT_EDITOR, 0, 0},
    {"Python",   'P', 0xF39C12, APP_TYPE_PYTHON, 0, 0},
    {"Games",    'G', 0x7DCEA0, APP_TYPE_GAME, 0, 0},
    {"Action",   'A', 0xCC3333, APP_TYPE_ACTION_EMPLOYEE, 0, 0},
    {"Calc",     'C', 0x2E8B61, APP_TYPE_CALCULATOR, 0, 0},
    {"Settings", 'S', 0x5A7EBD, APP_TYPE_SETTINGS, 0, 0},
};

static uint32_t blend_color(uint32_t c1, uint32_t c2, int t, int max) {
    if (max <= 0) return c1;
    int r1 = (c1 >> 16) & 0xFF, g1 = (c1 >> 8) & 0xFF, b1 = c1 & 0xFF;
    int r2 = (c2 >> 16) & 0xFF, g2 = (c2 >> 8) & 0xFF, b2 = c2 & 0xFF;
    int r = r1 + (r2 - r1) * t / max;
    int g = g1 + (g2 - g1) * t / max;
    int b = b1 + (b2 - b1) * t / max;
    return ((uint32_t)(r & 0xFF) << 16) | ((uint32_t)(g & 0xFF) << 8) | (uint32_t)(b & 0xFF);
}

static uint32_t alpha_blend(uint32_t bg, uint32_t fg, int alpha) {
    int br = (bg >> 16) & 0xFF;
    int bg_g = (bg >> 8) & 0xFF;
    int bb = bg & 0xFF;
    int fr = (fg >> 16) & 0xFF;
    int fg_g = (fg >> 8) & 0xFF;
    int fb = fg & 0xFF;

    int r = (fr * alpha + br * (255 - alpha)) / 255;
    int g = (fg_g * alpha + bg_g * (255 - alpha)) / 255;
    int b = (fb * alpha + bb * (255 - alpha)) / 255;
    return ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
}

static void draw_blob(uint32_t *buf, int width, int height,
                      int cx, int cy, int radius,
                      uint32_t color, int alpha_max) {
    if (radius <= 0 || alpha_max <= 0) return;

    int r2 = radius * radius;
    int y0 = cy - radius;
    int y1 = cy + radius;
    int x0 = cx - radius;
    int x1 = cx + radius;

    for (int y = y0; y <= y1; y++) {
        if (y < 0 || y >= height) continue;
        int dy = y - cy;
        for (int x = x0; x <= x1; x++) {
            if (x < 0 || x >= width) continue;
            int dx = x - cx;
            int d2 = dx * dx + dy * dy;
            if (d2 > r2) continue;

            int a = (alpha_max * (r2 - d2)) / r2;
            uint32_t bg = buf[y * width + x];
            buf[y * width + x] = alpha_blend(bg, color, a);
        }
    }
}

static void draw_rect(uint32_t *buf, int bw, int bh,
                      int x, int y, int w, int h, uint32_t color) {
    for (int j = y; j < y + h && j < bh; j++) {
        if (j < 0) continue;
        for (int i = x; i < x + w && i < bw; i++) {
            if (i < 0) continue;
            buf[j * bw + i] = color;
        }
    }
}

static uint32_t darken_color(uint32_t c, int amount) {
    int r = (c >> 16) & 0xFF;
    int g = (c >> 8) & 0xFF;
    int b = c & 0xFF;
    r = (r > amount) ? (r - amount) : 0;
    g = (g > amount) ? (g - amount) : 0;
    b = (b > amount) ? (b - amount) : 0;
    return ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
}

static void desktop_layout_icons(int width, int height) {
    (void)height;

    int icon_count = (int)(sizeof(desktop_icons) / sizeof(desktop_icons[0]));
    int col_count = width / DESKTOP_ICON_CELL_W;
    if (col_count < 1) col_count = 1;

    for (int i = 0; i < icon_count; i++) {
        int col = i % col_count;
        int row = i / col_count;
        desktop_icons[i].x = DESKTOP_ICON_START_X + col * DESKTOP_ICON_CELL_W;
        desktop_icons[i].y = DESKTOP_ICON_START_Y + row * DESKTOP_ICON_CELL_H;
    }
}

static void desktop_launch_app(int app_type) {
    switch (app_type) {
        case APP_TYPE_TERMINAL:
            gui_apps_spawn_terminal();
            break;
        case APP_TYPE_FILE_MANAGER:
            gui_apps_spawn_file_manager();
            break;
        case APP_TYPE_TEXT_EDITOR:
            gui_apps_spawn_text_editor();
            break;
        case APP_TYPE_SETTINGS:
            gui_apps_spawn_settings_panel();
            break;
        case APP_TYPE_ACTION_EMPLOYEE:
            gui_apps_spawn_action_employee();
            break;
        case APP_TYPE_CALCULATOR:
            gui_apps_spawn_calculator();
            break;
        case APP_TYPE_PYTHON:
            gui_apps_spawn_python();
            break;
        case APP_TYPE_GAME:
            gui_apps_spawn_game();
            break;
        default:
            break;
    }
}

void desktop_init(void) {
}

void desktop_render(uint32_t *buf, int width, int height) {
    const struct desktop_theme *theme = &desktop_themes[desktop_theme_id];
    desktop_w = width;
    desktop_h = height;
    desktop_layout_icons(width, height);

    // Full-screen gradient (menu bar + dock render on top later)
    for (int y = 0; y < height; y++) {
        uint32_t color = blend_color(theme->top, theme->bottom, y, height);
        for (int x = 0; x < width; x++) {
            buf[y * width + x] = color;
        }
    }

    // Subtle atmosphere blobs + top sheen to avoid a flat background.
    draw_blob(buf, width, height, width / 4, height / 3, height / 3, theme->blob_a, 80);
    draw_blob(buf, width, height, (width * 3) / 4, (height * 2) / 3, height / 3, theme->blob_b, 66);
    draw_blob(buf, width, height, width / 2, height / 4, height / 5, 0xFFFFFF, 36);

    int sheen_h = height / 3;
    if (sheen_h < 1) sheen_h = 1;
    for (int y = 0; y < sheen_h; y++) {
        int alpha = ((sheen_h - y) * 28) / sheen_h;
        for (int x = 0; x < width; x++) {
            uint32_t bg = buf[y * width + x];
            buf[y * width + x] = alpha_blend(bg, 0xDDEBFF, alpha);
        }
    }

    // Subtle centered OS name
    const char *title = "DoorOS";
    int title_w = font_string_width(title);
    int tx = (width - title_w) / 2;
    int ty = height / 2 - 16;
    if (tx < 0) tx = 0;
    if (ty < 0) ty = 0;
    if (tx >= width) tx = width - 1;
    if (ty >= height) ty = height - 1;
    uint32_t title_bg = buf[ty * width + tx];
    font_draw_string(buf, width, height, tx, ty, title, theme->title, title_bg);

    int icon_count = (int)(sizeof(desktop_icons) / sizeof(desktop_icons[0]));
    for (int i = 0; i < icon_count; i++) {
        const struct desktop_icon *icon = &desktop_icons[i];
        uint32_t border = darken_color(icon->color, 40);
        int ix = icon->x;
        int iy = icon->y;

        draw_rect(buf, width, height, ix - 1, iy - 1,
                  DESKTOP_ICON_SIZE + 2, DESKTOP_ICON_SIZE + 2, border);
        draw_rect(buf, width, height, ix, iy,
                  DESKTOP_ICON_SIZE, DESKTOP_ICON_SIZE, icon->color);

        int gx = ix + (DESKTOP_ICON_SIZE - FONT_WIDTH) / 2;
        int gy = iy + (DESKTOP_ICON_SIZE - FONT_HEIGHT) / 2;
        font_draw_char(buf, width, height, gx, gy, icon->glyph, 0xFFFFFF, icon->color);

        int lw = font_string_width(icon->label);
        int lx = ix + (DESKTOP_ICON_SIZE - lw) / 2;
        int ly = iy + DESKTOP_ICON_SIZE + 8;
        if (lx < 0) lx = 0;
        if (ly < 0) ly = 0;
        uint32_t label_bg = 0;
        if (lx < width && ly < height) {
            label_bg = buf[ly * width + lx];
        }
        font_draw_string(buf, width, height, lx, ly, icon->label, 0xE6F1FF, label_bg);
    }
}

void desktop_handle_mouse(int x, int y, int buttons) {
    if ((buttons & MOUSE_LEFT) == 0) return;
    if (desktop_w <= 0 || desktop_h <= 0) return;

    int icon_count = (int)(sizeof(desktop_icons) / sizeof(desktop_icons[0]));
    for (int i = 0; i < icon_count; i++) {
        const struct desktop_icon *icon = &desktop_icons[i];
        int bx = icon->x;
        int by = icon->y;
        int bw = DESKTOP_ICON_SIZE;
        int bh = DESKTOP_ICON_SIZE + FONT_HEIGHT + 10;

        if (x >= bx && x < bx + bw && y >= by && y < by + bh) {
            desktop_launch_app(icon->app_type);
            return;
        }
    }
}

void desktop_handle_key(uint32_t keycode) {
    (void)keycode;
}

void desktop_set_theme(int theme_id) {
    if (theme_id < 0 || theme_id >= (int)(sizeof(desktop_themes) / sizeof(desktop_themes[0]))) {
        return;
    }
    desktop_theme_id = theme_id;
}

int desktop_get_theme(void) {
    return desktop_theme_id;
}

int desktop_get_theme_count(void) {
    return (int)(sizeof(desktop_themes) / sizeof(desktop_themes[0]));
}
