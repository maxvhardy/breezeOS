#pragma once

#include "include/types.h"
#include "gui/event.h"

#define APP_TYPE_NONE         0
#define APP_TYPE_TERMINAL     1
#define APP_TYPE_FILE_MANAGER 2
#define APP_TYPE_TEXT_EDITOR  3
#define APP_TYPE_SETTINGS     4
#define APP_TYPE_ACTION_EMPLOYEE 5
#define APP_TYPE_CALCULATOR   6
#define APP_TYPE_PYTHON       7
#define APP_TYPE_GAME         8

void gui_apps_init(void);

int gui_apps_spawn_terminal(void);
int gui_apps_spawn_file_manager(void);
int gui_apps_spawn_text_editor(void);
int gui_apps_spawn_settings_panel(void);
int gui_apps_spawn_action_employee(void);
int gui_apps_spawn_calculator(void);
int gui_apps_spawn_python(void);
int gui_apps_spawn_game(void);

void gui_apps_handle_event(const struct gui_event *ev);
void gui_apps_on_window_destroyed(int wid);

bool gui_apps_is_type_running(int app_type);
bool gui_apps_is_managed(int wid);

bool gui_apps_terminal_stream_write(int wid, const char *buf, size_t len);
void gui_apps_terminal_stream_flush(int wid);
