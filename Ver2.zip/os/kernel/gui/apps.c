#include "gui/apps.h"

#include "gui/compositor.h"
#include "gui/desktop.h"
#include "gui/taskbar.h"
#include "gui/window.h"
#include "gui/font.h"
#include "fs/vfs.h"
#include "sched/process.h"
#include "drivers/pit.h"
#include "drivers/net.h"
#include "drivers/keyboard.h"
#include "drivers/power.h"
#include "drivers/vbe.h"
#include "arch/syscall.h"
#include "elf.h"
#include "mm/pmm.h"
#include "mm/heap.h"
#include "lib/string.h"
#include "lib/printf.h"

#define TERM_MAX_LINES 256
#define TERM_LINE_MAX  160
#define TERM_INPUT_MAX 128
#define TERM_MAX_ARGS  16

#define FILEMAN_MAX_ENTRIES 96

#define EDITOR_TEXT_MAX 8192

#define DOORCC_OBJ_MAGIC "DOOROBJ2"
#define DOORCC_OBJ_VERSION 2
#define DOORCC_MAX_SOURCE_BYTES (256 * 1024)
#define DOORCC_MAX_OUTPUT_BYTES (128 * 1024)
#define DOORCC_MAX_VARS 32
#define DOORCC_MAX_ARGS 8

#define TERM_BG_COLOR        0x0F1621
#define TERM_HEADER_COLOR    0x1D2A3A
#define TERM_TEXT_COLOR      0xD7DEE7
#define TERM_PROMPT_COLOR    0xA6E3A1
#define TERM_BORDER_COLOR    0x122033

#define FM_BG_COLOR          0xEEF3F8
#define FM_HEADER_COLOR      0x355C7D
#define FM_HEADER_TEXT       0xFFFFFF
#define FM_PATH_BG           0xD6E2EE
#define FM_ROW_A             0xF7FAFD
#define FM_ROW_B             0xEDF3F8
#define FM_ROW_SELECTED      0xC9E3FF
#define FM_STATUS_BG         0xDCE6F0
#define FM_TEXT_COLOR        0x253443
#define FM_ACCENT_TEXT       0x3B5874

#define ED_BG_COLOR          0xF8F7F4
#define ED_HEADER_COLOR      0x4A5D73
#define ED_HEADER_TEXT       0xFFFFFF
#define ED_TOOLBAR_BG        0xD9E1EA
#define ED_TEXT_COLOR        0x1E2832
#define ED_STATUS_BG         0xD2DBE5
#define ED_CARET_COLOR       0x0E3B66

#define SET_BG_TOP           0xEEF3FB
#define SET_BG_BOTTOM        0xD6E0ED
#define SET_HEADER_TOP       0x345679
#define SET_HEADER_BOTTOM    0x223952
#define SET_HEADER_TEXT      0xF6FAFF
#define SET_SUBTEXT_COLOR    0x2F4863
#define SET_CARD_BG          0xF5F8FC
#define SET_CARD_ALT         0xEAF0F8
#define SET_CARD_BORDER      0xC4D3E6
#define SET_LABEL_COLOR      0x2B4058
#define SET_VALUE_BG         0xFFFFFF
#define SET_VALUE_COLOR      0x11253A
#define SET_BUTTON_BG        0x4D78AA
#define SET_BUTTON_ALT       0x2E8B61
#define SET_BUTTON_TEXT      0xFFFFFF
#define SET_STATUS_BG        0xC9D6E8
#define SET_STATUS_TEXT      0x1C344D
#define SET_NET_OK           0x2D8255
#define SET_NET_WARN         0xA55B2A

#define SET_ROW_COUNT        3
#define SET_ROW_START_Y      82
#define SET_ROW_STEP         68
#define SET_ROW_HEIGHT       58

#define ACT_BG_COLOR         0x131A24
#define ACT_HEADER_COLOR     0x2A3B52
#define ACT_TEXT_COLOR       0xE7EEF7
#define ACT_SUBTEXT_COLOR    0xAFC4DE
#define ACT_ROW_A            0x1A2433
#define ACT_ROW_B            0x202C3D
#define ACT_ROW_SELECTED     0x2F557C
#define ACT_BORDER_COLOR     0x0F1824
#define ACT_BUTTON_COLOR     0x2E8B61
#define ACT_STATUS_COLOR     0x223247

#define CALC_BG_COLOR        0xF3F5F8
#define CALC_HEADER_COLOR    0x3A5270
#define CALC_DISPLAY_BG      0xFFFFFF
#define CALC_DISPLAY_TEXT    0x11253A
#define CALC_BUTTON_BG       0xDCE4EE
#define CALC_BUTTON_OP       0x9EC3E6
#define CALC_BUTTON_EQ       0x4A9BD9
#define CALC_BUTTON_CLR      0xD98585
#define CALC_STATUS_BG       0xD6DFEA
#define CALC_STATUS_TEXT     0x1F3044

struct terminal_state {
    char cwd[MAX_PATH];
    char input[TERM_INPUT_MAX];
    int input_len;
    char stream_line[TERM_LINE_MAX];
    int stream_len;

    char lines[TERM_MAX_LINES][TERM_LINE_MAX];
    int line_start;
    int line_count;
};

struct fileman_entry {
    char name[MAX_NAME + 1];
    uint8_t type;
};

struct fileman_state {
    char cwd[MAX_PATH];
    struct fileman_entry entries[FILEMAN_MAX_ENTRIES];
    int entry_count;
    int selected;
    char status[96];
};

struct editor_state {
    char path[MAX_PATH];
    char text[EDITOR_TEXT_MAX + 1];
    size_t len;
    size_t cursor;
    char status[96];
    bool dirty;
    bool rename_mode;
    char rename_input[MAX_PATH];
    int rename_len;
};

struct settings_state {
    int theme_id;
    int corner_index;
    int ui_style;
    char status[96];
};

struct action_state {
    int scroll;
    int selected_pid;
    char status[96];
};

struct calculator_state {
    char expr[96];
    int expr_len;
    int has_result;
    int result;
    char status[96];
};

struct gui_app {
    uint8_t used;
    uint8_t type;
    int window_id;
    union {
        struct terminal_state term;
        struct fileman_state fm;
        struct editor_state ed;
        struct settings_state settings;
        struct action_state action;
        struct calculator_state calc;
    } u;
};

static struct gui_app apps[MAX_WINDOWS];

static int gui_apps_spawn_text_editor_path(const char *path);
static void settings_apply(struct settings_state *st);
static void settings_render(struct gui_app *app);
static void settings_handle_click(struct gui_app *app, int x, int y);
static void action_render(struct gui_app *app);
static void action_handle_click(struct gui_app *app, int x, int y);
static void action_handle_key(struct gui_app *app, uint32_t keycode);
static void calc_render(struct gui_app *app);
static void calc_handle_click(struct gui_app *app, int x, int y);
static void calc_handle_key(struct gui_app *app, uint32_t keycode);
static char editor_scratch_lines[64][192];

static void draw_rect(uint32_t *buf, int buf_w, int buf_h,
                      int x, int y, int w, int h, uint32_t color) {
    for (int j = y; j < y + h && j < buf_h; j++) {
        if (j < 0) continue;
        for (int i = x; i < x + w && i < buf_w; i++) {
            if (i < 0) continue;
            buf[j * buf_w + i] = color;
        }
    }
}

static uint32_t blend_color(uint32_t c1, uint32_t c2, int t, int max) {
    if (max <= 0) return c1;
    int r1 = (c1 >> 16) & 0xFF;
    int g1 = (c1 >> 8) & 0xFF;
    int b1 = c1 & 0xFF;
    int r2 = (c2 >> 16) & 0xFF;
    int g2 = (c2 >> 8) & 0xFF;
    int b2 = c2 & 0xFF;
    int r = r1 + (r2 - r1) * t / max;
    int g = g1 + (g2 - g1) * t / max;
    int b = b1 + (b2 - b1) * t / max;
    return ((uint32_t)(r & 0xFF) << 16) | ((uint32_t)(g & 0xFF) << 8) | (uint32_t)(b & 0xFF);
}

static void draw_vertical_gradient(uint32_t *buf, int buf_w, int buf_h,
                                   int x, int y, int w, int h,
                                   uint32_t top, uint32_t bottom) {
    if (!buf || w <= 0 || h <= 0) return;
    for (int j = 0; j < h; j++) {
        int py = y + j;
        if (py < 0 || py >= buf_h) continue;
        uint32_t color = blend_color(top, bottom, j, h);
        for (int i = 0; i < w; i++) {
            int px = x + i;
            if (px < 0 || px >= buf_w) continue;
            buf[py * buf_w + px] = color;
        }
    }
}

static void fill_window(uint32_t *buf, int width, int height, uint32_t color) {
    if (!buf) return;
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            buf[y * width + x] = color;
        }
    }
}

static char printable_char(char ch) {
    uint8_t c = (uint8_t)ch;
    if (c < 32 || c > 126) return '?';
    return ch;
}

static void sanitize_text(char *dst) {
    if (!dst) return;
    for (size_t i = 0; dst[i]; i++) {
        if (dst[i] == '\t') {
            dst[i] = ' ';
            continue;
        }
        if ((uint8_t)dst[i] < 32 || (uint8_t)dst[i] > 126) {
            dst[i] = '?';
        }
    }
}

static __attribute__((unused)) struct gui_app *app_alloc(int wid, uint8_t type) {
    for (int i = 0; i < MAX_WINDOWS; i++) {
        if (!apps[i].used) {
            memset(&apps[i], 0, sizeof(apps[i]));
            apps[i].used = 1;
            apps[i].type = type;
            apps[i].window_id = wid;
            return &apps[i];
        }
    }
    return NULL;
}

static struct gui_app *app_find(int wid) {
    for (int i = 0; i < MAX_WINDOWS; i++) {
        if (apps[i].used && apps[i].window_id == wid) {
            return &apps[i];
        }
    }
    return NULL;
}

static void app_free(int wid) {
    for (int i = 0; i < MAX_WINDOWS; i++) {
        if (apps[i].used && apps[i].window_id == wid) {
            memset(&apps[i], 0, sizeof(apps[i]));
            return;
        }
    }
}

static int normalize_path(const char *raw, char *out, size_t out_sz) {
    if (!raw || raw[0] != '/' || out_sz < 2) return -1;

    char parts[32][MAX_NAME + 1];
    int part_count = 0;

    char comp[MAX_NAME + 1];
    int comp_len = 0;

    for (const char *p = raw;; p++) {
        char ch = *p;
        if (ch == '/' || ch == '\0') {
            if (comp_len > 0) {
                comp[comp_len] = '\0';
                if (strcmp(comp, ".") == 0) {
                    // Ignore.
                } else if (strcmp(comp, "..") == 0) {
                    if (part_count > 0) part_count--;
                } else {
                    if (part_count >= 32) return -1;
                    strncpy(parts[part_count], comp, MAX_NAME);
                    parts[part_count][MAX_NAME] = '\0';
                    part_count++;
                }
                comp_len = 0;
            }

            if (ch == '\0') break;
            continue;
        }

        if (comp_len >= MAX_NAME) return -1;
        comp[comp_len++] = ch;
    }

    out[0] = '/';
    out[1] = '\0';

    for (int i = 0; i < part_count; i++) {
        size_t len = strlen(out);
        size_t nlen = strlen(parts[i]);

        if (len > 1) {
            if (len + 1 >= out_sz) return -1;
            out[len++] = '/';
            out[len] = '\0';
        }

        if (len + nlen >= out_sz) return -1;
        memcpy(out + len, parts[i], nlen + 1);
    }

    return 0;
}

static int resolve_path(const char *cwd, const char *path, char *out, size_t out_sz) {
    if (!cwd || cwd[0] != '/' || !path || !out) return -1;

    if (path[0] == '\0') {
        strncpy(out, cwd, out_sz - 1);
        out[out_sz - 1] = '\0';
        return 0;
    }

    char raw[MAX_PATH * 2];

    if (path[0] == '/') {
        strncpy(raw, path, sizeof(raw) - 1);
        raw[sizeof(raw) - 1] = '\0';
    } else if (strcmp(cwd, "/") == 0) {
        snprintf(raw, sizeof(raw), "/%s", path);
    } else {
        snprintf(raw, sizeof(raw), "%s/%s", cwd, path);
    }

    return normalize_path(raw, out, out_sz);
}

static void parent_path(const char *path, char *out, size_t out_sz) {
    if (!path || path[0] != '/') {
        strncpy(out, "/", out_sz - 1);
        out[out_sz - 1] = '\0';
        return;
    }

    strncpy(out, path, out_sz - 1);
    out[out_sz - 1] = '\0';

    size_t len = strlen(out);
    while (len > 1 && out[len - 1] == '/') {
        out[len - 1] = '\0';
        len--;
    }

    if (strcmp(out, "/") == 0) return;

    char *last = strrchr(out, '/');
    if (!last || last == out) {
        out[0] = '/';
        out[1] = '\0';
    } else {
        *last = '\0';
    }
}

static int term_cols(const struct window *win) {
    int cols = (win->width - 20) / FONT_WIDTH;
    if (cols < 8) cols = 8;
    if (cols > TERM_LINE_MAX - 1) cols = TERM_LINE_MAX - 1;
    return cols;
}

static void term_clear(struct terminal_state *term) {
    term->line_start = 0;
    term->line_count = 0;
    term->stream_len = 0;
    term->stream_line[0] = '\0';
}

static void term_push_line(struct terminal_state *term, const char *text) {
    int idx;
    if (term->line_count < TERM_MAX_LINES) {
        idx = (term->line_start + term->line_count) % TERM_MAX_LINES;
        term->line_count++;
    } else {
        idx = term->line_start;
        term->line_start = (term->line_start + 1) % TERM_MAX_LINES;
    }

    if (text) {
        strncpy(term->lines[idx], text, TERM_LINE_MAX - 1);
        term->lines[idx][TERM_LINE_MAX - 1] = '\0';
    } else {
        term->lines[idx][0] = '\0';
    }
}

static void term_emit_wrapped(struct terminal_state *term, int cols,
                              const char *text, bool append_newline) {
    if (!text) text = "";

    char line[TERM_LINE_MAX];
    int len = 0;

    for (const char *p = text; *p; p++) {
        char ch = *p;

        if (ch == '\r') continue;

        if (ch == '\n') {
            line[len] = '\0';
            term_push_line(term, line);
            len = 0;
            continue;
        }

        if (ch == '\t') ch = ' ';
        if ((uint8_t)ch < 32 || (uint8_t)ch > 126) ch = '?';

        if (len >= cols || len >= TERM_LINE_MAX - 1) {
            line[len] = '\0';
            term_push_line(term, line);
            len = 0;
        }

        line[len++] = ch;
    }

    if (len > 0 || append_newline) {
        line[len] = '\0';
        term_push_line(term, line);
    }
}

static void term_stream_flush_pending(struct terminal_state *term) {
    if (!term || term->stream_len <= 0) return;
    term->stream_line[term->stream_len] = '\0';
    term_push_line(term, term->stream_line);
    term->stream_len = 0;
    term->stream_line[0] = '\0';
}

static void term_stream_write_bytes(struct terminal_state *term, const struct window *win,
                                    const char *text, size_t len) {
    if (!term || !win || !text || len == 0) return;

    int cols = term_cols(win);
    for (size_t i = 0; i < len; i++) {
        char ch = text[i];
        if (ch == '\r') continue;

        if (ch == '\n') {
            term->stream_line[term->stream_len] = '\0';
            term_push_line(term, term->stream_line);
            term->stream_len = 0;
            term->stream_line[0] = '\0';
            continue;
        }

        if (ch == '\t') ch = ' ';
        if ((uint8_t)ch < 32 || (uint8_t)ch > 126) ch = '?';

        if (term->stream_len >= cols || term->stream_len >= TERM_LINE_MAX - 1) {
            term->stream_line[term->stream_len] = '\0';
            term_push_line(term, term->stream_line);
            term->stream_len = 0;
            term->stream_line[0] = '\0';
        }

        term->stream_line[term->stream_len++] = ch;
        term->stream_line[term->stream_len] = '\0';
    }
}

static void term_write_line(struct terminal_state *term, const struct window *win,
                            const char *text) {
    term_stream_flush_pending(term);
    term_emit_wrapped(term, term_cols(win), text, true);
}

static void term_write_text(struct terminal_state *term, const struct window *win,
                            const char *text) {
    term_emit_wrapped(term, term_cols(win), text, false);
}

static void term_make_prompt(const struct terminal_state *term, char *buf, size_t buf_sz) {
    snprintf(buf, buf_sz, "door@door:%s$ ", term->cwd);
}

static int parse_args(char *line, char *argv[], int max_args) {
    int argc = 0;
    char *p = line;

    while (*p && argc < max_args) {
        while (*p == ' ' || *p == '\t') p++;
        if (*p == '\0') break;

        argv[argc++] = p;

        while (*p && *p != ' ' && *p != '\t') p++;
        if (*p) *p++ = '\0';
    }

    return argc;
}

static int term_calc_is_space(char c) {
    return c == ' ' || c == '\t';
}

static void term_calc_skip_spaces(const char **p) {
    while (p && *p && term_calc_is_space(**p)) (*p)++;
}

static int term_calc_parse_expr(const char **p, int *out, char *err, size_t err_sz);

static int term_calc_parse_factor(const char **p, int *out, char *err, size_t err_sz) {
    term_calc_skip_spaces(p);
    if (!p || !*p || !out) return 0;

    int sign = 1;
    while (**p == '+' || **p == '-') {
        if (**p == '-') sign = -sign;
        (*p)++;
        term_calc_skip_spaces(p);
    }

    if (**p == '(') {
        (*p)++;
        int value = 0;
        if (!term_calc_parse_expr(p, &value, err, err_sz)) return 0;
        term_calc_skip_spaces(p);
        if (**p != ')') {
            snprintf(err, err_sz, "expected ')'");
            return 0;
        }
        (*p)++;
        *out = sign * value;
        return 1;
    }

    if (**p < '0' || **p > '9') {
        snprintf(err, err_sz, "expected number");
        return 0;
    }

    int value = 0;
    while (**p >= '0' && **p <= '9') {
        value = value * 10 + (**p - '0');
        (*p)++;
    }

    *out = sign * value;
    return 1;
}

static int term_calc_parse_term(const char **p, int *out, char *err, size_t err_sz) {
    int value = 0;
    if (!term_calc_parse_factor(p, &value, err, err_sz)) return 0;

    while (1) {
        term_calc_skip_spaces(p);
        char op = **p;
        if (op != '*' && op != '/' && op != '%') break;
        (*p)++;

        int rhs = 0;
        if (!term_calc_parse_factor(p, &rhs, err, err_sz)) return 0;

        if ((op == '/' || op == '%') && rhs == 0) {
            snprintf(err, err_sz, "division by zero");
            return 0;
        }

        if (op == '*') value *= rhs;
        else if (op == '/') value /= rhs;
        else value %= rhs;
    }

    *out = value;
    return 1;
}

static int term_calc_parse_expr(const char **p, int *out, char *err, size_t err_sz) {
    int value = 0;
    if (!term_calc_parse_term(p, &value, err, err_sz)) return 0;

    while (1) {
        term_calc_skip_spaces(p);
        char op = **p;
        if (op != '+' && op != '-') break;
        (*p)++;

        int rhs = 0;
        if (!term_calc_parse_term(p, &rhs, err, err_sz)) return 0;
        if (op == '+') value += rhs;
        else value -= rhs;
    }

    *out = value;
    return 1;
}

static int term_calc_eval(const char *expr, int *out, char *err, size_t err_sz) {
    if (!expr || !out || !err || err_sz == 0) return 0;
    err[0] = '\0';

    const char *p = expr;
    if (!term_calc_parse_expr(&p, out, err, err_sz)) {
        if (err[0] == '\0') snprintf(err, err_sz, "invalid expression");
        return 0;
    }

    term_calc_skip_spaces(&p);
    if (*p != '\0') {
        snprintf(err, err_sz, "unexpected token '%c'", *p);
        return 0;
    }

    return 1;
}

static void term_cmd_help(struct terminal_state *term, const struct window *win) {
    term_write_line(term, win, "Built-in commands:");
    term_write_line(term, win, "  help  clear  pwd  cd  ls  cat  echo  stat");
    term_write_line(term, win, "  mkdir  rmdir  rm  touch  calc  uptime  fastfetch  ifconfig");
    term_write_line(term, win, "  sysinfo  uname  ps  run  reap  editor  settings  compile");
    term_write_line(term, win, "  action  taskman  calculator  ping  reboot  restart  lemonman  exit");
}

static void term_cmd_calc(struct terminal_state *term, const struct window *win,
                          int argc, char *argv[]) {
    if (argc < 2) {
        term_write_line(term, win, "calc usage: calc <expression>");
        term_write_line(term, win, "example: calc (12 + 3) * 4 - 5");
        return;
    }

    char expr[TERM_INPUT_MAX];
    expr[0] = '\0';
    for (int i = 1; i < argc; i++) {
        if (i > 1) strncat(expr, " ", sizeof(expr) - strlen(expr) - 1);
        strncat(expr, argv[i], sizeof(expr) - strlen(expr) - 1);
    }

    int result = 0;
    char err[64];
    if (!term_calc_eval(expr, &result, err, sizeof(err))) {
        char msg[TERM_LINE_MAX];
        snprintf(msg, sizeof(msg), "calc: %s", err);
        term_write_line(term, win, msg);
        return;
    }

    char out[TERM_LINE_MAX];
    snprintf(out, sizeof(out), "%d", result);
    term_write_line(term, win, out);
}

static void term_cmd_fastfetch(struct terminal_state *term, const struct window *win) {
    uint64_t ticks = pit_get_ticks();
    uint64_t seconds = ticks / 100;
    uint64_t minutes = seconds / 60;
    uint64_t hours = minutes / 60;
    uint64_t days = hours / 24;

    uint32_t vw = vbe_get_width();
    uint32_t vh = vbe_get_height();
    uint32_t vbpp = vbe_get_bpp();

    uint64_t total_mb = pmm_get_total_memory() / (1024 * 1024);
    uint64_t free_mb = pmm_get_free_memory() / (1024 * 1024);

    char line[TERM_LINE_MAX];

    term_write_line(term, win, "        ____                              ");
    term_write_line(term, win, "  /\\   | __ ) _ __ ___  ___ ________  ___ ");
    term_write_line(term, win, " /  \\  |  _ \\| '__/ _ \\/ _ \\_  / _ \\/ __|");
    term_write_line(term, win, "/ /\\ \\ | |_) | | |  __/  __// /  __/\\__ \\");
    term_write_line(term, win, "\\/  \\/ |____/|_|  \\___|\\___/___\\___||___/");
    term_write_line(term, win, "");

    term_write_line(term, win, "OS:        DoorOS");
    term_write_line(term, win, "Kernel:    64-bit monolithic");
    term_write_line(term, win, "Shell:     GUI Terminal");
    term_write_line(term, win, "Flavor:    MACROHARD DoorOS Deluxe");
    term_write_line(term, win, "Bootflow:  Conjure La Fridge");

    snprintf(line, sizeof(line), "Display:   %ux%u @ %ubpp", (unsigned)vw, (unsigned)vh, (unsigned)vbpp);
    term_write_line(term, win, line);

    snprintf(line, sizeof(line), "Uptime:    %u d %u h %u m %u s",
             (unsigned)days, (unsigned)(hours % 24), (unsigned)(minutes % 60), (unsigned)(seconds % 60));
    term_write_line(term, win, line);

    snprintf(line, sizeof(line), "Memory:    %u MB free / %u MB total",
             (unsigned)free_mb, (unsigned)total_mb);
    term_write_line(term, win, line);

    snprintf(line, sizeof(line), "Windows:   %d", window_get_count());
    term_write_line(term, win, line);
}

static void term_cmd_uname(struct terminal_state *term, const struct window *win) {
    term_write_line(term, win, "DoorOS x86_64");
}

static void term_cmd_ps(struct terminal_state *term, const struct window *win) {
    term_write_line(term, win, "PID  STATE     NAME");

    for (int pid = 0; pid < MAX_PROCESSES; pid++) {
        struct process *p = process_get(pid);
        if (!p) continue;

        const char *state = "UNK";
        switch (p->state) {
            case PROC_READY:    state = "READY"; break;
            case PROC_RUNNING:  state = "RUN";   break;
            case PROC_BLOCKED:  state = "BLOCK"; break;
            case PROC_SLEEPING: state = "SLEEP"; break;
            case PROC_ZOMBIE:   state = "ZOMB";  break;
            default:            state = "UNK";   break;
        }

        char line[TERM_LINE_MAX];
        snprintf(line, sizeof(line), "%3d  %-8s  %s", p->pid, state, p->name);
        term_write_line(term, win, line);
    }
}

static void term_cmd_ifconfig(struct terminal_state *term, const struct window *win) {
    if (!net_is_ready()) {
        term_write_line(term, win, "net: no supported Ethernet adapter (e1000) detected");
        return;
    }

    char line[TERM_LINE_MAX];
    char mac[32];
    char ip[32];
    char gw[32];
    char mask[32];

    net_format_mac(net_get_mac(), mac, sizeof(mac));
    net_format_ipv4(net_get_ip(), ip, sizeof(ip));
    net_format_ipv4(net_get_gateway(), gw, sizeof(gw));
    net_format_ipv4(net_get_netmask(), mask, sizeof(mask));

    snprintf(line, sizeof(line), "eth0: %s", net_is_link_up() ? "link up" : "link down");
    term_write_line(term, win, line);
    snprintf(line, sizeof(line), "  mac:  %s", mac);
    term_write_line(term, win, line);
    snprintf(line, sizeof(line), "  ipv4: %s", ip);
    term_write_line(term, win, line);
    snprintf(line, sizeof(line), "  mask: %s", mask);
    term_write_line(term, win, line);
    snprintf(line, sizeof(line), "  gw:   %s", gw);
    term_write_line(term, win, line);
}

static void term_cmd_ping(struct terminal_state *term, const struct window *win,
                          int argc, char *argv[]) {
    uint8_t dst[4];
    if (argc > 1) {
        if (net_parse_ipv4(argv[1], dst) < 0) {
            term_write_line(term, win, "ping: invalid IPv4 address");
            return;
        }
    } else {
        const uint8_t *gw = net_get_gateway();
        memcpy(dst, gw, 4);
    }

    if (!net_is_ready()) {
        term_write_line(term, win, "ping: networking is not initialized");
        return;
    }

    char ipbuf[32];
    net_format_ipv4(dst, ipbuf, sizeof(ipbuf));

    char msg[TERM_LINE_MAX];
    snprintf(msg, sizeof(msg), "ping %s ...", ipbuf);
    term_write_line(term, win, msg);

    uint32_t rtt_ms = 0;
    if (net_ping(dst, 2000, &rtt_ms) == 0) {
        snprintf(msg, sizeof(msg), "reply from %s: time=%u ms", ipbuf, (unsigned)rtt_ms);
        term_write_line(term, win, msg);
    } else {
        snprintf(msg, sizeof(msg), "ping timeout to %s", ipbuf);
        term_write_line(term, win, msg);
    }
}

static int term_reap_zombies(void) {
    int reaped = 0;
    for (int pid = 1; pid < MAX_PROCESSES; pid++) {
        struct process *p = process_get(pid);
        if (!p) continue;
        if (p->parent_pid != 0) continue;
        if (p->state != PROC_ZOMBIE) continue;
        if (process_waitpid(pid, NULL) >= 0) {
            reaped++;
        }
    }
    return reaped;
}

static bool path_has_suffix(const char *path, const char *suffix) {
    if (!path || !suffix) return false;
    size_t plen = strlen(path);
    size_t slen = strlen(suffix);
    if (plen < slen) return false;
    return strcmp(path + plen - slen, suffix) == 0;
}

static int term_resolve_any_path(const struct terminal_state *term,
                                 const char *input, char *out, size_t out_sz) {
    if (!input || !out || out_sz == 0 || !term) return -1;
    if (input[0] == '/') {
        strncpy(out, input, out_sz - 1);
        out[out_sz - 1] = '\0';
        return 0;
    }
    return resolve_path(term->cwd, input, out, out_sz);
}

struct doorcc_obj_header {
    char magic[8];
    uint32_t version;
    int32_t exit_code;
    uint32_t output_len;
    uint32_t reserved;
} PACKED;

struct doorcc_var {
    char name[32];
    int64_t value;
};

struct doorcc_program {
    char *output;
    size_t out_len;
    size_t out_cap;
    int32_t exit_code;
    bool saw_return;
    struct doorcc_var vars[DOORCC_MAX_VARS];
    int var_count;
};

struct doorcc_expr_parser {
    const char *p;
    const char *end;
    struct doorcc_program *prog;
};

static int doorcc_fail(char *err, size_t err_sz, const char *msg) {
    if (err && err_sz > 0) {
        strncpy(err, msg, err_sz - 1);
        err[err_sz - 1] = '\0';
    }
    return -1;
}

static bool doorcc_is_space(char c) {
    return c == ' ' || c == '\t' || c == '\r' || c == '\n' || c == '\f' || c == '\v';
}

static bool doorcc_is_alpha(char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}

static bool doorcc_is_digit(char c) {
    return c >= '0' && c <= '9';
}

static bool doorcc_is_ident_start(char c) {
    return doorcc_is_alpha(c) || c == '_';
}

static bool doorcc_is_ident_char(char c) {
    return doorcc_is_alpha(c) || doorcc_is_digit(c) || c == '_';
}

static size_t doorcc_align_up(size_t value, size_t align) {
    if (align == 0) return value;
    return (value + align - 1U) & ~(align - 1U);
}

static void doorcc_trim_span(const char **start, const char **end) {
    while (*start < *end && doorcc_is_space(**start)) {
        (*start)++;
    }
    while (*end > *start && doorcc_is_space((*end)[-1])) {
        (*end)--;
    }
}

static void doorcc_skip_ws_comments(const char **pp, const char *end) {
    const char *p = *pp;
    while (p < end) {
        if (doorcc_is_space(*p)) {
            p++;
            continue;
        }

        if ((p + 1) < end && p[0] == '/' && p[1] == '/') {
            p += 2;
            while (p < end && *p != '\n') p++;
            continue;
        }

        if ((p + 1) < end && p[0] == '/' && p[1] == '*') {
            p += 2;
            while ((p + 1) < end && !(p[0] == '*' && p[1] == '/')) p++;
            if ((p + 1) < end) p += 2;
            continue;
        }

        break;
    }
    *pp = p;
}

static int term_read_file_all(const char *path, uint8_t **data_out, size_t *size_out,
                              char *err, size_t err_sz) {
    if (!path || !data_out || !size_out) return doorcc_fail(err, err_sz, "internal read error");

    struct stat st;
    if (vfs_stat(path, &st) < 0 || st.type != VFS_FILE) {
        return doorcc_fail(err, err_sz, "source file not found");
    }

    if (st.size > DOORCC_MAX_SOURCE_BYTES) {
        return doorcc_fail(err, err_sz, "source file too large");
    }

    struct vfs_node *in = vfs_open(path, O_RDONLY);
    if (!in || in->type != VFS_FILE) {
        if (in) vfs_close(in);
        return doorcc_fail(err, err_sz, "cannot open source file");
    }

    size_t alloc_sz = (size_t)st.size + 1U;
    uint8_t *buf = (uint8_t *)kmalloc(alloc_sz);
    if (!buf) {
        vfs_close(in);
        return doorcc_fail(err, err_sz, "out of memory");
    }

    size_t total = 0;
    while (total < (size_t)st.size) {
        ssize_t n = vfs_read(in, buf + total, (size_t)st.size - total);
        if (n < 0) {
            vfs_close(in);
            kfree(buf);
            return doorcc_fail(err, err_sz, "failed to read source file");
        }
        if (n == 0) break;
        total += (size_t)n;
    }
    vfs_close(in);

    buf[total] = '\0';
    *data_out = buf;
    *size_out = total;
    return 0;
}

static int term_write_file_all(const char *path, const uint8_t *data, size_t size,
                               char *err, size_t err_sz) {
    struct vfs_node *out = vfs_open(path, O_CREAT | O_TRUNC | O_RDWR);
    if (!out || out->type != VFS_FILE) {
        if (out) vfs_close(out);
        return doorcc_fail(err, err_sz, "cannot create output file");
    }

    size_t total = 0;
    while (total < size) {
        ssize_t n = vfs_write(out, data + total, size - total);
        if (n <= 0) {
            vfs_close(out);
            return doorcc_fail(err, err_sz, "failed to write output file");
        }
        total += (size_t)n;
    }

    vfs_close(out);
    return 0;
}

static int doorcc_append_bytes(struct doorcc_program *prog, const uint8_t *data, size_t len) {
    if (!prog || !data || len == 0) return 0;
    if (prog->out_len + len > DOORCC_MAX_OUTPUT_BYTES) return -1;

    size_t need = prog->out_len + len;
    if (need > prog->out_cap) {
        size_t new_cap = prog->out_cap ? prog->out_cap : 256;
        while (new_cap < need) {
            new_cap *= 2;
            if (new_cap > DOORCC_MAX_OUTPUT_BYTES) {
                new_cap = DOORCC_MAX_OUTPUT_BYTES;
                break;
            }
        }
        if (new_cap < need) return -1;

        char *new_buf = (char *)krealloc(prog->output, new_cap);
        if (!new_buf) return -1;
        prog->output = new_buf;
        prog->out_cap = new_cap;
    }

    memcpy(prog->output + prog->out_len, data, len);
    prog->out_len += len;
    return 0;
}

static int doorcc_append_cstr(struct doorcc_program *prog, const char *s) {
    if (!s) return 0;
    return doorcc_append_bytes(prog, (const uint8_t *)s, strlen(s));
}

static int doorcc_append_char(struct doorcc_program *prog, char ch) {
    return doorcc_append_bytes(prog, (const uint8_t *)&ch, 1);
}

static int doorcc_find_var(struct doorcc_program *prog, const char *name) {
    if (!prog || !name) return -1;
    for (int i = 0; i < prog->var_count; i++) {
        if (strcmp(prog->vars[i].name, name) == 0) return i;
    }
    return -1;
}

static int doorcc_set_var(struct doorcc_program *prog, const char *name, int64_t value) {
    int idx = doorcc_find_var(prog, name);
    if (idx >= 0) {
        prog->vars[idx].value = value;
        return 0;
    }

    if (prog->var_count >= DOORCC_MAX_VARS) return -1;
    idx = prog->var_count++;
    strncpy(prog->vars[idx].name, name, sizeof(prog->vars[idx].name) - 1);
    prog->vars[idx].name[sizeof(prog->vars[idx].name) - 1] = '\0';
    prog->vars[idx].value = value;
    return 0;
}

static int doorcc_get_var(struct doorcc_program *prog, const char *name, int64_t *value_out) {
    int idx = doorcc_find_var(prog, name);
    if (idx < 0) return -1;
    if (value_out) *value_out = prog->vars[idx].value;
    return 0;
}

static int doorcc_hex_value(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

static int doorcc_parse_escape(const char **pp, const char *end, char *out_ch) {
    if (!pp || !*pp || !out_ch || *pp >= end) return -1;
    const char *p = *pp;
    char ch = *p++;

    switch (ch) {
        case 'n': *out_ch = '\n'; break;
        case 'r': *out_ch = '\r'; break;
        case 't': *out_ch = '\t'; break;
        case '\\': *out_ch = '\\'; break;
        case '\'': *out_ch = '\''; break;
        case '"': *out_ch = '"'; break;
        case '0': *out_ch = '\0'; break;
        case 'x': {
            int hi = -1;
            int lo = -1;
            if (p < end) hi = doorcc_hex_value(*p++);
            if (p < end) lo = doorcc_hex_value(*p++);
            if (hi < 0 || lo < 0) return -1;
            *out_ch = (char)((hi << 4) | lo);
            break;
        }
        default:
            *out_ch = ch;
            break;
    }

    *pp = p;
    return 0;
}

static int doorcc_parse_char_literal(const char **pp, const char *end, int64_t *value_out) {
    if (!pp || !*pp || !value_out) return -1;
    const char *p = *pp;
    if (p >= end || *p != '\'') return -1;
    p++;
    if (p >= end) return -1;

    char value = 0;
    if (*p == '\\') {
        p++;
        if (doorcc_parse_escape(&p, end, &value) < 0) return -1;
    } else {
        value = *p++;
    }

    if (p >= end || *p != '\'') return -1;
    p++;

    *pp = p;
    *value_out = (int64_t)(unsigned char)value;
    return 0;
}

static int doorcc_parse_identifier(const char **pp, const char *end,
                                   char *name_out, size_t name_out_sz) {
    if (!pp || !*pp || !name_out || name_out_sz == 0) return -1;
    const char *p = *pp;
    if (p >= end || !doorcc_is_ident_start(*p)) return -1;

    size_t len = 0;
    while (p < end && doorcc_is_ident_char(*p)) {
        if (len + 1 >= name_out_sz) return -1;
        name_out[len++] = *p++;
    }
    name_out[len] = '\0';
    *pp = p;
    return 0;
}

static int doorcc_parse_int_literal(const char **pp, const char *end, int64_t *value_out) {
    const char *p = *pp;
    if (p >= end) return -1;

    int base = 10;
    if ((p + 1) < end && p[0] == '0' && (p[1] == 'x' || p[1] == 'X')) {
        base = 16;
        p += 2;
    }

    int64_t value = 0;
    bool saw_digit = false;
    while (p < end) {
        int digit = -1;
        if (base == 16) {
            digit = doorcc_hex_value(*p);
        } else if (doorcc_is_digit(*p)) {
            digit = *p - '0';
        }

        if (digit < 0 || digit >= base) break;
        value = value * base + digit;
        saw_digit = true;
        p++;
    }

    if (!saw_digit) return -1;
    *pp = p;
    *value_out = value;
    return 0;
}

static void doorcc_expr_skip_ws(struct doorcc_expr_parser *ps) {
    while (ps->p < ps->end && doorcc_is_space(*ps->p)) ps->p++;
}

static int doorcc_parse_expr_addsub(struct doorcc_expr_parser *ps, int64_t *value_out);

static int doorcc_parse_expr_primary(struct doorcc_expr_parser *ps, int64_t *value_out) {
    doorcc_expr_skip_ws(ps);
    if (ps->p >= ps->end) return -1;

    if (*ps->p == '(') {
        ps->p++;
        int64_t value = 0;
        if (doorcc_parse_expr_addsub(ps, &value) < 0) return -1;
        doorcc_expr_skip_ws(ps);
        if (ps->p >= ps->end || *ps->p != ')') return -1;
        ps->p++;
        *value_out = value;
        return 0;
    }

    if (*ps->p == '\'') {
        int64_t value = 0;
        if (doorcc_parse_char_literal(&ps->p, ps->end, &value) < 0) return -1;
        *value_out = value;
        return 0;
    }

    if (doorcc_is_digit(*ps->p)) {
        int64_t value = 0;
        if (doorcc_parse_int_literal(&ps->p, ps->end, &value) < 0) return -1;
        *value_out = value;
        return 0;
    }

    if (doorcc_is_ident_start(*ps->p)) {
        char ident[32];
        if (doorcc_parse_identifier(&ps->p, ps->end, ident, sizeof(ident)) < 0) return -1;
        int64_t value = 0;
        if (doorcc_get_var(ps->prog, ident, &value) < 0) return -1;
        *value_out = value;
        return 0;
    }

    return -1;
}

static int doorcc_parse_expr_unary(struct doorcc_expr_parser *ps, int64_t *value_out) {
    doorcc_expr_skip_ws(ps);
    int sign = 1;
    while (ps->p < ps->end && (*ps->p == '+' || *ps->p == '-')) {
        if (*ps->p == '-') sign = -sign;
        ps->p++;
        doorcc_expr_skip_ws(ps);
    }

    int64_t value = 0;
    if (doorcc_parse_expr_primary(ps, &value) < 0) return -1;
    *value_out = sign > 0 ? value : -value;
    return 0;
}

static int doorcc_parse_expr_muldiv(struct doorcc_expr_parser *ps, int64_t *value_out) {
    int64_t lhs = 0;
    if (doorcc_parse_expr_unary(ps, &lhs) < 0) return -1;

    while (1) {
        doorcc_expr_skip_ws(ps);
        if (ps->p >= ps->end) break;

        char op = *ps->p;
        if (op != '*' && op != '/' && op != '%') break;
        ps->p++;

        int64_t rhs = 0;
        if (doorcc_parse_expr_unary(ps, &rhs) < 0) return -1;
        if ((op == '/' || op == '%') && rhs == 0) return -1;

        if (op == '*') lhs *= rhs;
        else if (op == '/') lhs /= rhs;
        else lhs %= rhs;
    }

    *value_out = lhs;
    return 0;
}

static int doorcc_parse_expr_addsub(struct doorcc_expr_parser *ps, int64_t *value_out) {
    int64_t lhs = 0;
    if (doorcc_parse_expr_muldiv(ps, &lhs) < 0) return -1;

    while (1) {
        doorcc_expr_skip_ws(ps);
        if (ps->p >= ps->end) break;

        char op = *ps->p;
        if (op != '+' && op != '-') break;
        ps->p++;

        int64_t rhs = 0;
        if (doorcc_parse_expr_muldiv(ps, &rhs) < 0) return -1;
        if (op == '+') lhs += rhs;
        else lhs -= rhs;
    }

    *value_out = lhs;
    return 0;
}

static int doorcc_eval_expr_span(struct doorcc_program *prog, const char *start,
                                 const char *end, int64_t *value_out) {
    struct doorcc_expr_parser ps = {
        .p = start,
        .end = end,
        .prog = prog,
    };

    int64_t value = 0;
    if (doorcc_parse_expr_addsub(&ps, &value) < 0) return -1;
    doorcc_expr_skip_ws(&ps);
    if (ps.p != ps.end) return -1;
    *value_out = value;
    return 0;
}

static int doorcc_decode_string_literal(const char *start, const char *end,
                                        char *out, size_t out_cap, size_t *out_len) {
    if (!out || out_cap == 0) return -1;

    const char *p = start;
    const char *q = end;
    doorcc_trim_span(&p, &q);
    if (p >= q || *p != '"') return -1;
    p++;

    size_t len = 0;
    while (p < q) {
        if (*p == '"') {
            p++;
            break;
        }

        char ch = 0;
        if (*p == '\\') {
            p++;
            if (doorcc_parse_escape(&p, q, &ch) < 0) return -1;
        } else {
            ch = *p++;
        }

        if (len + 1 >= out_cap) return -1;
        out[len++] = ch;
    }

    while (p < q && doorcc_is_space(*p)) p++;
    if (p != q) return -1;

    out[len] = '\0';
    if (out_len) *out_len = len;
    return 0;
}

static int doorcc_split_args(const char *args_start, const char *args_end,
                             const char **arg_start, const char **arg_end, int max_args) {
    if (!arg_start || !arg_end || max_args <= 0) return -1;
    if (args_start > args_end) return -1;

    int argc = 0;
    const char *cur = args_start;
    const char *p = args_start;
    int paren_depth = 0;
    bool in_str = false;
    bool in_chr = false;
    bool escape = false;

    while (p < args_end) {
        char ch = *p;

        if (in_str) {
            if (escape) {
                escape = false;
            } else if (ch == '\\') {
                escape = true;
            } else if (ch == '"') {
                in_str = false;
            }
            p++;
            continue;
        }

        if (in_chr) {
            if (escape) {
                escape = false;
            } else if (ch == '\\') {
                escape = true;
            } else if (ch == '\'') {
                in_chr = false;
            }
            p++;
            continue;
        }

        if (ch == '"') {
            in_str = true;
            p++;
            continue;
        }
        if (ch == '\'') {
            in_chr = true;
            p++;
            continue;
        }
        if (ch == '(') {
            paren_depth++;
            p++;
            continue;
        }
        if (ch == ')') {
            if (paren_depth > 0) paren_depth--;
            p++;
            continue;
        }

        if (ch == ',' && paren_depth == 0) {
            if (argc >= max_args) return -1;
            arg_start[argc] = cur;
            arg_end[argc] = p;
            argc++;
            p++;
            cur = p;
            continue;
        }

        p++;
    }

    if (argc >= max_args) return -1;
    arg_start[argc] = cur;
    arg_end[argc] = args_end;
    argc++;

    for (int i = 0; i < argc; i++) {
        const char *s = arg_start[i];
        const char *e = arg_end[i];
        doorcc_trim_span(&s, &e);
        arg_start[i] = s;
        arg_end[i] = e;
    }

    if (argc == 1 && arg_start[0] == arg_end[0]) return 0;
    return argc;
}

static int doorcc_extract_call_args(const char *stmt_start, const char *stmt_end,
                                    const char *name,
                                    const char **args_start, const char **args_end) {
    size_t name_len = strlen(name);
    if ((size_t)(stmt_end - stmt_start) < name_len + 2U) return -1;
    if (strncmp(stmt_start, name, name_len) != 0) return -1;
    if ((stmt_start + name_len) < stmt_end && doorcc_is_ident_char(stmt_start[name_len])) return -1;

    const char *p = stmt_start + name_len;
    while (p < stmt_end && doorcc_is_space(*p)) p++;
    if (p >= stmt_end || *p != '(') return -1;
    p++;
    const char *a_start = p;

    int depth = 1;
    bool in_str = false;
    bool in_chr = false;
    bool escape = false;
    while (p < stmt_end) {
        char ch = *p;
        if (in_str) {
            if (escape) {
                escape = false;
            } else if (ch == '\\') {
                escape = true;
            } else if (ch == '"') {
                in_str = false;
            }
            p++;
            continue;
        }
        if (in_chr) {
            if (escape) {
                escape = false;
            } else if (ch == '\\') {
                escape = true;
            } else if (ch == '\'') {
                in_chr = false;
            }
            p++;
            continue;
        }

        if (ch == '"') {
            in_str = true;
            p++;
            continue;
        }
        if (ch == '\'') {
            in_chr = true;
            p++;
            continue;
        }
        if (ch == '(') {
            depth++;
            p++;
            continue;
        }
        if (ch == ')') {
            depth--;
            if (depth == 0) break;
            p++;
            continue;
        }
        p++;
    }

    if (p >= stmt_end || *p != ')') return -1;
    const char *a_end = p;
    p++;
    while (p < stmt_end && doorcc_is_space(*p)) p++;
    if (p != stmt_end) return -1;

    *args_start = a_start;
    *args_end = a_end;
    return 0;
}

static int doorcc_append_formatted_int(struct doorcc_program *prog, int64_t value, char spec) {
    char tmp[64];
    if (spec == 'd' || spec == 'i') {
        snprintf(tmp, sizeof(tmp), "%lld", (long long)value);
    } else if (spec == 'u') {
        snprintf(tmp, sizeof(tmp), "%llu", (unsigned long long)value);
    } else if (spec == 'x') {
        snprintf(tmp, sizeof(tmp), "%llx", (unsigned long long)value);
    } else if (spec == 'X') {
        snprintf(tmp, sizeof(tmp), "%llX", (unsigned long long)value);
    } else {
        return -1;
    }
    return doorcc_append_cstr(prog, tmp);
}

static int doorcc_handle_printf(struct doorcc_program *prog, const char *stmt_start,
                                const char *stmt_end, char *err, size_t err_sz) {
    const char *args_start = NULL;
    const char *args_end = NULL;
    if (doorcc_extract_call_args(stmt_start, stmt_end, "printf", &args_start, &args_end) < 0) {
        return -1;
    }

    const char *arg_s[DOORCC_MAX_ARGS];
    const char *arg_e[DOORCC_MAX_ARGS];
    int argc = doorcc_split_args(args_start, args_end, arg_s, arg_e, DOORCC_MAX_ARGS);
    if (argc <= 0) return doorcc_fail(err, err_sz, "printf requires at least one argument");

    size_t fmt_cap = (size_t)(arg_e[0] - arg_s[0]) + 1U;
    char *fmt = (char *)kmalloc(fmt_cap);
    if (!fmt) return doorcc_fail(err, err_sz, "out of memory");

    size_t fmt_len = 0;
    int rc = doorcc_decode_string_literal(arg_s[0], arg_e[0], fmt, fmt_cap, &fmt_len);
    if (rc < 0) {
        kfree(fmt);
        return doorcc_fail(err, err_sz, "printf format must be a string literal");
    }

    int argi = 1;
    for (size_t i = 0; i < fmt_len; i++) {
        char ch = fmt[i];
        if (ch != '%') {
            if (doorcc_append_char(prog, ch) < 0) {
                kfree(fmt);
                return doorcc_fail(err, err_sz, "compiled output too large");
            }
            continue;
        }

        if (i + 1 >= fmt_len) {
            kfree(fmt);
            return doorcc_fail(err, err_sz, "unterminated '%' in printf format");
        }

        size_t j = i + 1;
        if (fmt[j] == '%') {
            if (doorcc_append_char(prog, '%') < 0) {
                kfree(fmt);
                return doorcc_fail(err, err_sz, "compiled output too large");
            }
            i = j;
            continue;
        }

        while (j < fmt_len && fmt[j] == 'l') j++;
        if (j >= fmt_len) {
            kfree(fmt);
            return doorcc_fail(err, err_sz, "invalid printf format");
        }

        if (argi >= argc) {
            kfree(fmt);
            return doorcc_fail(err, err_sz, "missing printf argument");
        }

        char spec = fmt[j];
        if (spec == 'd' || spec == 'i' || spec == 'u' || spec == 'x' || spec == 'X' || spec == 'c') {
            int64_t value = 0;
            if (doorcc_eval_expr_span(prog, arg_s[argi], arg_e[argi], &value) < 0) {
                kfree(fmt);
                return doorcc_fail(err, err_sz, "printf only supports constant integer arguments");
            }

            if (spec == 'c') {
                if (doorcc_append_char(prog, (char)value) < 0) {
                    kfree(fmt);
                    return doorcc_fail(err, err_sz, "compiled output too large");
                }
            } else if (doorcc_append_formatted_int(prog, value, spec) < 0) {
                kfree(fmt);
                return doorcc_fail(err, err_sz, "unsupported printf format");
            }
        } else if (spec == 's') {
            size_t str_cap = (size_t)(arg_e[argi] - arg_s[argi]) + 1U;
            char *tmp = (char *)kmalloc(str_cap);
            if (!tmp) {
                kfree(fmt);
                return doorcc_fail(err, err_sz, "out of memory");
            }
            size_t tmp_len = 0;
            if (doorcc_decode_string_literal(arg_s[argi], arg_e[argi], tmp, str_cap, &tmp_len) < 0) {
                kfree(tmp);
                kfree(fmt);
                return doorcc_fail(err, err_sz, "printf %s requires a string literal");
            }
            if (doorcc_append_bytes(prog, (const uint8_t *)tmp, tmp_len) < 0) {
                kfree(tmp);
                kfree(fmt);
                return doorcc_fail(err, err_sz, "compiled output too large");
            }
            kfree(tmp);
        } else {
            kfree(fmt);
            return doorcc_fail(err, err_sz, "unsupported printf format specifier");
        }

        argi++;
        i = j;
    }

    kfree(fmt);
    if (argi != argc) return doorcc_fail(err, err_sz, "too many printf arguments");
    return 0;
}

static int doorcc_handle_puts(struct doorcc_program *prog, const char *stmt_start,
                              const char *stmt_end, char *err, size_t err_sz) {
    const char *args_start = NULL;
    const char *args_end = NULL;
    if (doorcc_extract_call_args(stmt_start, stmt_end, "puts", &args_start, &args_end) < 0) {
        return -1;
    }

    const char *arg_s[DOORCC_MAX_ARGS];
    const char *arg_e[DOORCC_MAX_ARGS];
    int argc = doorcc_split_args(args_start, args_end, arg_s, arg_e, DOORCC_MAX_ARGS);
    if (argc != 1) return doorcc_fail(err, err_sz, "puts expects one argument");

    size_t cap = (size_t)(arg_e[0] - arg_s[0]) + 1U;
    char *tmp = (char *)kmalloc(cap);
    if (!tmp) return doorcc_fail(err, err_sz, "out of memory");

    size_t len = 0;
    if (doorcc_decode_string_literal(arg_s[0], arg_e[0], tmp, cap, &len) < 0) {
        kfree(tmp);
        return doorcc_fail(err, err_sz, "puts argument must be a string literal");
    }

    int rc = 0;
    if (doorcc_append_bytes(prog, (const uint8_t *)tmp, len) < 0 ||
        doorcc_append_char(prog, '\n') < 0) {
        rc = doorcc_fail(err, err_sz, "compiled output too large");
    }

    kfree(tmp);
    return rc;
}

static int doorcc_handle_putchar(struct doorcc_program *prog, const char *stmt_start,
                                 const char *stmt_end, char *err, size_t err_sz) {
    const char *args_start = NULL;
    const char *args_end = NULL;
    if (doorcc_extract_call_args(stmt_start, stmt_end, "putchar", &args_start, &args_end) < 0) {
        return -1;
    }

    const char *arg_s[DOORCC_MAX_ARGS];
    const char *arg_e[DOORCC_MAX_ARGS];
    int argc = doorcc_split_args(args_start, args_end, arg_s, arg_e, DOORCC_MAX_ARGS);
    if (argc != 1) return doorcc_fail(err, err_sz, "putchar expects one argument");

    int64_t value = 0;
    if (doorcc_eval_expr_span(prog, arg_s[0], arg_e[0], &value) < 0) {
        return doorcc_fail(err, err_sz, "putchar only supports constant expressions");
    }

    if (doorcc_append_char(prog, (char)value) < 0) {
        return doorcc_fail(err, err_sz, "compiled output too large");
    }
    return 0;
}

static bool doorcc_starts_with_keyword(const char *stmt_start, const char *stmt_end,
                                       const char *kw) {
    size_t kw_len = strlen(kw);
    if ((size_t)(stmt_end - stmt_start) < kw_len) return false;
    if (strncmp(stmt_start, kw, kw_len) != 0) return false;
    if ((stmt_start + kw_len) < stmt_end && doorcc_is_ident_char(stmt_start[kw_len])) return false;
    return true;
}

static int doorcc_handle_return(struct doorcc_program *prog, const char *stmt_start,
                                const char *stmt_end, char *err, size_t err_sz) {
    const char *p = stmt_start + strlen("return");
    doorcc_trim_span(&p, &stmt_end);
    int64_t value = 0;
    if (p < stmt_end && doorcc_eval_expr_span(prog, p, stmt_end, &value) < 0) {
        return doorcc_fail(err, err_sz, "return expects a constant expression");
    }

    prog->exit_code = (int32_t)value;
    prog->saw_return = true;
    return 0;
}

static int doorcc_handle_var_decl(struct doorcc_program *prog, const char *stmt_start,
                                  const char *stmt_end, char *err, size_t err_sz) {
    if (!doorcc_starts_with_keyword(stmt_start, stmt_end, "int")) return -1;

    const char *p = stmt_start + 3;
    while (p < stmt_end && doorcc_is_space(*p)) p++;

    char ident[32];
    if (doorcc_parse_identifier(&p, stmt_end, ident, sizeof(ident)) < 0) {
        return doorcc_fail(err, err_sz, "invalid int declaration");
    }

    while (p < stmt_end && doorcc_is_space(*p)) p++;
    int64_t value = 0;
    if (p < stmt_end) {
        if (*p != '=') return doorcc_fail(err, err_sz, "invalid int declaration");
        p++;
        if (doorcc_eval_expr_span(prog, p, stmt_end, &value) < 0) {
            return doorcc_fail(err, err_sz, "int declaration must use constant expression");
        }
    }

    if (doorcc_set_var(prog, ident, value) < 0) {
        return doorcc_fail(err, err_sz, "too many local variables");
    }
    return 0;
}

static int doorcc_handle_assignment(struct doorcc_program *prog, const char *stmt_start,
                                    const char *stmt_end, char *err, size_t err_sz) {
    const char *p = stmt_start;
    char ident[32];
    if (doorcc_parse_identifier(&p, stmt_end, ident, sizeof(ident)) < 0) return -1;

    while (p < stmt_end && doorcc_is_space(*p)) p++;
    if (p >= stmt_end || *p != '=') return -1;
    p++;

    int64_t value = 0;
    if (doorcc_eval_expr_span(prog, p, stmt_end, &value) < 0) {
        return doorcc_fail(err, err_sz, "assignment must use constant expression");
    }

    if (doorcc_set_var(prog, ident, value) < 0) {
        return doorcc_fail(err, err_sz, "too many local variables");
    }
    return 0;
}

static int doorcc_process_statement(struct doorcc_program *prog, const char *stmt_start,
                                    const char *stmt_end, char *err, size_t err_sz) {
    doorcc_trim_span(&stmt_start, &stmt_end);
    if (stmt_start >= stmt_end) return 0;

    if (doorcc_handle_printf(prog, stmt_start, stmt_end, err, err_sz) == 0) return 0;
    if (doorcc_handle_puts(prog, stmt_start, stmt_end, err, err_sz) == 0) return 0;
    if (doorcc_handle_putchar(prog, stmt_start, stmt_end, err, err_sz) == 0) return 0;

    if (doorcc_starts_with_keyword(stmt_start, stmt_end, "return")) {
        return doorcc_handle_return(prog, stmt_start, stmt_end, err, err_sz);
    }

    if (doorcc_handle_var_decl(prog, stmt_start, stmt_end, err, err_sz) == 0) return 0;
    if (doorcc_handle_assignment(prog, stmt_start, stmt_end, err, err_sz) == 0) return 0;

    return doorcc_fail(err, err_sz, "unsupported C statement in main()");
}

static void doorcc_skip_quoted(const char **pp, const char *end, char quote) {
    const char *p = *pp;
    if (p >= end || *p != quote) return;
    p++;
    bool escape = false;
    while (p < end) {
        char ch = *p++;
        if (escape) {
            escape = false;
            continue;
        }
        if (ch == '\\') {
            escape = true;
            continue;
        }
        if (ch == quote) break;
    }
    *pp = p;
}

static int doorcc_find_main_body(const char *src, size_t src_len,
                                 const char **body_start, const char **body_end) {
    const char *p = src;
    const char *end = src + src_len;

    while ((p + 4) <= end) {
        if ((p + 1) < end && p[0] == '/' && p[1] == '/') {
            p += 2;
            while (p < end && *p != '\n') p++;
            continue;
        }
        if ((p + 1) < end && p[0] == '/' && p[1] == '*') {
            p += 2;
            while ((p + 1) < end && !(p[0] == '*' && p[1] == '/')) p++;
            if ((p + 1) < end) p += 2;
            continue;
        }
        if (*p == '"' || *p == '\'') {
            char q = *p;
            doorcc_skip_quoted(&p, end, q);
            continue;
        }

        if ((p + 4) <= end && strncmp(p, "main", 4) == 0) {
            bool left_ok = (p == src) || !doorcc_is_ident_char(p[-1]);
            bool right_ok = (p + 4 >= end) || !doorcc_is_ident_char(p[4]);
            if (left_ok && right_ok) {
                const char *q = p + 4;
                doorcc_skip_ws_comments(&q, end);
                if (q >= end || *q != '(') {
                    p++;
                    continue;
                }

                q++;
                int paren_depth = 1;
                while (q < end && paren_depth > 0) {
                    if (*q == '"' || *q == '\'') {
                        char quote = *q;
                        doorcc_skip_quoted(&q, end, quote);
                        continue;
                    }
                    if ((q + 1) < end && q[0] == '/' && q[1] == '/') {
                        q += 2;
                        while (q < end && *q != '\n') q++;
                        continue;
                    }
                    if ((q + 1) < end && q[0] == '/' && q[1] == '*') {
                        q += 2;
                        while ((q + 1) < end && !(q[0] == '*' && q[1] == '/')) q++;
                        if ((q + 1) < end) q += 2;
                        continue;
                    }
                    if (*q == '(') paren_depth++;
                    else if (*q == ')') paren_depth--;
                    q++;
                }
                if (paren_depth != 0) return -1;

                doorcc_skip_ws_comments(&q, end);
                if (q >= end || *q != '{') {
                    p++;
                    continue;
                }

                const char *body = q + 1;
                q++;
                int brace_depth = 1;
                while (q < end && brace_depth > 0) {
                    if (*q == '"' || *q == '\'') {
                        char quote = *q;
                        doorcc_skip_quoted(&q, end, quote);
                        continue;
                    }
                    if ((q + 1) < end && q[0] == '/' && q[1] == '/') {
                        q += 2;
                        while (q < end && *q != '\n') q++;
                        continue;
                    }
                    if ((q + 1) < end && q[0] == '/' && q[1] == '*') {
                        q += 2;
                        while ((q + 1) < end && !(q[0] == '*' && q[1] == '/')) q++;
                        if ((q + 1) < end) q += 2;
                        continue;
                    }
                    if (*q == '{') brace_depth++;
                    else if (*q == '}') brace_depth--;
                    q++;
                }
                if (brace_depth != 0) return -1;

                *body_start = body;
                *body_end = q - 1;
                return 0;
            }
        }

        p++;
    }
    return -1;
}

static int doorcc_compile_source(const char *src, size_t src_len,
                                 uint8_t **output_out, size_t *output_len_out,
                                 int32_t *exit_code_out, char *err, size_t err_sz) {
    if (!src || !output_out || !output_len_out || !exit_code_out) {
        return doorcc_fail(err, err_sz, "internal compiler error");
    }

    struct doorcc_program prog;
    memset(&prog, 0, sizeof(prog));
    prog.exit_code = 0;

    const char *body_start = NULL;
    const char *body_end = NULL;
    if (doorcc_find_main_body(src, src_len, &body_start, &body_end) < 0) {
        return doorcc_fail(err, err_sz, "expected int main(...) { ... }");
    }

    const char *p = body_start;
    while (p < body_end) {
        doorcc_skip_ws_comments(&p, body_end);
        if (p >= body_end) break;

        const char *stmt_start = p;
        int paren_depth = 0;
        bool in_str = false;
        bool in_chr = false;
        bool escape = false;
        bool found_semi = false;

        while (p < body_end) {
            char ch = *p;
            if (in_str) {
                if (escape) escape = false;
                else if (ch == '\\') escape = true;
                else if (ch == '"') in_str = false;
                p++;
                continue;
            }
            if (in_chr) {
                if (escape) escape = false;
                else if (ch == '\\') escape = true;
                else if (ch == '\'') in_chr = false;
                p++;
                continue;
            }
            if ((p + 1) < body_end && p[0] == '/' && p[1] == '/') {
                p += 2;
                while (p < body_end && *p != '\n') p++;
                continue;
            }
            if ((p + 1) < body_end && p[0] == '/' && p[1] == '*') {
                p += 2;
                while ((p + 1) < body_end && !(p[0] == '*' && p[1] == '/')) p++;
                if ((p + 1) < body_end) p += 2;
                continue;
            }
            if (ch == '"') {
                in_str = true;
                p++;
                continue;
            }
            if (ch == '\'') {
                in_chr = true;
                p++;
                continue;
            }
            if (ch == '(') {
                paren_depth++;
                p++;
                continue;
            }
            if (ch == ')') {
                if (paren_depth > 0) paren_depth--;
                p++;
                continue;
            }
            if ((ch == '{' || ch == '}') && paren_depth == 0) {
                if (prog.output) kfree(prog.output);
                return doorcc_fail(err, err_sz, "control flow blocks are not supported yet");
            }
            if (ch == ';' && paren_depth == 0) {
                found_semi = true;
                break;
            }
            p++;
        }

        if (!found_semi) {
            if (prog.output) kfree(prog.output);
            return doorcc_fail(err, err_sz, "missing ';' in main()");
        }

        const char *stmt_end = p;
        p++; // consume ';'

        if (doorcc_process_statement(&prog, stmt_start, stmt_end, err, err_sz) < 0) {
            if (prog.output) kfree(prog.output);
            return -1;
        }
    }

    if (!prog.output) {
        prog.output = (char *)kmalloc(1);
        if (!prog.output) return doorcc_fail(err, err_sz, "out of memory");
        prog.output[0] = '\0';
    }

    *output_out = (uint8_t *)prog.output;
    *output_len_out = prog.out_len;
    *exit_code_out = prog.exit_code;
    return 0;
}

static int term_write_doorobj(const char *dst_path, const uint8_t *compiled_out, size_t out_len,
                              int32_t exit_code, char *err, size_t err_sz) {
    size_t total = sizeof(struct doorcc_obj_header) + out_len;
    uint8_t *buf = (uint8_t *)kmalloc(total ? total : 1);
    if (!buf) return doorcc_fail(err, err_sz, "out of memory");

    struct doorcc_obj_header hdr;
    memset(&hdr, 0, sizeof(hdr));
    memcpy(hdr.magic, DOORCC_OBJ_MAGIC, 8);
    hdr.version = DOORCC_OBJ_VERSION;
    hdr.exit_code = exit_code;
    hdr.output_len = (uint32_t)out_len;
    memcpy(buf, &hdr, sizeof(hdr));
    if (out_len > 0) memcpy(buf + sizeof(hdr), compiled_out, out_len);

    int rc = term_write_file_all(dst_path, buf, total, err, err_sz);
    kfree(buf);
    return rc;
}

static const uint8_t *doorcc_find_bytes(const uint8_t *haystack, size_t hay_len,
                                        const char *needle, size_t needle_len) {
    if (!haystack || !needle || needle_len == 0 || hay_len < needle_len) return NULL;
    for (size_t i = 0; i + needle_len <= hay_len; i++) {
        if (memcmp(haystack + i, needle, needle_len) == 0) return haystack + i;
    }
    return NULL;
}

static int term_read_doorobj(const char *src_path, uint8_t **compiled_out, size_t *out_len,
                             int32_t *exit_code, char *err, size_t err_sz) {
    uint8_t *raw = NULL;
    size_t raw_len = 0;
    if (term_read_file_all(src_path, &raw, &raw_len, err, err_sz) < 0) return -1;

    if (raw_len >= sizeof(struct doorcc_obj_header)) {
        struct doorcc_obj_header hdr;
        memcpy(&hdr, raw, sizeof(hdr));
        if (memcmp(hdr.magic, DOORCC_OBJ_MAGIC, 8) == 0) {
            size_t expect = sizeof(struct doorcc_obj_header) + (size_t)hdr.output_len;
            if (expect > raw_len) {
                kfree(raw);
                return doorcc_fail(err, err_sz, "object file is truncated");
            }

            uint8_t *payload = (uint8_t *)kmalloc((size_t)hdr.output_len ? (size_t)hdr.output_len : 1);
            if (!payload) {
                kfree(raw);
                return doorcc_fail(err, err_sz, "out of memory");
            }

            if (hdr.output_len > 0) {
                memcpy(payload, raw + sizeof(struct doorcc_obj_header), (size_t)hdr.output_len);
            }
            kfree(raw);

            *compiled_out = payload;
            *out_len = (size_t)hdr.output_len;
            *exit_code = hdr.exit_code;
            return 0;
        }
    }

    if (raw_len >= 9 && memcmp(raw, "DOOROBJ1\n", 8) == 0) {
        const uint8_t *sep = doorcc_find_bytes(raw, raw_len, "\n---\n", 5);
        if (!sep) {
            kfree(raw);
            return doorcc_fail(err, err_sz, "legacy object file is malformed");
        }
        const char *legacy_src = (const char *)(sep + 5);
        size_t legacy_len = raw_len - (size_t)((sep + 5) - raw);

        uint8_t *compiled = NULL;
        size_t compiled_len = 0;
        int32_t code = 0;
        int rc = doorcc_compile_source(legacy_src, legacy_len, &compiled, &compiled_len, &code, err, err_sz);
        kfree(raw);
        if (rc < 0) return rc;

        *compiled_out = compiled;
        *out_len = compiled_len;
        *exit_code = code;
        return 0;
    }

    kfree(raw);
    return doorcc_fail(err, err_sz, "unsupported object format");
}

static void doorcc_write_u32(uint8_t *dst, uint32_t value) {
    memcpy(dst, &value, sizeof(value));
}

static int term_write_compiled_elf(const char *dst_path, const uint8_t *compiled_out,
                                   size_t out_len, int32_t exit_code,
                                   char *err, size_t err_sz) {
    if (!compiled_out && out_len != 0) return doorcc_fail(err, err_sz, "internal codegen error");

    // mov eax, SYS_WRITE
    // mov edi, 1
    // lea rsi, [rip + msg]
    // mov edx, msg_len
    // syscall
    // mov eax, SYS_EXIT
    // mov edi, exit_code
    // syscall
    // jmp $
    uint8_t code[64];
    size_t code_len = 0;

    code[code_len++] = 0xB8;
    doorcc_write_u32(code + code_len, (uint32_t)SYS_WRITE);
    code_len += 4;

    code[code_len++] = 0xBF;
    doorcc_write_u32(code + code_len, 1);
    code_len += 4;

    code[code_len++] = 0x48;
    code[code_len++] = 0x8D;
    code[code_len++] = 0x35;
    size_t lea_disp_off = code_len;
    doorcc_write_u32(code + code_len, 0);
    code_len += 4;

    code[code_len++] = 0xBA;
    doorcc_write_u32(code + code_len, (uint32_t)out_len);
    code_len += 4;

    code[code_len++] = 0x0F;
    code[code_len++] = 0x05;

    code[code_len++] = 0xB8;
    doorcc_write_u32(code + code_len, (uint32_t)SYS_EXIT);
    code_len += 4;

    code[code_len++] = 0xBF;
    doorcc_write_u32(code + code_len, (uint32_t)exit_code);
    code_len += 4;

    code[code_len++] = 0x0F;
    code[code_len++] = 0x05;

    code[code_len++] = 0xEB;
    code[code_len++] = 0xFE;

    const uint64_t image_base = 0x400000ULL;
    size_t code_off = doorcc_align_up(sizeof(struct elf64_header) + sizeof(struct elf64_phdr), 16);
    size_t data_off = doorcc_align_up(code_off + code_len, 16);
    size_t file_size = data_off + out_len;

    int64_t rel = (int64_t)data_off - (int64_t)(code_off + lea_disp_off + 4U);
    if (rel < -2147483648LL || rel > 2147483647LL) {
        return doorcc_fail(err, err_sz, "internal codegen relocation error");
    }
    doorcc_write_u32(code + lea_disp_off, (uint32_t)(int32_t)rel);

    uint8_t *img = (uint8_t *)kmalloc(file_size ? file_size : 1);
    if (!img) return doorcc_fail(err, err_sz, "out of memory");
    memset(img, 0, file_size);

    struct elf64_header ehdr;
    memset(&ehdr, 0, sizeof(ehdr));
    ehdr.magic = ELF_MAGIC;
    ehdr.class = 2;
    ehdr.encoding = 1;
    ehdr.version = 1;
    ehdr.os_abi = 0;
    ehdr.padding = 0;
    ehdr.type = ET_EXEC;
    ehdr.machine = EM_X86_64;
    ehdr.elf_version = 1;
    ehdr.entry = image_base + code_off;
    ehdr.phoff = sizeof(struct elf64_header);
    ehdr.shoff = 0;
    ehdr.flags = 0;
    ehdr.ehsize = sizeof(struct elf64_header);
    ehdr.phentsize = sizeof(struct elf64_phdr);
    ehdr.phnum = 1;
    ehdr.shentsize = 0;
    ehdr.shnum = 0;
    ehdr.shstrndx = 0;

    struct elf64_phdr phdr;
    memset(&phdr, 0, sizeof(phdr));
    phdr.type = PT_LOAD;
    phdr.flags = 0x5; // PF_R | PF_X
    phdr.offset = 0;
    phdr.vaddr = image_base;
    phdr.paddr = image_base;
    phdr.filesz = file_size;
    phdr.memsz = file_size;
    phdr.align = 0x1000;

    memcpy(img, &ehdr, sizeof(ehdr));
    memcpy(img + sizeof(ehdr), &phdr, sizeof(phdr));
    memcpy(img + code_off, code, code_len);
    if (out_len > 0) memcpy(img + data_off, compiled_out, out_len);

    int rc = term_write_file_all(dst_path, img, file_size, err, err_sz);
    kfree(img);
    return rc;
}

static int term_compile_c_to_o(const char *src_path, const char *dst_path,
                               char *err, size_t err_sz) {
    uint8_t *src = NULL;
    size_t src_len = 0;
    if (term_read_file_all(src_path, &src, &src_len, err, err_sz) < 0) return -1;

    uint8_t *compiled = NULL;
    size_t compiled_len = 0;
    int32_t exit_code = 0;
    int rc = doorcc_compile_source((const char *)src, src_len,
                                   &compiled, &compiled_len, &exit_code,
                                   err, err_sz);
    kfree(src);
    if (rc < 0) return -1;

    rc = term_write_doorobj(dst_path, compiled, compiled_len, exit_code, err, err_sz);
    kfree(compiled);
    return rc;
}

static int term_compile_to_elf(const char *src_path, const char *dst_path,
                               char *err, size_t err_sz) {
    uint8_t *compiled = NULL;
    size_t compiled_len = 0;
    int32_t exit_code = 0;

    if (path_has_suffix(src_path, ".c")) {
        uint8_t *src = NULL;
        size_t src_len = 0;
        if (term_read_file_all(src_path, &src, &src_len, err, err_sz) < 0) return -1;
        int rc = doorcc_compile_source((const char *)src, src_len,
                                       &compiled, &compiled_len, &exit_code,
                                       err, err_sz);
        kfree(src);
        if (rc < 0) return -1;
    } else {
        if (term_read_doorobj(src_path, &compiled, &compiled_len, &exit_code, err, err_sz) < 0) {
            return -1;
        }
    }

    int rc = term_write_compiled_elf(dst_path, compiled, compiled_len, exit_code, err, err_sz);
    kfree(compiled);
    return rc;
}

static void term_cmd_lemonman(struct terminal_state *term, const struct window *win) {
    term_write_line(term, win, "The Lemon Man says: \"When life gives kernel panics, squeeze reboot.\"");
}

static void term_cmd_compile(struct terminal_state *term, const struct window *win,
                             int argc, char *argv[]) {
    if (argc < 3) {
        term_write_line(term, win, "compile usage:");
        term_write_line(term, win, "  compile file.c file.o");
        term_write_line(term, win, "  compile file.c file .elf");
        term_write_line(term, win, "  compile file.o file.elf");
        return;
    }

    const char *src_in = argv[1];
    char dst_in[MAX_PATH];
    const char *dst_arg = NULL;
    dst_in[0] = '\0';

    if (argc == 3) {
        dst_arg = argv[2];
    } else if (argc == 4 && strcmp(argv[3], ".elf") == 0) {
        if (snprintf(dst_in, sizeof(dst_in), "%s.elf", argv[2]) >= (int)sizeof(dst_in)) {
            term_write_line(term, win, "compile: destination path too long");
            return;
        }
        dst_arg = dst_in;
    } else {
        term_write_line(term, win, "compile: unsupported argument pattern");
        term_write_line(term, win, "try: compile main.c main.o  or  compile main.o main.elf");
        return;
    }

    char src[MAX_PATH];
    char dst[MAX_PATH];
    if (term_resolve_any_path(term, src_in, src, sizeof(src)) < 0 ||
        term_resolve_any_path(term, dst_arg, dst, sizeof(dst)) < 0) {
        term_write_line(term, win, "compile: invalid path");
        return;
    }

    bool src_c = path_has_suffix(src, ".c");
    bool src_o = path_has_suffix(src, ".o");
    bool dst_o = path_has_suffix(dst, ".o");
    bool dst_elf = path_has_suffix(dst, ".elf");

    char cc_err[TERM_LINE_MAX];
    cc_err[0] = '\0';

    int rc = -1;
    if (src_c && dst_o) {
        rc = term_compile_c_to_o(src, dst, cc_err, sizeof(cc_err));
    } else if ((src_c || src_o) && dst_elf) {
        rc = term_compile_to_elf(src, dst, cc_err, sizeof(cc_err));
    } else {
        term_write_line(term, win, "compile: only c->o, c->elf, and o->elf are supported");
        return;
    }

    if (rc < 0) {
        char msg[TERM_LINE_MAX];
        if (cc_err[0]) {
            snprintf(msg, sizeof(msg), "compile: %s", cc_err);
        } else {
            snprintf(msg, sizeof(msg), "compile: failed for %s", src);
        }
        term_write_line(term, win, msg);
        return;
    }

    char msg[TERM_LINE_MAX];
    snprintf(msg, sizeof(msg), "compiled %s -> %s", src, dst);
    term_write_line(term, win, msg);
    term_write_line(term, win, "Conjure La Fridge compiler whispers: \"fresh binary baked.\"");
}

static int term_launch_executable(struct terminal_state *term, const struct window *win,
                                  const char *input_path) {
    char path[MAX_PATH];
    if (!input_path || input_path[0] == '\0') return -1;

    if (input_path[0] == '/') {
        strncpy(path, input_path, sizeof(path) - 1);
        path[sizeof(path) - 1] = '\0';
    } else {
        char resolved[MAX_PATH];
        if (resolve_path(term->cwd, input_path, resolved, sizeof(resolved)) == 0) {
            struct stat st;
            if (vfs_stat(resolved, &st) == 0 && st.type != VFS_DIRECTORY) {
                strncpy(path, resolved, sizeof(path) - 1);
                path[sizeof(path) - 1] = '\0';
            } else {
                snprintf(path, sizeof(path), "/bin/%s", input_path);
            }
        } else {
            snprintf(path, sizeof(path), "/bin/%s", input_path);
        }
    }

    term_reap_zombies();
    int pid = process_create_user(path);
    const char *launched = path;
    char alt[MAX_PATH];

    if (pid < 0 && !path_has_suffix(path, ".exe")) {
        size_t plen = strlen(path);
        if (plen + 4 < sizeof(alt)) {
            memcpy(alt, path, plen);
            memcpy(alt + plen, ".exe", 5);
            pid = process_create_user(alt);
            if (pid >= 0) launched = alt;
        }
    }

    if (pid < 0 && path_has_suffix(path, ".exe")) {
        size_t plen = strlen(path);
        if (plen > 4 && plen - 4 < sizeof(alt)) {
            memcpy(alt, path, plen - 4);
            alt[plen - 4] = '\0';
            pid = process_create_user(alt);
            if (pid >= 0) launched = alt;
        }
    }

    if (pid < 0) {
        return -1;
    }

    process_set_terminal_window(pid, win->id);

    char msg[TERM_LINE_MAX];
    snprintf(msg, sizeof(msg), "launched %s (pid=%d)", launched, pid);
    term_write_line(term, win, msg);
    return pid;
}

static void term_cmd_pwd(struct terminal_state *term, const struct window *win) {
    term_write_line(term, win, term->cwd);
}

static void term_cmd_cd(struct terminal_state *term, const struct window *win,
                        int argc, char *argv[]) {
    const char *target = (argc > 1) ? argv[1] : "/";

    char resolved[MAX_PATH];
    if (resolve_path(term->cwd, target, resolved, sizeof(resolved)) < 0) {
        term_write_line(term, win, "cd: invalid path");
        return;
    }

    struct vfs_node *node = vfs_open(resolved, O_RDONLY);
    if (!node) {
        char msg[TERM_LINE_MAX];
        snprintf(msg, sizeof(msg), "cd: cannot open '%s'", target);
        term_write_line(term, win, msg);
        return;
    }

    if (node->type != VFS_DIRECTORY) {
        char msg[TERM_LINE_MAX];
        snprintf(msg, sizeof(msg), "cd: not a directory: '%s'", target);
        term_write_line(term, win, msg);
        vfs_close(node);
        return;
    }

    vfs_close(node);
    strncpy(term->cwd, resolved, sizeof(term->cwd) - 1);
    term->cwd[sizeof(term->cwd) - 1] = '\0';
}

static void term_cmd_ls(struct terminal_state *term, const struct window *win,
                        int argc, char *argv[]) {
    const char *target = (argc > 1) ? argv[1] : ".";

    char resolved[MAX_PATH];
    if (resolve_path(term->cwd, target, resolved, sizeof(resolved)) < 0) {
        term_write_line(term, win, "ls: invalid path");
        return;
    }

    struct vfs_node *node = vfs_open(resolved, O_RDONLY);
    if (!node) {
        char msg[TERM_LINE_MAX];
        snprintf(msg, sizeof(msg), "ls: cannot open '%s'", target);
        term_write_line(term, win, msg);
        return;
    }

    if (node->type != VFS_DIRECTORY) {
        char msg[TERM_LINE_MAX];
        snprintf(msg, sizeof(msg), "[FILE] %s (%u bytes)", resolved, (unsigned)node->size);
        term_write_line(term, win, msg);
        vfs_close(node);
        return;
    }

    struct dirent ent;
    int count = 0;

    while (vfs_readdir(node, &ent) == 0) {
        char line[TERM_LINE_MAX];
        const char *kind = (ent.type == VFS_DIRECTORY) ? "[DIR] " : "[FILE]";
        snprintf(line, sizeof(line), "%s %s", kind, ent.name);
        term_write_line(term, win, line);
        count++;
    }

    if (count == 0) {
        term_write_line(term, win, "(empty directory)");
    }

    vfs_close(node);
}

static void term_cmd_cat(struct terminal_state *term, const struct window *win,
                         int argc, char *argv[]) {
    if (argc < 2) {
        term_write_line(term, win, "cat: missing filename");
        return;
    }

    char resolved[MAX_PATH];
    if (resolve_path(term->cwd, argv[1], resolved, sizeof(resolved)) < 0) {
        term_write_line(term, win, "cat: invalid path");
        return;
    }

    struct vfs_node *node = vfs_open(resolved, O_RDONLY);
    if (!node) {
        char msg[TERM_LINE_MAX];
        snprintf(msg, sizeof(msg), "cat: cannot open '%s'", argv[1]);
        term_write_line(term, win, msg);
        return;
    }

    if (node->type != VFS_FILE) {
        term_write_line(term, win, "cat: target is not a file");
        vfs_close(node);
        return;
    }

    const size_t max_read = 8192;
    size_t want = node->size;
    bool truncated = false;
    if (want > max_read) {
        want = max_read;
        truncated = true;
    }

    char *buf = (char *)kmalloc(want + 1);
    if (!buf) {
        term_write_line(term, win, "cat: out of memory");
        vfs_close(node);
        return;
    }

    size_t total = 0;
    while (total < want) {
        ssize_t n = vfs_read(node, buf + total, want - total);
        if (n <= 0) break;
        total += (size_t)n;
    }

    buf[total] = '\0';

    if (total == 0) {
        term_write_line(term, win, "(empty file)");
    } else {
        term_write_text(term, win, buf);
    }

    if (truncated) {
        term_write_line(term, win, "[cat] output truncated at 8192 bytes");
    }

    kfree(buf);
    vfs_close(node);
}

static void term_cmd_echo(struct terminal_state *term, const struct window *win,
                          int argc, char *argv[]) {
    char line[TERM_LINE_MAX * 2];
    line[0] = '\0';

    for (int i = 1; i < argc; i++) {
        if (i > 1) strncat(line, " ", sizeof(line) - strlen(line) - 1);
        strncat(line, argv[i], sizeof(line) - strlen(line) - 1);
    }

    term_write_line(term, win, line);
}

static void term_cmd_stat(struct terminal_state *term, const struct window *win,
                          int argc, char *argv[]) {
    if (argc < 2) {
        term_write_line(term, win, "stat: missing path");
        return;
    }

    char resolved[MAX_PATH];
    if (resolve_path(term->cwd, argv[1], resolved, sizeof(resolved)) < 0) {
        term_write_line(term, win, "stat: invalid path");
        return;
    }

    struct stat st;
    if (vfs_stat(resolved, &st) < 0) {
        char msg[TERM_LINE_MAX];
        snprintf(msg, sizeof(msg), "stat: cannot stat '%s'", argv[1]);
        term_write_line(term, win, msg);
        return;
    }

    char line[TERM_LINE_MAX];
    snprintf(line, sizeof(line), "path: %s", resolved);
    term_write_line(term, win, line);

    snprintf(line, sizeof(line), "inode: %u", (unsigned)st.inode);
    term_write_line(term, win, line);

    snprintf(line, sizeof(line), "type: %s", st.type == VFS_DIRECTORY ? "directory" : "file");
    term_write_line(term, win, line);

    snprintf(line, sizeof(line), "size: %u bytes", (unsigned)st.size);
    term_write_line(term, win, line);

    snprintf(line, sizeof(line), "blocks: %u", (unsigned)st.blocks);
    term_write_line(term, win, line);
}

static void term_cmd_mkdir(struct terminal_state *term, const struct window *win,
                           int argc, char *argv[]) {
    if (argc < 2) {
        term_write_line(term, win, "mkdir: missing directory name");
        return;
    }

    char resolved[MAX_PATH];
    if (resolve_path(term->cwd, argv[1], resolved, sizeof(resolved)) < 0) {
        term_write_line(term, win, "mkdir: invalid path");
        return;
    }

    if (vfs_mkdir(resolved) < 0) {
        char msg[TERM_LINE_MAX];
        snprintf(msg, sizeof(msg), "mkdir: cannot create '%s'", resolved);
        term_write_line(term, win, msg);
        return;
    }

    char msg[TERM_LINE_MAX];
    snprintf(msg, sizeof(msg), "created directory: %s", resolved);
    term_write_line(term, win, msg);
}

static void term_cmd_rmdir(struct terminal_state *term, const struct window *win,
                           int argc, char *argv[]) {
    if (argc < 2) {
        term_write_line(term, win, "rmdir: missing directory name");
        return;
    }

    char resolved[MAX_PATH];
    if (resolve_path(term->cwd, argv[1], resolved, sizeof(resolved)) < 0) {
        term_write_line(term, win, "rmdir: invalid path");
        return;
    }

    if (vfs_rmdir(resolved) < 0) {
        char msg[TERM_LINE_MAX];
        snprintf(msg, sizeof(msg), "rmdir: cannot remove '%s'", resolved);
        term_write_line(term, win, msg);
        return;
    }

    char msg[TERM_LINE_MAX];
    snprintf(msg, sizeof(msg), "removed directory: %s", resolved);
    term_write_line(term, win, msg);
}

static void term_cmd_rm(struct terminal_state *term, const struct window *win,
                        int argc, char *argv[]) {
    if (argc < 2) {
        term_write_line(term, win, "rm: missing file name");
        return;
    }

    char resolved[MAX_PATH];
    if (resolve_path(term->cwd, argv[1], resolved, sizeof(resolved)) < 0) {
        term_write_line(term, win, "rm: invalid path");
        return;
    }

    if (vfs_unlink(resolved) < 0) {
        char msg[TERM_LINE_MAX];
        snprintf(msg, sizeof(msg), "rm: cannot remove '%s'", resolved);
        term_write_line(term, win, msg);
        return;
    }

    char msg[TERM_LINE_MAX];
    snprintf(msg, sizeof(msg), "removed file: %s", resolved);
    term_write_line(term, win, msg);
}

static void term_cmd_touch(struct terminal_state *term, const struct window *win,
                           int argc, char *argv[]) {
    if (argc < 2) {
        term_write_line(term, win, "touch: missing file name");
        return;
    }

    char resolved[MAX_PATH];
    if (resolve_path(term->cwd, argv[1], resolved, sizeof(resolved)) < 0) {
        term_write_line(term, win, "touch: invalid path");
        return;
    }

    struct vfs_node *node = vfs_open(resolved, O_CREAT | O_RDWR);
    if (!node) {
        char msg[TERM_LINE_MAX];
        snprintf(msg, sizeof(msg), "touch: cannot create '%s'", resolved);
        term_write_line(term, win, msg);
        return;
    }

    vfs_close(node);
    char msg[TERM_LINE_MAX];
    snprintf(msg, sizeof(msg), "created file: %s", resolved);
    term_write_line(term, win, msg);
}

static bool term_execute(struct gui_app *app, const char *command_line) {
    struct window *win = window_get(app->window_id);
    if (!win) return false;

    struct terminal_state *term = &app->u.term;

    char line[TERM_INPUT_MAX];
    strncpy(line, command_line, sizeof(line) - 1);
    line[sizeof(line) - 1] = '\0';

    char *argv[TERM_MAX_ARGS];
    int argc = parse_args(line, argv, TERM_MAX_ARGS);
    if (argc == 0) return true;

    if (strcmp(argv[0], "help") == 0) {
        term_cmd_help(term, win);
    } else if (strcmp(argv[0], "clear") == 0) {
        term_clear(term);
    } else if (strcmp(argv[0], "pwd") == 0) {
        term_cmd_pwd(term, win);
    } else if (strcmp(argv[0], "cd") == 0) {
        term_cmd_cd(term, win, argc, argv);
    } else if (strcmp(argv[0], "ls") == 0) {
        term_cmd_ls(term, win, argc, argv);
    } else if (strcmp(argv[0], "cat") == 0) {
        term_cmd_cat(term, win, argc, argv);
    } else if (strcmp(argv[0], "echo") == 0) {
        term_cmd_echo(term, win, argc, argv);
    } else if (strcmp(argv[0], "stat") == 0) {
        term_cmd_stat(term, win, argc, argv);
    } else if (strcmp(argv[0], "mkdir") == 0) {
        term_cmd_mkdir(term, win, argc, argv);
    } else if (strcmp(argv[0], "rmdir") == 0) {
        term_cmd_rmdir(term, win, argc, argv);
    } else if (strcmp(argv[0], "rm") == 0) {
        term_cmd_rm(term, win, argc, argv);
    } else if (strcmp(argv[0], "touch") == 0) {
        term_cmd_touch(term, win, argc, argv);
    } else if (strcmp(argv[0], "calc") == 0) {
        term_cmd_calc(term, win, argc, argv);
    } else if (strcmp(argv[0], "compile") == 0) {
        term_cmd_compile(term, win, argc, argv);
    } else if (strcmp(argv[0], "uptime") == 0) {
        uint64_t ticks = pit_get_ticks();
        uint64_t seconds = ticks / 100;
        char out[TERM_LINE_MAX];
        snprintf(out, sizeof(out), "uptime: %u seconds", (unsigned)seconds);
        term_write_line(term, win, out);
    } else if (strcmp(argv[0], "ifconfig") == 0 || strcmp(argv[0], "ipconfig") == 0) {
        term_cmd_ifconfig(term, win);
    } else if (strcmp(argv[0], "ping") == 0) {
        term_cmd_ping(term, win, argc, argv);
    } else if (strcmp(argv[0], "fastfetch") == 0 ||
               strcmp(argv[0], "neofetch") == 0 ||
               strcmp(argv[0], "sysinfo") == 0) {
        term_cmd_fastfetch(term, win);
    } else if (strcmp(argv[0], "uname") == 0) {
        term_cmd_uname(term, win);
    } else if (strcmp(argv[0], "ps") == 0) {
        term_cmd_ps(term, win);
    } else if (strcmp(argv[0], "lemonman") == 0 || strcmp(argv[0], "lemon") == 0) {
        term_cmd_lemonman(term, win);
    } else if (strcmp(argv[0], "reap") == 0) {
        int n = term_reap_zombies();
        char msg[TERM_LINE_MAX];
        snprintf(msg, sizeof(msg), "reaped %d zombie process(es)", n);
        term_write_line(term, win, msg);
    } else if (strcmp(argv[0], "reboot") == 0 || strcmp(argv[0], "restart") == 0) {
        term_write_line(term, win, "Rebooting DoorOS... Conjure La Fridge is turning the key.");
        power_reboot();
    } else if (strcmp(argv[0], "run") == 0 || strcmp(argv[0], "exec") == 0) {
        if (argc < 2) {
            term_write_line(term, win, "run: missing executable");
        } else if (term_launch_executable(term, win, argv[1]) < 0) {
            term_write_line(term, win, "run: executable not found or failed to start");
        }
    } else if (strcmp(argv[0], "action") == 0 ||
               strcmp(argv[0], "taskman") == 0 ||
               strcmp(argv[0], "employee") == 0) {
        if (gui_apps_spawn_action_employee() >= 0) {
            term_write_line(term, win, "Started Macrohard Action Employee");
        } else {
            term_write_line(term, win, "action: failed to launch process");
        }
    } else if (strcmp(argv[0], "calculator") == 0 ||
               strcmp(argv[0], "calcapp") == 0) {
        if (gui_apps_spawn_calculator() >= 0) {
            term_write_line(term, win, "Started Calculator");
        } else {
            term_write_line(term, win, "calculator: failed to launch process");
        }
    } else if (strcmp(argv[0], "settings") == 0 ||
               strcmp(argv[0], "freedomblock") == 0) {
        if (gui_apps_spawn_settings_panel() >= 0) {
            term_write_line(term, win, "Opened Macrohard FreedomBlock");
        } else {
            term_write_line(term, win, "settings: failed to open window");
        }
    } else if (strcmp(argv[0], "editor") == 0 || strcmp(argv[0], "edit") == 0) {
        if (argc > 1) {
            char resolved[MAX_PATH];
            if (resolve_path(term->cwd, argv[1], resolved, sizeof(resolved)) == 0) {
                if (gui_apps_spawn_text_editor_path(resolved) >= 0) {
                    char msg[TERM_LINE_MAX];
                    snprintf(msg, sizeof(msg), "Opened editor: %s", resolved);
                    term_write_line(term, win, msg);
                } else {
                    term_write_line(term, win, "editor: failed to open window");
                }
            } else {
                term_write_line(term, win, "editor: invalid path");
            }
        } else {
            if (gui_apps_spawn_text_editor() >= 0) {
                term_write_line(term, win, "Opened editor: /notes.txt");
            } else {
                term_write_line(term, win, "editor: failed to open window");
            }
        }
    } else if (strcmp(argv[0], "exit") == 0) {
        window_destroy(app->window_id);
        return false;
    } else {
        if (term_launch_executable(term, win, argv[0]) < 0) {
            char msg[TERM_LINE_MAX];
            snprintf(msg, sizeof(msg), "%s: command not found", argv[0]);
            term_write_line(term, win, msg);
        }
    }

    return true;
}

static void term_render(struct gui_app *app) {
    struct window *win = window_get(app->window_id);
    if (!win || !win->framebuffer) return;

    struct terminal_state *term = &app->u.term;

    fill_window(win->framebuffer, win->width, win->height, TERM_BG_COLOR);

    draw_rect(win->framebuffer, win->width, win->height,
              0, 0, win->width, 32, TERM_HEADER_COLOR);
    draw_rect(win->framebuffer, win->width, win->height,
              0, 32, win->width, 1, TERM_BORDER_COLOR);

    char header[96];
    snprintf(header, sizeof(header), "DoorOS Terminal  cwd: %s", term->cwd);
    font_draw_string(win->framebuffer, win->width, win->height,
                     10, 9, header, 0xD7E7F7, TERM_HEADER_COLOR);

    int top = 40;
    int rows = (win->height - top - 8) / FONT_HEIGHT;
    if (rows < 2) rows = 2;
    int history_rows = rows - 1;

    int extra_stream = (term->stream_len > 0) ? 1 : 0;
    int total_hist = term->line_count + extra_stream;
    int first_hist = 0;
    if (total_hist > history_rows) {
        first_hist = total_hist - history_rows;
    }

    int draw_row = 0;
    for (int i = first_hist; i < total_hist; i++) {
        const char *line_text = "";
        if (i < term->line_count) {
            int idx = (term->line_start + i) % TERM_MAX_LINES;
            line_text = term->lines[idx];
        } else {
            line_text = term->stream_line;
        }
        int y = top + draw_row * FONT_HEIGHT;
        font_draw_string(win->framebuffer, win->width, win->height,
                         10, y, line_text, TERM_TEXT_COLOR, TERM_BG_COLOR);
        draw_row++;
    }

    char prompt[320];
    term_make_prompt(term, prompt, sizeof(prompt));

    char line[512];
    snprintf(line, sizeof(line), "%s%s_", prompt, term->input);

    int cols = term_cols(win);
    const char *shown = line;
    int len = (int)strlen(line);
    if (len > cols) {
        shown = line + (len - cols);
    }

    int prompt_y = top + history_rows * FONT_HEIGHT;
    font_draw_string(win->framebuffer, win->width, win->height,
                     10, prompt_y, shown, TERM_PROMPT_COLOR, TERM_BG_COLOR);
}

static __attribute__((unused)) void term_init(struct terminal_state *term) {
    memset(term, 0, sizeof(*term));
    strcpy(term->cwd, "/");
    term_clear(term);

    term_push_line(term, "DoorOS GUI Terminal");
    term_push_line(term, "MACROHARD DoorOS edition loaded.");
    term_push_line(term, "Type 'help' to list commands.");
    term_push_line(term, "Try 'lemonman' for a mysterious quote.");
}

static void term_handle_key(struct gui_app *app, char key) {
    struct terminal_state *term = &app->u.term;

    if (key == '\r') key = '\n';

    if (key == '\n') {
        term->input[term->input_len] = '\0';

        struct window *win = window_get(app->window_id);
        if (!win) return;

        char prompt[320];
        term_make_prompt(term, prompt, sizeof(prompt));

        char line[512];
        snprintf(line, sizeof(line), "%s%s", prompt, term->input);
        term_write_line(term, win, line);

        char cmd[TERM_INPUT_MAX];
        strncpy(cmd, term->input, sizeof(cmd) - 1);
        cmd[sizeof(cmd) - 1] = '\0';

        term->input[0] = '\0';
        term->input_len = 0;

        if (cmd[0] != '\0') {
            if (!term_execute(app, cmd)) return;
        }

        term_render(app);
        return;
    }

    if (key == '\b' || key == 127) {
        if (term->input_len > 0) {
            term->input_len--;
            term->input[term->input_len] = '\0';
            term_render(app);
        }
        return;
    }

    if (key == '\t') {
        key = ' ';
    }

    if ((uint8_t)key < 32 || (uint8_t)key > 126) {
        return;
    }

    if (term->input_len < TERM_INPUT_MAX - 1) {
        term->input[term->input_len++] = key;
        term->input[term->input_len] = '\0';
        term_render(app);
    }
}

static void fileman_reload(struct fileman_state *fm) {
    fm->entry_count = 0;
    fm->selected = -1;

    struct vfs_node *node = vfs_open(fm->cwd, O_RDONLY);
    if (!node) {
        snprintf(fm->status, sizeof(fm->status), "Failed to open %s", fm->cwd);
        return;
    }

    if (node->type != VFS_DIRECTORY) {
        snprintf(fm->status, sizeof(fm->status), "%s is not a directory", fm->cwd);
        vfs_close(node);
        return;
    }

    struct dirent ent;
    int safety = 0;
    while (fm->entry_count < FILEMAN_MAX_ENTRIES && safety < 1024) {
        if (vfs_readdir(node, &ent) != 0) break;
        safety++;

        struct fileman_entry *dst = &fm->entries[fm->entry_count++];
        dst->type = ent.type;
        strncpy(dst->name, ent.name, sizeof(dst->name) - 1);
        dst->name[sizeof(dst->name) - 1] = '\0';
        sanitize_text(dst->name);
    }

    vfs_close(node);

    if (safety >= 1024) {
        snprintf(fm->status, sizeof(fm->status), "Read stopped (FS safety guard)");
    } else {
        snprintf(fm->status, sizeof(fm->status), "%d entries", fm->entry_count);
    }
}

static void fileman_render(struct gui_app *app) {
    struct window *win = window_get(app->window_id);
    if (!win || !win->framebuffer) return;

    struct fileman_state *fm = &app->u.fm;

    fill_window(win->framebuffer, win->width, win->height, FM_BG_COLOR);

    draw_rect(win->framebuffer, win->width, win->height,
              0, 0, win->width, 32, FM_HEADER_COLOR);
    font_draw_string(win->framebuffer, win->width, win->height,
                     10, 9, "DoorOS File Manager", FM_HEADER_TEXT, FM_HEADER_COLOR);

    draw_rect(win->framebuffer, win->width, win->height,
              0, 36, win->width, 24, FM_PATH_BG);

    char path_line[120];
    snprintf(path_line, sizeof(path_line), "Path: %s", fm->cwd);
    font_draw_string(win->framebuffer, win->width, win->height,
                     10, 40, path_line, FM_ACCENT_TEXT, FM_PATH_BG);

    int btn_w = 52;
    int btn_h = 20;
    int up_x = win->width - (btn_w * 2 + 18);
    int refresh_x = win->width - (btn_w + 10);

    draw_rect(win->framebuffer, win->width, win->height,
              up_x, 38, btn_w, btn_h, 0xA7BED3);
    draw_rect(win->framebuffer, win->width, win->height,
              refresh_x, 38, btn_w, btn_h, 0xA7BED3);

    font_draw_string(win->framebuffer, win->width, win->height,
                     up_x + 14, 41, "Up", 0x1D2A36, 0xA7BED3);
    font_draw_string(win->framebuffer, win->width, win->height,
                     refresh_x + 3, 41, "Refresh", 0x1D2A36, 0xA7BED3);

    int list_top = 68;
    int row_h = 22;
    int list_bottom = win->height - 28;
    int visible_rows = (list_bottom - list_top) / row_h;
    if (visible_rows < 1) visible_rows = 1;

    bool has_parent = strcmp(fm->cwd, "/") != 0;
    int total_rows = fm->entry_count + (has_parent ? 1 : 0);

    for (int row = 0; row < visible_rows && row < total_rows; row++) {
        int y = list_top + row * row_h;

        uint32_t row_color = (row % 2) ? FM_ROW_A : FM_ROW_B;
        int entry_index = row - (has_parent ? 1 : 0);
        if (entry_index >= 0 && entry_index == fm->selected) {
            row_color = FM_ROW_SELECTED;
        }

        draw_rect(win->framebuffer, win->width, win->height,
                  8, y, win->width - 16, row_h - 2, row_color);

        char line[96];
        if (has_parent && row == 0) {
            snprintf(line, sizeof(line), "[DIR]  ..");
        } else if (entry_index >= 0 && entry_index < fm->entry_count) {
            const char *kind = (fm->entries[entry_index].type == VFS_DIRECTORY) ? "[DIR] " : "[FILE]";
            snprintf(line, sizeof(line), "%s %s", kind, fm->entries[entry_index].name);
        } else {
            line[0] = '\0';
        }

        font_draw_string(win->framebuffer, win->width, win->height,
                         14, y + 4, line, FM_TEXT_COLOR, row_color);
    }

    draw_rect(win->framebuffer, win->width, win->height,
              0, win->height - 24, win->width, 24, FM_STATUS_BG);
    font_draw_string(win->framebuffer, win->width, win->height,
                     10, win->height - 20, fm->status, FM_ACCENT_TEXT, FM_STATUS_BG);
}

static void fileman_open_file(struct fileman_state *fm, const char *name) {
    char full[MAX_PATH];
    if (resolve_path(fm->cwd, name, full, sizeof(full)) < 0) {
        snprintf(fm->status, sizeof(fm->status), "Invalid path");
        return;
    }

    struct stat st;
    if (vfs_stat(full, &st) < 0) {
        snprintf(fm->status, sizeof(fm->status), "Cannot stat %s", name);
        return;
    }

    if (strncmp(full, "/bin/", 5) == 0) {
        int pid = process_create_user(full);
        if (pid >= 0) {
            snprintf(fm->status, sizeof(fm->status), "Launched %s (pid=%d)", name, pid);
            return;
        }
        snprintf(fm->status, sizeof(fm->status), "Launch failed: %s", name);
        return;
    }

    snprintf(fm->status, sizeof(fm->status), "%s: %u bytes", name, (unsigned)st.size);
}

static void fileman_handle_click(struct gui_app *app, int x, int y) {
    struct window *win = window_get(app->window_id);
    if (!win) return;
    if (x < 0 || y < 0 || x >= win->width || y >= win->height) return;

    struct fileman_state *fm = &app->u.fm;

    int btn_w = 52;
    int btn_h = 20;
    int up_x = win->width - (btn_w * 2 + 18);
    int refresh_x = win->width - (btn_w + 10);

    if (x >= up_x && x < up_x + btn_w && y >= 38 && y < 38 + btn_h) {
        if (strcmp(fm->cwd, "/") != 0) {
            char parent[MAX_PATH];
            parent_path(fm->cwd, parent, sizeof(parent));
            strncpy(fm->cwd, parent, sizeof(fm->cwd) - 1);
            fm->cwd[sizeof(fm->cwd) - 1] = '\0';
            fileman_reload(fm);
        }
        fileman_render(app);
        return;
    }

    if (x >= refresh_x && x < refresh_x + btn_w && y >= 38 && y < 38 + btn_h) {
        fileman_reload(fm);
        fileman_render(app);
        return;
    }

    int list_top = 68;
    int row_h = 22;
    int list_bottom = win->height - 28;

    if (x < 8 || x >= win->width - 8 || y < list_top || y >= list_bottom) {
        return;
    }

    int row = (y - list_top) / row_h;

    bool has_parent = strcmp(fm->cwd, "/") != 0;
    int total_rows = fm->entry_count + (has_parent ? 1 : 0);
    if (row < 0 || row >= total_rows) return;

    if (has_parent && row == 0) {
        char parent[MAX_PATH];
        parent_path(fm->cwd, parent, sizeof(parent));
        strncpy(fm->cwd, parent, sizeof(fm->cwd) - 1);
        fm->cwd[sizeof(fm->cwd) - 1] = '\0';
        fileman_reload(fm);
        fileman_render(app);
        return;
    }

    int entry_index = row - (has_parent ? 1 : 0);
    if (entry_index < 0 || entry_index >= fm->entry_count) return;

    fm->selected = entry_index;

    if (fm->entries[entry_index].type == VFS_DIRECTORY) {
        char next[MAX_PATH];
        if (resolve_path(fm->cwd, fm->entries[entry_index].name, next, sizeof(next)) == 0) {
            strncpy(fm->cwd, next, sizeof(fm->cwd) - 1);
            fm->cwd[sizeof(fm->cwd) - 1] = '\0';
            fileman_reload(fm);
        } else {
            snprintf(fm->status, sizeof(fm->status), "Invalid directory path");
        }
    } else {
        fileman_open_file(fm, fm->entries[entry_index].name);
    }

    fileman_render(app);
}

static void editor_set_status(struct editor_state *ed, const char *msg) {
    if (!ed) return;
    if (!msg) msg = "";
    strncpy(ed->status, msg, sizeof(ed->status) - 1);
    ed->status[sizeof(ed->status) - 1] = '\0';
}

struct editor_toolbar_layout {
    int y;
    int h;
    int save_x;
    int save_w;
    int reload_x;
    int reload_w;
    int rename_x;
    int rename_w;
    int export_c_x;
    int export_c_w;
    int export_txt_x;
    int export_txt_w;
};

static void editor_toolbar_compute(const struct window *win, struct editor_toolbar_layout *tb) {
    if (!win || !tb) return;

    tb->y = 38;
    tb->h = 20;
    tb->save_w = 52;
    tb->reload_w = 58;
    tb->rename_w = 66;
    tb->export_c_w = 66;
    tb->export_txt_w = 76;

    int gap = 6;
    int x = win->width - 10;

    tb->export_txt_x = x - tb->export_txt_w;
    x = tb->export_txt_x - gap;
    tb->export_c_x = x - tb->export_c_w;
    x = tb->export_c_x - gap;
    tb->rename_x = x - tb->rename_w;
    x = tb->rename_x - gap;
    tb->reload_x = x - tb->reload_w;
    x = tb->reload_x - gap;
    tb->save_x = x - tb->save_w;
}

static int editor_write_to_path(const struct editor_state *ed, const char *path, size_t *out_written) {
    if (!ed || !path || path[0] != '/') return -1;

    struct vfs_node *node = vfs_open(path, O_CREAT | O_WRONLY | O_TRUNC);
    if (!node || node->type != VFS_FILE) {
        if (node) vfs_close(node);
        return -1;
    }

    size_t total = 0;
    while (total < ed->len) {
        ssize_t n = vfs_write(node, ed->text + total, ed->len - total);
        if (n <= 0) break;
        total += (size_t)n;
    }

    vfs_close(node);
    if (out_written) *out_written = total;
    return (total == ed->len) ? 0 : -1;
}

static int editor_derive_export_path(const char *path, const char *ext,
                                     char *out, size_t out_sz) {
    if (!path || !ext || !out || out_sz == 0) return -1;

    const char *slash = strrchr(path, '/');
    const char *dot = strrchr(path, '.');
    if (!dot || (slash && dot < slash)) {
        dot = path + strlen(path);
    }

    size_t stem_len = (size_t)(dot - path);
    size_t ext_len = strlen(ext);
    if (stem_len + ext_len + 1 > out_sz) return -1;

    memcpy(out, path, stem_len);
    memcpy(out + stem_len, ext, ext_len + 1);
    return 0;
}

static void editor_export_ext(struct editor_state *ed, const char *ext) {
    if (!ed || !ext) return;

    char out_path[MAX_PATH];
    if (editor_derive_export_path(ed->path, ext, out_path, sizeof(out_path)) < 0) {
        editor_set_status(ed, "Export failed: output path too long");
        return;
    }

    size_t written = 0;
    if (editor_write_to_path(ed, out_path, &written) < 0) {
        editor_set_status(ed, "Export failed");
        return;
    }

    char msg[96];
    snprintf(msg, sizeof(msg), "Exported %u bytes to %s", (unsigned)written, out_path);
    editor_set_status(ed, msg);
}

static void editor_begin_rename(struct editor_state *ed) {
    if (!ed) return;
    ed->rename_mode = true;
    const char *base = strrchr(ed->path, '/');
    base = base ? base + 1 : ed->path;
    strncpy(ed->rename_input, base, sizeof(ed->rename_input) - 1);
    ed->rename_input[sizeof(ed->rename_input) - 1] = '\0';
    ed->rename_len = (int)strlen(ed->rename_input);
    editor_set_status(ed, "Rename mode: type new name, Enter to commit, Esc to cancel");
}

static void editor_commit_rename(struct editor_state *ed) {
    if (!ed) return;

    if (ed->rename_len <= 0) {
        editor_set_status(ed, "Rename failed: empty name");
        ed->rename_mode = false;
        return;
    }

    char target[MAX_PATH];
    if (ed->rename_input[0] == '/') {
        strncpy(target, ed->rename_input, sizeof(target) - 1);
        target[sizeof(target) - 1] = '\0';
    } else {
        char parent[MAX_PATH];
        parent_path(ed->path, parent, sizeof(parent));
        if (resolve_path(parent, ed->rename_input, target, sizeof(target)) < 0) {
            editor_set_status(ed, "Rename failed: invalid path");
            ed->rename_mode = false;
            return;
        }
    }

    if (strcmp(target, ed->path) == 0) {
        editor_set_status(ed, "Rename cancelled: same path");
        ed->rename_mode = false;
        return;
    }

    size_t written = 0;
    if (editor_write_to_path(ed, target, &written) < 0) {
        editor_set_status(ed, "Rename failed: cannot write target");
        ed->rename_mode = false;
        return;
    }

    struct stat st;
    if (vfs_stat(ed->path, &st) == 0 && st.type == VFS_FILE) {
        (void)vfs_unlink(ed->path);
    }

    strncpy(ed->path, target, sizeof(ed->path) - 1);
    ed->path[sizeof(ed->path) - 1] = '\0';
    ed->dirty = false;
    ed->rename_mode = false;

    char msg[96];
    snprintf(msg, sizeof(msg), "Renamed and saved %u bytes", (unsigned)written);
    editor_set_status(ed, msg);
}

static void editor_load(struct editor_state *ed) {
    if (!ed) return;

    ed->len = 0;
    ed->cursor = 0;
    ed->text[0] = '\0';
    ed->dirty = false;
    ed->rename_mode = false;
    ed->rename_len = 0;
    ed->rename_input[0] = '\0';

    struct vfs_node *node = vfs_open(ed->path, O_RDONLY);
    if (!node) {
        char msg[96];
        snprintf(msg, sizeof(msg), "New file: %s", ed->path);
        editor_set_status(ed, msg);
        return;
    }

    if (node->type != VFS_FILE) {
        editor_set_status(ed, "Open failed: path is not a file");
        vfs_close(node);
        return;
    }

    size_t want = node->size;
    bool truncated = false;
    if (want > EDITOR_TEXT_MAX) {
        want = EDITOR_TEXT_MAX;
        truncated = true;
    }

    size_t total = 0;
    while (total < want) {
        ssize_t n = vfs_read(node, ed->text + total, want - total);
        if (n <= 0) break;
        total += (size_t)n;
    }

    ed->len = total;
    ed->cursor = ed->len;
    ed->text[ed->len] = '\0';

    vfs_close(node);

    if (truncated) {
        editor_set_status(ed, "Loaded (truncated to 8192 bytes)");
    } else {
        char msg[96];
        snprintf(msg, sizeof(msg), "Loaded %u bytes", (unsigned)ed->len);
        editor_set_status(ed, msg);
    }
}

static void editor_save(struct editor_state *ed) {
    if (!ed) return;

    size_t written = 0;
    if (editor_write_to_path(ed, ed->path, &written) == 0) {
        ed->dirty = false;
        char msg[96];
        snprintf(msg, sizeof(msg), "Saved %u bytes", (unsigned)written);
        editor_set_status(ed, msg);
    } else {
        editor_set_status(ed, "Save failed: short write");
    }
}

static size_t editor_find_render_start(const struct editor_state *ed,
                                       int max_cols, int max_rows, size_t cursor) {
    if (!ed || max_cols <= 0 || max_rows <= 0) return 0;
    if (cursor > ed->len) cursor = ed->len;

    int rows = 1;
    int col = 0;
    size_t i = cursor;

    while (i > 0) {
        char ch = ed->text[i - 1];
        i--;

        if (ch == '\r') continue;

        if (ch == '\n') {
            rows++;
            col = 0;
            if (rows > max_rows) {
                return i + 1;
            }
            continue;
        }

        int w = (ch == '\t') ? 4 : 1;
        col += w;
        while (col > max_cols) {
            rows++;
            col -= max_cols;
            if (rows > max_rows) {
                return i + 1;
            }
        }
    }

    return 0;
}

static size_t editor_line_start(const struct editor_state *ed, size_t pos) {
    if (!ed) return 0;
    if (pos > ed->len) pos = ed->len;
    while (pos > 0 && ed->text[pos - 1] != '\n') pos--;
    return pos;
}

static size_t editor_line_end(const struct editor_state *ed, size_t pos) {
    if (!ed) return 0;
    if (pos > ed->len) pos = ed->len;
    while (pos < ed->len && ed->text[pos] != '\n') pos++;
    return pos;
}

static void editor_move_up(struct editor_state *ed) {
    if (!ed) return;
    size_t line_start = editor_line_start(ed, ed->cursor);
    if (line_start == 0) return;

    size_t col = ed->cursor - line_start;
    size_t prev_end = line_start - 1;
    size_t prev_start = editor_line_start(ed, prev_end);
    size_t prev_len = prev_end - prev_start;
    ed->cursor = prev_start + (col < prev_len ? col : prev_len);
}

static void editor_move_down(struct editor_state *ed) {
    if (!ed) return;
    size_t line_start = editor_line_start(ed, ed->cursor);
    size_t col = ed->cursor - line_start;
    size_t line_end = editor_line_end(ed, line_start);
    if (line_end >= ed->len) return;

    size_t next_start = line_end + 1;
    size_t next_end = editor_line_end(ed, next_start);
    size_t next_len = next_end - next_start;
    ed->cursor = next_start + (col < next_len ? col : next_len);
}

static void editor_render(struct gui_app *app) {
    struct window *win = window_get(app->window_id);
    if (!win || !win->framebuffer) return;

    struct editor_state *ed = &app->u.ed;

    fill_window(win->framebuffer, win->width, win->height, ED_BG_COLOR);

    draw_rect(win->framebuffer, win->width, win->height,
              0, 0, win->width, 32, ED_HEADER_COLOR);

    char header[160];
    snprintf(header, sizeof(header), "DoorOS Editor  %s%s",
             ed->path, ed->dirty ? "  *modified*" : "");
    font_draw_string(win->framebuffer, win->width, win->height,
                     10, 9, header, ED_HEADER_TEXT, ED_HEADER_COLOR);

    draw_rect(win->framebuffer, win->width, win->height,
              0, 36, win->width, 24, ED_TOOLBAR_BG);

    struct editor_toolbar_layout tb;
    editor_toolbar_compute(win, &tb);
    draw_rect(win->framebuffer, win->width, win->height,
              tb.save_x, tb.y, tb.save_w, tb.h, 0xA7BED3);
    draw_rect(win->framebuffer, win->width, win->height,
              tb.reload_x, tb.y, tb.reload_w, tb.h, 0xA7BED3);
    draw_rect(win->framebuffer, win->width, win->height,
              tb.rename_x, tb.y, tb.rename_w, tb.h, 0x93A8C1);
    draw_rect(win->framebuffer, win->width, win->height,
              tb.export_c_x, tb.y, tb.export_c_w, tb.h, 0x98B7D6);
    draw_rect(win->framebuffer, win->width, win->height,
              tb.export_txt_x, tb.y, tb.export_txt_w, tb.h, 0x85BFA1);
    font_draw_string(win->framebuffer, win->width, win->height,
                     tb.save_x + 9, tb.y + 3, "Save", 0x1D2A36, 0xA7BED3);
    font_draw_string(win->framebuffer, win->width, win->height,
                     tb.reload_x + 3, tb.y + 3, "Reload", 0x1D2A36, 0xA7BED3);
    font_draw_string(win->framebuffer, win->width, win->height,
                     tb.rename_x + 5, tb.y + 3, "Rename", 0x1D2A36, 0x93A8C1);
    font_draw_string(win->framebuffer, win->width, win->height,
                     tb.export_c_x + 10, tb.y + 3, "Exp .c", 0x1D2A36, 0x98B7D6);
    font_draw_string(win->framebuffer, win->width, win->height,
                     tb.export_txt_x + 5, tb.y + 3, "Exp .txt", 0x1D2A36, 0x85BFA1);

    int text_top = 68;
    if (ed->rename_mode) {
        draw_rect(win->framebuffer, win->width, win->height,
                  10, 64, win->width - 20, 24, 0xE6ECF5);
        font_draw_string(win->framebuffer, win->width, win->height,
                         16, 68, "Rename to:", 0x2B3C50, 0xE6ECF5);
        char rename_line[MAX_PATH + 4];
        snprintf(rename_line, sizeof(rename_line), "%s_", ed->rename_input);
        font_draw_string(win->framebuffer, win->width, win->height,
                         102, 68, rename_line, 0x223449, 0xE6ECF5);
        text_top = 96;
    }

    int text_left = 10;
    int text_right = win->width - 10;
    int text_bottom = win->height - 28;

    int max_cols = (text_right - text_left) / FONT_WIDTH;
    int max_rows = (text_bottom - text_top) / FONT_HEIGHT;
    if (max_cols < 8) max_cols = 8;
    if (max_cols > 191) max_cols = 191;
    if (max_rows < 1) max_rows = 1;
    if (max_rows > 64) max_rows = 64;

    char (*lines)[192] = editor_scratch_lines;
    for (int i = 0; i < max_rows; i++) {
        lines[i][0] = '\0';
    }

    int line_count = 1;
    int cur_len = 0;
    int caret_row = 0;
    int caret_col = 0;
    bool caret_set = false;

    size_t render_start = editor_find_render_start(ed, max_cols, max_rows, ed->cursor);
    for (size_t i = render_start; i <= ed->len; i++) {
        if (!caret_set && i == ed->cursor) {
            caret_row = line_count - 1;
            caret_col = cur_len;
            caret_set = true;
        }
        if (i == ed->len) break;
        char ch = ed->text[i];
        if (ch == '\r') continue;

        if (ch == '\n') {
            lines[line_count - 1][cur_len] = '\0';
            if (line_count < max_rows) {
                line_count++;
            } else {
                memmove(lines[0], lines[1], (size_t)(max_rows - 1) * 192);
                lines[max_rows - 1][0] = '\0';
                if (caret_row > 0) caret_row--;
            }
            cur_len = 0;
            continue;
        }

        int spaces = (ch == '\t') ? 4 : 1;
        for (int s = 0; s < spaces; s++) {
            if (cur_len >= max_cols) {
                lines[line_count - 1][cur_len] = '\0';
                if (line_count < max_rows) {
                    line_count++;
                } else {
                    memmove(lines[0], lines[1], (size_t)(max_rows - 1) * 192);
                    lines[max_rows - 1][0] = '\0';
                    if (caret_row > 0) caret_row--;
                }
                cur_len = 0;
            }
            if (cur_len < 191) {
                lines[line_count - 1][cur_len] = (ch == '\t') ? ' ' : printable_char(ch);
            }
            cur_len++;
            if (cur_len < 192) {
                lines[line_count - 1][cur_len] = '\0';
            } else {
                lines[line_count - 1][191] = '\0';
            }
            if (ch != '\t') break;
        }
    }
    if (!caret_set) {
        caret_row = line_count - 1;
        caret_col = cur_len;
    }
    lines[line_count - 1][cur_len < 191 ? cur_len : 191] = '\0';

    for (int r = 0; r < line_count && r < max_rows; r++) {
        int y = text_top + r * FONT_HEIGHT;
        font_draw_string(win->framebuffer, win->width, win->height,
                         text_left, y, lines[r], ED_TEXT_COLOR, ED_BG_COLOR);
    }

    int cx = text_left + caret_col * FONT_WIDTH;
    int cy = text_top + caret_row * FONT_HEIGHT;
    if (cx > text_right - 2) cx = text_right - 2;
    if (cy < text_top) cy = text_top;
    if (cy > text_bottom - FONT_HEIGHT) cy = text_bottom - FONT_HEIGHT;
    draw_rect(win->framebuffer, win->width, win->height, cx, cy, 2, FONT_HEIGHT, ED_CARET_COLOR);

    draw_rect(win->framebuffer, win->width, win->height,
              0, win->height - 24, win->width, 24, ED_STATUS_BG);
    font_draw_string(win->framebuffer, win->width, win->height,
                     10, win->height - 20, ed->status, 0x2A3744, ED_STATUS_BG);
}

static void editor_handle_key(struct gui_app *app, uint32_t keycode) {
    struct editor_state *ed = &app->u.ed;

    if (keycode == '\r') keycode = '\n';

    if (ed->rename_mode) {
        if (keycode == '\n') {
            editor_commit_rename(ed);
            editor_render(app);
            return;
        }
        if (keycode == 27) {
            ed->rename_mode = false;
            editor_set_status(ed, "Rename cancelled");
            editor_render(app);
            return;
        }
        if (keycode == '\b' || keycode == 127) {
            if (ed->rename_len > 0) {
                ed->rename_len--;
                ed->rename_input[ed->rename_len] = '\0';
            }
            editor_render(app);
            return;
        }
        if (keycode >= 32 && keycode <= 126 && ed->rename_len < MAX_PATH - 1) {
            ed->rename_input[ed->rename_len++] = (char)keycode;
            ed->rename_input[ed->rename_len] = '\0';
            editor_render(app);
        }
        return;
    }

    if (keycode == KBD_KEY_LEFT) {
        if (ed->cursor > 0) ed->cursor--;
        editor_render(app);
        return;
    }
    if (keycode == KBD_KEY_RIGHT) {
        if (ed->cursor < ed->len) ed->cursor++;
        editor_render(app);
        return;
    }
    if (keycode == KBD_KEY_UP) {
        editor_move_up(ed);
        editor_render(app);
        return;
    }
    if (keycode == KBD_KEY_DOWN) {
        editor_move_down(ed);
        editor_render(app);
        return;
    }

    if (keycode == '\b' || keycode == 127) {
        if (ed->cursor == 0 || ed->len == 0) return;
        memmove(ed->text + ed->cursor - 1,
                ed->text + ed->cursor,
                ed->len - ed->cursor + 1);
        ed->cursor--;
        ed->len--;
        ed->dirty = true;
        editor_set_status(ed, "Modified");
        editor_render(app);
        return;
    }

    if (keycode == '\t') keycode = ' ';

    if (keycode != '\n' && (keycode < 32 || keycode > 126)) {
        return;
    }

    if (ed->len >= EDITOR_TEXT_MAX) {
        editor_set_status(ed, "Buffer full (8192 bytes)");
        editor_render(app);
        return;
    }

    memmove(ed->text + ed->cursor + 1,
            ed->text + ed->cursor,
            ed->len - ed->cursor + 1);
    ed->text[ed->cursor] = (char)keycode;
    ed->cursor++;
    ed->len++;
    ed->dirty = true;
    editor_set_status(ed, "Modified");
    editor_render(app);
}

static void editor_handle_click(struct gui_app *app, int x, int y) {
    struct window *win = window_get(app->window_id);
    if (!win) return;
    if (x < 0 || y < 0 || x >= win->width || y >= win->height) return;

    struct editor_state *ed = &app->u.ed;
    struct editor_toolbar_layout tb;
    editor_toolbar_compute(win, &tb);

    if (y >= tb.y && y < tb.y + tb.h) {
        if (x >= tb.save_x && x < tb.save_x + tb.save_w) {
            editor_save(ed);
            editor_render(app);
            return;
        }
        if (x >= tb.reload_x && x < tb.reload_x + tb.reload_w) {
            editor_load(ed);
            editor_render(app);
            return;
        }
        if (x >= tb.rename_x && x < tb.rename_x + tb.rename_w) {
            editor_begin_rename(ed);
            editor_render(app);
            return;
        }
        if (x >= tb.export_c_x && x < tb.export_c_x + tb.export_c_w) {
            editor_export_ext(ed, ".c");
            editor_render(app);
            return;
        }
        if (x >= tb.export_txt_x && x < tb.export_txt_x + tb.export_txt_w) {
            editor_export_ext(ed, ".txt");
            editor_render(app);
            return;
        }
    }
}

static const int settings_corner_values[] = {0, 6, 11, 16};
static const char *settings_corner_names[] = {"Square", "Soft", "Rounded", "Bubble"};
static const char *settings_theme_names[] = {"Midnight", "Aurora", "Copper"};
static const char *settings_style_names[] = {"Calm", "Vivid"};

static int settings_clamp_index(int value, int count) {
    if (count <= 0) return 0;
    while (value < 0) value += count;
    while (value >= count) value -= count;
    return value;
}

static __attribute__((unused)) int settings_corner_index_from_radius(int radius) {
    int best = 0;
    int best_diff = 1 << 30;
    for (int i = 0; i < (int)(sizeof(settings_corner_values) / sizeof(settings_corner_values[0])); i++) {
        int diff = radius - settings_corner_values[i];
        if (diff < 0) diff = -diff;
        if (diff < best_diff) {
            best_diff = diff;
            best = i;
        }
    }
    return best;
}

static void settings_apply(struct settings_state *st) {
    if (!st) return;

    int theme_count = desktop_get_theme_count();
    st->theme_id = settings_clamp_index(st->theme_id, theme_count);
    st->corner_index = settings_clamp_index(
        st->corner_index,
        (int)(sizeof(settings_corner_values) / sizeof(settings_corner_values[0]))
    );
    st->ui_style = settings_clamp_index(st->ui_style, 2);

    desktop_set_theme(st->theme_id);
    taskbar_set_style(st->ui_style);
    compositor_set_chrome_style(st->ui_style);
    compositor_set_corner_radius(settings_corner_values[st->corner_index]);

    snprintf(st->status, sizeof(st->status),
             "Applied: %s, %s corners, %s chrome",
             settings_theme_names[st->theme_id],
             settings_corner_names[st->corner_index],
             settings_style_names[st->ui_style]);
}

static void settings_row_geometry(const struct window *win, int row,
                                  int *btn_lx, int *btn_rx, int *btn_y) {
    if (!win || !btn_lx || !btn_rx || !btn_y) return;

    int row_y = SET_ROW_START_Y + row * SET_ROW_STEP;
    int value_x = win->width - 236;
    *btn_lx = value_x - 36;
    *btn_rx = value_x + 148;
    *btn_y = row_y + 17;
}

static void settings_refresh_network_status(struct settings_state *st, bool test_ping) {
    if (!st) return;

    if (!net_is_ready()) {
        snprintf(st->status, sizeof(st->status), "Network: no supported e1000 adapter detected");
        return;
    }

    char ip[24];
    char gw[24];
    net_format_ipv4(net_get_ip(), ip, sizeof(ip));
    net_format_ipv4(net_get_gateway(), gw, sizeof(gw));

    if (!test_ping) {
        snprintf(st->status, sizeof(st->status),
                 "Network refreshed: eth0 %s, ip %s",
                 net_is_link_up() ? "link up" : "link down", ip);
        return;
    }

    uint32_t rtt_ms = 0;
    if (net_ping(net_get_gateway(), 1500, &rtt_ms) == 0) {
        snprintf(st->status, sizeof(st->status),
                 "Gateway %s replied in %u ms", gw, (unsigned)rtt_ms);
    } else {
        snprintf(st->status, sizeof(st->status),
                 "Ping timeout to gateway %s", gw);
    }
}

static void settings_render(struct gui_app *app) {
    struct window *win = window_get(app->window_id);
    if (!win || !win->framebuffer) return;
    struct settings_state *st = &app->u.settings;

    draw_vertical_gradient(win->framebuffer, win->width, win->height,
                           0, 0, win->width, win->height, SET_BG_TOP, SET_BG_BOTTOM);
    draw_vertical_gradient(win->framebuffer, win->width, win->height,
                           0, 0, win->width, 46, SET_HEADER_TOP, SET_HEADER_BOTTOM);
    font_draw_string(win->framebuffer, win->width, win->height,
                     14, 14, "Macrohard FreedomBlock", SET_HEADER_TEXT, SET_HEADER_TOP);

    font_draw_string(win->framebuffer, win->width, win->height,
                     20, 58, "Visual style + network controls (MACROHARD certified).",
                     SET_SUBTEXT_COLOR, SET_BG_TOP);

    for (int row = 0; row < SET_ROW_COUNT; row++) {
        int row_y = SET_ROW_START_Y + row * SET_ROW_STEP;
        uint32_t card = (row & 1) ? SET_CARD_ALT : SET_CARD_BG;
        draw_rect(win->framebuffer, win->width, win->height,
                  20, row_y, win->width - 40, SET_ROW_HEIGHT, SET_CARD_BORDER);
        draw_rect(win->framebuffer, win->width, win->height,
                  21, row_y + 1, win->width - 42, SET_ROW_HEIGHT - 2, card);
    }

    font_draw_string(win->framebuffer, win->width, win->height,
                     32, SET_ROW_START_Y + 13, "Wallpaper Theme", SET_LABEL_COLOR, SET_CARD_BG);
    font_draw_string(win->framebuffer, win->width, win->height,
                     32, SET_ROW_START_Y + SET_ROW_STEP + 13, "Window Corners", SET_LABEL_COLOR, SET_CARD_ALT);
    font_draw_string(win->framebuffer, win->width, win->height,
                     32, SET_ROW_START_Y + SET_ROW_STEP * 2 + 13, "UI Chrome", SET_LABEL_COLOR, SET_CARD_BG);

    const char *values[3];
    values[0] = settings_theme_names[settings_clamp_index(st->theme_id, desktop_get_theme_count())];
    values[1] = settings_corner_names[settings_clamp_index(st->corner_index,
                (int)(sizeof(settings_corner_names) / sizeof(settings_corner_names[0])))];
    values[2] = settings_style_names[settings_clamp_index(st->ui_style,
                (int)(sizeof(settings_style_names) / sizeof(settings_style_names[0])))];

    for (int row = 0; row < SET_ROW_COUNT; row++) {
        int row_y = SET_ROW_START_Y + row * SET_ROW_STEP;
        int value_x = win->width - 236;
        int btn_lx, btn_rx, btn_y;
        settings_row_geometry(win, row, &btn_lx, &btn_rx, &btn_y);

        draw_rect(win->framebuffer, win->width, win->height, value_x, row_y + 13, 140, 30, SET_VALUE_BG);
        draw_rect(win->framebuffer, win->width, win->height, btn_lx, btn_y, 28, 24, SET_BUTTON_BG);
        draw_rect(win->framebuffer, win->width, win->height, btn_rx, btn_y, 28, 24, SET_BUTTON_BG);

        font_draw_string(win->framebuffer, win->width, win->height,
                         btn_lx + 10, btn_y + 6, "<", SET_BUTTON_TEXT, SET_BUTTON_BG);
        font_draw_string(win->framebuffer, win->width, win->height,
                         btn_rx + 10, btn_y + 6, ">", SET_BUTTON_TEXT, SET_BUTTON_BG);

        int vw = font_string_width(values[row]);
        int vx = value_x + (140 - vw) / 2;
        font_draw_string(win->framebuffer, win->width, win->height,
                         vx, row_y + 21, values[row], SET_VALUE_COLOR, SET_VALUE_BG);
    }

    int net_y = SET_ROW_START_Y + SET_ROW_STEP * SET_ROW_COUNT + 8;
    int net_h = 102;
    draw_rect(win->framebuffer, win->width, win->height,
              20, net_y, win->width - 40, net_h, SET_CARD_BORDER);
    draw_rect(win->framebuffer, win->width, win->height,
              21, net_y + 1, win->width - 42, net_h - 2, SET_CARD_ALT);
    font_draw_string(win->framebuffer, win->width, win->height,
                     32, net_y + 10, "Network", SET_LABEL_COLOR, SET_CARD_ALT);

    if (net_is_ready()) {
        char ip[24];
        char gw[24];
        char mask[24];
        char mac[32];

        net_format_ipv4(net_get_ip(), ip, sizeof(ip));
        net_format_ipv4(net_get_gateway(), gw, sizeof(gw));
        net_format_ipv4(net_get_netmask(), mask, sizeof(mask));
        net_format_mac(net_get_mac(), mac, sizeof(mac));

        char line[96];
        snprintf(line, sizeof(line), "eth0 (e1000)   link: %s", net_is_link_up() ? "up" : "down");
        font_draw_string(win->framebuffer, win->width, win->height,
                         32, net_y + 28, line, net_is_link_up() ? SET_NET_OK : SET_NET_WARN, SET_CARD_ALT);

        snprintf(line, sizeof(line), "IPv4: %s   GW: %s", ip, gw);
        font_draw_string(win->framebuffer, win->width, win->height,
                         32, net_y + 44, line, SET_VALUE_COLOR, SET_CARD_ALT);

        snprintf(line, sizeof(line), "Mask: %s   MAC: %s", mask, mac);
        font_draw_string(win->framebuffer, win->width, win->height,
                         32, net_y + 60, line, SET_VALUE_COLOR, SET_CARD_ALT);
    } else {
        font_draw_string(win->framebuffer, win->width, win->height,
                         32, net_y + 36, "No supported e1000 adapter detected.",
                         SET_NET_WARN, SET_CARD_ALT);
    }

    int net_btn_y = net_y + 72;
    int refresh_x = win->width - 250;
    int ping_x = win->width - 138;
    int btn_w = 102;
    int btn_h = 24;
    draw_rect(win->framebuffer, win->width, win->height, refresh_x, net_btn_y, btn_w, btn_h, SET_BUTTON_BG);
    draw_rect(win->framebuffer, win->width, win->height, ping_x, net_btn_y, btn_w, btn_h, SET_BUTTON_ALT);
    font_draw_string(win->framebuffer, win->width, win->height,
                     refresh_x + 22, net_btn_y + 6, "Refresh", SET_BUTTON_TEXT, SET_BUTTON_BG);
    font_draw_string(win->framebuffer, win->width, win->height,
                     ping_x + 18, net_btn_y + 6, "Ping GW", SET_BUTTON_TEXT, SET_BUTTON_ALT);

    for (int x = 0; x < win->width; x += 10) {
        draw_rect(win->framebuffer, win->width, win->height,
                  x, win->height - 30, 1, 30, 0xB9C9DE);
    }

    draw_rect(win->framebuffer, win->width, win->height,
              0, win->height - 28, win->width, 28, SET_STATUS_BG);
    font_draw_string(win->framebuffer, win->width, win->height,
                     10, win->height - 20, st->status, SET_STATUS_TEXT, SET_STATUS_BG);
}

static void settings_handle_click(struct gui_app *app, int x, int y) {
    struct window *win = window_get(app->window_id);
    if (!win) return;
    if (x < 0 || y < 0 || x >= win->width || y >= win->height) return;
    struct settings_state *st = &app->u.settings;

    for (int row = 0; row < SET_ROW_COUNT; row++) {
        int btn_lx, btn_rx, btn_y;
        settings_row_geometry(win, row, &btn_lx, &btn_rx, &btn_y);
        if (y < btn_y || y >= btn_y + 24) continue;

        int delta = 0;
        if (x >= btn_lx && x < btn_lx + 28) delta = -1;
        if (x >= btn_rx && x < btn_rx + 28) delta = +1;
        if (delta == 0) continue;

        if (row == 0) {
            st->theme_id += delta;
        } else if (row == 1) {
            st->corner_index += delta;
        } else {
            st->ui_style += delta;
        }
        settings_apply(st);
        settings_render(app);
        return;
    }

    int net_y = SET_ROW_START_Y + SET_ROW_STEP * SET_ROW_COUNT + 8;
    int net_btn_y = net_y + 72;
    int refresh_x = win->width - 250;
    int ping_x = win->width - 138;
    int btn_w = 102;

    if (y >= net_btn_y && y < net_btn_y + 24) {
        if (x >= refresh_x && x < refresh_x + btn_w) {
            settings_refresh_network_status(st, false);
            settings_render(app);
            return;
        }
        if (x >= ping_x && x < ping_x + btn_w) {
            settings_refresh_network_status(st, true);
            settings_render(app);
            return;
        }
    }
}

static const char *action_proc_state_name(proc_state_t state) {
    switch (state) {
        case PROC_READY:    return "READY";
        case PROC_RUNNING:  return "RUN";
        case PROC_BLOCKED:  return "BLOCK";
        case PROC_SLEEPING: return "SLEEP";
        case PROC_ZOMBIE:   return "ZOMB";
        default:            return "UNUSED";
    }
}

static int action_total_processes(void) {
    int total = 0;
    for (int pid = 0; pid < MAX_PROCESSES; pid++) {
        if (process_get(pid)) total++;
    }
    return total;
}

static int action_visible_rows(const struct window *win) {
    if (!win) return 0;
    int rows = (win->height - 148) / (FONT_HEIGHT + 4);
    if (rows < 3) rows = 3;
    return rows;
}

static int action_pid_at_index(int index) {
    if (index < 0) return -1;
    int seen = 0;
    for (int pid = 0; pid < MAX_PROCESSES; pid++) {
        if (!process_get(pid)) continue;
        if (seen == index) return pid;
        seen++;
    }
    return -1;
}

static void action_clamp_scroll(struct action_state *st, const struct window *win) {
    if (!st || !win) return;

    int total = action_total_processes();
    int rows = action_visible_rows(win);
    int max_scroll = total - rows;
    if (max_scroll < 0) max_scroll = 0;

    if (st->scroll < 0) st->scroll = 0;
    if (st->scroll > max_scroll) st->scroll = max_scroll;
}

static void action_refresh_status(struct action_state *st) {
    if (!st) return;
    uint64_t ticks = pit_get_ticks();
    uint64_t sec = ticks / 100;
    snprintf(st->status, sizeof(st->status), "Refreshed at %02u:%02u:%02u",
             (unsigned)((sec / 3600) % 24),
             (unsigned)((sec / 60) % 60),
             (unsigned)(sec % 60));
}

static void action_render(struct gui_app *app) {
    struct window *win = window_get(app->window_id);
    if (!win || !win->framebuffer) return;

    struct action_state *st = &app->u.action;
    action_clamp_scroll(st, win);

    fill_window(win->framebuffer, win->width, win->height, ACT_BG_COLOR);
    draw_rect(win->framebuffer, win->width, win->height, 0, 0, win->width, 34, ACT_HEADER_COLOR);
    draw_rect(win->framebuffer, win->width, win->height, 0, 34, win->width, 1, ACT_BORDER_COLOR);
    font_draw_string(win->framebuffer, win->width, win->height,
                     12, 11, "Macrohard Action Employee", ACT_TEXT_COLOR, ACT_HEADER_COLOR);

    uint64_t total_mb = pmm_get_total_memory() / (1024 * 1024);
    uint64_t free_mb = pmm_get_free_memory() / (1024 * 1024);
    uint64_t ticks = pit_get_ticks();
    uint64_t sec = ticks / 100;
    int proc_count = action_total_processes();

    char line[96];
    snprintf(line, sizeof(line), "Processes: %d", proc_count);
    font_draw_string(win->framebuffer, win->width, win->height,
                     14, 46, line, ACT_TEXT_COLOR, ACT_BG_COLOR);
    snprintf(line, sizeof(line), "Memory: %u / %u MB free", (unsigned)free_mb, (unsigned)total_mb);
    font_draw_string(win->framebuffer, win->width, win->height,
                     14, 62, line, ACT_SUBTEXT_COLOR, ACT_BG_COLOR);
    snprintf(line, sizeof(line), "Uptime: %u:%02u:%02u", (unsigned)((sec / 3600) % 24),
             (unsigned)((sec / 60) % 60), (unsigned)(sec % 60));
    font_draw_string(win->framebuffer, win->width, win->height,
                     14, 78, line, ACT_SUBTEXT_COLOR, ACT_BG_COLOR);

    int refresh_x = win->width - 116;
    int refresh_y = 52;
    draw_rect(win->framebuffer, win->width, win->height,
              refresh_x, refresh_y, 96, 24, ACT_BUTTON_COLOR);
    font_draw_string(win->framebuffer, win->width, win->height,
                     refresh_x + 22, refresh_y + 8, "Refresh", 0xFFFFFF, ACT_BUTTON_COLOR);

    int table_y = 96;
    draw_rect(win->framebuffer, win->width, win->height,
              10, table_y, win->width - 20, 18, ACT_HEADER_COLOR);
    font_draw_string(win->framebuffer, win->width, win->height,
                     18, table_y + 6, "PID   STATE    NAME", ACT_TEXT_COLOR, ACT_HEADER_COLOR);

    int rows = action_visible_rows(win);
    int draw_row = 0;
    int seen = 0;
    for (int pid = 0; pid < MAX_PROCESSES && draw_row < rows; pid++) {
        struct process *p = process_get(pid);
        if (!p) continue;
        if (seen++ < st->scroll) continue;

        int row_y = table_y + 20 + draw_row * (FONT_HEIGHT + 4);
        uint32_t bg = (draw_row & 1) ? ACT_ROW_B : ACT_ROW_A;
        if (st->selected_pid == pid) bg = ACT_ROW_SELECTED;
        draw_rect(win->framebuffer, win->width, win->height,
                  10, row_y, win->width - 20, FONT_HEIGHT + 4, bg);

        snprintf(line, sizeof(line), "%3d   %-7s  %.34s",
                 p->pid, action_proc_state_name(p->state), p->name);
        font_draw_string(win->framebuffer, win->width, win->height,
                         16, row_y + 2, line, ACT_TEXT_COLOR, bg);
        draw_row++;
    }

    draw_rect(win->framebuffer, win->width, win->height,
              0, win->height - 26, win->width, 26, ACT_STATUS_COLOR);
    font_draw_string(win->framebuffer, win->width, win->height,
                     10, win->height - 18, st->status, ACT_SUBTEXT_COLOR, ACT_STATUS_COLOR);
}

static void action_handle_click(struct gui_app *app, int x, int y) {
    struct window *win = window_get(app->window_id);
    if (!win) return;

    struct action_state *st = &app->u.action;
    action_clamp_scroll(st, win);

    int refresh_x = win->width - 116;
    int refresh_y = 52;
    if (x >= refresh_x && x < refresh_x + 96 &&
        y >= refresh_y && y < refresh_y + 24) {
        action_refresh_status(st);
        action_render(app);
        return;
    }

    int table_y = 96;
    int rows = action_visible_rows(win);
    for (int row = 0; row < rows; row++) {
        int row_y = table_y + 20 + row * (FONT_HEIGHT + 4);
        if (y < row_y || y >= row_y + FONT_HEIGHT + 4) continue;
        int target_index = st->scroll + row;
        st->selected_pid = action_pid_at_index(target_index);
        if (st->selected_pid >= 0) {
            snprintf(st->status, sizeof(st->status), "Selected PID %d (read-only monitor)",
                     st->selected_pid);
        }
        action_render(app);
        return;
    }
}

static void action_handle_key(struct gui_app *app, uint32_t keycode) {
    struct window *win = window_get(app->window_id);
    if (!win) return;

    struct action_state *st = &app->u.action;
    action_clamp_scroll(st, win);

    if (keycode == KBD_KEY_UP || keycode == 'k' || keycode == 'K') {
        st->scroll--;
        action_clamp_scroll(st, win);
        action_render(app);
        return;
    }
    if (keycode == KBD_KEY_DOWN || keycode == 'j' || keycode == 'J') {
        st->scroll++;
        action_clamp_scroll(st, win);
        action_render(app);
        return;
    }
    if (keycode == 'r' || keycode == 'R') {
        action_refresh_status(st);
        action_render(app);
    }
}

struct calc_button {
    const char *label;
    uint32_t color;
};

static const struct calc_button calc_buttons[5][4] = {
    {{"7", CALC_BUTTON_BG}, {"8", CALC_BUTTON_BG}, {"9", CALC_BUTTON_BG}, {"/", CALC_BUTTON_OP}},
    {{"4", CALC_BUTTON_BG}, {"5", CALC_BUTTON_BG}, {"6", CALC_BUTTON_BG}, {"*", CALC_BUTTON_OP}},
    {{"1", CALC_BUTTON_BG}, {"2", CALC_BUTTON_BG}, {"3", CALC_BUTTON_BG}, {"-", CALC_BUTTON_OP}},
    {{"0", CALC_BUTTON_BG}, {"(", CALC_BUTTON_BG}, {")", CALC_BUTTON_BG}, {"+", CALC_BUTTON_OP}},
    {{"C", CALC_BUTTON_CLR}, {"<-", CALC_BUTTON_CLR}, {"=", CALC_BUTTON_EQ}, {"%", CALC_BUTTON_OP}},
};

static void calc_set_status(struct calculator_state *st, const char *msg) {
    if (!st || !msg) return;
    strncpy(st->status, msg, sizeof(st->status) - 1);
    st->status[sizeof(st->status) - 1] = '\0';
}

static void calc_append(struct calculator_state *st, const char *token) {
    if (!st || !token) return;
    if (st->expr_len >= (int)sizeof(st->expr) - 1) return;

    while (*token && st->expr_len < (int)sizeof(st->expr) - 1) {
        st->expr[st->expr_len++] = *token++;
    }
    st->expr[st->expr_len] = '\0';
}

static void calc_backspace(struct calculator_state *st) {
    if (!st || st->expr_len <= 0) return;
    st->expr_len--;
    st->expr[st->expr_len] = '\0';
}

static void calc_clear(struct calculator_state *st) {
    if (!st) return;
    st->expr_len = 0;
    st->expr[0] = '\0';
    st->has_result = 0;
    st->result = 0;
    calc_set_status(st, "Cleared");
}

static void calc_eval_expr(struct calculator_state *st) {
    if (!st) return;
    if (st->expr_len <= 0) {
        calc_set_status(st, "Enter an expression");
        return;
    }

    int result = 0;
    char err[64];
    if (!term_calc_eval(st->expr, &result, err, sizeof(err))) {
        char msg[96];
        snprintf(msg, sizeof(msg), "Error: %s", err);
        calc_set_status(st, msg);
        st->has_result = 0;
        return;
    }

    st->has_result = 1;
    st->result = result;
    char msg[96];
    snprintf(msg, sizeof(msg), "Result = %d", result);
    calc_set_status(st, msg);
}

static void calc_button_geometry(const struct window *win, int row, int col,
                                 int *x, int *y, int *w, int *h) {
    int pad = 12;
    int spacing = 8;
    int grid_y = 132;
    int cols = 4;
    int rows = 5;
    int btn_w = (win->width - pad * 2 - spacing * (cols - 1)) / cols;
    int btn_h = (win->height - grid_y - 42 - spacing * (rows - 1)) / rows;
    if (btn_h < 24) btn_h = 24;

    *x = pad + col * (btn_w + spacing);
    *y = grid_y + row * (btn_h + spacing);
    *w = btn_w;
    *h = btn_h;
}

static void calc_render(struct gui_app *app) {
    struct window *win = window_get(app->window_id);
    if (!win || !win->framebuffer) return;
    struct calculator_state *st = &app->u.calc;

    fill_window(win->framebuffer, win->width, win->height, CALC_BG_COLOR);
    draw_rect(win->framebuffer, win->width, win->height, 0, 0, win->width, 34, CALC_HEADER_COLOR);
    font_draw_string(win->framebuffer, win->width, win->height,
                     12, 11, "Calculator", 0xFFFFFF, CALC_HEADER_COLOR);

    draw_rect(win->framebuffer, win->width, win->height,
              12, 46, win->width - 24, 72, CALC_DISPLAY_BG);
    font_draw_string(win->framebuffer, win->width, win->height,
                     20, 58, st->expr_len > 0 ? st->expr : "0", CALC_DISPLAY_TEXT, CALC_DISPLAY_BG);

    if (st->has_result) {
        char result_line[64];
        snprintf(result_line, sizeof(result_line), "= %d", st->result);
        font_draw_string(win->framebuffer, win->width, win->height,
                         20, 82, result_line, CALC_DISPLAY_TEXT, CALC_DISPLAY_BG);
    } else {
        font_draw_string(win->framebuffer, win->width, win->height,
                         20, 82, "Enter with keyboard or click buttons", 0x4A5D73, CALC_DISPLAY_BG);
    }

    for (int row = 0; row < 5; row++) {
        for (int col = 0; col < 4; col++) {
            int bx, by, bw, bh;
            calc_button_geometry(win, row, col, &bx, &by, &bw, &bh);
            uint32_t color = calc_buttons[row][col].color;
            draw_rect(win->framebuffer, win->width, win->height, bx, by, bw, bh, color);

            int lw = font_string_width(calc_buttons[row][col].label);
            int lx = bx + (bw - lw) / 2;
            int ly = by + (bh - FONT_HEIGHT) / 2;
            font_draw_string(win->framebuffer, win->width, win->height,
                             lx, ly, calc_buttons[row][col].label, 0x102338, color);
        }
    }

    draw_rect(win->framebuffer, win->width, win->height,
              0, win->height - 26, win->width, 26, CALC_STATUS_BG);
    font_draw_string(win->framebuffer, win->width, win->height,
                     10, win->height - 18, st->status, CALC_STATUS_TEXT, CALC_STATUS_BG);
}

static void calc_apply_button(struct calculator_state *st, const char *label) {
    if (!st || !label) return;

    if (strcmp(label, "C") == 0) {
        calc_clear(st);
        return;
    }
    if (strcmp(label, "<-") == 0) {
        calc_backspace(st);
        calc_set_status(st, "Backspace");
        st->has_result = 0;
        return;
    }
    if (strcmp(label, "=") == 0) {
        calc_eval_expr(st);
        return;
    }

    calc_append(st, label);
    st->has_result = 0;
    calc_set_status(st, "Editing expression");
}

static void calc_handle_click(struct gui_app *app, int x, int y) {
    struct window *win = window_get(app->window_id);
    if (!win) return;
    struct calculator_state *st = &app->u.calc;

    for (int row = 0; row < 5; row++) {
        for (int col = 0; col < 4; col++) {
            int bx, by, bw, bh;
            calc_button_geometry(win, row, col, &bx, &by, &bw, &bh);
            if (x >= bx && x < bx + bw && y >= by && y < by + bh) {
                calc_apply_button(st, calc_buttons[row][col].label);
                calc_render(app);
                return;
            }
        }
    }
}

static void calc_handle_key(struct gui_app *app, uint32_t keycode) {
    struct calculator_state *st = &app->u.calc;
    char ch = (char)keycode;

    if (keycode == '\r' || keycode == '\n') {
        calc_eval_expr(st);
        calc_render(app);
        return;
    }
    if (keycode == '\b' || keycode == 127) {
        calc_backspace(st);
        calc_set_status(st, "Backspace");
        st->has_result = 0;
        calc_render(app);
        return;
    }
    if (ch == 'c' || ch == 'C' || keycode == 27) {
        calc_clear(st);
        calc_render(app);
        return;
    }

    if ((ch >= '0' && ch <= '9') ||
        ch == '+' || ch == '-' || ch == '*' || ch == '/' ||
        ch == '%' || ch == '(' || ch == ')') {
        char token[2] = {ch, '\0'};
        calc_append(st, token);
        calc_set_status(st, "Editing expression");
        st->has_result = 0;
        calc_render(app);
    }
}

void gui_apps_init(void) {
    memset(apps, 0, sizeof(apps));
}

int gui_apps_spawn_terminal(void) {
    int pid = process_spawn_user("/bin/terminal");
    if (pid < 0) {
        kprintf("[APPS] Failed to spawn /bin/terminal\n");
        return -1;
    }
    return pid;
}

int gui_apps_spawn_file_manager(void) {
    int pid = process_spawn_user("/bin/fileman");
    if (pid < 0) {
        kprintf("[APPS] Failed to spawn /bin/fileman\n");
        return -1;
    }
    return pid;
}

static int gui_apps_spawn_text_editor_path(const char *path) {
    (void)path;
    int pid = process_spawn_user("/bin/textedit");
    if (pid < 0) {
        kprintf("[APPS] Failed to spawn /bin/textedit\n");
        return -1;
    }
    return pid;
}

int gui_apps_spawn_text_editor(void) {
    return gui_apps_spawn_text_editor_path("/notes.txt");
}

int gui_apps_spawn_settings_panel(void) {
    int pid = process_spawn_user("/bin/settings");
    if (pid < 0) {
        kprintf("[APPS] Failed to spawn /bin/settings\n");
        return -1;
    }
    return pid;
}

int gui_apps_spawn_action_employee(void) {
    int pid = process_spawn_user("/bin/action");
    if (pid < 0) {
        kprintf("[APPS] Failed to spawn /bin/action\n");
        return -1;
    }
    return pid;
}

int gui_apps_spawn_calculator(void) {
    int pid = process_spawn_user("/bin/calculator");
    if (pid < 0) {
        kprintf("[APPS] Failed to spawn /bin/calculator\n");
        return -1;
    }
    return pid;
}

int gui_apps_spawn_python(void) {
    int pid = process_spawn_user("/bin/python");
    if (pid < 0) {
        kprintf("[APPS] Failed to spawn /bin/python\n");
        return -1;
    }
    return pid;
}

int gui_apps_spawn_game(void) {
    int pid = process_spawn_user("/bin/game");
    if (pid < 0) {
        kprintf("[APPS] Failed to spawn /bin/game\n");
        return -1;
    }
    return pid;
}

bool gui_apps_terminal_stream_write(int wid, const char *buf, size_t len) {
    if (wid < 0 || !buf || len == 0) return false;

    struct gui_app *app = app_find(wid);
    if (!app || app->type != APP_TYPE_TERMINAL) return false;

    struct window *win = window_get(wid);
    if (!win) return false;

    term_stream_write_bytes(&app->u.term, win, buf, len);
    term_render(app);
    return true;
}

void gui_apps_terminal_stream_flush(int wid) {
    if (wid < 0) return;

    struct gui_app *app = app_find(wid);
    if (!app || app->type != APP_TYPE_TERMINAL) return;

    term_stream_flush_pending(&app->u.term);
    term_render(app);
}

void gui_apps_handle_event(const struct gui_event *ev) {
    if (!ev) return;

    struct gui_app *app = app_find((int)ev->window_id);
    if (!app) return;

    if (app->type == APP_TYPE_TERMINAL) {
        if (ev->type == GUI_EVENT_KEY_PRESS) {
            term_handle_key(app, (char)ev->keycode);
        } else if (ev->type == GUI_EVENT_WIN_FOCUS) {
            term_render(app);
        }
        return;
    }

    if (app->type == APP_TYPE_FILE_MANAGER) {
        if (ev->type == GUI_EVENT_MOUSE_DOWN) {
            fileman_handle_click(app, ev->x, ev->y);
        } else if (ev->type == GUI_EVENT_KEY_PRESS) {
            if (ev->keycode == '\b' || ev->keycode == 127) {
                char parent[MAX_PATH];
                parent_path(app->u.fm.cwd, parent, sizeof(parent));
                strncpy(app->u.fm.cwd, parent, sizeof(app->u.fm.cwd) - 1);
                app->u.fm.cwd[sizeof(app->u.fm.cwd) - 1] = '\0';
                fileman_reload(&app->u.fm);
                fileman_render(app);
            }
        } else if (ev->type == GUI_EVENT_WIN_FOCUS) {
            fileman_render(app);
        }
        return;
    }

    if (app->type == APP_TYPE_TEXT_EDITOR) {
        if (ev->type == GUI_EVENT_KEY_PRESS) {
            editor_handle_key(app, ev->keycode);
        } else if (ev->type == GUI_EVENT_MOUSE_DOWN) {
            editor_handle_click(app, ev->x, ev->y);
        } else if (ev->type == GUI_EVENT_WIN_FOCUS) {
            editor_render(app);
        }
        return;
    }

    if (app->type == APP_TYPE_SETTINGS) {
        if (ev->type == GUI_EVENT_MOUSE_DOWN) {
            settings_handle_click(app, ev->x, ev->y);
        } else if (ev->type == GUI_EVENT_WIN_FOCUS) {
            settings_render(app);
        }
        return;
    }

    if (app->type == APP_TYPE_ACTION_EMPLOYEE) {
        if (ev->type == GUI_EVENT_MOUSE_DOWN) {
            action_handle_click(app, ev->x, ev->y);
        } else if (ev->type == GUI_EVENT_KEY_PRESS) {
            action_handle_key(app, ev->keycode);
        } else if (ev->type == GUI_EVENT_WIN_FOCUS) {
            action_render(app);
        }
        return;
    }

    if (app->type == APP_TYPE_CALCULATOR) {
        if (ev->type == GUI_EVENT_MOUSE_DOWN) {
            calc_handle_click(app, ev->x, ev->y);
        } else if (ev->type == GUI_EVENT_KEY_PRESS) {
            calc_handle_key(app, ev->keycode);
        } else if (ev->type == GUI_EVENT_WIN_FOCUS) {
            calc_render(app);
        }
        return;
    }
}

void gui_apps_on_window_destroyed(int wid) {
    app_free(wid);
}

bool gui_apps_is_type_running(int app_type) {
    const char *name = NULL;
    switch (app_type) {
        case APP_TYPE_TERMINAL: name = "terminal"; break;
        case APP_TYPE_FILE_MANAGER: name = "fileman"; break;
        case APP_TYPE_TEXT_EDITOR: name = "textedit"; break;
        case APP_TYPE_SETTINGS: name = "settings"; break;
        case APP_TYPE_ACTION_EMPLOYEE: name = "action"; break;
        case APP_TYPE_CALCULATOR: name = "calculator"; break;
        case APP_TYPE_PYTHON: name = "python"; break;
        case APP_TYPE_GAME: name = "game"; break;
        default: break;
    }

    if (name) {
        for (int pid = 1; pid < MAX_PROCESSES; pid++) {
            struct process *p = process_get(pid);
            if (!p) continue;
            if (!(p->flags & PROC_FLAG_USER)) continue;
            if (p->state == PROC_ZOMBIE) continue;
            if (strcmp(p->name, name) == 0) return true;
        }
        return false;
    }

    for (int i = 0; i < MAX_WINDOWS; i++) {
        if (apps[i].used && apps[i].type == (uint8_t)app_type) return true;
    }
    return false;
}

bool gui_apps_is_managed(int wid) {
    if (app_find(wid)) return true;

    struct window *win = window_get(wid);
    if (!win || win->owner_pid <= 0) return false;

    struct process *p = process_get(win->owner_pid);
    if (!p || !(p->flags & PROC_FLAG_USER) || p->state == PROC_ZOMBIE) return false;

    return strcmp(p->name, "terminal") == 0 ||
           strcmp(p->name, "fileman") == 0 ||
           strcmp(p->name, "textedit") == 0 ||
           strcmp(p->name, "settings") == 0 ||
           strcmp(p->name, "action") == 0 ||
           strcmp(p->name, "calculator") == 0 ||
           strcmp(p->name, "python") == 0 ||
           strcmp(p->name, "game") == 0;
}
