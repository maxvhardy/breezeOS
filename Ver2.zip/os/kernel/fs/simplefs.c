#include "fs/simplefs.h"
#include "drivers/ata.h"
#include "mm/heap.h"
#include "lib/string.h"
#include "lib/printf.h"

static uint32_t fs_start_lba;
static struct sfs_superblock sb;
static uint8_t block_buf[SFS_BLOCK_SIZE];

static int sfs_read_block(uint32_t block, void *buf) {
    uint32_t lba = fs_start_lba + block * SFS_SECTORS_PER_BLOCK;
    return ata_read_sectors(lba, SFS_SECTORS_PER_BLOCK, buf);
}

static int sfs_write_block(uint32_t block, const void *buf) {
    uint32_t lba = fs_start_lba + block * SFS_SECTORS_PER_BLOCK;
    return ata_write_sectors(lba, SFS_SECTORS_PER_BLOCK, buf);
}

static int sfs_read_inode(uint32_t inum, struct sfs_inode *inode) {
    uint32_t inodes_per_block = SFS_BLOCK_SIZE / SFS_INODE_SIZE;
    uint32_t block = sb.inode_start + inum / inodes_per_block;
    uint32_t offset = (inum % inodes_per_block) * SFS_INODE_SIZE;

    if (sfs_read_block(block, block_buf) < 0) return -1;
    memcpy(inode, block_buf + offset, sizeof(struct sfs_inode));
    return 0;
}

static int sfs_write_inode(uint32_t inum, const struct sfs_inode *inode) {
    uint32_t inodes_per_block = SFS_BLOCK_SIZE / SFS_INODE_SIZE;
    uint32_t block = sb.inode_start + inum / inodes_per_block;
    uint32_t offset = (inum % inodes_per_block) * SFS_INODE_SIZE;

    if (sfs_read_block(block, block_buf) < 0) return -1;
    memcpy(block_buf + offset, inode, sizeof(struct sfs_inode));
    return sfs_write_block(block, block_buf);
}

static uint32_t sfs_alloc_block(void) {
    uint8_t bmap[SFS_BLOCK_SIZE];
    for (uint32_t b = 0; b < sb.bitmap_blocks; b++) {
        if (sfs_read_block(sb.bitmap_start + b, bmap) < 0) return 0;
        for (uint32_t i = 0; i < SFS_BLOCK_SIZE; i++) {
            if (bmap[i] == 0xFF) continue;
            for (int bit = 0; bit < 8; bit++) {
                if (!(bmap[i] & (1 << bit))) {
                    bmap[i] |= (1 << bit);
                    sfs_write_block(sb.bitmap_start + b, bmap);
                    sb.free_blocks--;
                    return b * SFS_BLOCK_SIZE * 8 + i * 8 + bit + sb.data_start;
                }
            }
        }
    }
    return 0;
}

static void sfs_free_block(uint32_t block_num) {
    if (block_num < sb.data_start) return;
    uint32_t rel = block_num - sb.data_start;
    uint32_t bmap_block = rel / (SFS_BLOCK_SIZE * 8);
    uint32_t bmap_byte = (rel % (SFS_BLOCK_SIZE * 8)) / 8;
    uint32_t bmap_bit = rel % 8;

    uint8_t bmap[SFS_BLOCK_SIZE];
    sfs_read_block(sb.bitmap_start + bmap_block, bmap);
    bmap[bmap_byte] &= ~(1 << bmap_bit);
    sfs_write_block(sb.bitmap_start + bmap_block, bmap);
    sb.free_blocks++;
}

static uint32_t sfs_alloc_inode(void) {
    struct sfs_inode inode;
    for (uint32_t i = 1; i < sb.total_inodes; i++) {
        sfs_read_inode(i, &inode);
        if (inode.type == SFS_TYPE_FREE) {
            sb.free_inodes--;
            return i;
        }
    }
    return 0;
}

static uint32_t sfs_get_block_ptr(struct sfs_inode *inode, uint32_t block_index) {
    if (block_index < SFS_DIRECT_BLOCKS) {
        return inode->direct[block_index];
    }
    block_index -= SFS_DIRECT_BLOCKS;
    if (block_index < SFS_BLOCK_SIZE / 4) {
        if (!inode->indirect) return 0;
        uint32_t ptrs[SFS_BLOCK_SIZE / 4];
        sfs_read_block(inode->indirect, ptrs);
        return ptrs[block_index];
    }
    return 0;
}

static int sfs_set_block_ptr(struct sfs_inode *inode, uint32_t block_index, uint32_t block_num) {
    if (block_index < SFS_DIRECT_BLOCKS) {
        inode->direct[block_index] = block_num;
        return 0;
    }
    block_index -= SFS_DIRECT_BLOCKS;
    if (block_index < SFS_BLOCK_SIZE / 4) {
        if (!inode->indirect) {
            inode->indirect = sfs_alloc_block();
            if (!inode->indirect) return -1;
            uint8_t zeros[SFS_BLOCK_SIZE];
            memset(zeros, 0, SFS_BLOCK_SIZE);
            sfs_write_block(inode->indirect, zeros);
        }
        uint32_t ptrs[SFS_BLOCK_SIZE / 4];
        sfs_read_block(inode->indirect, ptrs);
        ptrs[block_index] = block_num;
        sfs_write_block(inode->indirect, ptrs);
        return 0;
    }
    return -1;
}

// Resolve path to inode number
static uint32_t sfs_resolve_path(const char *path) {
    if (!path || path[0] != '/') return 0;
    if (path[0] == '/' && path[1] == '\0') return sb.root_inode;

    uint32_t current = sb.root_inode;
    char component[MAX_NAME + 1];
    const char *p = path + 1;

    while (*p) {
        // Extract next component
        int i = 0;
        while (*p && *p != '/' && i < MAX_NAME) {
            component[i++] = *p++;
        }
        component[i] = '\0';
        if (*p == '/') p++;
        if (i == 0) continue;

        // Look up component in current directory
        struct sfs_inode dir_inode;
        sfs_read_inode(current, &dir_inode);
        if (dir_inode.type != SFS_TYPE_DIR) return 0;

        int found = 0;
        uint32_t num_entries = dir_inode.size / SFS_DIRENT_SIZE;
        uint32_t entries_read = 0;
        for (uint32_t bi = 0; entries_read < num_entries; bi++) {
            uint32_t blk = sfs_get_block_ptr(&dir_inode, bi);
            if (!blk) break;

            struct sfs_dirent dirents[SFS_BLOCK_SIZE / SFS_DIRENT_SIZE];
            sfs_read_block(blk, dirents);

            uint32_t per_block = SFS_BLOCK_SIZE / SFS_DIRENT_SIZE;
            for (uint32_t j = 0; j < per_block && entries_read < num_entries; j++, entries_read++) {
                if (dirents[j].inode && strcmp(dirents[j].name, component) == 0) {
                    current = dirents[j].inode;
                    found = 1;
                    break;
                }
            }
            if (found) break;
        }
        if (!found) return 0;
    }
    return current;
}

static void sfs_split_path(const char *path, char *parent, char *name) {
    strcpy(parent, path);
    char *last = strrchr(parent, '/');
    if (last == parent) {
        strcpy(name, parent + 1);
        parent[1] = '\0';
    } else if (last) {
        strcpy(name, last + 1);
        *last = '\0';
    } else {
        strcpy(name, path);
        strcpy(parent, "/");
    }
}

// VFS operations implementation

static ssize_t sfs_vfs_read(struct vfs_node *node, void *buf, size_t count) {
    struct sfs_inode inode;
    sfs_read_inode(node->inode, &inode);

    if (node->offset >= inode.size) return 0;
    if (node->offset + count > inode.size) count = inode.size - node->offset;

    size_t read = 0;
    uint8_t tmp[SFS_BLOCK_SIZE];

    while (read < count) {
        uint32_t block_index = (node->offset + read) / SFS_BLOCK_SIZE;
        uint32_t block_offset = (node->offset + read) % SFS_BLOCK_SIZE;
        uint32_t blk = sfs_get_block_ptr(&inode, block_index);
        if (!blk) break;

        sfs_read_block(blk, tmp);

        size_t to_copy = SFS_BLOCK_SIZE - block_offset;
        if (to_copy > count - read) to_copy = count - read;
        memcpy((uint8_t *)buf + read, tmp + block_offset, to_copy);
        read += to_copy;
    }

    node->offset += read;
    return (ssize_t)read;
}

static ssize_t sfs_vfs_write(struct vfs_node *node, const void *buf, size_t count) {
    struct sfs_inode inode;
    sfs_read_inode(node->inode, &inode);

    if (node->flags & O_APPEND) {
        node->offset = inode.size;
    }

    size_t written = 0;
    uint8_t tmp[SFS_BLOCK_SIZE];

    while (written < count) {
        uint32_t block_index = (node->offset + written) / SFS_BLOCK_SIZE;
        uint32_t block_offset = (node->offset + written) % SFS_BLOCK_SIZE;
        uint32_t blk = sfs_get_block_ptr(&inode, block_index);

        if (!blk) {
            blk = sfs_alloc_block();
            if (!blk) break;
            sfs_set_block_ptr(&inode, block_index, blk);
            inode.blocks++;
            memset(tmp, 0, SFS_BLOCK_SIZE);
        } else {
            sfs_read_block(blk, tmp);
        }

        size_t to_copy = SFS_BLOCK_SIZE - block_offset;
        if (to_copy > count - written) to_copy = count - written;
        memcpy(tmp + block_offset, (const uint8_t *)buf + written, to_copy);
        sfs_write_block(blk, tmp);
        written += to_copy;
    }

    node->offset += written;
    if (node->offset > inode.size) {
        inode.size = node->offset;
    }
    node->size = inode.size;
    sfs_write_inode(node->inode, &inode);

    return (ssize_t)written;
}

static int sfs_vfs_open(struct vfs_node *node, int flags) {
    const char *path = node->name;
    uint32_t inum = sfs_resolve_path(path);

    if (!inum && (flags & O_CREAT)) {
        // Create new file
        char parent[MAX_PATH], name[MAX_NAME + 1];
        sfs_split_path(path, parent, name);

        uint32_t parent_inum = sfs_resolve_path(parent);
        if (!parent_inum) return -1;

        inum = sfs_alloc_inode();
        if (!inum) return -1;

        struct sfs_inode new_inode;
        memset(&new_inode, 0, sizeof(new_inode));
        new_inode.type = SFS_TYPE_FILE;
        sfs_write_inode(inum, &new_inode);

        // Add entry to parent directory
        struct sfs_inode parent_inode;
        sfs_read_inode(parent_inum, &parent_inode);

        struct sfs_dirent entry;
        memset(&entry, 0, sizeof(entry));
        entry.inode = inum;
        entry.type = SFS_TYPE_FILE;
        entry.name_len = strlen(name);
        strncpy(entry.name, name, SFS_DIRENT_SIZE - 6);

        // Find space in directory or allocate new block
        uint32_t num_entries = parent_inode.size / SFS_DIRENT_SIZE;
        uint32_t target_block_index = num_entries / (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE);
        uint32_t target_offset = (num_entries % (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE)) * SFS_DIRENT_SIZE;

        uint32_t blk = sfs_get_block_ptr(&parent_inode, target_block_index);
        if (!blk) {
            blk = sfs_alloc_block();
            if (!blk) return -1;
            sfs_set_block_ptr(&parent_inode, target_block_index, blk);
            parent_inode.blocks++;
            uint8_t zeros[SFS_BLOCK_SIZE];
            memset(zeros, 0, SFS_BLOCK_SIZE);
            sfs_write_block(blk, zeros);
        }

        uint8_t dir_buf[SFS_BLOCK_SIZE];
        sfs_read_block(blk, dir_buf);
        memcpy(dir_buf + target_offset, &entry, SFS_DIRENT_SIZE);
        sfs_write_block(blk, dir_buf);

        parent_inode.size += SFS_DIRENT_SIZE;
        sfs_write_inode(parent_inum, &parent_inode);
    }

    if (!inum) return -1;

    struct sfs_inode inode;
    sfs_read_inode(inum, &inode);

    node->inode = inum;
    node->type = inode.type;
    node->size = inode.size;
    node->offset = 0;

    if (flags & O_TRUNC) {
        // Free all data blocks
        for (uint32_t i = 0; i < inode.blocks; i++) {
            uint32_t blk = sfs_get_block_ptr(&inode, i);
            if (blk) sfs_free_block(blk);
        }
        if (inode.indirect) sfs_free_block(inode.indirect);
        inode.size = 0;
        inode.blocks = 0;
        inode.indirect = 0;
        memset(inode.direct, 0, sizeof(inode.direct));
        sfs_write_inode(inum, &inode);
        node->size = 0;
    }

    return 0;
}

static void sfs_vfs_close(struct vfs_node *node) {
    (void)node;
}

static int sfs_vfs_readdir(struct vfs_node *node, struct dirent *entry) {
    struct sfs_inode inode;
    sfs_read_inode(node->inode, &inode);

    if (inode.type != SFS_TYPE_DIR) return -1;

    uint32_t num_entries = inode.size / SFS_DIRENT_SIZE;
    while (node->dir_index < num_entries) {
        uint32_t block_index = node->dir_index / (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE);
        uint32_t entry_in_block = node->dir_index % (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE);

        uint32_t blk = sfs_get_block_ptr(&inode, block_index);
        if (!blk) return -1;

        struct sfs_dirent dirents[SFS_BLOCK_SIZE / SFS_DIRENT_SIZE];
        sfs_read_block(blk, dirents);

        node->dir_index++;

        if (dirents[entry_in_block].inode) {
            entry->inode = dirents[entry_in_block].inode;
            entry->type = dirents[entry_in_block].type;
            strncpy(entry->name, dirents[entry_in_block].name, MAX_NAME);
            entry->name[MAX_NAME] = '\0';
            return 0;
        }
    }
    return -1; // End of directory
}

static int sfs_vfs_mkdir(const char *path) {
    char parent[MAX_PATH], name[MAX_NAME + 1];
    sfs_split_path(path, parent, name);

    uint32_t parent_inum = sfs_resolve_path(parent);
    if (!parent_inum) return -1;

    // Check if already exists
    if (sfs_resolve_path(path)) return -1;

    uint32_t inum = sfs_alloc_inode();
    if (!inum) return -1;

    struct sfs_inode new_inode;
    memset(&new_inode, 0, sizeof(new_inode));
    new_inode.type = SFS_TYPE_DIR;
    new_inode.size = 0;
    sfs_write_inode(inum, &new_inode);

    // Add entry to parent
    struct sfs_inode parent_inode;
    sfs_read_inode(parent_inum, &parent_inode);

    struct sfs_dirent entry;
    memset(&entry, 0, sizeof(entry));
    entry.inode = inum;
    entry.type = SFS_TYPE_DIR;
    entry.name_len = strlen(name);
    strncpy(entry.name, name, SFS_DIRENT_SIZE - 6);

    uint32_t num_entries = parent_inode.size / SFS_DIRENT_SIZE;
    uint32_t bi = num_entries / (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE);
    uint32_t off = (num_entries % (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE)) * SFS_DIRENT_SIZE;

    uint32_t blk = sfs_get_block_ptr(&parent_inode, bi);
    if (!blk) {
        blk = sfs_alloc_block();
        if (!blk) return -1;
        sfs_set_block_ptr(&parent_inode, bi, blk);
        parent_inode.blocks++;
        uint8_t z[SFS_BLOCK_SIZE];
        memset(z, 0, SFS_BLOCK_SIZE);
        sfs_write_block(blk, z);
    }

    uint8_t dbuf[SFS_BLOCK_SIZE];
    sfs_read_block(blk, dbuf);
    memcpy(dbuf + off, &entry, SFS_DIRENT_SIZE);
    sfs_write_block(blk, dbuf);

    parent_inode.size += SFS_DIRENT_SIZE;
    sfs_write_inode(parent_inum, &parent_inode);
    return 0;
}

static int sfs_vfs_rmdir(const char *path) {
    uint32_t inum = sfs_resolve_path(path);
    if (!inum) return -1;

    struct sfs_inode inode;
    sfs_read_inode(inum, &inode);
    if (inode.type != SFS_TYPE_DIR) return -1;
    if (inode.size > 0) return -1; // Not empty

    // Remove from parent
    char parent[MAX_PATH], name[MAX_NAME + 1];
    sfs_split_path(path, parent, name);
    uint32_t parent_inum = sfs_resolve_path(parent);
    if (!parent_inum) return -1;

    struct sfs_inode parent_inode;
    sfs_read_inode(parent_inum, &parent_inode);

    uint32_t num_entries = parent_inode.size / SFS_DIRENT_SIZE;
    for (uint32_t i = 0; i < num_entries; i++) {
        uint32_t bi = i / (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE);
        uint32_t ei = i % (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE);
        uint32_t blk = sfs_get_block_ptr(&parent_inode, bi);
        if (!blk) continue;

        struct sfs_dirent dirents[SFS_BLOCK_SIZE / SFS_DIRENT_SIZE];
        sfs_read_block(blk, dirents);

        if (dirents[ei].inode == inum) {
            memset(&dirents[ei], 0, SFS_DIRENT_SIZE);
            sfs_write_block(blk, dirents);
            break;
        }
    }

    // Free inode
    inode.type = SFS_TYPE_FREE;
    sfs_write_inode(inum, &inode);
    sb.free_inodes++;
    return 0;
}

static int sfs_vfs_unlink(const char *path) {
    uint32_t inum = sfs_resolve_path(path);
    if (!inum) return -1;

    struct sfs_inode inode;
    sfs_read_inode(inum, &inode);
    if (inode.type != SFS_TYPE_FILE) return -1;

    // Free data blocks
    for (uint32_t i = 0; i < inode.blocks; i++) {
        uint32_t blk = sfs_get_block_ptr(&inode, i);
        if (blk) sfs_free_block(blk);
    }
    if (inode.indirect) sfs_free_block(inode.indirect);

    // Remove from parent
    char parent[MAX_PATH], name[MAX_NAME + 1];
    sfs_split_path(path, parent, name);
    uint32_t parent_inum = sfs_resolve_path(parent);
    if (!parent_inum) return -1;

    struct sfs_inode parent_inode;
    sfs_read_inode(parent_inum, &parent_inode);

    uint32_t num_entries = parent_inode.size / SFS_DIRENT_SIZE;
    for (uint32_t i = 0; i < num_entries; i++) {
        uint32_t bi = i / (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE);
        uint32_t ei = i % (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE);
        uint32_t blk = sfs_get_block_ptr(&parent_inode, bi);
        if (!blk) continue;

        struct sfs_dirent dirents[SFS_BLOCK_SIZE / SFS_DIRENT_SIZE];
        sfs_read_block(blk, dirents);

        if (dirents[ei].inode == inum) {
            memset(&dirents[ei], 0, SFS_DIRENT_SIZE);
            sfs_write_block(blk, dirents);
            break;
        }
    }

    inode.type = SFS_TYPE_FREE;
    sfs_write_inode(inum, &inode);
    sb.free_inodes++;
    return 0;
}

static int sfs_vfs_stat(const char *path, struct stat *st) {
    uint32_t inum = sfs_resolve_path(path);
    if (!inum) return -1;

    struct sfs_inode inode;
    sfs_read_inode(inum, &inode);

    st->inode = inum;
    st->type = inode.type;
    st->size = inode.size;
    st->blocks = inode.blocks;
    st->created = inode.created;
    st->modified = inode.modified;
    return 0;
}

static int64_t sfs_vfs_lseek(struct vfs_node *node, int64_t offset, int whence) {
    struct sfs_inode inode;
    sfs_read_inode(node->inode, &inode);

    int64_t new_offset;
    switch (whence) {
        case SEEK_SET: new_offset = offset; break;
        case SEEK_CUR: new_offset = (int64_t)node->offset + offset; break;
        case SEEK_END: new_offset = (int64_t)inode.size + offset; break;
        default: return -1;
    }
    if (new_offset < 0) return -1;
    node->offset = (uint64_t)new_offset;
    return new_offset;
}

static struct vfs_ops sfs_ops = {
    .read    = sfs_vfs_read,
    .write   = sfs_vfs_write,
    .open    = sfs_vfs_open,
    .close   = sfs_vfs_close,
    .readdir = sfs_vfs_readdir,
    .mkdir   = sfs_vfs_mkdir,
    .rmdir   = sfs_vfs_rmdir,
    .unlink  = sfs_vfs_unlink,
    .stat    = sfs_vfs_stat,
    .lseek   = sfs_vfs_lseek,
};

void simplefs_init(uint32_t start_lba) {
    fs_start_lba = start_lba;

    // Read superblock
    uint8_t sb_buf[SFS_BLOCK_SIZE];
    if (sfs_read_block(0, sb_buf) < 0) {
        kprintf("SimpleFS: Failed to read superblock\n");
        return;
    }
    memcpy(&sb, sb_buf, sizeof(sb));

    if (sb.magic != SFS_MAGIC) {
        kprintf("SimpleFS: Invalid magic: 0x%x\n", sb.magic);
        return;
    }

    kprintf("SimpleFS: %d blocks, %d inodes, root=%d\n",
            sb.total_blocks, sb.total_inodes, sb.root_inode);

    vfs_register_fs(&sfs_ops);
}
