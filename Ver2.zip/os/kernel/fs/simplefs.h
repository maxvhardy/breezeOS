#pragma once
#include "include/types.h"
#include "fs/vfs.h"

#define SFS_MAGIC       0x53465321  // "SFS!"
#define SFS_BLOCK_SIZE  4096
#define SFS_SECTORS_PER_BLOCK 8
#define SFS_DIRECT_BLOCKS 10
#define SFS_INODE_SIZE  128
#define SFS_DIRENT_SIZE 64
#define SFS_MAX_INODES  2048

#define SFS_TYPE_FREE   0
#define SFS_TYPE_FILE   1
#define SFS_TYPE_DIR    2

struct sfs_superblock {
    uint32_t magic;
    uint32_t version;
    uint32_t block_size;
    uint32_t total_blocks;
    uint32_t total_inodes;
    uint32_t bitmap_start;    // Block number
    uint32_t bitmap_blocks;
    uint32_t inode_start;     // Block number
    uint32_t inode_blocks;
    uint32_t data_start;      // Block number
    uint32_t root_inode;
    uint32_t free_blocks;
    uint32_t free_inodes;
    uint8_t  padding[460];    // Pad to 512 bytes
} PACKED;

struct sfs_inode {
    uint32_t type;
    uint32_t size;
    uint32_t blocks;
    uint32_t uid;
    uint32_t gid;
    uint32_t permissions;
    uint64_t created;
    uint64_t modified;
    uint32_t direct[SFS_DIRECT_BLOCKS];
    uint32_t indirect;
    uint32_t dindirect;
    uint8_t  padding[8];
} PACKED;

struct sfs_dirent {
    uint32_t inode;
    uint8_t  name_len;
    uint8_t  type;
    char     name[SFS_DIRENT_SIZE - 6];
} PACKED;

void simplefs_init(uint32_t start_lba);
