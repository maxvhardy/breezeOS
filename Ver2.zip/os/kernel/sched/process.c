#include "sched/process.h"
#include "sched/scheduler.h"
#include "arch/paging.h"
#include "arch/gdt.h"
#include "arch/tss.h"
#include "mm/pmm.h"
#include "mm/vmm.h"
#include "mm/heap.h"
#include "lib/string.h"
#include "lib/printf.h"
#include "elf.h"
#include "gui/apps.h"
#include "gui/window.h"
#include "drivers/pit.h"

static struct process processes[MAX_PROCESSES];
static int current_pid = -1;
static int next_pid = 1;

extern void context_switch(uint64_t *old_rsp, uint64_t new_rsp, uint64_t new_cr3);
extern void enter_usermode(uint64_t rip, uint64_t rsp, uint64_t rflags);

static int alloc_pid(void) {
    for (int i = 0; i < MAX_PROCESSES; i++) {
        int pid = (next_pid + i) % MAX_PROCESSES;
        if (pid == 0) continue;
        if (processes[pid].state == PROC_UNUSED) {
            next_pid = pid + 1;
            return pid;
        }
    }
    return -1;
}

static int process_pick_parent_pid(void) {
    int parent = current_pid;
    if (parent == 0) {
        struct process *init_proc = process_get(1);
        if (init_proc && init_proc->state != PROC_UNUSED &&
            (init_proc->flags & PROC_FLAG_USER)) {
            parent = 1;
        }
    }
    return parent;
}

static void process_release_resources(struct process *proc) {
    if (!proc) return;

    if (proc->pml4 && proc->pml4 != paging_get_kernel_pml4()) {
        paging_destroy_address_space(proc->pml4);
    }
    if (proc->kernel_stack_base) {
        vmm_free_pages((void *)proc->kernel_stack_base,
                       KERNEL_STACK_SIZE / PAGE_SIZE);
    }

    memset(proc, 0, sizeof(*proc));
    proc->state = PROC_UNUSED;
    proc->terminal_wid = -1;
}

static int process_write_user(uint64_t *pml4, uint64_t va,
                              const void *src, size_t len) {
    const uint8_t *in = (const uint8_t *)src;

    while (len > 0) {
        uint64_t page_va = va & ~(uint64_t)(PAGE_SIZE - 1);
        uint64_t phys = paging_get_phys(pml4, page_va);
        if (!phys) return -1;

        size_t off = (size_t)(va & (PAGE_SIZE - 1));
        size_t chunk = PAGE_SIZE - off;
        if (chunk > len) chunk = len;

        memcpy((uint8_t *)PHYS_TO_VIRT(phys & PTE_ADDR_MASK) + off, in, chunk);

        va += chunk;
        in += chunk;
        len -= chunk;
    }

    return 0;
}

static int process_write_user_u64(uint64_t *pml4, uint64_t va, uint64_t val) {
    return process_write_user(pml4, va, &val, sizeof(val));
}

static int process_map_user_stack(uint64_t *pml4) {
    for (uint64_t i = 0; i < USER_STACK_SIZE / PAGE_SIZE; i++) {
        if (vmm_map_user_page(pml4,
                              USER_STACK_TOP - USER_STACK_SIZE + i * PAGE_SIZE,
                              PTE_PRESENT | PTE_WRITABLE) < 0) {
            return -1;
        }
    }
    return 0;
}

static int process_build_user_stack(uint64_t *pml4,
                                    int argc, const char *const argv[],
                                    int envc, const char *const envp[],
                                    uint64_t *out_rsp) {
    if (!pml4 || !out_rsp) return -1;
    if (argc < 0 || argc > PROC_EXEC_MAX_ARGS) return -1;
    if (envc < 0 || envc > PROC_EXEC_MAX_ENVS) return -1;

    uint64_t arg_ptrs[PROC_EXEC_MAX_ARGS];
    uint64_t env_ptrs[PROC_EXEC_MAX_ENVS];
    uint64_t sp = USER_STACK_TOP;
    uint64_t floor = USER_STACK_TOP - USER_STACK_SIZE;

    for (int i = envc - 1; i >= 0; i--) {
        const char *s = (envp && envp[i]) ? envp[i] : "";
        size_t len = strlen(s) + 1;

        if (sp < floor + len) return -1;
        sp -= len;
        if (process_write_user(pml4, sp, s, len) < 0) return -1;
        env_ptrs[i] = sp;
    }

    for (int i = argc - 1; i >= 0; i--) {
        const char *s = (argv && argv[i]) ? argv[i] : "";
        size_t len = strlen(s) + 1;

        if (sp < floor + len) return -1;
        sp -= len;
        if (process_write_user(pml4, sp, s, len) < 0) return -1;
        arg_ptrs[i] = sp;
    }

    sp &= ~0xFULL;

    size_t ptr_words = (size_t)argc + (size_t)envc + 3;
    if (sp < floor + ptr_words * sizeof(uint64_t)) return -1;

    sp -= sizeof(uint64_t);
    if (process_write_user_u64(pml4, sp, 0) < 0) return -1;
    for (int i = envc - 1; i >= 0; i--) {
        sp -= sizeof(uint64_t);
        if (process_write_user_u64(pml4, sp, env_ptrs[i]) < 0) return -1;
    }

    sp -= sizeof(uint64_t);
    if (process_write_user_u64(pml4, sp, 0) < 0) return -1;
    for (int i = argc - 1; i >= 0; i--) {
        sp -= sizeof(uint64_t);
        if (process_write_user_u64(pml4, sp, arg_ptrs[i]) < 0) return -1;
    }

    sp -= sizeof(uint64_t);
    if (process_write_user_u64(pml4, sp, (uint64_t)argc) < 0) return -1;

    *out_rsp = sp;
    return 0;
}

static int process_prepare_user_image(uint64_t *pml4, const char *path,
                                      int argc, const char *const argv[],
                                      int envc, const char *const envp[],
                                      uint64_t *entry_out,
                                      uint64_t *user_stack_out) {
    if (!pml4 || !path || path[0] == '\0' || !entry_out || !user_stack_out) return -1;

    struct process image;
    memset(&image, 0, sizeof(image));
    image.pml4 = pml4;

    if (elf_load(&image, path, entry_out) < 0) return -1;
    if (process_map_user_stack(pml4) < 0) return -1;

    if (process_build_user_stack(pml4, argc, argv, envc, envp, user_stack_out) < 0) {
        return -1;
    }

    return 0;
}

void process_init(void) {
    memset(processes, 0, sizeof(processes));
    for (int i = 0; i < MAX_PROCESSES; i++) {
        processes[i].terminal_wid = -1;
    }

    processes[0].pid = 0;
    processes[0].state = PROC_RUNNING;
    processes[0].pml4 = paging_get_kernel_pml4();
    processes[0].terminal_wid = -1;
    processes[0].flags = PROC_FLAG_KERNEL;
    processes[0].pending_signal = PROC_SIGNAL_NONE;
    processes[0].start_ticks = pit_get_ticks();
    processes[0].cpu_ticks = 0;
    strcpy(processes[0].cwd, "/");
    strcpy(processes[0].name, "idle");
    current_pid = 0;
}

struct process *process_current(void) {
    if (current_pid < 0 || current_pid >= MAX_PROCESSES) return NULL;
    return &processes[current_pid];
}

struct process *process_get(int pid) {
    if (pid < 0 || pid >= MAX_PROCESSES) return NULL;
    if (processes[pid].state == PROC_UNUSED) return NULL;
    return &processes[pid];
}

void process_set_current(int pid) {
    current_pid = pid;
}

void process_set_terminal_window(int pid, int wid) {
    if (pid < 0 || pid >= MAX_PROCESSES) return;
    if (processes[pid].state == PROC_UNUSED) return;
    processes[pid].terminal_wid = wid;
}

int process_getppid(void) {
    struct process *proc = process_current();
    if (!proc) return -1;
    return proc->parent_pid;
}

static void fill_proc_info(const struct process *src, struct proc_info *dst) {
    if (!src || !dst) return;

    memset(dst, 0, sizeof(*dst));
    dst->pid = src->pid;
    dst->ppid = src->parent_pid;
    dst->state = (uint32_t)src->state;
    dst->flags = src->flags;
    dst->exit_code = src->exit_code;
    dst->start_ticks = src->start_ticks;
    dst->cpu_ticks = src->cpu_ticks;
    strncpy(dst->name, src->name, sizeof(dst->name) - 1);
    strncpy(dst->cwd, src->cwd, sizeof(dst->cwd) - 1);
}

size_t process_list(struct proc_info *out, size_t cap) {
    size_t total = 0;
    size_t written = 0;

    for (int pid = 0; pid < MAX_PROCESSES; pid++) {
        struct process *p = process_get(pid);
        if (!p) continue;

        total++;
        if (out && written < cap) {
            fill_proc_info(p, &out[written]);
            written++;
        }
    }

    return total;
}

void process_reap_kernel_zombies(int skip_pid) {
    for (int pid = 1; pid < MAX_PROCESSES; pid++) {
        if (pid == skip_pid) continue;

        struct process *p = process_get(pid);
        if (!p) continue;
        if (p->parent_pid != 0) continue;
        if (p->state != PROC_ZOMBIE) continue;

        process_release_resources(p);
    }
}

static int clone_user_page(uint64_t *dst_pml4, uint64_t virt, uint64_t src_entry) {
    uint64_t src_phys = src_entry & PTE_ADDR_MASK;
    uint64_t flags = src_entry & ~PTE_ADDR_MASK;

    uint64_t dst_phys = pmm_alloc_page();
    if (!dst_phys) return -1;

    memcpy(PHYS_TO_VIRT(dst_phys), PHYS_TO_VIRT(src_phys), PAGE_SIZE);
    paging_map_page(dst_pml4, virt, dst_phys, flags);
    return 0;
}

static int clone_user_address_space(uint64_t *src_pml4, uint64_t *dst_pml4) {
    for (int i = 0; i < 256; i++) {
        if (!(src_pml4[i] & PTE_PRESENT)) continue;

        uint64_t *src_pdpt = (uint64_t *)PHYS_TO_VIRT(src_pml4[i] & PTE_ADDR_MASK);
        for (int j = 0; j < 512; j++) {
            if (!(src_pdpt[j] & PTE_PRESENT)) continue;
            if (src_pdpt[j] & PTE_HUGE) {
                return -1;
            }

            uint64_t *src_pd = (uint64_t *)PHYS_TO_VIRT(src_pdpt[j] & PTE_ADDR_MASK);
            for (int k = 0; k < 512; k++) {
                if (!(src_pd[k] & PTE_PRESENT)) continue;

                uint64_t base_va = ((uint64_t)i << 39) |
                                   ((uint64_t)j << 30) |
                                   ((uint64_t)k << 21);

                if (src_pd[k] & PTE_HUGE) {
                    if (!(src_pd[k] & PTE_USER)) continue;

                    uint64_t src_base = src_pd[k] & PTE_ADDR_MASK;
                    uint64_t page_flags = (src_pd[k] & ~PTE_ADDR_MASK) & ~PTE_HUGE;

                    for (int page = 0; page < 512; page++) {
                        uint64_t va = base_va + (uint64_t)page * PAGE_SIZE;
                        uint64_t src_entry = (src_base + (uint64_t)page * PAGE_SIZE) | page_flags;
                        if (clone_user_page(dst_pml4, va, src_entry) < 0) {
                            return -1;
                        }
                    }
                    continue;
                }

                uint64_t *src_pt = (uint64_t *)PHYS_TO_VIRT(src_pd[k] & PTE_ADDR_MASK);
                for (int l = 0; l < 512; l++) {
                    uint64_t src_pte = src_pt[l];
                    if (!(src_pte & PTE_PRESENT)) continue;
                    if (!(src_pte & PTE_USER)) continue;

                    uint64_t va = base_va | ((uint64_t)l << 12);
                    if (clone_user_page(dst_pml4, va, src_pte) < 0) {
                        return -1;
                    }
                }
            }
        }
    }

    return 0;
}

int process_create_kernel(void (*entry)(void), const char *name) {
    if (!entry) return -1;

    int pid = alloc_pid();
    if (pid < 0) return -1;

    struct process *proc = &processes[pid];
    memset(proc, 0, sizeof(*proc));

    proc->pid = pid;
    proc->state = PROC_READY;
    proc->pml4 = paging_get_kernel_pml4();
    proc->flags = PROC_FLAG_KERNEL;
    proc->pending_signal = PROC_SIGNAL_NONE;
    proc->start_ticks = pit_get_ticks();
    proc->cpu_ticks = 0;
    proc->parent_pid = current_pid;

    proc->terminal_wid = (current_pid >= 0 && current_pid < MAX_PROCESSES)
                       ? processes[current_pid].terminal_wid : -1;

    if (current_pid >= 0 && current_pid < MAX_PROCESSES &&
        processes[current_pid].state != PROC_UNUSED) {
        strncpy(proc->cwd, processes[current_pid].cwd, sizeof(proc->cwd) - 1);
        proc->cwd[sizeof(proc->cwd) - 1] = '\0';
    } else {
        strcpy(proc->cwd, "/");
    }

    strncpy(proc->name, name ? name : "kproc", sizeof(proc->name) - 1);
    proc->name[sizeof(proc->name) - 1] = '\0';

    proc->kernel_stack_base = (uint64_t)vmm_alloc_pages(KERNEL_STACK_SIZE / PAGE_SIZE);
    if (!proc->kernel_stack_base) {
        process_release_resources(proc);
        return -1;
    }

    uint64_t stack_top = proc->kernel_stack_base + KERNEL_STACK_SIZE;
    uint64_t *sp = (uint64_t *)stack_top;

    *--sp = (uint64_t)entry;
    *--sp = 0;
    *--sp = 0;
    *--sp = 0;
    *--sp = 0;
    *--sp = 0;
    *--sp = 0;
    *--sp = 0x202;

    proc->kernel_rsp = (uint64_t)sp;
    return pid;
}

int process_create_user(const char *path) {
    if (!path || path[0] == '\0') return -1;

    int pid = alloc_pid();
    if (pid < 0) return -1;

    struct process *proc = &processes[pid];
    memset(proc, 0, sizeof(*proc));

    proc->pid = pid;
    proc->flags = PROC_FLAG_USER;
    proc->pending_signal = PROC_SIGNAL_NONE;
    proc->start_ticks = pit_get_ticks();
    proc->cpu_ticks = 0;
    proc->parent_pid = process_pick_parent_pid();

    proc->terminal_wid = (current_pid >= 0 && current_pid < MAX_PROCESSES)
                       ? processes[current_pid].terminal_wid : -1;

    if (current_pid >= 0 && current_pid < MAX_PROCESSES &&
        processes[current_pid].state != PROC_UNUSED) {
        strncpy(proc->cwd, processes[current_pid].cwd, sizeof(proc->cwd) - 1);
        proc->cwd[sizeof(proc->cwd) - 1] = '\0';
    } else {
        strcpy(proc->cwd, "/");
    }

    const char *name = strrchr(path, '/');
    strncpy(proc->name, name ? name + 1 : path, sizeof(proc->name) - 1);
    proc->name[sizeof(proc->name) - 1] = '\0';

    proc->pml4 = paging_create_address_space();
    if (!proc->pml4) {
        process_release_resources(proc);
        return -1;
    }

    const char *argv0[1] = { path };
    uint64_t entry_point = 0;
    uint64_t user_stack = USER_STACK_TOP;
    if (process_prepare_user_image(proc->pml4, path,
                                   1, argv0,
                                   0, NULL,
                                   &entry_point, &user_stack) < 0) {
        kprintf("Failed to load ELF: %s\n", path);
        process_release_resources(proc);
        return -1;
    }

    proc->user_heap_end = USER_HEAP_START;

    proc->kernel_stack_base = (uint64_t)vmm_alloc_pages(KERNEL_STACK_SIZE / PAGE_SIZE);
    if (!proc->kernel_stack_base) {
        process_release_resources(proc);
        return -1;
    }

    uint64_t kstack_top = proc->kernel_stack_base + KERNEL_STACK_SIZE;
    uint64_t *sp = (uint64_t *)kstack_top;

    extern void user_process_trampoline(void);
    *--sp = (uint64_t)user_process_trampoline;
    *--sp = entry_point;
    *--sp = user_stack;
    *--sp = 0;
    *--sp = 0;
    *--sp = 0;
    *--sp = 0;
    *--sp = 0x202;

    proc->kernel_rsp = (uint64_t)sp;
    proc->state = PROC_READY;
    return pid;
}

int process_spawn_user(const char *path) {
    if (!path || path[0] == '\0') return -1;
    return process_create_user(path);
}

void user_process_trampoline_c(uint64_t entry, uint64_t user_stack) {
    struct process *proc = process_current();
    gdt_set_tss_rsp0(proc->kernel_stack_base + KERNEL_STACK_SIZE);
    paging_switch(proc->pml4);
    enter_usermode(entry, user_stack, 0x202);
}

int process_fork(void) {
    struct process *parent = process_current();
    if (!parent) return -1;

    int child_pid = alloc_pid();
    if (child_pid < 0) return -1;

    struct process *child = &processes[child_pid];
    memcpy(child, parent, sizeof(*child));
    child->pid = child_pid;
    child->parent_pid = parent->pid;
    child->pending_signal = PROC_SIGNAL_NONE;
    child->start_ticks = pit_get_ticks();
    child->cpu_ticks = 0;
    child->state = PROC_READY;

    child->pml4 = paging_create_address_space();
    if (!child->pml4) {
        child->state = PROC_UNUSED;
        return -1;
    }

    if (clone_user_address_space(parent->pml4, child->pml4) < 0) {
        process_release_resources(child);
        return -1;
    }

    child->kernel_stack_base = (uint64_t)vmm_alloc_pages(KERNEL_STACK_SIZE / PAGE_SIZE);
    if (!child->kernel_stack_base) {
        process_release_resources(child);
        return -1;
    }

    memcpy((void *)child->kernel_stack_base,
           (void *)parent->kernel_stack_base, KERNEL_STACK_SIZE);

    uint64_t rsp_offset = parent->kernel_rsp - parent->kernel_stack_base;
    child->kernel_rsp = child->kernel_stack_base + rsp_offset;

    for (int i = 0; i < MAX_FDS; i++) {
        child->fds[i] = parent->fds[i];
    }

    return child_pid;
}

int process_exec(const char *path) {
    const char *argv0[1] = { path };
    return process_execve(path, 1, argv0, 0, NULL);
}

int process_execve(const char *path, int argc, const char *const argv[],
                   int envc, const char *const envp[]) {
    struct process *proc = process_current();
    if (!proc || !path || path[0] == '\0') return -1;

    const char *default_argv[1] = { path };
    if (!argv || argc <= 0) {
        argv = default_argv;
        argc = 1;
    }
    if (!envp || envc < 0) {
        envp = NULL;
        envc = 0;
    }

    uint64_t *new_pml4 = paging_create_address_space();
    if (!new_pml4) return -1;

    uint64_t entry_point = 0;
    uint64_t user_stack = USER_STACK_TOP;
    if (process_prepare_user_image(new_pml4, path, argc, argv, envc, envp,
                                   &entry_point, &user_stack) < 0) {
        paging_destroy_address_space(new_pml4);
        return -1;
    }

    uint64_t *old_pml4 = proc->pml4;
    proc->pml4 = new_pml4;
    proc->user_heap_end = USER_HEAP_START;
    proc->pending_signal = PROC_SIGNAL_NONE;

    const char *name = strrchr(path, '/');
    strncpy(proc->name, name ? name + 1 : path, sizeof(proc->name) - 1);
    proc->name[sizeof(proc->name) - 1] = '\0';

    paging_switch(proc->pml4);
    if (old_pml4 && old_pml4 != paging_get_kernel_pml4()) {
        paging_destroy_address_space(old_pml4);
    }

    enter_usermode(entry_point, user_stack, 0x202);
    return 0;
}

int process_kill(int pid) {
    if (pid <= 0 || pid >= MAX_PROCESSES) return -1;
    if (pid == 1) return -1;

    struct process *target = process_get(pid);
    if (!target) return -1;
    if (target->state == PROC_ZOMBIE) return 0;
    if (target->flags & PROC_FLAG_KERNEL) return -1;

    target->pending_signal = PROC_SIGNAL_TERM;
    if (target->state == PROC_SLEEPING || target->state == PROC_BLOCKED) {
        target->state = PROC_READY;
    }

    struct process *self = process_current();
    if (self && self->pid == target->pid) {
        process_exit(128 + PROC_SIGNAL_TERM);
        schedule();
    }

    return 0;
}

void process_exit(int code) {
    struct process *proc = process_current();
    if (!proc || proc->pid == 0) return;

    proc->pending_signal = PROC_SIGNAL_NONE;
    proc->exit_code = code;
    proc->state = PROC_ZOMBIE;

    if (proc->terminal_wid >= 0) {
        gui_apps_terminal_stream_flush(proc->terminal_wid);
    }

    for (int i = 3; i < MAX_FDS; i++) {
        if (proc->fds[i]) {
            vfs_close(proc->fds[i]);
            proc->fds[i] = NULL;
        }
    }

    window_destroy_by_owner(proc->pid);

    struct process *parent = process_get(proc->parent_pid);
    if (parent && parent->state == PROC_BLOCKED) {
        parent->state = PROC_READY;
    }
}

int process_waitpid(int pid, int *status) {
    struct process *self = process_current();
    struct process *child = process_get(pid);
    if (!self || !child) return -1;
    if (child->parent_pid != self->pid) return -1;

    while (child->state != PROC_ZOMBIE) {
        self->state = PROC_BLOCKED;
        schedule();
    }

    if (status) *status = child->exit_code;
    process_release_resources(child);
    return pid;
}

int process_waitany(int *status) {
    struct process *self = process_current();
    if (!self) return -1;

    while (1) {
        int have_children = 0;
        for (int pid = 1; pid < MAX_PROCESSES; pid++) {
            struct process *p = process_get(pid);
            if (!p) continue;
            if (p->parent_pid != self->pid) continue;

            have_children = 1;
            if (p->state == PROC_ZOMBIE) {
                return process_waitpid(pid, status);
            }
        }

        if (!have_children) return -1;
        self->state = PROC_BLOCKED;
        schedule();
    }
}

int64_t process_sbrk(struct process *proc, int64_t incr) {
    uint64_t old_end = proc->user_heap_end;
    uint64_t new_end = old_end + incr;

    if (incr > 0) {
        uint64_t start_page = (old_end + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1);
        uint64_t end_page = (new_end + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1);

        for (uint64_t addr = start_page; addr < end_page; addr += PAGE_SIZE) {
            vmm_map_user_page(proc->pml4, addr, PTE_PRESENT | PTE_WRITABLE);
        }
    }

    proc->user_heap_end = new_end;
    return (int64_t)old_end;
}

void process_sleep(uint64_t ms) {
    struct process *proc = process_current();
    if (!proc) return;

    proc->sleep_until = pit_get_ticks() + (ms * 100) / 1000;
    proc->state = PROC_SLEEPING;
}
