#pragma once
#include "include/types.h"
#include "fs/vfs.h"
#include "arch/idt.h"

#define MAX_PROCESSES 64
#define KERNEL_STACK_SIZE (8 * PAGE_SIZE)
#define USER_STACK_SIZE   (16 * PAGE_SIZE)
#define USER_STACK_TOP    0x7FFFFFFFE000ULL
#define USER_HEAP_START   0x10000000ULL

typedef enum {
    PROC_UNUSED = 0,
    PROC_READY,
    PROC_RUNNING,
    PROC_BLOCKED,
    PROC_SLEEPING,
    PROC_ZOMBIE
} proc_state_t;

#define PROC_FLAG_USER   0x1u
#define PROC_FLAG_KERNEL 0x2u

#define PROC_SIGNAL_NONE 0
#define PROC_SIGNAL_TERM 15

#define PROC_EXEC_MAX_ARGS 32
#define PROC_EXEC_MAX_ENVS 32
#define PROC_EXEC_STR_MAX  256

struct proc_info {
    int32_t  pid;
    int32_t  ppid;
    uint32_t state;
    uint32_t flags;
    int32_t  exit_code;
    uint32_t _reserved;
    uint64_t start_ticks;
    uint64_t cpu_ticks;
    char     name[64];
    char     cwd[MAX_PATH];
};

struct process {
    int pid;
    proc_state_t state;
    uint64_t *pml4;              // Page table root (virtual address)
    uint64_t kernel_rsp;         // Saved kernel stack pointer
    uint64_t kernel_stack_base;  // Base of kernel stack allocation
    uint64_t user_heap_end;      // Current end of user heap (for sbrk)
    uint64_t sleep_until;        // For sleep(), tick count to wake
    uint64_t start_ticks;        // PIT ticks when process was created
    uint64_t cpu_ticks;          // PIT ticks spent in PROC_RUNNING
    uint32_t flags;              // PROC_FLAG_*
    int pending_signal;          // PROC_SIGNAL_* pending delivery
    int exit_code;
    int parent_pid;
    int terminal_wid;            // Bound GUI terminal window for stdout/stderr, or -1
    char cwd[MAX_PATH];
    struct vfs_node *fds[MAX_FDS];
    char name[64];
};

void process_init(void);
struct process *process_current(void);
struct process *process_get(int pid);
int process_create_kernel(void (*entry)(void), const char *name);
int process_create_user(const char *path);
int process_spawn_user(const char *path);
int process_fork(void);
int process_exec(const char *path);
int process_execve(const char *path, int argc, const char *const argv[],
                   int envc, const char *const envp[]);
int process_kill(int pid);
void process_exit(int code);
int process_waitpid(int pid, int *status);
int process_waitany(int *status);
int process_getppid(void);
size_t process_list(struct proc_info *out, size_t cap);
int64_t process_sbrk(struct process *proc, int64_t incr);
void process_sleep(uint64_t ms);
void process_set_current(int pid);
void process_reap_kernel_zombies(int skip_pid);
void process_set_terminal_window(int pid, int wid);
