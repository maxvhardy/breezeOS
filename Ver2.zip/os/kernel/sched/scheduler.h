#pragma once
#include "arch/idt.h"

void scheduler_init(void);
void schedule(void);
void schedule_tick(struct registers *regs);
