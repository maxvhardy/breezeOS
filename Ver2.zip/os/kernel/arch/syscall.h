#pragma once
#include "include/types.h"
#include "arch/idt.h"

// Syscall numbers
#define SYS_EXIT        0
#define SYS_WRITE       1
#define SYS_READ        2
#define SYS_OPEN        3
#define SYS_CLOSE       4
#define SYS_FORK        5
#define SYS_EXEC        6
#define SYS_WAITPID     7
#define SYS_GETPID      8
#define SYS_SBRK        9
#define SYS_MKDIR       10
#define SYS_RMDIR       11
#define SYS_UNLINK      12
#define SYS_CHDIR       13
#define SYS_GETCWD      14
#define SYS_READDIR     15
#define SYS_STAT        16
#define SYS_YIELD       17
#define SYS_SLEEP       18
#define SYS_GETFB       19
#define SYS_WIN_CREATE  20
#define SYS_WIN_DESTROY 21
#define SYS_WIN_UPDATE  22
#define SYS_WIN_EVENT   23
#define SYS_DUP2        24
#define SYS_PIPE        25
#define SYS_LSEEK       26
#define SYS_FSTAT       27
#define SYS_TICKS       28
#define SYS_REBOOT      29
#define SYS_GETPPID     30
#define SYS_SPAWN       31
#define SYS_PROCLIST    32
#define SYS_KILL        33
#define SYS_EXECVE      34

#define SYSCALL_COUNT   35

void syscall_init(void);
void syscall_set_kernel_rsp(uint64_t rsp);

// Defined in syscall_entry.asm
extern void syscall_entry(void);
