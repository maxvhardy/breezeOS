#include "arch/tss.h"
#include "arch/gdt.h"

// TSS is allocated in gdt.c
// This file provides helper functions

void tss_set_rsp0(uint64_t rsp0) {
    tss.rsp0 = rsp0;
}

void tss_set_ist(int ist_num, uint64_t addr) {
    switch (ist_num) {
        case 1: tss.ist1 = addr; break;
        case 2: tss.ist2 = addr; break;
        case 3: tss.ist3 = addr; break;
        case 4: tss.ist4 = addr; break;
        case 5: tss.ist5 = addr; break;
        case 6: tss.ist6 = addr; break;
        case 7: tss.ist7 = addr; break;
    }
}
