#include "include/types.h"
#include "include/boot.h"
#include "lib/string.h"
#include "lib/printf.h"
#include "arch/gdt.h"
#include "arch/idt.h"
#include "arch/paging.h"
#include "arch/syscall.h"
#include "mm/pmm.h"
#include "mm/vmm.h"
#include "mm/heap.h"
#include "drivers/pic.h"
#include "drivers/pit.h"
#include "drivers/vga.h"
#include "drivers/vbe.h"
#include "drivers/keyboard.h"
#include "drivers/mouse.h"
#include "drivers/pci.h"
#include "drivers/ata.h"
#include "drivers/net.h"
#include "fs/vfs.h"
#include "fs/simplefs.h"
#include "sched/process.h"
#include "sched/scheduler.h"
#include "gui/event.h"
#include "gui/font.h"
#include "gui/compositor.h"
#include "gui/window.h"
#include "gui/desktop.h"
#include "gui/taskbar.h"
#include "gui/apps.h"

extern uint64_t _bss_start;
extern uint64_t _bss_end;

static struct boot_info *boot;
static struct e820_entry *mmap;

static void create_boot_window(void) {
    int wid = window_create(96, 96, 520, 280, "DoorOS");
    if (wid < 0) {
        kprintf("[GUI] Failed to create boot window\n");
        return;
    }

    struct window *win = window_get(wid);
    if (!win || !win->framebuffer) return;

    for (int y = 0; y < win->height; y++) {
        for (int x = 0; x < win->width; x++) {
            uint32_t r = 24 + (uint32_t)(x * 40) / (uint32_t)win->width;
            uint32_t g = 34 + (uint32_t)(y * 60) / (uint32_t)win->height;
            uint32_t b = 58 + (uint32_t)((x + y) * 35) / (uint32_t)(win->width + win->height);
            win->framebuffer[y * win->width + x] = (r << 16) | (g << 8) | b;
        }
    }

    font_draw_string(win->framebuffer, win->width, win->height,
                     24, 28, "DoorOS GUI booted successfully",
                     0xFFFFFF, win->framebuffer[28 * win->width + 24]);
    font_draw_string(win->framebuffer, win->width, win->height,
                     24, 56, "Desktop environment is live.",
                     0xD6E4FF, win->framebuffer[56 * win->width + 24]);
    font_draw_string(win->framebuffer, win->width, win->height,
                     24, 84, "Use the Dock or Launchpad to open apps.",
                     0xB8FFDA, win->framebuffer[84 * win->width + 24]);
}

// GUI kernel task: runs the compositor loop
static void gui_task(void) {
    kprintf("[GUI] Desktop environment started\n");

    while (1) {
        compositor_render();

        // Keep the desktop/cursor responsive with a steady ~60 FPS refresh.
        extern void pit_sleep(uint64_t ms);
        pit_sleep(16);
    }
}

// Init launcher: loads /bin/init from the filesystem
static void init_launcher(void) {
    kprintf("[INIT] Launching /bin/init...\n");

    int pid = process_create_user("/bin/init");
    if (pid < 0) {
        kprintf("[INIT] Failed to load /bin/init, starting shell directly\n");
        pid = process_create_user("/bin/shell");
        if (pid < 0) {
            kprintf("[INIT] Failed to load /bin/shell\n");
            kprintf("[INIT] No user programs available.\n");
        }
    }

    // This kernel thread just waits
    while (1) {
        extern void pit_sleep(uint64_t ms);
        pit_sleep(1000);
    }
}

// Kernel entry point - called from stage2 bootloader
SECTION(".text.entry")
void kernel_entry(void) {
    // Clear BSS before using any static/global state.
    memset(&_bss_start, 0, (uint64_t)&_bss_end - (uint64_t)&_bss_start);

    // Get boot info from known physical address (identity + higher-half mapped)
    boot = (struct boot_info *)PHYS_TO_VIRT(BOOT_INFO_ADDR);
    mmap = (struct e820_entry *)PHYS_TO_VIRT(E820_MAP_ADDR);

    // Phase 1: Core CPU structures
    gdt_init();
    idt_init();
    pic_init();

    // Phase 2: VGA text mode for early debug output
    vga_init();
    vga_clear();
    vga_set_color(VGA_BLACK, VGA_LCYAN);
    vga_puts("DoorOS v0.1 - Booting...\n");
    vga_set_color(VGA_BLACK, VGA_LGRAY);

    // Phase 3: Memory management
    kprintf("[BOOT] Initializing physical memory manager...\n");
    pmm_init(boot, mmap);
    kprintf("[BOOT] Total: %d MB, Free: %d MB\n",
            (int)(pmm_get_total_memory() / (1024 * 1024)),
            (int)(pmm_get_free_memory() / (1024 * 1024)));

    // Phase 4: Paging (captures current bootloader page tables)
    kprintf("[BOOT] Initializing paging...\n");
    paging_init();

    kprintf("[BOOT] Initializing virtual memory manager...\n");
    vmm_init();

    kprintf("[BOOT] Initializing kernel heap...\n");
    heap_init();

    // Phase 5: System call interface
    kprintf("[BOOT] Initializing syscall interface...\n");
    syscall_init();

    // Phase 6: Hardware drivers
    kprintf("[BOOT] Initializing PIT timer (100Hz)...\n");
    pit_init();

    kprintf("[BOOT] Initializing PS/2 keyboard...\n");
    keyboard_init();

    kprintf("[BOOT] Initializing PS/2 mouse...\n");
    mouse_init();

    kprintf("[BOOT] Scanning PCI bus...\n");
    pci_init();

    kprintf("[BOOT] Initializing Ethernet...\n");
    net_init();

    kprintf("[BOOT] Initializing ATA disk...\n");
    ata_init();

    // Phase 7: Graphics
    if (boot->vbe_available) {
        kprintf("[BOOT] Initializing VBE framebuffer (%dx%dx%d)...\n",
                boot->fb_width, boot->fb_height, boot->fb_bpp);
        vbe_init(boot);
        if (vbe_available()) {
            mouse_set_bounds((int)boot->fb_width, (int)boot->fb_height);
            mouse_set_position((int)boot->fb_width / 2, (int)boot->fb_height / 2);
        }
    } else {
        kprintf("[BOOT] VBE not available, using text mode\n");
    }

    // Phase 8: Filesystem
    kprintf("[BOOT] Initializing VFS...\n");
    vfs_init();

    kprintf("[BOOT] Mounting SimpleFS at LBA %d...\n", boot->fs_start_lba);
    simplefs_init(boot->fs_start_lba);

    // Phase 9: Process management
    kprintf("[BOOT] Initializing process manager...\n");
    process_init();
    scheduler_init();

    // Phase 10: GUI subsystem
    if (vbe_available()) {
        kprintf("[BOOT] Initializing GUI subsystem...\n");
        gui_event_init();
        font_init();
        window_init();
        desktop_init();
        taskbar_init();
        gui_apps_init();
        compositor_init();
        create_boot_window();
    }

    // Phase 11: Enable interrupts and start the system
    kprintf("[BOOT] System initialization complete!\n");

    kprintf("[BOOT] Starting init launcher...\n");
    process_create_kernel(init_launcher, "init_launcher");

    // Enable interrupts now that all handlers/drivers are configured.
    sti();

    // For now, run the GUI loop directly on the boot CPU context.
    // This avoids scheduler/preemption edge cases and keeps rendering/input stable.
    if (vbe_available()) {
        kprintf("[BOOT] Entering GUI loop.\n");
        gui_task();
    }

    // Text-mode fallback path.
    kprintf("[BOOT] Entering idle loop.\n");
    while (1) {
        hlt();
    }
}
