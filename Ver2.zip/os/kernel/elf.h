#pragma once
#include "include/types.h"
#include "sched/process.h"

#define ELF_MAGIC 0x464C457F // "\x7FELF"

#define ET_EXEC  2
#define EM_X86_64 62
#define PT_LOAD  1

struct elf64_header {
    uint32_t magic;
    uint8_t  class;
    uint8_t  encoding;
    uint8_t  version;
    uint8_t  os_abi;
    uint64_t padding;
    uint16_t type;
    uint16_t machine;
    uint32_t elf_version;
    uint64_t entry;
    uint64_t phoff;
    uint64_t shoff;
    uint32_t flags;
    uint16_t ehsize;
    uint16_t phentsize;
    uint16_t phnum;
    uint16_t shentsize;
    uint16_t shnum;
    uint16_t shstrndx;
} PACKED;

struct elf64_phdr {
    uint32_t type;
    uint32_t flags;
    uint64_t offset;
    uint64_t vaddr;
    uint64_t paddr;
    uint64_t filesz;
    uint64_t memsz;
    uint64_t align;
} PACKED;

int elf_load(struct process *proc, const char *path, uint64_t *entry_point);
