#include "lib/printf.h"
#include "lib/string.h"
#include "drivers/vga.h"

typedef __builtin_va_list va_list;
#define va_start(ap, last) __builtin_va_start(ap, last)
#define va_end(ap)         __builtin_va_end(ap)
#define va_arg(ap, type)   __builtin_va_arg(ap, type)

static putchar_fn kprint_fn = NULL;

void set_kprintf_putchar(putchar_fn fn) {
    kprint_fn = fn;
}

static void kputc(char c) {
    if (kprint_fn)
        kprint_fn(c);
    else
        vga_putchar(c);
}

static void print_string(const char *s) {
    while (*s) kputc(*s++);
}

static void print_uint(uint64_t val, int base, int width, char pad, int uppercase) {
    char buf[64];
    const char *digits = uppercase ? "0123456789ABCDEF" : "0123456789abcdef";
    int i = 0;

    if (val == 0) {
        buf[i++] = '0';
    } else {
        while (val > 0) {
            buf[i++] = digits[val % base];
            val /= base;
        }
    }

    while (i < width) buf[i++] = pad;

    for (int j = i - 1; j >= 0; j--)
        kputc(buf[j]);
}

static void print_int(int64_t val, int width, char pad) {
    if (val < 0) {
        kputc('-');
        val = -val;
        if (width > 0) width--;
    }
    print_uint((uint64_t)val, 10, width, pad, 0);
}

static int vprintf_internal(const char *fmt, va_list ap) {
    int count = 0;
    while (*fmt) {
        if (*fmt != '%') {
            kputc(*fmt++);
            count++;
            continue;
        }
        fmt++; // skip %

        char pad = ' ';
        if (*fmt == '0') { pad = '0'; fmt++; }

        int width = 0;
        while (*fmt >= '0' && *fmt <= '9') {
            width = width * 10 + (*fmt - '0');
            fmt++;
        }

        int long_count = 0;
        while (*fmt == 'l') { long_count++; fmt++; }

        switch (*fmt) {
            case 'd':
            case 'i': {
                int64_t val;
                if (long_count >= 2) val = va_arg(ap, int64_t);
                else val = va_arg(ap, int);
                print_int(val, width, pad);
                break;
            }
            case 'u': {
                uint64_t val;
                if (long_count >= 2) val = va_arg(ap, uint64_t);
                else val = va_arg(ap, unsigned int);
                print_uint(val, 10, width, pad, 0);
                break;
            }
            case 'x': {
                uint64_t val;
                if (long_count >= 2) val = va_arg(ap, uint64_t);
                else val = va_arg(ap, unsigned int);
                print_uint(val, 16, width, pad, 0);
                break;
            }
            case 'X': {
                uint64_t val;
                if (long_count >= 2) val = va_arg(ap, uint64_t);
                else val = va_arg(ap, unsigned int);
                print_uint(val, 16, width, pad, 1);
                break;
            }
            case 'p': {
                uint64_t val = (uint64_t)va_arg(ap, void *);
                print_string("0x");
                print_uint(val, 16, 16, '0', 0);
                break;
            }
            case 's': {
                const char *s = va_arg(ap, const char *);
                if (!s) s = "(null)";
                print_string(s);
                break;
            }
            case 'c': {
                char c = (char)va_arg(ap, int);
                kputc(c);
                break;
            }
            case '%':
                kputc('%');
                break;
            default:
                kputc('%');
                kputc(*fmt);
                break;
        }
        fmt++;
        count++;
    }
    return count;
}

int kprintf(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    int ret = vprintf_internal(fmt, ap);
    va_end(ap);
    return ret;
}

// snprintf implementation using a buffer
static char *snprintf_buf;
static size_t snprintf_pos;
static size_t snprintf_max;

static void snprintf_putc(char c) {
    if (snprintf_pos < snprintf_max - 1) {
        snprintf_buf[snprintf_pos++] = c;
    }
}

int snprintf(char *buf, size_t size, const char *fmt, ...) {
    if (!buf || size == 0) return 0;

    putchar_fn old_fn = kprint_fn;
    snprintf_buf = buf;
    snprintf_pos = 0;
    snprintf_max = size;
    kprint_fn = snprintf_putc;

    va_list ap;
    va_start(ap, fmt);
    vprintf_internal(fmt, ap);
    va_end(ap);

    buf[snprintf_pos] = '\0';
    kprint_fn = old_fn;
    return (int)snprintf_pos;
}
