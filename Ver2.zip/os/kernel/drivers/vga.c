#include "drivers/vga.h"
#include "lib/string.h"

#define VGA_WIDTH   80
#define VGA_HEIGHT  25
#define VGA_MEM     ((uint16_t *)PHYS_TO_VIRT(0xB8000))

static int cursor_x = 0;
static int cursor_y = 0;
static uint8_t color_attr = 0x07; // Light gray on black

static void update_cursor(void) {
    uint16_t pos = cursor_y * VGA_WIDTH + cursor_x;
    outb(0x3D4, 14);
    outb(0x3D5, (pos >> 8) & 0xFF);
    outb(0x3D4, 15);
    outb(0x3D5, pos & 0xFF);
}

static void scroll(void) {
    if (cursor_y < VGA_HEIGHT) return;

    // Move everything up one line
    memmove(VGA_MEM, VGA_MEM + VGA_WIDTH,
            (VGA_HEIGHT - 1) * VGA_WIDTH * 2);

    // Clear last line
    uint16_t blank = (color_attr << 8) | ' ';
    for (int i = 0; i < VGA_WIDTH; i++) {
        VGA_MEM[(VGA_HEIGHT - 1) * VGA_WIDTH + i] = blank;
    }

    cursor_y = VGA_HEIGHT - 1;
}

void vga_init(void) {
    color_attr = 0x07;
    cursor_x = 0;
    cursor_y = 0;
    vga_clear();
}

void vga_clear(void) {
    uint16_t blank = (color_attr << 8) | ' ';
    for (int i = 0; i < VGA_WIDTH * VGA_HEIGHT; i++) {
        VGA_MEM[i] = blank;
    }
    cursor_x = 0;
    cursor_y = 0;
    update_cursor();
}

void vga_putchar(char c) {
    switch (c) {
        case '\n':
            cursor_x = 0;
            cursor_y++;
            break;
        case '\r':
            cursor_x = 0;
            break;
        case '\t':
            cursor_x = (cursor_x + 8) & ~7;
            break;
        case '\b':
            if (cursor_x > 0) {
                cursor_x--;
                VGA_MEM[cursor_y * VGA_WIDTH + cursor_x] = (color_attr << 8) | ' ';
            }
            break;
        default:
            if (c >= ' ') {
                VGA_MEM[cursor_y * VGA_WIDTH + cursor_x] = (color_attr << 8) | c;
                cursor_x++;
            }
            break;
    }

    if (cursor_x >= VGA_WIDTH) {
        cursor_x = 0;
        cursor_y++;
    }
    scroll();
    update_cursor();
}

void vga_puts(const char *s) {
    while (*s) vga_putchar(*s++);
}

void vga_set_color(uint8_t bg, uint8_t fg) {
    color_attr = (bg << 4) | (fg & 0x0F);
}

void vga_set_cursor(int x, int y) {
    cursor_x = x;
    cursor_y = y;
    update_cursor();
}

int vga_get_x(void) { return cursor_x; }
int vga_get_y(void) { return cursor_y; }
