#include "drivers/keyboard.h"
#include "drivers/pic.h"
#include "arch/idt.h"

#define KBD_DATA    0x60
#define KBD_STATUS  0x64
#define KBD_BUF_SIZE 256

static char kbd_buffer[KBD_BUF_SIZE];
static volatile int kbd_read_pos = 0;
static volatile int kbd_write_pos = 0;
static struct kbd_event kbd_event_buffer[KBD_BUF_SIZE];
static volatile int kbd_event_read_pos = 0;
static volatile int kbd_event_write_pos = 0;

static int shift_pressed = 0;
static int ctrl_pressed = 0;
static int alt_pressed = 0;
static int capslock = 0;
static int e0_prefix = 0;

// US QWERTY scancode -> ASCII
static const char scancode_normal[128] = {
    0,  27, '1','2','3','4','5','6','7','8','9','0','-','=','\b',
    '\t','q','w','e','r','t','y','u','i','o','p','[',']','\n',
    0,  'a','s','d','f','g','h','j','k','l',';','\'','`',
    0,  '\\','z','x','c','v','b','n','m',',','.','/', 0,
    '*', 0, ' ', 0,  0,0,0,0,0,0,0,0,0,0, 0,0,
    '7','8','9','-','4','5','6','+','1','2','3','0','.',
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
};

static const char scancode_shift[128] = {
    0,  27, '!','@','#','$','%','^','&','*','(',')','_','+','\b',
    '\t','Q','W','E','R','T','Y','U','I','O','P','{','}','\n',
    0,  'A','S','D','F','G','H','J','K','L',':','"','~',
    0,  '|','Z','X','C','V','B','N','M','<','>','?', 0,
    '*', 0, ' ', 0,  0,0,0,0,0,0,0,0,0,0, 0,0,
    '7','8','9','-','4','5','6','+','1','2','3','0','.',
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
};

static void kbd_buffer_push(char c) {
    int next = (kbd_write_pos + 1) % KBD_BUF_SIZE;
    if (next != kbd_read_pos) {
        kbd_buffer[kbd_write_pos] = c;
        kbd_write_pos = next;
    }
}

static void kbd_event_push(uint8_t pressed, uint8_t keycode) {
    int next = (kbd_event_write_pos + 1) % KBD_BUF_SIZE;
    if (next != kbd_event_read_pos) {
        kbd_event_buffer[kbd_event_write_pos].pressed = pressed;
        kbd_event_buffer[kbd_event_write_pos].keycode = keycode;
        kbd_event_write_pos = next;
    }
}

static uint8_t keycode_from_scancode(uint8_t scancode, int extended) {
    if (extended) {
        switch (scancode) {
            case 0x4B: return KBD_KEY_LEFT;
            case 0x4D: return KBD_KEY_RIGHT;
            case 0x48: return KBD_KEY_UP;
            case 0x50: return KBD_KEY_DOWN;
            default:   return 0;
        }
    }

    if (scancode >= 128) return 0;
    return (uint8_t)scancode_normal[scancode];
}

void keyboard_process_scancode(uint8_t scancode) {
    if (scancode == 0xE0) {
        e0_prefix = 1;
        return;
    }

    // Key release (bit 7 set)
    if (scancode & 0x80) {
        uint8_t released = scancode & 0x7F;
        if (e0_prefix) {
            uint8_t key = keycode_from_scancode(released, 1);
            e0_prefix = 0;
            if (key) kbd_event_push(0, key);
            return;
        }
        switch (released) {
            case 0x2A: case 0x36: shift_pressed = 0; break; // Shift
            case 0x1D: ctrl_pressed = 0; break;  // Ctrl
            case 0x38: alt_pressed = 0; break;   // Alt
        }
        uint8_t key = keycode_from_scancode(released, 0);
        if (key) kbd_event_push(0, key);
        return;
    }

    if (e0_prefix) {
        uint8_t key = keycode_from_scancode(scancode, 1);
        e0_prefix = 0;
        if (key) {
            kbd_event_push(1, key);
            kbd_buffer_push((char)key);
        }
        return;
    }

    if (scancode >= 128) return;

    // Key press
    switch (scancode) {
        case 0x2A: case 0x36: shift_pressed = 1; return; // Shift
        case 0x1D: ctrl_pressed = 1; return; // Ctrl
        case 0x38: alt_pressed = 1; return;  // Alt
        case 0x3A: capslock = !capslock; return; // Caps Lock
    }

    char c;
    if (shift_pressed) {
        c = scancode_shift[scancode];
    } else {
        c = scancode_normal[scancode];
    }

    // Apply caps lock to letters
    if (capslock && c >= 'a' && c <= 'z') c -= 32;
    else if (capslock && c >= 'A' && c <= 'Z') c += 32;

    if (c) {
        kbd_buffer_push(c);
    }

    uint8_t key = keycode_from_scancode(scancode, 0);
    if (key) kbd_event_push(1, key);
}

static void keyboard_handler(struct registers *regs) {
    (void)regs;
    for (int i = 0; i < 32; i++) {
        uint8_t status = inb(KBD_STATUS);
        if (!(status & 1)) break; // No output byte
        if (status & 0x20) break; // Auxiliary (mouse) data, leave for mouse path
        keyboard_process_scancode(inb(KBD_DATA));
    }
}

void keyboard_init(void) {
    // Flush keyboard buffer
    while (inb(KBD_STATUS) & 1) {
        inb(KBD_DATA);
    }

    kbd_read_pos = 0;
    kbd_write_pos = 0;
    kbd_event_read_pos = 0;
    kbd_event_write_pos = 0;

    isr_register_handler(33, keyboard_handler);
    pic_clear_mask(IRQ_KEYBOARD);
}

char kbd_getchar(void) {
    if (kbd_read_pos == kbd_write_pos) return 0;
    char c = kbd_buffer[kbd_read_pos];
    kbd_read_pos = (kbd_read_pos + 1) % KBD_BUF_SIZE;
    return c;
}

int kbd_has_key(void) {
    return kbd_read_pos != kbd_write_pos;
}

int kbd_has_event(void) {
    return kbd_event_read_pos != kbd_event_write_pos;
}

int kbd_get_event(struct kbd_event *ev) {
    if (!ev) return 0;
    if (kbd_event_read_pos == kbd_event_write_pos) return 0;

    *ev = kbd_event_buffer[kbd_event_read_pos];
    kbd_event_read_pos = (kbd_event_read_pos + 1) % KBD_BUF_SIZE;
    return 1;
}

uint8_t kbd_get_scancode(void) {
    return inb(KBD_DATA);
}

int kbd_is_shift(void) { return shift_pressed; }
int kbd_is_ctrl(void) { return ctrl_pressed; }
int kbd_is_alt(void) { return alt_pressed; }
