#include "drivers/power.h"

NORETURN void power_reboot(void) {
    cli();

    // Ask the keyboard controller to pulse CPU reset.
    for (int spin = 0; spin < 100000; spin++) {
        if ((inb(0x64) & 0x02) == 0) break;
        io_wait();
    }
    outb(0x64, 0xFE);

    // Fallback: force a triple fault if KBC reset does not fire.
    struct PACKED {
        uint16_t limit;
        uint64_t base;
    } idtr = {0, 0};

    __asm__ volatile("lidt %0" : : "m"(idtr));
    __asm__ volatile("int3");

    while (1) {
        hlt();
    }
}
