#pragma once
#include "include/types.h"

// VGA text mode colors
#define VGA_BLACK   0
#define VGA_BLUE    1
#define VGA_GREEN   2
#define VGA_CYAN    3
#define VGA_RED     4
#define VGA_MAGENTA 5
#define VGA_BROWN   6
#define VGA_LGRAY   7
#define VGA_DGRAY   8
#define VGA_LBLUE   9
#define VGA_LGREEN  10
#define VGA_LCYAN   11
#define VGA_LRED    12
#define VGA_LMAGENTA 13
#define VGA_YELLOW  14
#define VGA_WHITE   15

void vga_init(void);
void vga_clear(void);
void vga_putchar(char c);
void vga_puts(const char *s);
void vga_set_color(uint8_t bg, uint8_t fg);
void vga_set_cursor(int x, int y);
int  vga_get_x(void);
int  vga_get_y(void);
