#pragma once
#include "include/types.h"

void mouse_init(void);
int  mouse_get_x(void);
int  mouse_get_y(void);
int  mouse_get_buttons(void);
void mouse_poll(void);
void mouse_set_bounds(int width, int height);
void mouse_set_position(int x, int y);

#define MOUSE_LEFT   1
#define MOUSE_RIGHT  2
#define MOUSE_MIDDLE 4
