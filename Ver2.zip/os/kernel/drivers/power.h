#pragma once

#include "include/types.h"

NORETURN void power_reboot(void);
