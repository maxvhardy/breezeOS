#pragma once
#include "include/types.h"

#define KBD_KEY_LEFT   0x80
#define KBD_KEY_RIGHT  0x81
#define KBD_KEY_UP     0x82
#define KBD_KEY_DOWN   0x83

struct kbd_event {
    uint8_t pressed;
    uint8_t keycode;
};

void keyboard_init(void);
void keyboard_process_scancode(uint8_t scancode);
char kbd_getchar(void);
int  kbd_has_key(void);
int  kbd_has_event(void);
int  kbd_get_event(struct kbd_event *ev);
uint8_t kbd_get_scancode(void);
int  kbd_is_shift(void);
int  kbd_is_ctrl(void);
int  kbd_is_alt(void);
