#include "drivers/net.h"

#include "drivers/e1000.h"
#include "drivers/pit.h"
#include "lib/string.h"
#include "lib/printf.h"

#define ETH_TYPE_ARP   0x0806
#define ETH_TYPE_IPV4  0x0800

#define IP_PROTO_ICMP  1

#define ICMP_ECHO_REPLY 0
#define ICMP_ECHO_REQ   8

#define ARP_HTYPE_ETH  1
#define ARP_PTYPE_IPV4 0x0800
#define ARP_OP_REQ      1
#define ARP_OP_REPLY    2

struct eth_header {
    uint8_t dst[6];
    uint8_t src[6];
    uint16_t type_be;
} PACKED;

struct arp_packet {
    uint16_t htype_be;
    uint16_t ptype_be;
    uint8_t hlen;
    uint8_t plen;
    uint16_t op_be;
    uint8_t sender_mac[6];
    uint8_t sender_ip[4];
    uint8_t target_mac[6];
    uint8_t target_ip[4];
} PACKED;

struct ipv4_header {
    uint8_t version_ihl;
    uint8_t tos;
    uint16_t total_len_be;
    uint16_t id_be;
    uint16_t frag_be;
    uint8_t ttl;
    uint8_t proto;
    uint16_t csum_be;
    uint8_t src[4];
    uint8_t dst[4];
} PACKED;

struct icmp_echo {
    uint8_t type;
    uint8_t code;
    uint16_t csum_be;
    uint16_t ident_be;
    uint16_t seq_be;
    uint8_t payload[8];
} PACKED;

struct arp_cache_entry {
    bool valid;
    uint8_t ip[4];
    uint8_t mac[6];
    uint64_t updated_ticks;
};

static struct e1000_device nic;
static bool net_ready = false;

// QEMU user-net defaults.
static uint8_t net_ip_addr[4] = {10, 0, 2, 15};
static uint8_t net_gateway[4] = {10, 0, 2, 2};
static uint8_t net_mask[4] = {255, 255, 255, 0};

static struct arp_cache_entry arp_cache[8];
static uint16_t ping_ident = 0xD00F; // Tag for this kernel ping client.
static uint16_t ping_seq = 1;
static bool ping_waiting = false;
static bool ping_received = false;
static uint8_t ping_wait_ip[4];
static uint16_t ping_wait_seq = 0;
static uint64_t ping_sent_ticks = 0;
static uint32_t ping_last_rtt_ms = 0;

static uint16_t bswap16(uint16_t x) {
    return (uint16_t)((x << 8) | (x >> 8));
}

static uint32_t bswap32(uint32_t x) {
    return ((x & 0x000000FFU) << 24) |
           ((x & 0x0000FF00U) << 8) |
           ((x & 0x00FF0000U) >> 8) |
           ((x & 0xFF000000U) >> 24);
}

static uint16_t htons16(uint16_t x) { return bswap16(x); }
static uint16_t ntohs16(uint16_t x) { return bswap16(x); }
static uint32_t htonl32(uint32_t x) { return bswap32(x); }

static uint16_t ip_checksum(const void *data, size_t len) {
    const uint8_t *p = (const uint8_t *)data;
    uint32_t sum = 0;

    while (len > 1) {
        sum += ((uint16_t)p[0] << 8) | p[1];
        p += 2;
        len -= 2;
    }
    if (len) sum += ((uint16_t)p[0] << 8);

    while (sum >> 16) {
        sum = (sum & 0xFFFFU) + (sum >> 16);
    }
    return (uint16_t)(~sum);
}

static int is_broadcast_mac(const uint8_t mac[6]) {
    for (int i = 0; i < 6; i++) {
        if (mac[i] != 0xFF) return 0;
    }
    return 1;
}

static int mac_equal(const uint8_t a[6], const uint8_t b[6]) {
    return memcmp(a, b, 6) == 0;
}

static int ip_equal(const uint8_t a[4], const uint8_t b[4]) {
    return memcmp(a, b, 4) == 0;
}

static void arp_cache_put(const uint8_t ip[4], const uint8_t mac[6]) {
    int slot = -1;
    uint64_t oldest = (uint64_t)-1;
    int oldest_idx = 0;

    for (int i = 0; i < (int)(sizeof(arp_cache) / sizeof(arp_cache[0])); i++) {
        if (arp_cache[i].valid && ip_equal(arp_cache[i].ip, ip)) {
            slot = i;
            break;
        }
        if (!arp_cache[i].valid && slot < 0) {
            slot = i;
        }
        if (arp_cache[i].updated_ticks < oldest) {
            oldest = arp_cache[i].updated_ticks;
            oldest_idx = i;
        }
    }
    if (slot < 0) slot = oldest_idx;

    arp_cache[slot].valid = true;
    memcpy(arp_cache[slot].ip, ip, 4);
    memcpy(arp_cache[slot].mac, mac, 6);
    arp_cache[slot].updated_ticks = pit_get_ticks();
}

static int arp_cache_get(const uint8_t ip[4], uint8_t out_mac[6]) {
    for (int i = 0; i < (int)(sizeof(arp_cache) / sizeof(arp_cache[0])); i++) {
        if (!arp_cache[i].valid) continue;
        if (!ip_equal(arp_cache[i].ip, ip)) continue;
        memcpy(out_mac, arp_cache[i].mac, 6);
        return 0;
    }
    return -1;
}

static int net_send_frame(const uint8_t *frame, size_t len) {
    return e1000_send(&nic, frame, len);
}

static void net_send_arp(const uint8_t dst_mac[6], uint16_t op,
                         const uint8_t sender_mac[6], const uint8_t sender_ip[4],
                         const uint8_t target_mac[6], const uint8_t target_ip[4]) {
    uint8_t frame[sizeof(struct eth_header) + sizeof(struct arp_packet)];
    struct eth_header *eth = (struct eth_header *)frame;
    struct arp_packet *arp = (struct arp_packet *)(frame + sizeof(*eth));

    memcpy(eth->dst, dst_mac, 6);
    memcpy(eth->src, sender_mac, 6);
    eth->type_be = htons16(ETH_TYPE_ARP);

    arp->htype_be = htons16(ARP_HTYPE_ETH);
    arp->ptype_be = htons16(ARP_PTYPE_IPV4);
    arp->hlen = 6;
    arp->plen = 4;
    arp->op_be = htons16(op);
    memcpy(arp->sender_mac, sender_mac, 6);
    memcpy(arp->sender_ip, sender_ip, 4);
    memcpy(arp->target_mac, target_mac, 6);
    memcpy(arp->target_ip, target_ip, 4);

    (void)net_send_frame(frame, sizeof(frame));
}

static void net_send_arp_request(const uint8_t target_ip[4]) {
    uint8_t broadcast[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
    uint8_t null_mac[6] = {0, 0, 0, 0, 0, 0};
    net_send_arp(broadcast, ARP_OP_REQ, nic.mac, net_ip_addr, null_mac, target_ip);
}

static void net_send_arp_reply(const uint8_t req_src_mac[6], const uint8_t req_src_ip[4]) {
    net_send_arp(req_src_mac, ARP_OP_REPLY, nic.mac, net_ip_addr, req_src_mac, req_src_ip);
}

static int is_same_subnet(const uint8_t ip_a[4], const uint8_t ip_b[4]) {
    for (int i = 0; i < 4; i++) {
        if ((ip_a[i] & net_mask[i]) != (ip_b[i] & net_mask[i])) return 0;
    }
    return 1;
}

static int resolve_mac(const uint8_t dst_ip[4], uint8_t out_mac[6], uint32_t timeout_ms) {
    if (arp_cache_get(dst_ip, out_mac) == 0) return 0;

    uint64_t start = pit_get_ticks();
    uint64_t timeout_ticks = start + (timeout_ms + 9U) / 10U;
    uint64_t next_probe = start;

    while (pit_get_ticks() <= timeout_ticks) {
        uint64_t now = pit_get_ticks();
        if (now >= next_probe) {
            net_send_arp_request(dst_ip);
            next_probe = now + 20; // ~200 ms
        }
        net_poll();
        if (arp_cache_get(dst_ip, out_mac) == 0) return 0;
        pit_sleep(10);
    }

    return -1;
}

static int route_mac_for_ip(const uint8_t dst_ip[4], uint8_t out_mac[6], uint32_t timeout_ms) {
    if (is_same_subnet(net_ip_addr, dst_ip)) {
        return resolve_mac(dst_ip, out_mac, timeout_ms);
    }
    return resolve_mac(net_gateway, out_mac, timeout_ms);
}

static void net_send_ipv4_icmp_echo(const uint8_t dst_ip[4], const uint8_t dst_mac[6],
                                    uint16_t ident, uint16_t seq, uint8_t type) {
    uint8_t frame[sizeof(struct eth_header) + sizeof(struct ipv4_header) + sizeof(struct icmp_echo)];
    struct eth_header *eth = (struct eth_header *)frame;
    struct ipv4_header *ip = (struct ipv4_header *)(frame + sizeof(*eth));
    struct icmp_echo *icmp = (struct icmp_echo *)((uint8_t *)ip + sizeof(*ip));

    memcpy(eth->dst, dst_mac, 6);
    memcpy(eth->src, nic.mac, 6);
    eth->type_be = htons16(ETH_TYPE_IPV4);

    ip->version_ihl = 0x45;
    ip->tos = 0;
    ip->total_len_be = htons16((uint16_t)(sizeof(struct ipv4_header) + sizeof(struct icmp_echo)));
    ip->id_be = htons16(seq);
    ip->frag_be = htons16(0x4000); // Don't fragment
    ip->ttl = 64;
    ip->proto = IP_PROTO_ICMP;
    ip->csum_be = 0;
    memcpy(ip->src, net_ip_addr, 4);
    memcpy(ip->dst, dst_ip, 4);
    ip->csum_be = htons16(ip_checksum(ip, sizeof(*ip)));

    icmp->type = type;
    icmp->code = 0;
    icmp->csum_be = 0;
    icmp->ident_be = htons16(ident);
    icmp->seq_be = htons16(seq);
    uint32_t ticks = (uint32_t)pit_get_ticks();
    uint32_t ticks_be = htonl32(ticks);
    memcpy(icmp->payload, &ticks_be, sizeof(ticks_be));
    memset(icmp->payload + sizeof(ticks_be), 0xA5, sizeof(icmp->payload) - sizeof(ticks_be));
    icmp->csum_be = htons16(ip_checksum(icmp, sizeof(*icmp)));

    (void)net_send_frame(frame, sizeof(frame));
}

static void handle_arp_packet(const struct eth_header *eth, const uint8_t *payload, size_t len) {
    if (len < sizeof(struct arp_packet)) return;
    const struct arp_packet *arp = (const struct arp_packet *)payload;

    if (ntohs16(arp->htype_be) != ARP_HTYPE_ETH) return;
    if (ntohs16(arp->ptype_be) != ARP_PTYPE_IPV4) return;
    if (arp->hlen != 6 || arp->plen != 4) return;

    arp_cache_put(arp->sender_ip, arp->sender_mac);

    uint16_t op = ntohs16(arp->op_be);
    if (op == ARP_OP_REQ && ip_equal(arp->target_ip, net_ip_addr)) {
        net_send_arp_reply(arp->sender_mac, arp->sender_ip);
    }

    (void)eth;
}

static void handle_ipv4_packet(const struct eth_header *eth, const uint8_t *payload, size_t len) {
    if (len < sizeof(struct ipv4_header)) return;
    const struct ipv4_header *ip = (const struct ipv4_header *)payload;
    uint8_t ihl = (ip->version_ihl & 0x0F) * 4;
    if ((ip->version_ihl >> 4) != 4) return;
    if (ihl < sizeof(struct ipv4_header) || len < ihl) return;
    if (!ip_equal(ip->dst, net_ip_addr)) return;

    if (ip->proto != IP_PROTO_ICMP) return;
    if (len < ihl + sizeof(struct icmp_echo)) return;

    const struct icmp_echo *icmp = (const struct icmp_echo *)(payload + ihl);
    uint16_t ident = ntohs16(icmp->ident_be);
    uint16_t seq = ntohs16(icmp->seq_be);

    if (icmp->type == ICMP_ECHO_REQ) {
        // Reply using source MAC/IP from request packet.
        net_send_ipv4_icmp_echo(ip->src, eth->src, ident, seq, ICMP_ECHO_REPLY);
        return;
    }

    if (icmp->type == ICMP_ECHO_REPLY && ping_waiting &&
        ident == ping_ident && seq == ping_wait_seq &&
        ip_equal(ip->src, ping_wait_ip)) {
        uint64_t now_ticks = pit_get_ticks();
        uint64_t delta_ticks = now_ticks - ping_sent_ticks;
        ping_last_rtt_ms = (uint32_t)(delta_ticks * 10ULL);
        ping_received = true;
        ping_waiting = false;
    }
}

void net_poll(void) {
    if (!net_ready) return;

    uint8_t frame[E1000_PKT_BUF_SIZE];
    for (int i = 0; i < 16; i++) {
        size_t frame_len = 0;
        int rc = e1000_recv(&nic, frame, sizeof(frame), &frame_len);
        if (rc <= 0 || frame_len < sizeof(struct eth_header)) break;

        struct eth_header *eth = (struct eth_header *)frame;
        if (!mac_equal(eth->dst, nic.mac) && !is_broadcast_mac(eth->dst)) continue;

        uint16_t type = ntohs16(eth->type_be);
        const uint8_t *payload = frame + sizeof(struct eth_header);
        size_t payload_len = frame_len - sizeof(struct eth_header);

        if (type == ETH_TYPE_ARP) {
            handle_arp_packet(eth, payload, payload_len);
        } else if (type == ETH_TYPE_IPV4) {
            handle_ipv4_packet(eth, payload, payload_len);
        }
    }
}

void net_init(void) {
    memset(arp_cache, 0, sizeof(arp_cache));
    ping_waiting = false;
    ping_received = false;
    ping_seq = 1;

    if (e1000_init(&nic) < 0) {
        net_ready = false;
        return;
    }

    net_ready = true;
    e1000_update_link(&nic);

    if (nic.link_up) {
        uint8_t gw_mac[6];
        if (resolve_mac(net_gateway, gw_mac, 500) == 0) {
            arp_cache_put(net_gateway, gw_mac);
        }
    }
}

bool net_is_ready(void) {
    return net_ready;
}

bool net_is_link_up(void) {
    if (!net_ready) return false;
    e1000_update_link(&nic);
    return nic.link_up;
}

const uint8_t *net_get_mac(void) {
    return nic.mac;
}

const uint8_t *net_get_ip(void) {
    return net_ip_addr;
}

const uint8_t *net_get_gateway(void) {
    return net_gateway;
}

const uint8_t *net_get_netmask(void) {
    return net_mask;
}

int net_parse_ipv4(const char *text, uint8_t out_ip[4]) {
    if (!text || !out_ip) return -1;

    int part = 0;
    int value = 0;
    int have_digit = 0;
    memset(out_ip, 0, 4);

    for (size_t i = 0;; i++) {
        char ch = text[i];
        if (ch >= '0' && ch <= '9') {
            value = value * 10 + (ch - '0');
            if (value > 255) return -1;
            have_digit = 1;
            continue;
        }

        if ((ch == '.' || ch == '\0') && have_digit) {
            if (part >= 4) return -1;
            out_ip[part++] = (uint8_t)value;
            value = 0;
            have_digit = 0;
            if (ch == '\0') break;
            continue;
        }

        return -1;
    }

    return (part == 4) ? 0 : -1;
}

void net_format_ipv4(const uint8_t ip[4], char *buf, size_t buf_sz) {
    if (!buf || buf_sz == 0 || !ip) return;
    snprintf(buf, buf_sz, "%u.%u.%u.%u",
             (unsigned)ip[0], (unsigned)ip[1], (unsigned)ip[2], (unsigned)ip[3]);
}

void net_format_mac(const uint8_t mac[6], char *buf, size_t buf_sz) {
    if (!buf || buf_sz == 0 || !mac) return;
    snprintf(buf, buf_sz, "%02x:%02x:%02x:%02x:%02x:%02x",
             (unsigned)mac[0], (unsigned)mac[1], (unsigned)mac[2],
             (unsigned)mac[3], (unsigned)mac[4], (unsigned)mac[5]);
}

int net_ping(const uint8_t dst_ip[4], uint32_t timeout_ms, uint32_t *out_rtt_ms) {
    if (!net_ready) return -1;
    if (!net_is_link_up()) return -1;

    uint8_t dst_mac[6];
    if (route_mac_for_ip(dst_ip, dst_mac, timeout_ms < 1000 ? 1000 : timeout_ms) < 0) {
        return -1;
    }

    uint16_t seq = ping_seq++;
    ping_waiting = true;
    ping_received = false;
    ping_wait_seq = seq;
    memcpy(ping_wait_ip, dst_ip, 4);
    ping_sent_ticks = pit_get_ticks();
    ping_last_rtt_ms = 0;

    net_send_ipv4_icmp_echo(dst_ip, dst_mac, ping_ident, seq, ICMP_ECHO_REQ);

    uint64_t deadline = pit_get_ticks() + ((timeout_ms + 9U) / 10U);
    while (pit_get_ticks() <= deadline) {
        net_poll();
        if (ping_received) {
            if (out_rtt_ms) *out_rtt_ms = ping_last_rtt_ms;
            return 0;
        }
        pit_sleep(10);
    }

    ping_waiting = false;
    return -1;
}
