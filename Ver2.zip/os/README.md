# DoorOS (x86_64)

## Prerequisites

- NASM
- GCC (x86_64-elf cross-compiler or system GCC)
- GNU Make
- QEMU
- `qemu-img` (for VDI/VMDK conversion)

Ubuntu/Debian:
```bash
sudo apt install nasm gcc make qemu-system-x86 qemu-utils
```

## Build

```bash
make
```

## LLVM C Compiler (User Programs)

Build a DoorOS user ELF with LLVM/Clang:

```bash
make llvm-user SRC=user/hello.c OUT=build/user/hello.elf
```

Defaults:
- `LLVM_CC=clang`
- `LLVM_LD=ld.lld`

You can override them, for example:

```bash
make llvm-user LLVM_CC=clang LLVM_LD=ld.lld SRC=user/hello.c OUT=build/user/hello.elf
```

## `.exe` Launch Support

DoorOS keeps ELF binaries as the executable format, but supports `.exe` names:

- `mkfs` adds `/bin/<name>.exe` aliases for each built `/bin/<name>` ELF.
- Both shells try fallback launch paths:
  - `foo` -> `foo.exe`
  - `foo.exe` -> `foo`

This provides practical `.exe` launching without a PE/Windows loader.

## Shell Compile + Reboot Commands

Both shells now include:

- `compile file.c file.o`
- `compile file.c file .elf`
- `compile file.o file.elf`
- `ps` / `ppid` / `spawn <program>` / `kill <pid>`
- `reboot` / `restart`
- `lemonman` (easter egg)

Built-in sample source:
- `/hello.c` is baked into the image as a starter file for `compile`.

## Process Model + Syscalls

DoorOS now exposes a richer process API:

- Every program is tracked as a process with parent PID, creation tick, CPU tick usage, cwd, and flags.
- New syscalls:
  - `SYS_GETPPID` (`getppid()`)
  - `SYS_SPAWN` (`spawn(path)`)
  - `SYS_PROCLIST` (`proc_list(...)`)
  - `SYS_KILL` (`kill(pid)`) with signal-based terminate delivery
  - `SYS_EXECVE` (`execve(path, argv, envp)`) with argument/environment stack setup
- `waitpid(-1, ...)` now waits for any child process (instead of only checking once).
- User `_start` now receives and forwards `argc/argv/envp`; libc exposes `environ` and `getenv`.
- `/bin/init` is a userland init/service manager that supervises shell and reaps child app processes.

## Networking (e1000 Ethernet)

QEMU run targets include an Intel e1000 NIC (`-nic user,model=e1000`).

In GUI Terminal:
- `ifconfig` (or `ipconfig`) shows link, MAC, IPv4, mask, gateway.
- `ping [ip]` sends ICMP echo (defaults to gateway if no IP is given).

Example:

```text
ping 10.0.2.2
```

## Productivity Apps

DoorOS now ships with:

- `Macrohard Action Employee`:
  - now runs as a user process (`/bin/action`)
  - Task-Manager-style process dashboard (PID/PPID/state/type/CPU/name)
  - refresh and terminate controls for selected processes
- `Calculator`:
  - now runs as a user process (`/bin/calculator`)
  - interactive GUI calculator app (keyboard + on-screen keypad)
  - supports integer expressions with `+ - * / %` and parentheses

## Settings Panel

Open `Macrohard FreedomBlock` from Launchpad/Dock (or run `settings` in the GUI terminal) to tweak:

1. Wallpaper theme
2. Window corner roundness
3. UI chrome style
4. Network section (`eth0` status, IP/GW/mask, refresh, and gateway ping test)

Text Editor now supports:
- Arrow-key cursor movement
- Export buttons for `.c` and `.txt`
- In-app rename prompt

## Run In QEMU (Normal)

```bash
make run
```

This is the normal run target and does NOT start paused.
If the guest crashes, QEMU will stop instead of reboot-looping (`-no-reboot -no-shutdown`).

## Run In QEMU (Headless)

```bash
make run-headless
```

## Debug In QEMU (Starts Paused)

```bash
make debug
```

`make debug` intentionally uses `-S` and starts paused for GDB.

## VirtualBox Disk (VDI)

Generate a VirtualBox disk:

```bash
make vdi
```

Use `build/os.vdi` as the VM hard disk in VirtualBox.
Create a VM as `Other/Unknown (64-bit)`, set RAM to 256 MB+, and boot from that disk.
Do not attach this project as a CD/DVD ISO. The bootloader expects an MBR hard disk.

## VMDK Disk (Optional)

```bash
make vmdk
```

Outputs `build/os.vmdk`.

## Clean

```bash
make clean
```
