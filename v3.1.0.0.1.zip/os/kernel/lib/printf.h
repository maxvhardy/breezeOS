#pragma once
#include "include/types.h"

typedef void (*putchar_fn)(char c);

int kprintf(const char *fmt, ...);
int snprintf(char *buf, size_t size, const char *fmt, ...);
void set_kprintf_putchar(putchar_fn fn);
