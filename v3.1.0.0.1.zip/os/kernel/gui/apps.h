#pragma once

#include "include/types.h"
#include "gui/event.h"

#define APP_TYPE_NONE         0
#define APP_TYPE_TERMINAL     1
#define APP_TYPE_FILE_MANAGER 2
#define APP_TYPE_TEXT_EDITOR  3
#define APP_TYPE_SETTINGS     4
#define APP_TYPE_TASK_MANAGER 5

void gui_apps_init(void);

int gui_apps_spawn_terminal(void);
int gui_apps_spawn_file_manager(void);
int gui_apps_spawn_text_editor(void);
int gui_apps_spawn_text_editor_path(const char *path);
int gui_apps_spawn_settings_panel(void);
int gui_apps_spawn_task_manager(void);
int gui_apps_launch_doom(void);

void gui_apps_handle_event(const struct gui_event *ev);
void gui_apps_on_window_destroyed(int wid);
void gui_apps_tick(void);

bool gui_apps_is_type_running(int app_type);
bool gui_apps_is_managed(int wid);
