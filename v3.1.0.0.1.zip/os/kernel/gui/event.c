#include "gui/event.h"
#include "gui/window.h"
#include "lib/string.h"

static struct gui_event event_queue[EVENT_QUEUE_SIZE];
static volatile int eq_read = 0;
static volatile int eq_write = 0;
static volatile uint32_t eq_epoch = 0;

void gui_event_init(void) {
    uint64_t irq = irq_save();
    eq_read = 0;
    eq_write = 0;
    eq_epoch = 0;
    memset(event_queue, 0, sizeof(event_queue));
    irq_restore(irq);
}

void gui_event_push(struct gui_event *ev) {
    if (!ev) return;

    uint64_t irq = irq_save();
    int next = (eq_write + 1) % EVENT_QUEUE_SIZE;
    if (next == eq_read) {
        irq_restore(irq);
        return; // Queue full
    }
    event_queue[eq_write] = *ev;
    eq_write = next;
    eq_epoch++;
    irq_restore(irq);
}

int gui_event_poll(struct gui_event *ev) {
    if (!ev) return 0;

    uint64_t irq = irq_save();
    if (eq_read == eq_write) {
        ev->type = GUI_EVENT_NONE;
        irq_restore(irq);
        return 0;
    }
    *ev = event_queue[eq_read];
    eq_read = (eq_read + 1) % EVENT_QUEUE_SIZE;
    eq_epoch++;
    irq_restore(irq);
    return 1;
}

int gui_event_poll_for_owner(int owner_pid, struct gui_event *ev) {
    if (!ev) return 0;
    if (owner_pid <= 0) {
        ev->type = GUI_EVENT_NONE;
        return 0;
    }

    struct gui_event local[EVENT_QUEUE_SIZE];
    const int max_attempts = 8;

    for (int attempt = 0; attempt < max_attempts; attempt++) {
        int snap_read;
        int snap_write;
        uint32_t snap_epoch;
        int local_count = 0;

        // Snapshot queue quickly with IRQs disabled so each copied event
        // struct is internally consistent.
        uint64_t irq = irq_save();
        if (eq_read == eq_write) {
            ev->type = GUI_EVENT_NONE;
            irq_restore(irq);
            return 0;
        }
        snap_read = eq_read;
        snap_write = eq_write;
        snap_epoch = eq_epoch;

        int idx = snap_read;
        int scanned = 0;
        while (idx != snap_write &&
               local_count < EVENT_QUEUE_SIZE &&
               scanned < EVENT_QUEUE_SIZE) {
            local[local_count++] = event_queue[idx];
            idx = (idx + 1) % EVENT_QUEUE_SIZE;
            scanned++;
        }
        irq_restore(irq);

        // Process snapshot with IRQs enabled.
        int found = 0;
        struct gui_event found_ev;
        int kept_count = 0;
        int changed = 0;

        for (int i = 0; i < local_count; i++) {
            struct gui_event cand = local[i];
            struct window *win = window_get((int)cand.window_id);

            if (!win || win->owner_pid <= 0) {
                changed = 1;
                continue; // Drop stale event.
            }

            if (!found && win->owner_pid == owner_pid) {
                found = 1;
                found_ev = cand;
                changed = 1; // Consumed one event from queue.
                continue;
            }

            local[kept_count++] = cand;
        }

        // Commit only if queue is unchanged since snapshot.
        irq = irq_save();
        if (eq_epoch != snap_epoch || eq_read != snap_read || eq_write != snap_write) {
            irq_restore(irq);
            continue;
        }

        if (changed) {
            eq_read = 0;
            eq_write = kept_count;
            for (int i = 0; i < kept_count; i++) {
                event_queue[i] = local[i];
            }
            eq_epoch++;
        }
        irq_restore(irq);

        if (found) {
            *ev = found_ev;
            return 1;
        }

        ev->type = GUI_EVENT_NONE;
        return 0;
    }

    // High contention fallback: report no event without blocking interrupts.
    ev->type = GUI_EVENT_NONE;
    return 0;
}

void gui_event_discard_window(uint32_t window_id) {
    struct gui_event local[EVENT_QUEUE_SIZE];
    const int max_attempts = 8;

    for (int attempt = 0; attempt < max_attempts; attempt++) {
        int snap_read;
        int snap_write;
        uint32_t snap_epoch;
        int local_count = 0;

        uint64_t irq = irq_save();
        if (eq_read == eq_write) {
            irq_restore(irq);
            return;
        }
        snap_read = eq_read;
        snap_write = eq_write;
        snap_epoch = eq_epoch;

        int idx = snap_read;
        int scanned = 0;
        while (idx != snap_write &&
               local_count < EVENT_QUEUE_SIZE &&
               scanned < EVENT_QUEUE_SIZE) {
            local[local_count++] = event_queue[idx];
            idx = (idx + 1) % EVENT_QUEUE_SIZE;
            scanned++;
        }
        irq_restore(irq);

        int kept_count = 0;
        for (int i = 0; i < local_count; i++) {
            if (local[i].window_id == window_id) continue;
            local[kept_count++] = local[i];
        }
        if (kept_count == local_count) {
            return; // Nothing to discard.
        }

        irq = irq_save();
        if (eq_epoch != snap_epoch || eq_read != snap_read || eq_write != snap_write) {
            irq_restore(irq);
            continue;
        }

        eq_read = 0;
        eq_write = kept_count;
        for (int i = 0; i < kept_count; i++) {
            event_queue[i] = local[i];
        }
        eq_epoch++;
        irq_restore(irq);
        return;
    }
}

int gui_event_has_events(void) {
    uint64_t irq = irq_save();
    int has = (eq_read != eq_write);
    irq_restore(irq);
    return has;
}
