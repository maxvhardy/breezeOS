#pragma once
#include "include/types.h"

#define MAX_WINDOWS 32
#define WINDOW_TITLE_HEIGHT 28
#define WINDOW_BORDER_SIZE  1

#define WIN_FLAG_VISIBLE    (1 << 0)
#define WIN_FLAG_FOCUSED    (1 << 1)
#define WIN_FLAG_DRAGGING   (1 << 2)
#define WIN_FLAG_DECORATED  (1 << 3)

struct window {
    int id;
    int x, y;
    int width, height;
    char title[64];
    uint32_t *framebuffer;
    uint32_t flags;
    int owner_pid;
    int z_order;
};

void window_init(void);
int  window_create(int x, int y, int w, int h, const char *title);
void window_destroy(int wid);
int  window_update_buffer(int wid, uint32_t *pixels);
struct window *window_get(int wid);
int  window_get_count(void);
struct window *window_get_focused(void);
void window_set_focused(int wid);
void window_move(int wid, int x, int y);
void window_get_sorted(struct window **list, int *count);
void window_destroy_by_owner(int owner_pid);
void window_collect_garbage(void);
