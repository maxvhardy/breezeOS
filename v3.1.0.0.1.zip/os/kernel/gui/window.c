#include "gui/window.h"
#include "gui/event.h"
#include "gui/apps.h"
#include "sched/process.h"
#include "mm/heap.h"
#include "lib/string.h"
#include "lib/printf.h"

static struct window windows[MAX_WINDOWS];
static int focused_window = -1;
static int next_z = 1;
static void *retired_framebuffers[MAX_WINDOWS * 4];
static int retired_fb_count = 0;

void window_init(void) {
    memset(windows, 0, sizeof(windows));
    focused_window = -1;
    next_z = 1;
    retired_fb_count = 0;
}

int window_create(int x, int y, int w, int h, const char *title) {
    // Reject invalid or obviously unsafe dimensions.
    if (w <= 0 || h <= 0) return -1;
    if (w > 4096 || h > 4096) return -1;

    size_t pixel_count = (size_t)w * (size_t)h;
    if (pixel_count / (size_t)w != (size_t)h) return -1;
    if (pixel_count > ((size_t)-1) / sizeof(uint32_t)) return -1;

    // Find free slot
    int id = -1;
    for (int i = 0; i < MAX_WINDOWS; i++) {
        if (!(windows[i].flags & WIN_FLAG_VISIBLE)) {
            id = i;
            break;
        }
    }
    if (id < 0) return -1;

    struct window *win = &windows[id];
    win->id = id;
    win->x = x;
    win->y = y;
    win->width = w;
    win->height = h;
    win->flags = WIN_FLAG_VISIBLE | WIN_FLAG_DECORATED;
    win->z_order = next_z++;

    if (title) {
        strncpy(win->title, title, sizeof(win->title) - 1);
        win->title[sizeof(win->title) - 1] = '\0';
    } else {
        strcpy(win->title, "Window");
    }

    struct process *proc = process_current();
    win->owner_pid = proc ? proc->pid : 0;

    // Allocate client area framebuffer
    size_t fb_size = pixel_count * sizeof(uint32_t);
    win->framebuffer = (uint32_t *)kmalloc(fb_size);
    if (!win->framebuffer) {
        win->flags = 0;
        return -1;
    }
    memset(win->framebuffer, 0, fb_size);

    // Focus this new window
    window_set_focused(id);

    kprintf("[WIN] Created window %d: \"%s\" (%dx%d at %d,%d)\n",
            id, win->title, w, h, x, y);
    return id;
}

void window_destroy(int wid) {
    if (wid < 0 || wid >= MAX_WINDOWS) return;
    struct window *win = &windows[wid];
    if (!(win->flags & WIN_FLAG_VISIBLE)) return;

    gui_event_discard_window((uint32_t)wid);
    gui_apps_on_window_destroyed(wid);

    if (win->framebuffer) {
        uint64_t irq = irq_save();
        if (retired_fb_count < (int)(sizeof(retired_framebuffers) / sizeof(retired_framebuffers[0]))) {
            retired_framebuffers[retired_fb_count++] = win->framebuffer;
            win->framebuffer = NULL;
            irq_restore(irq);
        } else {
            // Fallback path if retire queue is unexpectedly full.
            void *fb = win->framebuffer;
            win->framebuffer = NULL;
            irq_restore(irq);
            kfree(fb);
        }
    }
    win->flags = 0;

    if (focused_window == wid) {
        focused_window = -1;
        // Focus the topmost remaining window
        int best_z = -1;
        for (int i = 0; i < MAX_WINDOWS; i++) {
            if ((windows[i].flags & WIN_FLAG_VISIBLE) && windows[i].z_order > best_z) {
                best_z = windows[i].z_order;
                focused_window = i;
            }
        }
    }
}

int window_update_buffer(int wid, uint32_t *pixels) {
    if (wid < 0 || wid >= MAX_WINDOWS) return -1;
    if (!pixels) return -1;
    struct window *win = &windows[wid];
    if (!(win->flags & WIN_FLAG_VISIBLE) || !win->framebuffer) return -1;

    size_t fb_size = (size_t)win->width * win->height * sizeof(uint32_t);
    memcpy(win->framebuffer, pixels, fb_size);
    return 0;
}

struct window *window_get(int wid) {
    if (wid < 0 || wid >= MAX_WINDOWS) return NULL;
    if (!(windows[wid].flags & WIN_FLAG_VISIBLE)) return NULL;
    return &windows[wid];
}

int window_get_count(void) {
    int count = 0;
    for (int i = 0; i < MAX_WINDOWS; i++) {
        if (windows[i].flags & WIN_FLAG_VISIBLE) count++;
    }
    return count;
}

struct window *window_get_focused(void) {
    if (focused_window < 0) return NULL;
    return window_get(focused_window);
}

void window_set_focused(int wid) {
    if (wid < 0 || wid >= MAX_WINDOWS) return;
    if (!(windows[wid].flags & WIN_FLAG_VISIBLE)) return;

    // Remove focus from old window
    if (focused_window >= 0 && focused_window < MAX_WINDOWS) {
        windows[focused_window].flags &= ~WIN_FLAG_FOCUSED;
    }

    focused_window = wid;
    windows[wid].flags |= WIN_FLAG_FOCUSED;
    windows[wid].z_order = next_z++;

    // Send focus event
    struct gui_event ev;
    memset(&ev, 0, sizeof(ev));
    ev.type = GUI_EVENT_WIN_FOCUS;
    ev.window_id = wid;
    if (windows[wid].owner_pid > 0) {
        gui_event_push(&ev);
    }
    gui_apps_handle_event(&ev);
}

void window_move(int wid, int x, int y) {
    if (wid < 0 || wid >= MAX_WINDOWS) return;
    if (!(windows[wid].flags & WIN_FLAG_VISIBLE)) return;
    windows[wid].x = x;
    windows[wid].y = y;
}

void window_get_sorted(struct window **list, int *count) {
    *count = 0;

    // Collect visible windows
    struct window *visible[MAX_WINDOWS];
    int n = 0;
    for (int i = 0; i < MAX_WINDOWS; i++) {
        if (windows[i].flags & WIN_FLAG_VISIBLE) {
            visible[n++] = &windows[i];
        }
    }

    // Sort by z_order (lowest first = drawn first = behind)
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            if (visible[i]->z_order > visible[j]->z_order) {
                struct window *tmp = visible[i];
                visible[i] = visible[j];
                visible[j] = tmp;
            }
        }
    }

    for (int i = 0; i < n; i++) {
        list[i] = visible[i];
    }
    *count = n;
}

void window_destroy_by_owner(int owner_pid) {
    if (owner_pid <= 0) return;

    for (int i = 0; i < MAX_WINDOWS; i++) {
        if ((windows[i].flags & WIN_FLAG_VISIBLE) && windows[i].owner_pid == owner_pid) {
            window_destroy(i);
        }
    }
}

void window_collect_garbage(void) {
    void *to_free[MAX_WINDOWS * 4];
    int n = 0;

    uint64_t irq = irq_save();
    n = retired_fb_count;
    if (n > (int)(sizeof(to_free) / sizeof(to_free[0]))) {
        n = (int)(sizeof(to_free) / sizeof(to_free[0]));
    }
    for (int i = 0; i < n; i++) {
        to_free[i] = retired_framebuffers[i];
    }
    retired_fb_count = 0;
    irq_restore(irq);

    for (int i = 0; i < n; i++) {
        if (to_free[i]) kfree(to_free[i]);
    }
}
