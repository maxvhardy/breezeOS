#pragma once
#include "include/types.h"

#define VFS_FILE      1
#define VFS_DIRECTORY 2
#define VFS_CHARDEV   3

#define O_RDONLY  0
#define O_WRONLY  1
#define O_RDWR    2
#define O_CREAT   0x100
#define O_TRUNC   0x200
#define O_APPEND  0x400

#define SEEK_SET  0
#define SEEK_CUR  1
#define SEEK_END  2

#define MAX_PATH  256
#define MAX_NAME  58
#define MAX_FDS   32

struct dirent {
    uint32_t inode;
    uint8_t  type;
    char     name[MAX_NAME + 1];
};

struct stat {
    uint32_t inode;
    uint32_t type;
    uint32_t size;
    uint32_t blocks;
    uint64_t created;
    uint64_t modified;
};

struct vfs_node;

struct vfs_ops {
    ssize_t (*read)(struct vfs_node *node, void *buf, size_t count);
    ssize_t (*write)(struct vfs_node *node, const void *buf, size_t count);
    int (*open)(struct vfs_node *node, int flags);
    void (*close)(struct vfs_node *node);
    int (*readdir)(struct vfs_node *node, struct dirent *entry);
    int (*mkdir)(const char *path);
    int (*rmdir)(const char *path);
    int (*unlink)(const char *path);
    int (*stat)(const char *path, struct stat *st);
    int64_t (*lseek)(struct vfs_node *node, int64_t offset, int whence);
    int (*rename)(const char *oldpath, const char *newpath);
    int (*truncate)(const char *path, uint32_t length);
    int (*chmod)(const char *path, uint32_t mode);
};

struct vfs_node {
    char     name[MAX_NAME + 1];
    uint32_t type;
    uint32_t inode;
    uint32_t size;
    uint64_t offset;       // Current read/write position
    uint32_t dir_index;    // For readdir iteration
    int      flags;
    struct vfs_ops *ops;
    void    *private_data;
};

void vfs_init(void);
struct vfs_node *vfs_open(const char *path, int flags);
void vfs_close(struct vfs_node *node);
ssize_t vfs_read(struct vfs_node *node, void *buf, size_t count);
ssize_t vfs_write(struct vfs_node *node, const void *buf, size_t count);
int vfs_readdir(struct vfs_node *node, struct dirent *entry);
int vfs_mkdir(const char *path);
int vfs_rmdir(const char *path);
int vfs_unlink(const char *path);
int vfs_stat(const char *path, struct stat *st);
int64_t vfs_lseek(struct vfs_node *node, int64_t offset, int whence);

int vfs_rename(const char *oldpath, const char *newpath);
int vfs_truncate(const char *path, uint32_t length);
int vfs_chmod(const char *path, uint32_t mode);

// Register a filesystem
void vfs_register_fs(struct vfs_ops *ops);
