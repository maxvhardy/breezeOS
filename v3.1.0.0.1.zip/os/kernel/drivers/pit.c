#include "drivers/pit.h"
#include "drivers/pic.h"
#include "arch/idt.h"
#include "sched/scheduler.h"

static volatile uint64_t ticks = 0;

static void pit_handler(struct registers *regs) {
    (void)regs;
    ticks++;
    schedule_tick(regs);
}

void pit_init(void) {
    uint16_t divisor = PIT_FREQ / PIT_HZ;

    // Channel 0, lobyte/hibyte, rate generator
    outb(0x43, 0x36);
    outb(0x40, divisor & 0xFF);
    outb(0x40, (divisor >> 8) & 0xFF);

    // Register handler and unmask IRQ0
    isr_register_handler(32, pit_handler);
    pic_clear_mask(IRQ_TIMER);
}

uint64_t pit_get_ticks(void) {
    return ticks;
}

void pit_sleep(uint64_t ms) {
    uint64_t target = ticks + (ms * PIT_HZ) / 1000;

    // hlt only wakes on maskable interrupts, so temporarily ensure IF is set.
    uint64_t rflags = 0;
    __asm__ volatile("pushfq; pop %0" : "=r"(rflags));
    int had_if = (rflags & (1ULL << 9)) != 0;
    if (!had_if) sti();

    while (ticks < target) {
        __asm__ volatile("hlt");
    }

    if (!had_if) cli();
}
