#pragma once

#include "include/types.h"
#include "drivers/pci.h"

#define E1000_RX_DESC_COUNT 32
#define E1000_TX_DESC_COUNT 32
#define E1000_PKT_BUF_SIZE  2048

struct e1000_rx_desc {
    uint64_t addr;
    uint16_t length;
    uint16_t csum;
    uint8_t status;
    uint8_t errors;
    uint16_t special;
} PACKED;

struct e1000_tx_desc {
    uint64_t addr;
    uint16_t length;
    uint8_t cso;
    uint8_t cmd;
    uint8_t status;
    uint8_t css;
    uint16_t special;
} PACKED;

struct e1000_device {
    bool present;
    bool link_up;
    uint8_t mac[6];

    struct pci_device pci;
    volatile uint8_t *mmio;
    uint32_t mmio_size;

    struct e1000_rx_desc *rx_descs;
    struct e1000_tx_desc *tx_descs;
    uint8_t *rx_buffers[E1000_RX_DESC_COUNT];
    uint8_t *tx_buffers[E1000_TX_DESC_COUNT];
    uint16_t rx_cur;
};

int e1000_init(struct e1000_device *dev);
int e1000_send(struct e1000_device *dev, const void *data, size_t len);
int e1000_recv(struct e1000_device *dev, void *buf, size_t buf_sz, size_t *out_len);
void e1000_update_link(struct e1000_device *dev);
