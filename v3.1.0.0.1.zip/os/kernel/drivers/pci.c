#include "drivers/pci.h"
#include "lib/printf.h"

static struct pci_device pci_devices[MAX_PCI_DEVICES];
static int pci_device_count = 0;

uint32_t pci_read(uint8_t bus, uint8_t slot, uint8_t func, uint8_t offset) {
    uint32_t addr = (1u << 31) |
                    ((uint32_t)bus << 16) |
                    ((uint32_t)slot << 11) |
                    ((uint32_t)func << 8) |
                    (offset & 0xFC);
    outl(PCI_CONFIG_ADDR, addr);
    return inl(PCI_CONFIG_DATA);
}

void pci_write(uint8_t bus, uint8_t slot, uint8_t func, uint8_t offset, uint32_t val) {
    uint32_t addr = (1u << 31) |
                    ((uint32_t)bus << 16) |
                    ((uint32_t)slot << 11) |
                    ((uint32_t)func << 8) |
                    (offset & 0xFC);
    outl(PCI_CONFIG_ADDR, addr);
    outl(PCI_CONFIG_DATA, val);
}

static void pci_scan_device(uint8_t bus, uint8_t slot, uint8_t func) {
    uint32_t reg0 = pci_read(bus, slot, func, 0);
    uint16_t vendor = reg0 & 0xFFFF;
    uint16_t device = (reg0 >> 16) & 0xFFFF;

    if (vendor == 0xFFFF) return;
    if (pci_device_count >= MAX_PCI_DEVICES) return;

    struct pci_device *dev = &pci_devices[pci_device_count];
    dev->bus = bus;
    dev->slot = slot;
    dev->func = func;
    dev->vendor_id = vendor;
    dev->device_id = device;

    uint32_t reg2 = pci_read(bus, slot, func, 0x08);
    dev->class_code = (reg2 >> 24) & 0xFF;
    dev->subclass   = (reg2 >> 16) & 0xFF;
    dev->prog_if    = (reg2 >> 8) & 0xFF;

    uint32_t reg3 = pci_read(bus, slot, func, 0x0C);
    dev->header_type = (reg3 >> 16) & 0xFF;

    // Read BARs for type 0 header
    if ((dev->header_type & 0x7F) == 0) {
        for (int i = 0; i < 6; i++) {
            dev->bar[i] = pci_read(bus, slot, func, 0x10 + i * 4);
        }
    }

    pci_device_count++;
}

void pci_init(void) {
    pci_device_count = 0;

    for (int bus = 0; bus < 256; bus++) {
        for (int slot = 0; slot < 32; slot++) {
            uint32_t reg0 = pci_read(bus, slot, 0, 0);
            if ((reg0 & 0xFFFF) == 0xFFFF) continue;

            pci_scan_device(bus, slot, 0);

            // Check for multi-function device
            uint32_t reg3 = pci_read(bus, slot, 0, 0x0C);
            if ((reg3 >> 16) & 0x80) {
                for (int func = 1; func < 8; func++) {
                    pci_scan_device(bus, slot, func);
                }
            }
        }
    }

    kprintf("PCI: Found %d devices\n", pci_device_count);
    for (int i = 0; i < pci_device_count; i++) {
        struct pci_device *d = &pci_devices[i];
        kprintf("  %02x:%02x.%d - %04x:%04x class %02x:%02x\n",
                d->bus, d->slot, d->func,
                d->vendor_id, d->device_id,
                d->class_code, d->subclass);
    }
}

int pci_get_device_count(void) { return pci_device_count; }
struct pci_device *pci_get_device(int index) {
    if (index < 0 || index >= pci_device_count) return NULL;
    return &pci_devices[index];
}

struct pci_device *pci_find_device(uint16_t vendor, uint16_t device) {
    for (int i = 0; i < pci_device_count; i++) {
        if (pci_devices[i].vendor_id == vendor &&
            pci_devices[i].device_id == device)
            return &pci_devices[i];
    }
    return NULL;
}

struct pci_device *pci_find_class(uint8_t class_code, uint8_t subclass) {
    for (int i = 0; i < pci_device_count; i++) {
        if (pci_devices[i].class_code == class_code &&
            pci_devices[i].subclass == subclass)
            return &pci_devices[i];
    }
    return NULL;
}
