#include "drivers/ata.h"
#include "lib/printf.h"

#define ATA_DATA(base)     (base + 0)
#define ATA_ERROR(base)    (base + 1)
#define ATA_SECT_CNT(base) (base + 2)
#define ATA_LBA_LO(base)   (base + 3)
#define ATA_LBA_MID(base)  (base + 4)
#define ATA_LBA_HI(base)   (base + 5)
#define ATA_DRIVE(base)    (base + 6)
#define ATA_STATUS(base)   (base + 7)
#define ATA_CMD(base)      (base + 7)

#define ATA_STATUS_BSY  0x80
#define ATA_STATUS_DRDY 0x40
#define ATA_STATUS_DRQ  0x08
#define ATA_STATUS_ERR  0x01

#define ATA_CMD_READ     0x20
#define ATA_CMD_WRITE    0x30
#define ATA_CMD_IDENTIFY 0xEC
#define ATA_CMD_FLUSH    0xE7

#define ATA_DRIVE_MASTER 0xA0
#define ATA_DRIVE_SLAVE  0xB0

#define ATA_POLL_MAX 1000000

static uint16_t ata_base = ATA_PRIMARY_IO;
static uint8_t ata_drive = ATA_DRIVE_MASTER;
static int ata_present = 0;

static int ata_wait_not_bsy_base(uint16_t base) {
    for (int i = 0; i < ATA_POLL_MAX; i++) {
        uint8_t status = inb(ATA_STATUS(base));
        if (!(status & ATA_STATUS_BSY)) {
            return (status & ATA_STATUS_ERR) ? -1 : 0;
        }
    }
    return -1;
}

static int ata_wait_drq_base(uint16_t base) {
    for (int i = 0; i < ATA_POLL_MAX; i++) {
        uint8_t status = inb(ATA_STATUS(base));
        if (status & ATA_STATUS_ERR) return -1;
        if (!(status & ATA_STATUS_BSY) && (status & ATA_STATUS_DRQ)) return 0;
    }
    return -1;
}

static int ata_wait_ready_base(uint16_t base) {
    for (int i = 0; i < ATA_POLL_MAX; i++) {
        uint8_t status = inb(ATA_STATUS(base));
        if (status & ATA_STATUS_ERR) return -1;
        if (!(status & ATA_STATUS_BSY) && (status & ATA_STATUS_DRDY)) return 0;
    }
    return -1;
}

static void ata_soft_reset(uint16_t ctrl) {
    outb(ctrl, 0x04);
    io_wait();
    io_wait();
    io_wait();
    io_wait();
    outb(ctrl, 0x00);
}

static int ata_identify_candidate(uint16_t base, uint16_t ctrl, uint8_t drive, uint32_t *sectors_out) {
    ata_soft_reset(ctrl);

    outb(ATA_DRIVE(base), drive);
    io_wait();

    uint8_t status = inb(ATA_STATUS(base));
    if (status == 0x00 || status == 0xFF) {
        return -1;
    }

    outb(ATA_SECT_CNT(base), 0);
    outb(ATA_LBA_LO(base), 0);
    outb(ATA_LBA_MID(base), 0);
    outb(ATA_LBA_HI(base), 0);
    outb(ATA_CMD(base), ATA_CMD_IDENTIFY);

    status = inb(ATA_STATUS(base));
    if (status == 0x00 || status == 0xFF) {
        return -1;
    }

    if (ata_wait_not_bsy_base(base) < 0) {
        return -1;
    }

    // Non-zero MID/HI identifies non-ATA devices (ATAPI/SATA bridge in legacy mode).
    if (inb(ATA_LBA_MID(base)) || inb(ATA_LBA_HI(base))) {
        return -1;
    }

    if (ata_wait_drq_base(base) < 0) {
        return -1;
    }

    uint16_t identify[256];
    for (int i = 0; i < 256; i++) {
        identify[i] = inw(ATA_DATA(base));
    }

    if (sectors_out) {
        *sectors_out = identify[60] | ((uint32_t)identify[61] << 16);
    }
    return 0;
}

static uint8_t ata_lba_drive_bits(uint32_t lba) {
    uint8_t drive_bit = (ata_drive == ATA_DRIVE_SLAVE) ? 0x10 : 0x00;
    return (uint8_t)(0xE0 | drive_bit | ((lba >> 24) & 0x0F));
}

void ata_init(void) {
    const struct {
        uint16_t base;
        uint16_t ctrl;
        uint8_t drive;
        const char *name;
    } candidates[] = {
        {ATA_PRIMARY_IO, ATA_PRIMARY_CTRL, ATA_DRIVE_MASTER, "primary master"},
        {ATA_PRIMARY_IO, ATA_PRIMARY_CTRL, ATA_DRIVE_SLAVE,  "primary slave"},
        {ATA_SECONDARY_IO, ATA_SECONDARY_CTRL, ATA_DRIVE_MASTER, "secondary master"},
        {ATA_SECONDARY_IO, ATA_SECONDARY_CTRL, ATA_DRIVE_SLAVE,  "secondary slave"},
    };

    for (size_t i = 0; i < sizeof(candidates) / sizeof(candidates[0]); i++) {
        uint32_t sectors = 0;
        if (ata_identify_candidate(candidates[i].base, candidates[i].ctrl,
                                   candidates[i].drive, &sectors) < 0) {
            continue;
        }

        ata_base = candidates[i].base;
        ata_drive = candidates[i].drive;
        ata_present = 1;

        kprintf("ATA: Drive found on %s, %u sectors (%u MB)\n",
                candidates[i].name,
                (unsigned)sectors,
                (unsigned)(sectors / 2048));
        return;
    }

    kprintf("ATA: No legacy IDE drive detected (primary/secondary, master/slave)\n");
    kprintf("ATA: VirtualBox tip: attach disk to an IDE controller (PIIX3/PIIX4).\n");
}

int ata_read_sectors(uint32_t lba, uint8_t count, void *buf) {
    if (!ata_present) return -1;
    if (count == 0) return 0;

    if (ata_wait_not_bsy_base(ata_base) < 0) return -1;

    outb(ATA_DRIVE(ata_base), ata_lba_drive_bits(lba));
    outb(ATA_SECT_CNT(ata_base), count);
    outb(ATA_LBA_LO(ata_base), lba & 0xFF);
    outb(ATA_LBA_MID(ata_base), (lba >> 8) & 0xFF);
    outb(ATA_LBA_HI(ata_base), (lba >> 16) & 0xFF);
    outb(ATA_CMD(ata_base), ATA_CMD_READ);

    uint16_t *ptr = (uint16_t *)buf;
    for (int s = 0; s < count; s++) {
        if (ata_wait_not_bsy_base(ata_base) < 0) return -1;
        if (ata_wait_ready_base(ata_base) < 0) return -1;
        if (ata_wait_drq_base(ata_base) < 0) return -1;

        for (int i = 0; i < 256; i++) {
            *ptr++ = inw(ATA_DATA(ata_base));
        }

        // 400ns delay (status port reads).
        (void)inb(ATA_STATUS(ata_base));
        (void)inb(ATA_STATUS(ata_base));
        (void)inb(ATA_STATUS(ata_base));
        (void)inb(ATA_STATUS(ata_base));
    }
    return 0;
}

int ata_write_sectors(uint32_t lba, uint8_t count, const void *buf) {
    if (!ata_present) return -1;
    if (count == 0) return 0;

    if (ata_wait_not_bsy_base(ata_base) < 0) return -1;

    outb(ATA_DRIVE(ata_base), ata_lba_drive_bits(lba));
    outb(ATA_SECT_CNT(ata_base), count);
    outb(ATA_LBA_LO(ata_base), lba & 0xFF);
    outb(ATA_LBA_MID(ata_base), (lba >> 8) & 0xFF);
    outb(ATA_LBA_HI(ata_base), (lba >> 16) & 0xFF);
    outb(ATA_CMD(ata_base), ATA_CMD_WRITE);

    const uint16_t *ptr = (const uint16_t *)buf;
    for (int s = 0; s < count; s++) {
        if (ata_wait_not_bsy_base(ata_base) < 0) return -1;
        if (ata_wait_drq_base(ata_base) < 0) return -1;

        for (int i = 0; i < 256; i++) {
            outw(ATA_DATA(ata_base), *ptr++);
        }

        (void)inb(ATA_STATUS(ata_base));
        (void)inb(ATA_STATUS(ata_base));
        (void)inb(ATA_STATUS(ata_base));
        (void)inb(ATA_STATUS(ata_base));
    }

    outb(ATA_CMD(ata_base), ATA_CMD_FLUSH);
    if (ata_wait_not_bsy_base(ata_base) < 0) return -1;
    return 0;
}
