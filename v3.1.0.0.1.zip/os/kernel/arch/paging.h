#pragma once
#include "include/types.h"

#define PTE_PRESENT     (1ULL << 0)
#define PTE_WRITABLE    (1ULL << 1)
#define PTE_USER        (1ULL << 2)
#define PTE_WRITETHROUGH (1ULL << 3)
#define PTE_NOCACHE     (1ULL << 4)
#define PTE_ACCESSED    (1ULL << 5)
#define PTE_DIRTY       (1ULL << 6)
#define PTE_HUGE        (1ULL << 7)
#define PTE_GLOBAL      (1ULL << 8)
#define PTE_NX          (1ULL << 63)

#define PTE_ADDR_MASK   0x000FFFFFFFFFF000ULL

#define PML4_INDEX(va) (((va) >> 39) & 0x1FF)
#define PDPT_INDEX(va) (((va) >> 30) & 0x1FF)
#define PD_INDEX(va)   (((va) >> 21) & 0x1FF)
#define PT_INDEX(va)   (((va) >> 12) & 0x1FF)

typedef uint64_t page_table_t[512] ALIGNED(PAGE_SIZE);

// Initialize kernel paging (called after PMM is ready)
void paging_init(void);

// Map a virtual page to a physical frame
void paging_map_page(uint64_t *pml4, uint64_t virt, uint64_t phys, uint64_t flags);

// Unmap a virtual page
void paging_unmap_page(uint64_t *pml4, uint64_t virt);

// Get physical address for a virtual address (returns 0 if unmapped)
uint64_t paging_get_phys(uint64_t *pml4, uint64_t virt);

// Create a new PML4 for a user process (copies kernel mappings)
uint64_t *paging_create_address_space(void);

// Destroy a user address space
void paging_destroy_address_space(uint64_t *pml4);

// Switch to a different address space
void paging_switch(uint64_t *pml4);

// Get kernel PML4
uint64_t *paging_get_kernel_pml4(void);
