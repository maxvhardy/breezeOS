#pragma once
#include "include/types.h"

#define IDT_ENTRIES 256

// IDT gate types
#define IDT_GATE_INT  0x8E  // Present, ring 0, interrupt gate
#define IDT_GATE_TRAP 0x8F  // Present, ring 0, trap gate
#define IDT_GATE_USER 0xEE  // Present, ring 3, interrupt gate (for syscalls)

struct idt_entry {
    uint16_t offset_low;
    uint16_t selector;
    uint8_t  ist;
    uint8_t  type_attr;
    uint16_t offset_mid;
    uint32_t offset_high;
    uint32_t reserved;
} PACKED;

struct idt_ptr {
    uint16_t limit;
    uint64_t base;
} PACKED;

// Register state pushed by ISR stubs
struct registers {
    uint64_t ds;
    uint64_t r15, r14, r13, r12, r11, r10, r9, r8;
    uint64_t rbp, rdi, rsi, rdx, rcx, rbx, rax;
    uint64_t int_no, err_code;
    uint64_t rip, cs, rflags, rsp, ss;
} PACKED;

typedef void (*isr_handler_t)(struct registers *regs);

void idt_init(void);
void idt_set_gate(uint8_t num, uint64_t handler, uint16_t sel, uint8_t flags);
void isr_register_handler(uint8_t num, isr_handler_t handler);
