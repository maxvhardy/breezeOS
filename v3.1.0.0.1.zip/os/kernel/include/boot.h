#pragma once
#include "types.h"

#define BOOT_MAGIC      0xB007B007
#define BOOT_INFO_ADDR  0x1000
#define E820_MAP_ADDR   0x1100
#define MAX_E820        64

struct e820_entry {
    uint64_t base;
    uint64_t length;
    uint32_t type;
    uint32_t acpi;
} PACKED;

#define E820_USABLE     1
#define E820_RESERVED   2
#define E820_ACPI_RECL  3
#define E820_ACPI_NVS   4
#define E820_BAD        5

struct boot_info {
    uint32_t magic;
    uint32_t fb_addr_low;
    uint32_t fb_addr_high;
    uint32_t fb_width;
    uint32_t fb_height;
    uint32_t fb_pitch;
    uint32_t fb_bpp;
    uint32_t mmap_count;
    uint32_t mmap_addr;
    uint32_t boot_drive;
    uint32_t fs_start_lba;
    uint32_t vbe_available;
} PACKED;
