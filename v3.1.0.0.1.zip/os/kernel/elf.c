#include "elf.h"
#include "fs/vfs.h"
#include "mm/vmm.h"
#include "mm/heap.h"
#include "arch/paging.h"
#include "lib/string.h"
#include "lib/printf.h"

int elf_load(struct process *proc, const char *path, uint64_t *entry_point) {
    const uint64_t user_virt_top = 0x0000800000000000ULL;

    struct vfs_node *file = vfs_open(path, O_RDONLY);
    if (!file) return -1;

    // Read ELF header
    struct elf64_header ehdr;
    if (vfs_read(file, &ehdr, sizeof(ehdr)) != sizeof(ehdr)) {
        vfs_close(file);
        return -1;
    }

    // Validate ELF
    if (ehdr.magic != ELF_MAGIC || ehdr.class != 2 ||
        ehdr.machine != EM_X86_64 || ehdr.type != ET_EXEC) {
        vfs_close(file);
        return -1;
    }

    // Read and process program headers
    for (int i = 0; i < ehdr.phnum; i++) {
        struct elf64_phdr phdr;
        vfs_lseek(file, ehdr.phoff + i * ehdr.phentsize, SEEK_SET);
        if (vfs_read(file, &phdr, sizeof(phdr)) != sizeof(phdr)) {
            vfs_close(file);
            return -1;
        }

        if (phdr.type != PT_LOAD) continue;
        if (phdr.memsz == 0) continue;
        if (phdr.filesz > phdr.memsz) {
            vfs_close(file);
            return -1;
        }
        if (phdr.vaddr >= user_virt_top) {
            vfs_close(file);
            return -1;
        }
        if (phdr.memsz > user_virt_top - phdr.vaddr) {
            vfs_close(file);
            return -1;
        }

        // Map pages for this segment
        uint64_t vaddr_start = phdr.vaddr & ~(PAGE_SIZE - 1);
        uint64_t vaddr_end = (phdr.vaddr + phdr.memsz + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1);

        uint64_t flags = PTE_PRESENT | PTE_USER;
        if (phdr.flags & 2) flags |= PTE_WRITABLE; // PF_W

        for (uint64_t va = vaddr_start; va < vaddr_end; va += PAGE_SIZE) {
            if (paging_get_phys(proc->pml4, va)) continue;
            if (vmm_map_user_page(proc->pml4, va, flags) < 0) {
                vfs_close(file);
                return -1;
            }
        }

        // Read segment data via physical addresses
        // (we can access any physical page through PHYS_TO_VIRT)
        vfs_lseek(file, phdr.offset, SEEK_SET);

        size_t remaining = phdr.filesz;
        uint64_t dst_va = phdr.vaddr;

        while (remaining > 0) {
            // Get physical page for this virtual address
            uint64_t phys = paging_get_phys(proc->pml4, dst_va & ~(PAGE_SIZE - 1));
            if (!phys) break;

            uint64_t page_offset = dst_va & (PAGE_SIZE - 1);
            size_t to_read = PAGE_SIZE - page_offset;
            if (to_read > remaining) to_read = remaining;

            uint8_t *dest = (uint8_t *)PHYS_TO_VIRT(phys) + page_offset;
            if (vfs_read(file, dest, to_read) != (ssize_t)to_read) {
                vfs_close(file);
                return -1;
            }

            dst_va += to_read;
            remaining -= to_read;
        }

        // Zero BSS (memsz > filesz)
        if (phdr.memsz > phdr.filesz) {
            size_t bss_size = phdr.memsz - phdr.filesz;
            dst_va = phdr.vaddr + phdr.filesz;

            while (bss_size > 0) {
                uint64_t phys = paging_get_phys(proc->pml4, dst_va & ~(PAGE_SIZE - 1));
                if (!phys) break;

                uint64_t page_offset = dst_va & (PAGE_SIZE - 1);
                size_t to_zero = PAGE_SIZE - page_offset;
                if (to_zero > bss_size) to_zero = bss_size;

                memset((uint8_t *)PHYS_TO_VIRT(phys) + page_offset, 0, to_zero);

                dst_va += to_zero;
                bss_size -= to_zero;
            }
        }
    }

    *entry_point = ehdr.entry;
    if (*entry_point >= user_virt_top) {
        vfs_close(file);
        return -1;
    }
    vfs_close(file);
    return 0;
}
