// DoorOS video/input backend for the official id Software DOOM source.

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "d_main.h"
#include "doomdef.h"
#include "i_system.h"
#include "v_video.h"

struct gui_event {
    uint32_t type;
    uint32_t window_id;
    int32_t x;
    int32_t y;
    uint32_t keycode;
    uint32_t buttons;
};

#define GUI_EVENT_KEY_PRESS    1
#define GUI_EVENT_KEY_RELEASE  2
#define GUI_EVENT_MOUSE_MOVE   3
#define GUI_EVENT_MOUSE_DOWN   4
#define GUI_EVENT_MOUSE_UP     5
#define GUI_EVENT_WIN_CLOSE    6

static int g_window_id = -1;
static uint32_t g_palette[256];
static uint32_t g_pixels[SCREENWIDTH * SCREENHEIGHT];
static int g_mouse_inited = 0;
static int g_last_mouse_x = 0;
static int g_last_mouse_y = 0;

static int win_create(int x, int y, int w, int h, const char *title) {
    return (int)syscall5(SYS_WIN_CREATE,
                         (uint64_t)x, (uint64_t)y,
                         (uint64_t)w, (uint64_t)h,
                         (uint64_t)title);
}

static void win_destroy(int wid) {
    syscall1(SYS_WIN_DESTROY, (uint64_t)wid);
}

static int win_update(int wid, uint32_t *pixels) {
    return (int)syscall2(SYS_WIN_UPDATE, (uint64_t)wid, (uint64_t)pixels);
}

static int win_event(struct gui_event *ev) {
    return (int)syscall1(SYS_WIN_EVENT, (uint64_t)ev);
}

static void post_key_event(evtype_t type, int key) {
    event_t ev;
    ev.type = type;
    ev.data1 = key;
    ev.data2 = 0;
    ev.data3 = 0;
    D_PostEvent(&ev);
}

static int map_key(uint32_t keycode) {
    int c = (int)(unsigned char)keycode;

    if (c >= 'A' && c <= 'Z') {
        c = c - 'A' + 'a';
    }

    switch (c) {
        case 27:      return KEY_ESCAPE;
        case '\r':
        case '\n':    return KEY_ENTER;
        case '\t':    return KEY_TAB;
        case '\b':
        case 127:     return KEY_BACKSPACE;
        case '=':     return KEY_EQUALS;
        case '-':     return KEY_MINUS;

        // Convenience mappings for the current DoorOS keyboard input model.
        case 'w':     return KEY_UPARROW;
        case 's':     return KEY_DOWNARROW;
        case 'a':     return KEY_LEFTARROW;
        case 'd':     return KEY_RIGHTARROW;
        case 'q':     return ',';
        case 'e':     return '.';
        case 'f':     return KEY_RCTRL;

        default:
            return c;
    }
}

static void post_mouse_event(uint32_t buttons, int dx, int dy) {
    event_t ev;
    ev.type = ev_mouse;
    ev.data1 = (int)(buttons & 0x7);
    ev.data2 = dx;
    ev.data3 = dy;
    D_PostEvent(&ev);
}

static void pump_events(void) {
    struct gui_event ev;
    int guard = 0;

    while (guard++ < 256 && win_event(&ev) == 1) {
        int mapped;

        if ((int)ev.window_id != g_window_id) {
            continue;
        }

        if (ev.type == GUI_EVENT_WIN_CLOSE) {
            I_Quit();
            return;
        }

        if (ev.type == GUI_EVENT_KEY_PRESS) {
            mapped = map_key(ev.keycode);
            if (mapped != 0) {
                // DoorOS currently emits key-press events only.
                post_key_event(ev_keydown, mapped);
                post_key_event(ev_keyup, mapped);
            }
            continue;
        }

        if (ev.type == GUI_EVENT_KEY_RELEASE) {
            mapped = map_key(ev.keycode);
            if (mapped != 0) {
                post_key_event(ev_keyup, mapped);
            }
            continue;
        }

        if (ev.type == GUI_EVENT_MOUSE_DOWN || ev.type == GUI_EVENT_MOUSE_UP) {
            post_mouse_event(ev.buttons, 0, 0);
            continue;
        }

        if (ev.type == GUI_EVENT_MOUSE_MOVE) {
            int dx = 0;
            int dy = 0;

            if (g_mouse_inited) {
                dx = (ev.x - g_last_mouse_x) << 2;
                dy = (g_last_mouse_y - ev.y) << 2;
            } else {
                g_mouse_inited = 1;
            }

            g_last_mouse_x = ev.x;
            g_last_mouse_y = ev.y;

            if (dx != 0 || dy != 0) {
                post_mouse_event(ev.buttons, dx, dy);
            }
        }
    }
}

void I_StartFrame(void) {
}

void I_StartTic(void) {
    if (g_window_id < 0) {
        return;
    }

    pump_events();
    yield();
}

void I_UpdateNoBlit(void) {
}

void I_FinishUpdate(void) {
    byte *src;
    int i;

    if (g_window_id < 0 || !screens[0]) {
        return;
    }

    src = screens[0];
    for (i = 0; i < SCREENWIDTH * SCREENHEIGHT; i++) {
        g_pixels[i] = g_palette[src[i]];
    }

    win_update(g_window_id, g_pixels);
    pump_events();
    yield();
}

void I_ReadScreen(byte *scr) {
    if (!scr || !screens[0]) {
        return;
    }

    memcpy(scr, screens[0], SCREENWIDTH * SCREENHEIGHT);
}

void I_SetPalette(byte *palette) {
    int i;

    if (!palette) {
        return;
    }

    for (i = 0; i < 256; i++) {
        int r = gammatable[usegamma][*palette++];
        int g = gammatable[usegamma][*palette++];
        int b = gammatable[usegamma][*palette++];
        g_palette[i] = ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
    }
}

void I_InitGraphics(void) {
    int i;

    if (g_window_id >= 0) {
        return;
    }

    for (i = 0; i < 256; i++) {
        g_palette[i] = ((uint32_t)i << 16) | ((uint32_t)i << 8) | (uint32_t)i;
    }

    g_window_id = win_create(44, 26, SCREENWIDTH, SCREENHEIGHT, "DOOM - DoorOS");
    if (g_window_id < 0) {
        I_Error("doom: failed to create video window");
    }

    g_mouse_inited = 0;
    g_last_mouse_x = 0;
    g_last_mouse_y = 0;
}

void I_ShutdownGraphics(void) {
    if (g_window_id >= 0) {
        win_destroy(g_window_id);
        g_window_id = -1;
    }
}
