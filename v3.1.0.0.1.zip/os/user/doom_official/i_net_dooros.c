#include <stdlib.h>
#include <string.h>

#include "d_net.h"
#include "doomstat.h"
#include "i_net.h"

void I_InitNetwork(void) {
    doomcom = (doomcom_t *)malloc(sizeof(*doomcom));
    if (!doomcom) {
        netgame = false;
        return;
    }

    memset(doomcom, 0, sizeof(*doomcom));
    doomcom->id = DOOMCOM_ID;
    doomcom->numplayers = 1;
    doomcom->numnodes = 1;
    doomcom->consoleplayer = 0;
    doomcom->ticdup = 1;
    doomcom->extratics = 0;
    doomcom->deathmatch = 0;
    doomcom->remotenode = -1;
    netgame = false;
}

void I_NetCmd(void) {
    if (doomcom) {
        doomcom->remotenode = -1;
    }
}
