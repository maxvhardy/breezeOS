#pragma once

typedef unsigned char       uint8_t;
typedef unsigned short      uint16_t;
typedef unsigned int        uint32_t;
typedef unsigned long long  uint64_t;
typedef signed int          int32_t;
typedef signed long long    int64_t;
typedef unsigned long long  size_t;
typedef signed long long    ssize_t;

#define NULL ((void*)0)

// System call numbers (must match kernel/arch/syscall.h)
#define SYS_EXIT        0
#define SYS_WRITE       1
#define SYS_READ        2
#define SYS_OPEN        3
#define SYS_CLOSE       4
#define SYS_FORK        5
#define SYS_EXEC        6
#define SYS_WAITPID     7
#define SYS_GETPID      8
#define SYS_SBRK        9
#define SYS_MKDIR       10
#define SYS_RMDIR       11
#define SYS_UNLINK      12
#define SYS_CHDIR       13
#define SYS_GETCWD      14
#define SYS_READDIR     15
#define SYS_STAT        16
#define SYS_YIELD       17
#define SYS_SLEEP       18
#define SYS_GETFB       19
#define SYS_WIN_CREATE  20
#define SYS_WIN_DESTROY 21
#define SYS_WIN_UPDATE  22
#define SYS_WIN_EVENT   23
#define SYS_DUP2        24
#define SYS_PIPE        25
#define SYS_LSEEK       26
#define SYS_FSTAT       27
#define SYS_TICKS       28
#define SYS_KILL        29
#define SYS_GETPPID     30
#define SYS_RENAME      31
#define SYS_TRUNCATE    32
#define SYS_GETPRIO     33
#define SYS_SETPRIO     34

// Assembly syscall wrappers
extern int64_t syscall0(uint64_t num);
extern int64_t syscall1(uint64_t num, uint64_t a1);
extern int64_t syscall2(uint64_t num, uint64_t a1, uint64_t a2);
extern int64_t syscall3(uint64_t num, uint64_t a1, uint64_t a2, uint64_t a3);
extern int64_t syscall4(uint64_t num, uint64_t a1, uint64_t a2, uint64_t a3, uint64_t a4);
extern int64_t syscall5(uint64_t num, uint64_t a1, uint64_t a2, uint64_t a3, uint64_t a4, uint64_t a5);
