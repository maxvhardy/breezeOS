#pragma once

#include "../syscall.h"

typedef int64_t off_t;
typedef int mode_t;
