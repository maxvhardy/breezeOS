#include "stdlib.h"
#include "string.h"

#define ALLOC_MAGIC 0xBEEFBEEF

struct alloc_header {
    uint32_t magic;
    uint32_t _pad;
    size_t size;
};

static void *heap_ptr = NULL;
static void *heap_end = NULL;

#define ATEXIT_MAX 64
static void (*atexit_handlers[ATEXIT_MAX])(void);
static int atexit_count = 0;

static size_t align_up_16(size_t size) {
    return (size + 15ULL) & ~15ULL;
}

void exit(int code) {
    for (int i = atexit_count - 1; i >= 0; i--) {
        if (atexit_handlers[i]) {
            atexit_handlers[i]();
        }
    }

    syscall1(SYS_EXIT, (uint64_t)code);
    while (1) {
    }
}

int fork(void) {
    return (int)syscall0(SYS_FORK);
}

int exec(const char *path) {
    return (int)syscall1(SYS_EXEC, (uint64_t)path);
}

int waitpid(int pid, int *status) {
    return (int)syscall2(SYS_WAITPID, (uint64_t)pid, (uint64_t)status);
}

int getpid(void) {
    return (int)syscall0(SYS_GETPID);
}

void *sbrk(int64_t incr) {
    int64_t result = syscall1(SYS_SBRK, (uint64_t)incr);
    if (result < 0) return NULL;
    return (void *)(uint64_t)result;
}

void yield(void) {
    syscall0(SYS_YIELD);
}

void sleep(uint64_t ms) {
    syscall1(SYS_SLEEP, ms);
}

int getppid(void) {
    return (int)syscall0(SYS_GETPPID);
}

int64_t ticks(void) {
    return syscall0(SYS_TICKS);
}

int kill(int pid, int sig) {
    return (int)syscall2(SYS_KILL, (uint64_t)pid, (uint64_t)sig);
}

int pipe(int fds[2]) {
    return (int)syscall1(SYS_PIPE, (uint64_t)fds);
}

int dup2(int oldfd, int newfd) {
    return (int)syscall2(SYS_DUP2, (uint64_t)oldfd, (uint64_t)newfd);
}

int truncate(const char *path, uint32_t length) {
    return (int)syscall2(SYS_TRUNCATE, (uint64_t)path, (uint64_t)length);
}

void *malloc(size_t size) {
    if (size == 0) size = 1;

    size_t payload = align_up_16(size);
    size_t total = payload + sizeof(struct alloc_header);

    if (!heap_ptr) {
        heap_ptr = sbrk(0);
        heap_end = heap_ptr;
    }

    if ((uint8_t *)heap_ptr + total > (uint8_t *)heap_end) {
        size_t grow = total;
        if (grow < 4096) grow = 4096;
        void *old_end = sbrk((int64_t)grow);
        if (!old_end) return NULL;
        heap_end = (uint8_t *)heap_end + grow;
    }

    struct alloc_header *hdr = (struct alloc_header *)heap_ptr;
    hdr->magic = ALLOC_MAGIC;
    hdr->_pad = 0;
    hdr->size = payload;

    heap_ptr = (uint8_t *)heap_ptr + total;
    return (void *)(hdr + 1);
}

void free(void *ptr) {
    (void)ptr;
}

void *calloc(size_t nmemb, size_t size) {
    if (nmemb == 0 || size == 0) return malloc(1);
    size_t total = nmemb * size;
    void *p = malloc(total);
    if (!p) return NULL;
    memset(p, 0, total);
    return p;
}

void *realloc(void *ptr, size_t size) {
    if (!ptr) return malloc(size);
    if (size == 0) {
        free(ptr);
        return NULL;
    }

    struct alloc_header *hdr = ((struct alloc_header *)ptr) - 1;
    size_t old_size = 0;
    if (hdr->magic == ALLOC_MAGIC) {
        old_size = hdr->size;
    }

    void *n = malloc(size);
    if (!n) return NULL;

    size_t copy = old_size;
    if (copy > size) copy = size;
    if (copy > 0) {
        memcpy(n, ptr, copy);
    }

    free(ptr);
    return n;
}

void *alloca(size_t size) {
    return malloc(size);
}

int abs(int v) {
    return v < 0 ? -v : v;
}

long labs(long v) {
    return v < 0 ? -v : v;
}

static int is_space(char c) {
    return c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f' || c == '\v';
}

double atof(const char *s) {
    if (!s) return 0.0;

    while (is_space(*s)) s++;

    int sign = 1;
    if (*s == '-') {
        sign = -1;
        s++;
    } else if (*s == '+') {
        s++;
    }

    double value = 0.0;
    while (*s >= '0' && *s <= '9') {
        value = value * 10.0 + (double)(*s - '0');
        s++;
    }

    if (*s == '.') {
        s++;
        double scale = 1.0;
        while (*s >= '0' && *s <= '9') {
            scale *= 10.0;
            value += (double)(*s - '0') / scale;
            s++;
        }
    }

    return sign < 0 ? -value : value;
}

char *getenv(const char *name) {
    (void)name;
    return NULL;
}

int putenv(char *string) {
    (void)string;
    return 0;
}

int system(const char *command) {
    (void)command;
    return -1;
}

void abort(void) {
    exit(1);
}

int atexit(void (*func)(void)) {
    if (atexit_count >= ATEXIT_MAX) return -1;
    atexit_handlers[atexit_count++] = func;
    return 0;
}
