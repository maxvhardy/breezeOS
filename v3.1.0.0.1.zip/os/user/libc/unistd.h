#pragma once

#include "stdio.h"
#include "stdlib.h"

int open(const char *path, int flags, ...);
int close(int fd);

int usleep(unsigned int usec);
unsigned int sleep_seconds(unsigned int seconds);
