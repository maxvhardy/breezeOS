#include "stdio.h"
#include "stdlib.h"
#include "string.h"

#define FILE_FLAG_READ  0x1
#define FILE_FLAG_WRITE 0x2

FILE __stdin_file = { .fd = STDIN_FILENO, .eof = 0, .err = 0, .ungot = -1, .flags = FILE_FLAG_READ };
FILE __stdout_file = { .fd = STDOUT_FILENO, .eof = 0, .err = 0, .ungot = -1, .flags = FILE_FLAG_WRITE };
FILE __stderr_file = { .fd = STDERR_FILENO, .eof = 0, .err = 0, .ungot = -1, .flags = FILE_FLAG_WRITE };

ssize_t write(int fd, const void *buf, size_t count) {
    return (ssize_t)syscall3(SYS_WRITE, (uint64_t)fd, (uint64_t)buf, (uint64_t)count);
}

ssize_t read(int fd, void *buf, size_t count) {
    return (ssize_t)syscall3(SYS_READ, (uint64_t)fd, (uint64_t)buf, (uint64_t)count);
}

int open(const char *path, int flags, ...) {
    return (int)syscall3(SYS_OPEN, 0, (uint64_t)path, (uint64_t)flags);
}

int close(int fd) {
    return (int)syscall1(SYS_CLOSE, (uint64_t)fd);
}

int64_t lseek(int fd, int64_t offset, int whence) {
    return syscall3(SYS_LSEEK, (uint64_t)fd, (uint64_t)offset, (uint64_t)whence);
}

int readdir(int fd, struct dirent *entry) {
    return (int)syscall2(SYS_READDIR, (uint64_t)fd, (uint64_t)entry);
}

int stat(const char *path, struct stat *st) {
    return (int)syscall2(SYS_STAT, (uint64_t)path, (uint64_t)st);
}

int fstat(int fd, struct stat *st) {
    return (int)syscall2(SYS_FSTAT, (uint64_t)fd, (uint64_t)st);
}

int mkdir(const char *path, ...) {
    return (int)syscall1(SYS_MKDIR, (uint64_t)path);
}

int rmdir(const char *path) {
    return (int)syscall1(SYS_RMDIR, (uint64_t)path);
}

int unlink(const char *path) {
    return (int)syscall1(SYS_UNLINK, (uint64_t)path);
}

int chdir(const char *path) {
    return (int)syscall1(SYS_CHDIR, (uint64_t)path);
}

char *getcwd(char *buf, size_t size) {
    int64_t result = syscall2(SYS_GETCWD, (uint64_t)buf, (uint64_t)size);
    return result >= 0 ? buf : NULL;
}

int access(const char *path, int mode) {
    (void)mode;
    struct stat st;
    return stat(path, &st) == 0 ? 0 : -1;
}

static int file_mode_to_flags(const char *mode, int *rwflags) {
    if (!mode || !mode[0]) return -1;

    int flags = 0;
    int rw = 0;

    switch (mode[0]) {
        case 'r':
            flags = O_RDONLY;
            rw |= FILE_FLAG_READ;
            break;
        case 'w':
            flags = O_WRONLY | O_CREAT | O_TRUNC;
            rw |= FILE_FLAG_WRITE;
            break;
        case 'a':
            flags = O_WRONLY | O_CREAT | O_APPEND;
            rw |= FILE_FLAG_WRITE;
            break;
        default:
            return -1;
    }

    for (const char *p = mode + 1; *p; p++) {
        if (*p == '+') {
            flags &= ~(O_RDONLY | O_WRONLY);
            flags |= O_RDWR;
            rw = FILE_FLAG_READ | FILE_FLAG_WRITE;
        }
    }

    *rwflags = rw;
    return flags;
}

FILE *fopen(const char *path, const char *mode) {
    int rw = 0;
    int flags = file_mode_to_flags(mode, &rw);
    if (flags < 0) return NULL;

    int fd = open(path, flags);
    if (fd < 0) return NULL;

    FILE *f = (FILE *)malloc(sizeof(FILE));
    if (!f) {
        close(fd);
        return NULL;
    }

    f->fd = fd;
    f->eof = 0;
    f->err = 0;
    f->ungot = -1;
    f->flags = rw;

    if (mode[0] == 'a') {
        lseek(fd, 0, SEEK_END);
    }

    return f;
}

int fclose(FILE *stream) {
    if (!stream) return -1;

    int rc = 0;
    if (stream != stdin && stream != stdout && stream != stderr) {
        rc = close(stream->fd);
        free(stream);
    }

    return rc;
}

size_t fread(void *ptr, size_t size, size_t nmemb, FILE *stream) {
    if (!stream || !(stream->flags & FILE_FLAG_READ) || size == 0 || nmemb == 0) return 0;
    if (nmemb > ((size_t)-1) / size) {
        stream->err = 1;
        return 0;
    }

    size_t total = size * nmemb;
    size_t done = 0;
    uint8_t *out = (uint8_t *)ptr;

    if (stream->ungot >= 0 && total > 0) {
        out[0] = (uint8_t)stream->ungot;
        stream->ungot = -1;
        done = 1;
    }

    while (done < total) {
        size_t chunk = total - done;
        if (chunk > 4096) chunk = 4096;

        ssize_t n = read(stream->fd, out + done, chunk);
        if (n < 0) {
            stream->err = 1;
            break;
        }
        if (n == 0) {
            stream->eof = 1;
            break;
        }

        done += (size_t)n;
        if ((size_t)n < chunk) {
            stream->eof = 1;
            break;
        }
    }

    return done / size;
}

size_t fwrite(const void *ptr, size_t size, size_t nmemb, FILE *stream) {
    if (!stream || !(stream->flags & FILE_FLAG_WRITE) || size == 0 || nmemb == 0) return 0;

    size_t total = size * nmemb;
    ssize_t n = write(stream->fd, ptr, total);
    if (n < 0) {
        stream->err = 1;
        return 0;
    }

    return (size_t)n / size;
}

int fseek(FILE *stream, long offset, int whence) {
    if (!stream) return -1;
    stream->ungot = -1;
    stream->eof = 0;
    int64_t rc = lseek(stream->fd, (int64_t)offset, whence);
    return rc < 0 ? -1 : 0;
}

long ftell(FILE *stream) {
    if (!stream) return -1;
    int64_t rc = lseek(stream->fd, 0, SEEK_CUR);
    return rc < 0 ? -1 : (long)rc;
}

int fflush(FILE *stream) {
    (void)stream;
    return 0;
}

int feof(FILE *stream) {
    return stream ? stream->eof : 1;
}

int ferror(FILE *stream) {
    return stream ? stream->err : 1;
}

int fgetc(FILE *stream) {
    if (!stream) return EOF;

    if (stream->ungot >= 0) {
        int ch = stream->ungot;
        stream->ungot = -1;
        return ch;
    }

    char ch;
    ssize_t n = read(stream->fd, &ch, 1);
    if (n <= 0) {
        if (n == 0) stream->eof = 1;
        else stream->err = 1;
        return EOF;
    }

    return (unsigned char)ch;
}

int fputc(int c, FILE *stream) {
    if (!stream) return EOF;
    char ch = (char)c;
    ssize_t n = write(stream->fd, &ch, 1);
    if (n != 1) {
        stream->err = 1;
        return EOF;
    }
    return (unsigned char)ch;
}

char *fgets(char *s, int size, FILE *stream) {
    if (!s || size <= 0 || !stream) return NULL;

    int i = 0;
    while (i < size - 1) {
        int c = fgetc(stream);
        if (c == EOF) break;
        s[i++] = (char)c;
        if (c == '\n') break;
    }

    if (i == 0) return NULL;
    s[i] = '\0';
    return s;
}

int ungetc(int c, FILE *stream) {
    if (!stream || c == EOF) return EOF;
    stream->ungot = c & 0xFF;
    stream->eof = 0;
    return c;
}

static int append_char(char *buf, size_t cap, size_t *len, char c) {
    if (*len + 1 < cap) {
        buf[*len] = c;
    }
    (*len)++;
    return 0;
}

static int append_str(char *buf, size_t cap, size_t *len, const char *s, int max_chars) {
    int count = 0;
    while (*s && (max_chars < 0 || count < max_chars)) {
        append_char(buf, cap, len, *s++);
        count++;
    }
    return count;
}

static int utoa_base(uint64_t val, unsigned base, int upper, char *out, int out_sz) {
    char tmp[65];
    int t = 0;

    if (base < 2 || base > 16 || out_sz <= 0) {
        if (out_sz > 0) out[0] = '\0';
        return 0;
    }

    if (val == 0) {
        tmp[t++] = '0';
    } else {
        while (val > 0 && t < (int)sizeof(tmp)) {
            unsigned d = (unsigned)(val % base);
            tmp[t++] = (char)(d < 10 ? ('0' + d) : ((upper ? 'A' : 'a') + (d - 10)));
            val /= base;
        }
    }

    int n = 0;
    while (t > 0 && n < out_sz - 1) {
        out[n++] = tmp[--t];
    }
    out[n] = '\0';
    return n;
}

static int format_float(char *out, int out_sz, double v, int precision) {
    if (precision < 0) precision = 6;
    if (precision > 9) precision = 9;

    char *p = out;
    int remain = out_sz;

    if (remain <= 1) {
        if (out_sz > 0) out[0] = '\0';
        return 0;
    }

    if (v < 0.0) {
        *p++ = '-';
        remain--;
        v = -v;
    }

    uint64_t ip = (uint64_t)v;
    double frac = v - (double)ip;

    char ibuf[32];
    int ilen = utoa_base(ip, 10, 0, ibuf, sizeof(ibuf));
    for (int i = 0; i < ilen && remain > 1; i++) {
        *p++ = ibuf[i];
        remain--;
    }

    if (precision > 0 && remain > 1) {
        *p++ = '.';
        remain--;

        for (int i = 0; i < precision && remain > 1; i++) {
            frac *= 10.0;
            int d = (int)frac;
            if (d < 0) d = 0;
            if (d > 9) d = 9;
            *p++ = (char)('0' + d);
            remain--;
            frac -= (double)d;
        }
    }

    *p = '\0';
    return (int)(p - out);
}

int vsnprintf(char *buf, size_t size, const char *fmt, va_list ap) {
    size_t len = 0;

    if (!buf || size == 0) {
        buf = (char *)"";
        size = 0;
    }

    for (const char *f = fmt; *f; f++) {
        if (*f != '%') {
            append_char(buf, size, &len, *f);
            continue;
        }

        f++;
        if (!*f) break;

        int left = 0;
        int plus = 0;
        int space = 0;
        int zero = 0;
        int alt = 0;

        int parse_flags = 1;
        while (parse_flags) {
            switch (*f) {
                case '-': left = 1; f++; break;
                case '+': plus = 1; f++; break;
                case ' ': space = 1; f++; break;
                case '0': zero = 1; f++; break;
                case '#': alt = 1; f++; break;
                default: parse_flags = 0; break;
            }
        }

        int width = 0;
        while (*f >= '0' && *f <= '9') {
            width = width * 10 + (*f - '0');
            f++;
        }

        int precision = -1;
        if (*f == '.') {
            f++;
            precision = 0;
            while (*f >= '0' && *f <= '9') {
                precision = precision * 10 + (*f - '0');
                f++;
            }
        }

        while (*f == 'l' || *f == 'h' || *f == 'z' || *f == 't') {
            f++;
        }

        char tmp[256];
        tmp[0] = '\0';
        int is_num = 0;
        int has_sign = 0;
        int prefix_len = 0;

        switch (*f) {
            case '%':
                tmp[0] = '%';
                tmp[1] = '\0';
                break;
            case 'd':
            case 'i': {
                is_num = 1;
                int64_t v = (int64_t)va_arg(ap, int);
                uint64_t uv;
                int neg = 0;
                if (v < 0) {
                    neg = 1;
                    uv = (uint64_t)(-v);
                } else {
                    uv = (uint64_t)v;
                }

                char nbuf[64];
                utoa_base(uv, 10, 0, nbuf, sizeof(nbuf));

                if (neg) {
                    tmp[0] = '-';
                    strcpy(tmp + 1, nbuf);
                    has_sign = 1;
                    prefix_len = 1;
                } else if (plus) {
                    tmp[0] = '+';
                    strcpy(tmp + 1, nbuf);
                    has_sign = 1;
                    prefix_len = 1;
                } else if (space) {
                    tmp[0] = ' ';
                    strcpy(tmp + 1, nbuf);
                    has_sign = 1;
                    prefix_len = 1;
                } else {
                    strcpy(tmp, nbuf);
                }
                break;
            }
            case 'u': {
                is_num = 1;
                uint32_t v = va_arg(ap, uint32_t);
                utoa_base(v, 10, 0, tmp, sizeof(tmp));
                break;
            }
            case 'x':
            case 'X': {
                is_num = 1;
                uint32_t v = va_arg(ap, uint32_t);
                int upper = (*f == 'X');
                char nbuf[64];
                utoa_base(v, 16, upper, nbuf, sizeof(nbuf));
                if (alt && v != 0) {
                    tmp[0] = '0';
                    tmp[1] = upper ? 'X' : 'x';
                    strcpy(tmp + 2, nbuf);
                    prefix_len = 2;
                } else {
                    strcpy(tmp, nbuf);
                }
                break;
            }
            case 'p': {
                is_num = 1;
                uint64_t v = (uint64_t)va_arg(ap, void *);
                char nbuf[64];
                utoa_base(v, 16, 0, nbuf, sizeof(nbuf));
                tmp[0] = '0';
                tmp[1] = 'x';
                strcpy(tmp + 2, nbuf);
                prefix_len = 2;
                break;
            }
            case 'c': {
                int c = va_arg(ap, int);
                tmp[0] = (char)c;
                tmp[1] = '\0';
                break;
            }
            case 's': {
                const char *s = va_arg(ap, const char *);
                if (!s) s = "(null)";
                if (precision >= 0) {
                    strncpy(tmp, s, (size_t)precision);
                    tmp[precision < (int)sizeof(tmp) - 1 ? precision : (int)sizeof(tmp) - 1] = '\0';
                } else {
                    strncpy(tmp, s, sizeof(tmp) - 1);
                    tmp[sizeof(tmp) - 1] = '\0';
                }
                break;
            }
            case 'f': {
                double v = va_arg(ap, double);
                format_float(tmp, sizeof(tmp), v, precision);
                is_num = 1;
                if (tmp[0] == '-') {
                    has_sign = 1;
                    prefix_len = 1;
                } else if (plus) {
                    char nbuf[256];
                    strncpy(nbuf, tmp, sizeof(nbuf) - 1);
                    nbuf[sizeof(nbuf) - 1] = '\0';
                    tmp[0] = '+';
                    strncpy(tmp + 1, nbuf, sizeof(tmp) - 2);
                    tmp[sizeof(tmp) - 1] = '\0';
                    has_sign = 1;
                    prefix_len = 1;
                } else if (space) {
                    char nbuf[256];
                    strncpy(nbuf, tmp, sizeof(nbuf) - 1);
                    nbuf[sizeof(nbuf) - 1] = '\0';
                    tmp[0] = ' ';
                    strncpy(tmp + 1, nbuf, sizeof(tmp) - 2);
                    tmp[sizeof(tmp) - 1] = '\0';
                    has_sign = 1;
                    prefix_len = 1;
                }
                break;
            }
            default:
                tmp[0] = '%';
                tmp[1] = *f;
                tmp[2] = '\0';
                break;
        }

        int tlen = (int)strlen(tmp);
        int pad = width > tlen ? width - tlen : 0;

        if (!left) {
            if (zero && is_num && precision < 0 && pad > 0) {
                int prefix_written = 0;
                if (has_sign && prefix_len == 1) {
                    append_char(buf, size, &len, tmp[0]);
                    prefix_written = 1;
                } else if (prefix_len == 2 && tmp[0] == '0' && (tmp[1] == 'x' || tmp[1] == 'X')) {
                    append_char(buf, size, &len, tmp[0]);
                    append_char(buf, size, &len, tmp[1]);
                    prefix_written = 2;
                }
                for (int i = 0; i < pad; i++) append_char(buf, size, &len, '0');
                append_str(buf, size, &len, tmp + prefix_written, -1);
            } else {
                for (int i = 0; i < pad; i++) append_char(buf, size, &len, ' ');
                append_str(buf, size, &len, tmp, -1);
            }
        } else {
            append_str(buf, size, &len, tmp, -1);
            for (int i = 0; i < pad; i++) append_char(buf, size, &len, ' ');
        }
    }

    if (size > 0) {
        size_t pos = (len < size - 1) ? len : (size - 1);
        buf[pos] = '\0';
    }

    return (int)len;
}

int snprintf(char *buf, size_t size, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(buf, size, fmt, ap);
    va_end(ap);
    return n;
}

int sprintf(char *buf, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(buf, (size_t)-1, fmt, ap);
    va_end(ap);
    return n;
}

int vfprintf(FILE *stream, const char *fmt, va_list ap) {
    if (!stream) return -1;

    char out[4096];
    int len = vsnprintf(out, sizeof(out), fmt, ap);
    if (len <= 0) return len;

    size_t to_write = (size_t)len;
    if (to_write > sizeof(out) - 1) to_write = sizeof(out) - 1;

    ssize_t n = write(stream->fd, out, to_write);
    if (n < 0) {
        stream->err = 1;
        return -1;
    }

    return len;
}

int fprintf(FILE *stream, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    int n = vfprintf(stream, fmt, ap);
    va_end(ap);
    return n;
}

int vprintf(const char *fmt, va_list ap) {
    return vfprintf(stdout, fmt, ap);
}

int printf(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    int n = vfprintf(stdout, fmt, ap);
    va_end(ap);
    return n;
}

int putchar(int c) {
    return fputc(c, stdout);
}

int getchar(void) {
    return fgetc(stdin);
}

void setbuf(FILE *stream, char *buf) {
    (void)stream;
    (void)buf;
}

int puts(const char *s) {
    int n = fprintf(stdout, "%s\n", s ? s : "(null)");
    return n < 0 ? EOF : 0;
}

static int is_space(char c) {
    return c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f' || c == '\v';
}

static const char *skip_space(const char *s) {
    while (*s && is_space(*s)) s++;
    return s;
}

static int parse_int(const char **sp, int base, int signed_mode, long long *out) {
    const char *s = *sp;
    int neg = 0;
    unsigned long long v = 0;
    int any = 0;

    if (signed_mode) {
        if (*s == '-') {
            neg = 1;
            s++;
        } else if (*s == '+') {
            s++;
        }
    }

    if (base == 0) {
        base = 10;
        if (s[0] == '0') {
            if (s[1] == 'x' || s[1] == 'X') {
                base = 16;
                s += 2;
            } else {
                base = 8;
                s += 1;
            }
        }
    } else if (base == 16) {
        if (s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) s += 2;
    }

    while (*s) {
        int d;
        if (*s >= '0' && *s <= '9') d = *s - '0';
        else if (*s >= 'a' && *s <= 'f') d = *s - 'a' + 10;
        else if (*s >= 'A' && *s <= 'F') d = *s - 'A' + 10;
        else break;

        if (d >= base) break;
        v = v * (unsigned)base + (unsigned)d;
        any = 1;
        s++;
    }

    if (!any) return 0;

    if (signed_mode) {
        long long sv = (long long)v;
        if (neg) sv = -sv;
        *out = sv;
    } else {
        *out = (long long)v;
    }

    *sp = s;
    return 1;
}

static int parse_float(const char **sp, double *out) {
    const char *s = *sp;
    int sign = 1;
    double v = 0.0;
    double frac = 0.0;
    double scale = 1.0;
    int any = 0;

    if (*s == '-') {
        sign = -1;
        s++;
    } else if (*s == '+') {
        s++;
    }

    while (*s >= '0' && *s <= '9') {
        v = v * 10.0 + (double)(*s - '0');
        s++;
        any = 1;
    }

    if (*s == '.') {
        s++;
        while (*s >= '0' && *s <= '9') {
            frac = frac * 10.0 + (double)(*s - '0');
            scale *= 10.0;
            s++;
            any = 1;
        }
    }

    if (!any) return 0;

    *out = (v + frac / scale) * (double)sign;
    *sp = s;
    return 1;
}

static int vsscanf_internal(const char *str, const char *fmt, va_list ap) {
    int assigned = 0;
    const char *s = str;

    for (const char *f = fmt; *f; f++) {
        if (is_space(*f)) {
            while (is_space(*f)) f++;
            f--;
            s = skip_space(s);
            continue;
        }

        if (*f != '%') {
            if (*s != *f) break;
            s++;
            continue;
        }

        f++;
        if (!*f) break;

        int suppress = 0;
        if (*f == '*') {
            suppress = 1;
            f++;
        }

        int width = 0;
        while (*f >= '0' && *f <= '9') {
            width = width * 10 + (*f - '0');
            f++;
        }

        if (*f == 'l' || *f == 'h') {
            while (*f == 'l' || *f == 'h') f++;
        }

        switch (*f) {
            case 'd':
            case 'i':
            case 'u':
            case 'x':
            case 'o': {
                s = skip_space(s);
                long long val;
                int ok = 0;
                if (*f == 'd') ok = parse_int(&s, 10, 1, &val);
                else if (*f == 'i') ok = parse_int(&s, 0, 1, &val);
                else if (*f == 'u') ok = parse_int(&s, 10, 0, &val);
                else if (*f == 'x') ok = parse_int(&s, 16, 0, &val);
                else ok = parse_int(&s, 8, 0, &val);
                if (!ok) return assigned;

                if (!suppress) {
                    int *out = va_arg(ap, int *);
                    if (out) *out = (int)val;
                    assigned++;
                }
                break;
            }
            case 'f': {
                s = skip_space(s);
                double dv;
                if (!parse_float(&s, &dv)) return assigned;
                if (!suppress) {
                    float *out = va_arg(ap, float *);
                    if (out) *out = (float)dv;
                    assigned++;
                }
                break;
            }
            case 'c': {
                int n = width > 0 ? width : 1;
                if (!*s) return assigned;
                if (!suppress) {
                    char *out = va_arg(ap, char *);
                    for (int i = 0; i < n; i++) {
                        if (!*s) return assigned;
                        out[i] = *s++;
                    }
                    assigned++;
                } else {
                    for (int i = 0; i < n && *s; i++) s++;
                }
                break;
            }
            case 's': {
                s = skip_space(s);
                if (!*s) return assigned;
                int n = 0;
                if (!suppress) {
                    char *out = va_arg(ap, char *);
                    while (*s && !is_space(*s) && (width == 0 || n < width - 1)) {
                        out[n++] = *s++;
                    }
                    out[n] = '\0';
                    assigned++;
                } else {
                    while (*s && !is_space(*s) && (width == 0 || n < width)) {
                        s++;
                        n++;
                    }
                }
                break;
            }
            case '[': {
                int invert = 0;
                f++;
                if (*f == '^') {
                    invert = 1;
                    f++;
                }

                char cls[64];
                int cls_len = 0;
                while (*f && *f != ']' && cls_len < (int)sizeof(cls) - 1) {
                    cls[cls_len++] = *f++;
                }
                cls[cls_len] = '\0';

                if (*f != ']') return assigned;

                int n = 0;
                if (!suppress) {
                    char *out = va_arg(ap, char *);
                    while (*s) {
                        int in_cls = 0;
                        for (int i = 0; i < cls_len; i++) {
                            if (*s == cls[i]) {
                                in_cls = 1;
                                break;
                            }
                        }
                        if ((invert && in_cls) || (!invert && !in_cls)) break;
                        if (width && n >= width - 1) break;
                        out[n++] = *s++;
                    }
                    out[n] = '\0';
                    if (n == 0) return assigned;
                    assigned++;
                } else {
                    while (*s) {
                        int in_cls = 0;
                        for (int i = 0; i < cls_len; i++) {
                            if (*s == cls[i]) {
                                in_cls = 1;
                                break;
                            }
                        }
                        if ((invert && in_cls) || (!invert && !in_cls)) break;
                        if (width && n >= width) break;
                        s++;
                        n++;
                    }
                    if (n == 0) return assigned;
                }
                break;
            }
            case '%': {
                if (*s != '%') return assigned;
                s++;
                break;
            }
            default:
                return assigned;
        }
    }

    return assigned;
}

int sscanf(const char *str, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    int n = vsscanf_internal(str, fmt, ap);
    va_end(ap);
    return n;
}

int fscanf(FILE *stream, const char *fmt, ...) {
    if (!stream) return EOF;

    char line[512];
    if (!fgets(line, sizeof(line), stream)) {
        return EOF;
    }

    va_list ap;
    va_start(ap, fmt);
    int n = vsscanf_internal(line, fmt, ap);
    va_end(ap);
    return n;
}

int perror(const char *s) {
    if (!s) s = "error";
    fprintf(stderr, "%s\n", s);
    return 0;
}

int remove(const char *path) {
    return unlink(path);
}

int rename(const char *oldpath, const char *newpath) {
    return (int)syscall2(SYS_RENAME, (uint64_t)oldpath, (uint64_t)newpath);
}
