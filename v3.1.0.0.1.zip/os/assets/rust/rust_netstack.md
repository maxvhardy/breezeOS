# DoorOS Rust Networking Stack (Skeleton)

This file documents `rust_netstack.rs`, a no_std networking-stack skeleton staged into `/bin`.

Provided pieces:

- Ethernet header encode path
- ARP packet encode path and fixed-size ARP table
- IPv4 header encode + checksum
- ICMP echo request builder
- Basic next-hop lookup (local subnet vs gateway)

Compiled artifact:

- `build/rust/dooros_rust_netstack.rlib`

Build commands:

- `make compiler` (builds both Rust driver and Rust netstack libraries)
- `make llvm-rust SRC=assets/rust/rust_netstack.rs OUT=build/rust/custom_netstack.rlib`

Notes:

- This is a host-built Rust library artifact and reference implementation.
- It is not wired into the kernel runtime yet.
- The goal is to keep protocol logic in Rust while leaving hardware transport in kernel C drivers.
