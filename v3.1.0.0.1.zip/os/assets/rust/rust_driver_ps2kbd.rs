use crate::rust_driver_traits::{Driver, DriverError, IrqHandler};

pub struct Ps2Keyboard {
    shift: bool,
    ctrl: bool,
    alt: bool,
}

impl Ps2Keyboard {
    pub const fn new() -> Self {
        Self {
            shift: false,
            ctrl: false,
            alt: false,
        }
    }

    pub fn process_scancode(&mut self, scancode: u8) -> Option<u8> {
        let released = (scancode & 0x80) != 0;
        let code = scancode & 0x7F;

        match code {
            0x2A | 0x36 => {
                self.shift = !released;
                None
            }
            0x1D => {
                self.ctrl = !released;
                None
            }
            0x38 => {
                self.alt = !released;
                None
            }
            _ => {
                if released {
                    None
                } else {
                    Some(code)
                }
            }
        }
    }
}

impl Driver for Ps2Keyboard {
    fn name(&self) -> &'static str {
        "ps2-kbd"
    }

    fn init(&mut self) -> Result<(), DriverError> {
        Ok(())
    }
}

impl IrqHandler for Ps2Keyboard {
    fn on_irq(&mut self) -> Result<(), DriverError> {
        // Port 0x60 read + decode would be done by the IRQ shim.
        Ok(())
    }
}
