use crate::rust_driver_traits::{Driver, DriverError};

pub trait FrameAllocator {
    fn alloc_frame(&mut self) -> Option<u64>;
    fn free_frame(&mut self, phys_addr: u64) -> Result<(), DriverError>;
}

pub struct BitmapFrameAllocator {
    base_phys: u64,
    frame_count: u32,
    bitmap: [u64; 64], // 4096 frames max in this skeleton
}

impl BitmapFrameAllocator {
    pub const fn new(base_phys: u64, frame_count: u32) -> Self {
        Self {
            base_phys,
            frame_count,
            bitmap: [0; 64],
        }
    }

    fn bit_is_set(&self, bit: u32) -> bool {
        let idx = (bit / 64) as usize;
        let off = bit % 64;
        (self.bitmap[idx] & (1u64 << off)) != 0
    }

    fn set_bit(&mut self, bit: u32) {
        let idx = (bit / 64) as usize;
        let off = bit % 64;
        self.bitmap[idx] |= 1u64 << off;
    }

    fn clear_bit(&mut self, bit: u32) {
        let idx = (bit / 64) as usize;
        let off = bit % 64;
        self.bitmap[idx] &= !(1u64 << off);
    }
}

impl Driver for BitmapFrameAllocator {
    fn name(&self) -> &'static str {
        "mem-bitmap"
    }

    fn init(&mut self) -> Result<(), DriverError> {
        if self.frame_count == 0 {
            return Err(DriverError::BadState);
        }
        Ok(())
    }
}

impl FrameAllocator for BitmapFrameAllocator {
    fn alloc_frame(&mut self) -> Option<u64> {
        for bit in 0..self.frame_count {
            if self.bit_is_set(bit) {
                continue;
            }
            self.set_bit(bit);
            return Some(self.base_phys + (bit as u64) * 4096);
        }
        None
    }

    fn free_frame(&mut self, phys_addr: u64) -> Result<(), DriverError> {
        if phys_addr < self.base_phys {
            return Err(DriverError::BadState);
        }
        let rel = phys_addr - self.base_phys;
        if (rel & 0xFFF) != 0 {
            return Err(DriverError::BadState);
        }
        let bit = (rel / 4096) as u32;
        if bit >= self.frame_count {
            return Err(DriverError::BadState);
        }
        self.clear_bit(bit);
        Ok(())
    }
}

pub struct PagingDriver<'a, A: FrameAllocator> {
    allocator: &'a mut A,
    mapped_pages: u32,
}

impl<'a, A: FrameAllocator> PagingDriver<'a, A> {
    pub fn new(allocator: &'a mut A) -> Self {
        Self {
            allocator,
            mapped_pages: 0,
        }
    }

    pub fn map_page(&mut self, _virt_addr: u64, _flags: u64) -> Result<u64, DriverError> {
        let frame = self.allocator.alloc_frame().ok_or(DriverError::IoTimeout)?;
        self.mapped_pages += 1;
        Ok(frame)
    }

    pub fn unmap_page(&mut self, _virt_addr: u64, phys_addr: u64) -> Result<(), DriverError> {
        self.allocator.free_frame(phys_addr)?;
        if self.mapped_pages > 0 {
            self.mapped_pages -= 1;
        }
        Ok(())
    }

    pub fn mapped_pages(&self) -> u32 {
        self.mapped_pages
    }
}
