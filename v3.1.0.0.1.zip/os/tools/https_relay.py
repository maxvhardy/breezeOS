#!/usr/bin/env python3
"""
Tiny HTTP relay for DoorOS curl HTTPS support.

DoorOS can only fetch plain HTTP from IPv4 endpoints in-kernel.
This host-side relay accepts:

  GET /fetch?url=<percent-encoded-https-url>

and returns the upstream response body over plain HTTP so the guest can read it.
"""

from __future__ import annotations

import argparse
import http.server
import socketserver
import sys
import urllib.error
import urllib.parse
import urllib.request


class RelayHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, addr, handler_cls, fetch_timeout: float, max_bytes: int):
        super().__init__(addr, handler_cls)
        self.fetch_timeout = fetch_timeout
        self.max_bytes = max_bytes


class RelayHandler(http.server.BaseHTTPRequestHandler):
    server_version = "DoorOSHTTPSRelay/1.0"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt: str, *args) -> None:
        sys.stderr.write("[https-relay] %s - %s\n" % (self.address_string(), fmt % args))

    def _send_text(self, status: int, text: str) -> None:
        data = text.encode("utf-8", errors="replace")
        self.send_response(status)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self) -> None:  # noqa: N802
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/":
            self._send_text(200, "DoorOS HTTPS relay running\nUse /fetch?url=https%3A%2F%2Fexample.com%2F\n")
            return
        if parsed.path != "/fetch":
            self._send_text(404, "not found\n")
            return

        q = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        target = q.get("url", [""])[0].strip()
        if not target:
            self._send_text(400, "missing url query parameter\n")
            return

        target = urllib.parse.unquote(target)
        u = urllib.parse.urlparse(target)
        if u.scheme not in ("https", "http"):
            self._send_text(400, "url must start with https:// or http://\n")
            return

        req = urllib.request.Request(
            target,
            headers={
                "User-Agent": "DoorOS-HTTPS-Relay/1.0",
                "Accept": "*/*",
            },
        )

        status = 200
        body = b""
        content_type = "application/octet-stream"
        truncated = False

        try:
            with urllib.request.urlopen(req, timeout=self.server.fetch_timeout) as resp:  # type: ignore[attr-defined]
                status = int(resp.getcode() or 200)
                content_type = resp.headers.get("Content-Type", content_type)
                body = resp.read(self.server.max_bytes + 1)  # type: ignore[attr-defined]
        except urllib.error.HTTPError as e:
            status = int(e.code or 502)
            content_type = e.headers.get("Content-Type", "text/plain; charset=utf-8")
            body = e.read(self.server.max_bytes + 1)  # type: ignore[attr-defined]
        except Exception as e:  # pragma: no cover
            self._send_text(502, f"upstream fetch failed: {e}\n")
            return

        if len(body) > self.server.max_bytes:  # type: ignore[attr-defined]
            body = body[: self.server.max_bytes]  # type: ignore[attr-defined]
            truncated = True

        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.send_header("X-DoorOS-Relay", "https")
        if truncated:
            self.send_header("X-DoorOS-Relay-Truncated", "1")
        self.end_headers()
        self.wfile.write(body)


def main() -> int:
    ap = argparse.ArgumentParser(description="DoorOS HTTPS relay server")
    ap.add_argument("--host", default="0.0.0.0", help="Bind host (default: 0.0.0.0)")
    ap.add_argument("--port", default=8080, type=int, help="Bind port (default: 8080)")
    ap.add_argument("--timeout", default=8.0, type=float, help="Upstream timeout seconds")
    ap.add_argument("--max-bytes", default=262144, type=int, help="Max response bytes to return")
    args = ap.parse_args()

    if args.max_bytes <= 0:
        print("error: --max-bytes must be > 0", file=sys.stderr)
        return 2

    srv = RelayHTTPServer((args.host, args.port), RelayHandler, args.timeout, args.max_bytes)
    print(f"[https-relay] listening on http://{args.host}:{args.port}")
    print("[https-relay] guest URL: http://10.0.2.2:8080/fetch?url=https%3A%2F%2Fexample.com%2F")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
