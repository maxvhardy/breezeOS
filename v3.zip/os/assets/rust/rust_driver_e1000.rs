use core::ptr::{read_volatile, write_volatile};

use crate::rust_driver_traits::{Driver, DriverError, IrqHandler};

pub struct E1000 {
    mmio_base: *mut u32,
    link_up: bool,
}

impl E1000 {
    pub const fn new(mmio_base: usize) -> Self {
        Self {
            mmio_base: mmio_base as *mut u32,
            link_up: false,
        }
    }

    fn reg_read(&self, index: usize) -> u32 {
        unsafe { read_volatile(self.mmio_base.add(index)) }
    }

    fn reg_write(&self, index: usize, value: u32) {
        unsafe { write_volatile(self.mmio_base.add(index), value) }
    }

    fn probe_link(&mut self) {
        const STATUS_REG: usize = 0x0008 / 4;
        const STATUS_LINK_UP: u32 = 1 << 1;
        self.link_up = (self.reg_read(STATUS_REG) & STATUS_LINK_UP) != 0;
    }
}

impl Driver for E1000 {
    fn name(&self) -> &'static str {
        "e1000"
    }

    fn init(&mut self) -> Result<(), DriverError> {
        // Reset + descriptor ring setup would happen here.
        self.probe_link();
        Ok(())
    }
}

impl IrqHandler for E1000 {
    fn on_irq(&mut self) -> Result<(), DriverError> {
        // RX/TX completion and interrupt cause handling would go here.
        self.probe_link();
        Ok(())
    }
}
