pub trait Driver {
    fn name(&self) -> &'static str;
    fn init(&mut self) -> Result<(), DriverError>;
}

pub trait IrqHandler {
    fn on_irq(&mut self) -> Result<(), DriverError>;
}

#[derive(Copy, Clone, Debug, Eq, PartialEq)]
pub enum DriverError {
    NotPresent,
    IoTimeout,
    BadState,
    Unsupported,
}
