# DoorOS Rust Driver Notes

These files are staged in the filesystem image so you can inspect Rust-style
driver architecture from inside DoorOS (`/bin`).

Included examples:

- `rust_driver_traits.rs`: shared traits for device drivers.
- `rust_driver_e1000.rs`: Intel e1000 NIC skeleton.
- `rust_driver_vbe.rs`: VBE framebuffer helper skeleton.
- `rust_driver_ps2kbd.rs`: PS/2 keyboard input skeleton.
- `rust_driver_memory.rs`: bitmap frame allocator + paging driver skeleton.
- `rust_drivers_lib.rs`: crate root used by `make compiler` / `make rust-compile`.

These are reference skeletons (not yet built into the kernel). They are meant
to show how a no_std Rust driver layer can map onto the current C/ASM kernel.
