#pragma once

#include "syscall.h"
#include "stdarg.h"

#define STDIN_FILENO  0
#define STDOUT_FILENO 1
#define STDERR_FILENO 2

#define O_RDONLY  0
#define O_WRONLY  1
#define O_RDWR    2
#define O_CREAT   0x100
#define O_TRUNC   0x200
#define O_APPEND  0x400
#define O_BINARY  0
#define O_TEXT    0

#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2

#define F_OK 0
#define X_OK 1
#define W_OK 2
#define R_OK 4

#define MAX_PATH 256

#define EOF (-1)

struct dirent {
    uint32_t inode;
    uint8_t type;
    char name[59];
};

struct stat {
    uint32_t inode;
    uint32_t type;
    uint32_t size;
    uint32_t blocks;
    uint64_t created;
    uint64_t modified;
};

typedef struct FILE {
    int fd;
    int eof;
    int err;
    int ungot;
    int flags;
} FILE;

extern FILE __stdin_file;
extern FILE __stdout_file;
extern FILE __stderr_file;

#define stdin  (&__stdin_file)
#define stdout (&__stdout_file)
#define stderr (&__stderr_file)

int printf(const char *fmt, ...);
int vprintf(const char *fmt, va_list ap);
int fprintf(FILE *stream, const char *fmt, ...);
int vfprintf(FILE *stream, const char *fmt, va_list ap);
int snprintf(char *buf, size_t size, const char *fmt, ...);
int vsnprintf(char *buf, size_t size, const char *fmt, va_list ap);
int sprintf(char *buf, const char *fmt, ...);
int sscanf(const char *str, const char *fmt, ...);
int fscanf(FILE *stream, const char *fmt, ...);

int puts(const char *s);
int putchar(int c);
int getchar(void);
void setbuf(FILE *stream, char *buf);

ssize_t write(int fd, const void *buf, size_t count);
ssize_t read(int fd, void *buf, size_t count);
int64_t lseek(int fd, int64_t offset, int whence);
int readdir(int fd, struct dirent *entry);
int stat(const char *path, struct stat *st);
int fstat(int fd, struct stat *st);
int mkdir(const char *path, ...);
int rmdir(const char *path);
int unlink(const char *path);
int chdir(const char *path);
char *getcwd(char *buf, size_t size);
int access(const char *path, int mode);

FILE *fopen(const char *path, const char *mode);
int fclose(FILE *stream);
size_t fread(void *ptr, size_t size, size_t nmemb, FILE *stream);
size_t fwrite(const void *ptr, size_t size, size_t nmemb, FILE *stream);
int fseek(FILE *stream, long offset, int whence);
long ftell(FILE *stream);
int fflush(FILE *stream);
int feof(FILE *stream);
int ferror(FILE *stream);
int fgetc(FILE *stream);
int fputc(int c, FILE *stream);
char *fgets(char *s, int size, FILE *stream);
int ungetc(int c, FILE *stream);
int perror(const char *s);
int remove(const char *path);
int rename(const char *oldpath, const char *newpath);

// Signals
#define SIGTERM   1
#define SIGKILL   2
#define SIGCHLD   3
#define SIGUSR1   4
#define SIGUSR2   5
