#include "errno.h"

int errno = 0;
