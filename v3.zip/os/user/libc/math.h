#pragma once

double sin(double x);
double cos(double x);
double tan(double x);
double atan(double x);
double fabs(double x);
float fabsf(float x);
