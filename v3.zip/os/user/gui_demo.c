#include "libc/stdio.h"
#include "libc/stdlib.h"
#include "libc/string.h"

// GUI syscall wrappers
struct gui_event {
    uint32_t type;
    uint32_t window_id;
    int32_t  x, y;
    uint32_t keycode;
    uint32_t buttons;
};

#define GUI_EVENT_NONE       0
#define GUI_EVENT_KEY_PRESS  1
#define GUI_EVENT_MOUSE_DOWN 4
#define GUI_EVENT_MOUSE_UP   5
#define GUI_EVENT_WIN_CLOSE  6
#define GUI_EVENT_REPAINT    8

static int win_create(int x, int y, int w, int h, const char *title) {
    return (int)syscall5(SYS_WIN_CREATE,
                         (uint64_t)x, (uint64_t)y,
                         (uint64_t)w, (uint64_t)h,
                         (uint64_t)title);
}

static void win_destroy(int wid) {
    syscall1(SYS_WIN_DESTROY, (uint64_t)wid);
}

static int win_update(int wid, uint32_t *pixels) {
    return (int)syscall2(SYS_WIN_UPDATE, (uint64_t)wid, (uint64_t)pixels);
}

static int win_event(struct gui_event *ev) {
    return (int)syscall1(SYS_WIN_EVENT, (uint64_t)ev);
}

// Simple pixel drawing
#define WIN_W 320
#define WIN_H 240

static uint32_t framebuf[WIN_W * WIN_H];

static void put_pixel(int x, int y, uint32_t color) {
    if (x >= 0 && x < WIN_W && y >= 0 && y < WIN_H) {
        framebuf[y * WIN_W + x] = color;
    }
}

static void fill_rect(int x, int y, int w, int h, uint32_t color) {
    for (int j = y; j < y + h; j++) {
        for (int i = x; i < x + w; i++) {
            put_pixel(i, j, color);
        }
    }
}

int main(void) {
    printf("GUI Demo: Creating window...\n");

    int wid = win_create(100, 100, WIN_W, WIN_H, "GUI Demo");
    if (wid < 0) {
        printf("GUI Demo: Failed to create window\n");
        return 1;
    }

    printf("GUI Demo: Window %d created\n", wid);

    // Clear to white
    fill_rect(0, 0, WIN_W, WIN_H, 0xF0F0F0);

    // Draw some colored rectangles
    fill_rect(10, 10, 80, 60, 0xE74C3C);  // Red
    fill_rect(100, 10, 80, 60, 0x2ECC71);  // Green
    fill_rect(190, 10, 80, 60, 0x3498DB);  // Blue

    // Draw a gradient bar
    for (int x = 10; x < WIN_W - 10; x++) {
        uint32_t r = (x * 255) / WIN_W;
        uint32_t g = 128;
        uint32_t b = 255 - r;
        uint32_t color = (r << 16) | (g << 8) | b;
        for (int y = 80; y < 100; y++) {
            put_pixel(x, y, color);
        }
    }

    // Draw some text area
    fill_rect(10, 110, WIN_W - 20, 80, 0xFFFFFF);
    fill_rect(10, 110, WIN_W - 20, 1, 0x999999);
    fill_rect(10, 110, 1, 80, 0x999999);
    fill_rect(WIN_W - 11, 110, 1, 80, 0x999999);
    fill_rect(10, 189, WIN_W - 20, 1, 0x999999);

    // Bottom status bar
    fill_rect(0, WIN_H - 20, WIN_W, 20, 0x34495E);

    // Draw a simple button
    fill_rect(WIN_W / 2 - 40, 200, 80, 25, 0x3498DB);

    win_update(wid, framebuf);

    // Event loop
    int running = 1;
    int click_count = 0;

    while (running) {
        struct gui_event ev;
        if (win_event(&ev) == 0) {
            switch (ev.type) {
                case GUI_EVENT_WIN_CLOSE:
                    running = 0;
                    break;
                case GUI_EVENT_MOUSE_DOWN:
                    // Draw a dot where clicked
                    click_count++;
                    for (int dy = -3; dy <= 3; dy++) {
                        for (int dx = -3; dx <= 3; dx++) {
                            if (dx*dx + dy*dy <= 9) {
                                uint32_t c = ((click_count * 50) % 256) << 16 |
                                             ((click_count * 80) % 256) << 8 |
                                             ((click_count * 30) % 256);
                                put_pixel(ev.x + dx, ev.y + dy, c);
                            }
                        }
                    }
                    win_update(wid, framebuf);
                    break;
                case GUI_EVENT_KEY_PRESS:
                    if (ev.keycode == 'q' || ev.keycode == 27) {
                        running = 0;
                    }
                    break;
            }
        }
        yield();
    }

    win_destroy(wid);
    printf("GUI Demo: Window closed\n");
    return 0;
}
