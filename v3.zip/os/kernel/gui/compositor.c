#include "gui/compositor.h"
#include "gui/window.h"
#include "gui/desktop.h"
#include "gui/taskbar.h"
#include "gui/font.h"
#include "gui/apps.h"
#include "gui/event.h"
#include "drivers/vbe.h"
#include "drivers/mouse.h"
#include "drivers/keyboard.h"
#include "drivers/net.h"
#include "lib/string.h"
#include "include/types.h"

static uint32_t wallpaper_color = 0x2E4057;
static int prev_mouse_x = 0, prev_mouse_y = 0;
static int prev_mouse_buttons = 0;
static int drag_window = -1;
static int drag_offset_x = 0, drag_offset_y = 0;
static int window_corner_radius = 11;
static int chrome_style = 0;

static void dispatch_event(struct gui_event *ev) {
    if (!ev) return;
    struct window *target = window_get((int)ev->window_id);
    if (target && target->owner_pid > 0) {
        gui_event_push(ev);
    }
    gui_apps_handle_event(ev);
}

struct chrome_palette {
    uint32_t title_active;
    uint32_t title_inactive;
    uint32_t title_text_active;
    uint32_t title_text_inactive;
    uint32_t border;
    uint32_t close_btn;
    uint32_t min_btn;
    uint32_t max_btn;
    uint32_t inactive_btn;
};

static const struct chrome_palette chrome_palettes[] = {
    {0x223043, 0x1B2432, 0xE8EEF5, 0x96A2AF, 0x0F131A, 0xE56B6F, 0xF4C95D, 0x57CC99, 0x4C5561},
    {0x2E4F7D, 0x203854, 0xF2F7FF, 0x9FB7D4, 0x162439, 0xFF6B6B, 0xFFD166, 0x06D6A0, 0x647C9A},
};

// Traffic light geometry (relative to title bar)
#define BTN_SIZE              12
#define BTN_FIRST_X           12      // offset from window left edge
#define BTN_SPACING           20      // center-to-center spacing

void compositor_init(void) {
    prev_mouse_x = 0;
    prev_mouse_y = 0;
    prev_mouse_buttons = 0;
    drag_window = -1;
}

void compositor_set_wallpaper(uint32_t color) {
    wallpaper_color = color;
}

void compositor_set_corner_radius(int radius) {
    if (radius < 0) radius = 0;
    if (radius > 24) radius = 24;
    window_corner_radius = radius;
}

int compositor_get_corner_radius(void) {
    return window_corner_radius;
}

void compositor_set_chrome_style(int style) {
    if (style < 0) style = 0;
    if (style >= (int)(sizeof(chrome_palettes) / sizeof(chrome_palettes[0]))) {
        style = (int)(sizeof(chrome_palettes) / sizeof(chrome_palettes[0])) - 1;
    }
    chrome_style = style;
}

int compositor_get_chrome_style(void) {
    return chrome_style;
}

static const struct chrome_palette *active_palette(void) {
    int count = (int)(sizeof(chrome_palettes) / sizeof(chrome_palettes[0]));
    if (chrome_style < 0 || chrome_style >= count) {
        chrome_style = 0;
    }
    return &chrome_palettes[chrome_style];
}

static int point_in_round_rect_local(int lx, int ly, int w, int h, int radius) {
    if (lx < 0 || ly < 0 || lx >= w || ly >= h) return 0;
    if (radius <= 0) return 1;

    int r = radius;
    int max_r = w < h ? w / 2 : h / 2;
    if (r > max_r) r = max_r;
    if (r <= 0) return 1;

    // Interior bands
    if (lx >= r && lx < w - r) return 1;
    if (ly >= r && ly < h - r) return 1;

    // Corner circles
    int cx = (lx < r) ? (r - 1) : (w - r);
    int cy = (ly < r) ? (r - 1) : (h - r);
    int dx = lx - cx;
    int dy = ly - cy;
    return (dx * dx + dy * dy) <= (r * r);
}

static int point_in_round_top_rect_local(int lx, int ly, int w, int h, int radius) {
    if (lx < 0 || ly < 0 || lx >= w || ly >= h) return 0;
    if (radius <= 0) return 1;

    int r = radius;
    int max_r = w / 2;
    if (h < max_r) max_r = h;
    if (r > max_r) r = max_r;
    if (r <= 0) return 1;

    // Lower region is plain.
    if (ly >= r) return 1;
    if (lx >= r && lx < w - r) return 1;

    int cx = (lx < r) ? (r - 1) : (w - r);
    int cy = r - 1;
    int dx = lx - cx;
    int dy = ly - cy;
    return (dx * dx + dy * dy) <= (r * r);
}

static void draw_round_rect(uint32_t *buf, int buf_w, int buf_h,
                            int x, int y, int w, int h, int radius, uint32_t color) {
    for (int j = 0; j < h; j++) {
        int py = y + j;
        if (py < 0 || py >= buf_h) continue;
        for (int i = 0; i < w; i++) {
            int px = x + i;
            if (px < 0 || px >= buf_w) continue;
            if (!point_in_round_rect_local(i, j, w, h, radius)) continue;
            buf[py * buf_w + px] = color;
        }
    }
}

static void draw_round_top_rect(uint32_t *buf, int buf_w, int buf_h,
                                int x, int y, int w, int h, int radius, uint32_t color) {
    for (int j = 0; j < h; j++) {
        int py = y + j;
        if (py < 0 || py >= buf_h) continue;
        for (int i = 0; i < w; i++) {
            int px = x + i;
            if (px < 0 || px >= buf_w) continue;
            if (!point_in_round_top_rect_local(i, j, w, h, radius)) continue;
            buf[py * buf_w + px] = color;
        }
    }
}

static void draw_filled_circle(uint32_t *buf, int buf_w, int buf_h,
                               int cx, int cy, int radius, uint32_t color) {
    int r2 = radius * radius;
    for (int y = -radius; y <= radius; y++) {
        int py = cy + y;
        if (py < 0 || py >= buf_h) continue;
        for (int x = -radius; x <= radius; x++) {
            int px = cx + x;
            if (px < 0 || px >= buf_w) continue;
            if (x * x + y * y > r2) continue;
            buf[py * buf_w + px] = color;
        }
    }
}

static void draw_window_decoration(uint32_t *buf, int buf_w, int buf_h,
                                   struct window *win) {
    if (!(win->flags & WIN_FLAG_DECORATED)) return;

    const struct chrome_palette *pal = active_palette();
    bool focused = (win->flags & WIN_FLAG_FOCUSED) != 0;

    uint32_t title_bg = focused ? pal->title_active : pal->title_inactive;
    uint32_t title_text = focused ? pal->title_text_active : pal->title_text_inactive;

    int bx = win->x - WINDOW_BORDER_SIZE;
    int by = win->y - WINDOW_TITLE_HEIGHT - WINDOW_BORDER_SIZE;
    int full_w = win->width + WINDOW_BORDER_SIZE * 2;
    int full_h = win->height + WINDOW_TITLE_HEIGHT + WINDOW_BORDER_SIZE * 2;
    int inner_x = win->x;
    int inner_y = win->y - WINDOW_TITLE_HEIGHT;
    int inner_w = win->width;
    int inner_h = win->height + WINDOW_TITLE_HEIGHT;
    int radius = window_corner_radius;
    if (radius < 0) radius = 0;

    // Rounded border shell.
    draw_round_rect(buf, buf_w, buf_h, bx, by, full_w, full_h,
                    radius + WINDOW_BORDER_SIZE, pal->border);

    // Window interior.
    draw_round_rect(buf, buf_w, buf_h, inner_x, inner_y, inner_w, inner_h,
                    radius, 0x131922);

    // Title bar with rounded top corners.
    draw_round_top_rect(buf, buf_w, buf_h, inner_x, inner_y,
                        inner_w, WINDOW_TITLE_HEIGHT + 2, radius, title_bg);

    // Traffic-light buttons (left side).
    int btn_cy = win->y - WINDOW_TITLE_HEIGHT + WINDOW_TITLE_HEIGHT / 2;
    int btn_r = BTN_SIZE / 2;
    int btn_cx = win->x + BTN_FIRST_X + btn_r;

    uint32_t close_c = focused ? pal->close_btn : pal->inactive_btn;
    uint32_t min_c = focused ? pal->min_btn : pal->inactive_btn;
    uint32_t max_c = focused ? pal->max_btn : pal->inactive_btn;

    draw_filled_circle(buf, buf_w, buf_h, btn_cx, btn_cy, btn_r, close_c);
    draw_filled_circle(buf, buf_w, buf_h, btn_cx + BTN_SPACING, btn_cy, btn_r, min_c);
    draw_filled_circle(buf, buf_w, buf_h, btn_cx + BTN_SPACING * 2, btn_cy, btn_r, max_c);

    // Centered title text.
    int tw = font_string_width(win->title);
    int tx = win->x + (win->width - tw) / 2;
    int ty = win->y - WINDOW_TITLE_HEIGHT + (WINDOW_TITLE_HEIGHT - FONT_HEIGHT) / 2 + 1;
    font_draw_string(buf, buf_w, buf_h, tx, ty, win->title, title_text, title_bg);
}

static void blit_window_content(uint32_t *buf, int buf_w, int buf_h,
                                struct window *win) {
    if (!win->framebuffer) return;

    int clip_x = win->x;
    int clip_y = win->y - WINDOW_TITLE_HEIGHT;
    int clip_w = win->width;
    int clip_h = win->height + WINDOW_TITLE_HEIGHT;
    int radius = window_corner_radius;
    if (radius < 0) radius = 0;

    for (int j = 0; j < win->height; j++) {
        int dy = win->y + j;
        if (dy < 0 || dy >= buf_h) continue;
        for (int i = 0; i < win->width; i++) {
            int dx = win->x + i;
            if (dx < 0 || dx >= buf_w) continue;
            if (!point_in_round_rect_local(dx - clip_x, dy - clip_y,
                                           clip_w, clip_h, radius)) {
                continue;
            }
            uint32_t pixel = win->framebuffer[j * win->width + i];
            buf[dy * buf_w + dx] = pixel;
        }
    }
}

// 12x16 arrow cursor
static void draw_cursor(uint32_t *buf, int buf_w, int buf_h, int mx, int my) {
    static const char cursor[16][12] = {
        "X           ",
        "XX          ",
        "X.X         ",
        "X..X        ",
        "X...X       ",
        "X....X      ",
        "X.....X     ",
        "X......X    ",
        "X.......X   ",
        "X........X  ",
        "X.....XXXXX ",
        "X..X..X     ",
        "X.X X..X    ",
        "XX  X..X    ",
        "X    X..X   ",
        "     X..X   ",
    };

    for (int j = 0; j < 16; j++) {
        for (int i = 0; i < 12; i++) {
            int px = mx + i;
            int py = my + j;
            if (px < 0 || px >= buf_w || py < 0 || py >= buf_h) continue;
            if (cursor[j][i] == 'X') {
                buf[py * buf_w + px] = 0x000000;
            } else if (cursor[j][i] == '.') {
                buf[py * buf_w + px] = 0xFFFFFF;
            }
        }
    }
}

// =====================================================================
//  Input handling
// =====================================================================

static void handle_mouse_input(int screen_w, int screen_h) {
    mouse_poll();

    int mx = mouse_get_x();
    int my = mouse_get_y();
    int buttons = mouse_get_buttons();

    int left_pressed  = (buttons & MOUSE_LEFT) && !(prev_mouse_buttons & MOUSE_LEFT);
    int left_released = !(buttons & MOUSE_LEFT) && (prev_mouse_buttons & MOUSE_LEFT);

    // --- Window dragging ---
    if (drag_window >= 0) {
        if (buttons & MOUSE_LEFT) {
            window_move(drag_window, mx - drag_offset_x, my - drag_offset_y);
        } else {
            struct window *win = window_get(drag_window);
            if (win) win->flags &= ~WIN_FLAG_DRAGGING;
            drag_window = -1;
        }
    }

    // --- Click handling ---
    if (left_pressed && drag_window < 0) {
        int click_consumed = 0;

        // Always let the taskbar/dock/menubar/launchpad handle first
        click_consumed = taskbar_handle_click(mx, my, screen_w, screen_h);

        if (click_consumed) {
            goto click_done;
        }

        // Desktop icons and shortcuts.
        if (desktop_handle_mouse(mx, my, buttons)) {
            goto click_done;
        }

        // Hit-test windows (front to back)
        struct window *sorted[MAX_WINDOWS];
        int count;
        window_get_sorted(sorted, &count);

        for (int i = count - 1; i >= 0; i--) {
            struct window *win = sorted[i];
            int wx = win->x;
            int wy = win->y - WINDOW_TITLE_HEIGHT;
            int ww = win->width;
            int wh = win->height + WINDOW_TITLE_HEIGHT;

            if (mx >= wx && mx < wx + ww && my >= wy && my < wy + wh) {
                if (!point_in_round_rect_local(mx - wx, my - wy, ww, wh, window_corner_radius)) {
                    continue;
                }
                window_set_focused(win->id);

                // Check close button (traffic light, left side)
                int btn_y = win->y - WINDOW_TITLE_HEIGHT +
                            (WINDOW_TITLE_HEIGHT - BTN_SIZE) / 2;
                int close_x = win->x + BTN_FIRST_X;
                if (mx >= close_x && mx < close_x + BTN_SIZE &&
                    my >= btn_y && my < btn_y + BTN_SIZE) {
                    if (win->owner_pid == 0) {
                        window_destroy(win->id);
                    } else {
                        struct gui_event ev;
                        memset(&ev, 0, sizeof(ev));
                        ev.type = GUI_EVENT_WIN_CLOSE;
                        ev.window_id = win->id;
                        dispatch_event(&ev);
                    }
                    break;
                }

                // Title bar drag
                if (my < win->y) {
                    drag_window = win->id;
                    drag_offset_x = mx - win->x;
                    drag_offset_y = my - win->y;
                    win->flags |= WIN_FLAG_DRAGGING;
                    break;
                }

                // Click inside window client area
                struct gui_event ev;
                memset(&ev, 0, sizeof(ev));
                ev.type = GUI_EVENT_MOUSE_DOWN;
                ev.window_id = win->id;
                ev.x = mx - win->x;
                ev.y = my - win->y;
                ev.buttons = buttons;
                dispatch_event(&ev);
                break;
            }
        }
click_done:
        ;
    }

    if (left_released) {
        struct window *focused = window_get_focused();
        if (focused) {
            struct gui_event ev;
            memset(&ev, 0, sizeof(ev));
            ev.type = GUI_EVENT_MOUSE_UP;
            ev.window_id = focused->id;
            ev.x = mx - focused->x;
            ev.y = my - focused->y;
            ev.buttons = buttons;
            dispatch_event(&ev);
        }
    }

    // Mouse move events (BUG FIX: also send when buttons are held,
    // unless the compositor is handling a window title-bar drag.)
    if (mx != prev_mouse_x || my != prev_mouse_y) {
        if (drag_window < 0) {
            struct window *focused = window_get_focused();
            if (focused) {
                struct gui_event ev;
                memset(&ev, 0, sizeof(ev));
                ev.type = GUI_EVENT_MOUSE_MOVE;
                ev.window_id = focused->id;
                ev.x = mx - focused->x;
                ev.y = my - focused->y;
                ev.buttons = buttons;
                dispatch_event(&ev);
            }
        }
    }

    // Keyboard events
    while (kbd_has_key()) {
        char c = kbd_getchar();
        if (c) {
            // Let taskbar handle ESC when launchpad is open
            if (taskbar_handle_key((uint32_t)(uint8_t)c)) continue;

            struct window *focused = window_get_focused();
            struct gui_event ev;
            memset(&ev, 0, sizeof(ev));
            ev.type = GUI_EVENT_KEY_PRESS;
            ev.window_id = focused ? focused->id : 0;
            ev.keycode = (uint32_t)(uint8_t)c;
            dispatch_event(&ev);
        }
    }

    prev_mouse_x = mx;
    prev_mouse_y = my;
    prev_mouse_buttons = buttons;
}

// =====================================================================
//  Compositor render loop
// =====================================================================

void compositor_render(void) {
    if (!vbe_available()) return;

    // Free window framebuffers retired in prior frames.
    window_collect_garbage();

    int w = (int)vbe_get_width();
    int h = (int)vbe_get_height();
    uint32_t *backbuf = vbe_get_backbuffer();
    if (!backbuf) return;

    // Handle input
    handle_mouse_input(w, h);
    gui_apps_tick();
    net_poll();

    // 1. Desktop background (full screen)
    desktop_render(backbuf, w, h);

    // 2. Windows (back to front)
    struct window *sorted[MAX_WINDOWS];
    int count;
    window_get_sorted(sorted, &count);

    for (int i = 0; i < count; i++) {
        draw_window_decoration(backbuf, w, h, sorted[i]);
        blit_window_content(backbuf, w, h, sorted[i]);
    }

    // 3. Menu bar + Dock + Launchpad overlay (always on top)
    taskbar_render(backbuf, w, h);

    // 4. Mouse cursor (always on top)
    draw_cursor(backbuf, w, h, mouse_get_x(), mouse_get_y());

    // Swap to screen
    vbe_swap_buffers();
}
