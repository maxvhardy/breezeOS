#include "gui/event.h"
#include "gui/window.h"
#include "lib/string.h"

static struct gui_event event_queue[EVENT_QUEUE_SIZE];
static volatile int eq_read = 0;
static volatile int eq_write = 0;

void gui_event_init(void) {
    uint64_t irq = irq_save();
    eq_read = 0;
    eq_write = 0;
    memset(event_queue, 0, sizeof(event_queue));
    irq_restore(irq);
}

void gui_event_push(struct gui_event *ev) {
    if (!ev) return;

    uint64_t irq = irq_save();
    int next = (eq_write + 1) % EVENT_QUEUE_SIZE;
    if (next == eq_read) {
        irq_restore(irq);
        return; // Queue full
    }
    event_queue[eq_write] = *ev;
    eq_write = next;
    irq_restore(irq);
}

int gui_event_poll(struct gui_event *ev) {
    if (!ev) return 0;

    uint64_t irq = irq_save();
    if (eq_read == eq_write) {
        ev->type = GUI_EVENT_NONE;
        irq_restore(irq);
        return 0;
    }
    *ev = event_queue[eq_read];
    eq_read = (eq_read + 1) % EVENT_QUEUE_SIZE;
    irq_restore(irq);
    return 1;
}

int gui_event_poll_for_owner(int owner_pid, struct gui_event *ev) {
    if (!ev) return 0;
    if (owner_pid <= 0) {
        ev->type = GUI_EVENT_NONE;
        return 0;
    }

    uint64_t irq = irq_save();
    if (eq_read == eq_write) {
        ev->type = GUI_EVENT_NONE;
        irq_restore(irq);
        return 0;
    }

    int idx = eq_read;
    while (idx != eq_write) {
        struct gui_event cand = event_queue[idx];
        struct window *win = window_get((int)cand.window_id);

        if (!win || win->owner_pid <= 0) {
            int cur = idx;
            while (cur != eq_write) {
                int next = (cur + 1) % EVENT_QUEUE_SIZE;
                if (next == eq_write) break;
                event_queue[cur] = event_queue[next];
                cur = next;
            }
            eq_write = (eq_write + EVENT_QUEUE_SIZE - 1) % EVENT_QUEUE_SIZE;
            continue;
        }

        if (win->owner_pid == owner_pid) {
            *ev = cand;

            int cur = idx;
            while (cur != eq_write) {
                int next = (cur + 1) % EVENT_QUEUE_SIZE;
                if (next == eq_write) break;
                event_queue[cur] = event_queue[next];
                cur = next;
            }
            eq_write = (eq_write + EVENT_QUEUE_SIZE - 1) % EVENT_QUEUE_SIZE;
            irq_restore(irq);
            return 1;
        }

        idx = (idx + 1) % EVENT_QUEUE_SIZE;
    }

    ev->type = GUI_EVENT_NONE;
    irq_restore(irq);
    return 0;
}

void gui_event_discard_window(uint32_t window_id) {
    uint64_t irq = irq_save();
    int idx = eq_read;
    while (idx != eq_write) {
        if (event_queue[idx].window_id == window_id) {
            int cur = idx;
            while (cur != eq_write) {
                int next = (cur + 1) % EVENT_QUEUE_SIZE;
                if (next == eq_write) break;
                event_queue[cur] = event_queue[next];
                cur = next;
            }
            eq_write = (eq_write + EVENT_QUEUE_SIZE - 1) % EVENT_QUEUE_SIZE;
            // Do not advance idx; a new entry now occupies this slot.
            continue;
        }
        idx = (idx + 1) % EVENT_QUEUE_SIZE;
    }
    irq_restore(irq);
}

int gui_event_has_events(void) {
    uint64_t irq = irq_save();
    int has = (eq_read != eq_write);
    irq_restore(irq);
    return has;
}
