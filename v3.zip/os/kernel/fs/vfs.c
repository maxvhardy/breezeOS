#include "fs/vfs.h"
#include "mm/heap.h"
#include "lib/string.h"

static struct vfs_ops *root_fs = NULL;

void vfs_init(void) {
    root_fs = NULL;
}

void vfs_register_fs(struct vfs_ops *ops) {
    root_fs = ops;
}

struct vfs_node *vfs_open(const char *path, int flags) {
    if (!root_fs || !root_fs->open) return NULL;

    struct vfs_node *node = kcalloc(1, sizeof(struct vfs_node));
    if (!node) return NULL;

    node->ops = root_fs;
    node->flags = flags;
    node->offset = 0;
    node->dir_index = 0;
    strncpy(node->name, path, MAX_NAME);

    if (root_fs->open(node, flags) < 0) {
        kfree(node);
        return NULL;
    }

    return node;
}

void vfs_close(struct vfs_node *node) {
    if (!node) return;
    if (node->ops && node->ops->close) {
        node->ops->close(node);
    }
    kfree(node);
}

ssize_t vfs_read(struct vfs_node *node, void *buf, size_t count) {
    if (!node || !node->ops || !node->ops->read) return -1;
    return node->ops->read(node, buf, count);
}

ssize_t vfs_write(struct vfs_node *node, const void *buf, size_t count) {
    if (!node || !node->ops || !node->ops->write) return -1;
    return node->ops->write(node, buf, count);
}

int vfs_readdir(struct vfs_node *node, struct dirent *entry) {
    if (!node || !node->ops || !node->ops->readdir) return -1;
    return node->ops->readdir(node, entry);
}

int vfs_mkdir(const char *path) {
    if (!root_fs || !root_fs->mkdir) return -1;
    return root_fs->mkdir(path);
}

int vfs_rmdir(const char *path) {
    if (!root_fs || !root_fs->rmdir) return -1;
    return root_fs->rmdir(path);
}

int vfs_unlink(const char *path) {
    if (!root_fs || !root_fs->unlink) return -1;
    return root_fs->unlink(path);
}

int vfs_stat(const char *path, struct stat *st) {
    if (!root_fs || !root_fs->stat) return -1;
    return root_fs->stat(path, st);
}

int64_t vfs_lseek(struct vfs_node *node, int64_t offset, int whence) {
    if (!node || !node->ops || !node->ops->lseek) return -1;
    return node->ops->lseek(node, offset, whence);
}

int vfs_rename(const char *oldpath, const char *newpath) {
    if (!root_fs || !root_fs->rename) return -1;
    return root_fs->rename(oldpath, newpath);
}

int vfs_truncate(const char *path, uint32_t length) {
    if (!root_fs || !root_fs->truncate) return -1;
    return root_fs->truncate(path, length);
}

int vfs_chmod(const char *path, uint32_t mode) {
    if (!root_fs || !root_fs->chmod) return -1;
    return root_fs->chmod(path, mode);
}
