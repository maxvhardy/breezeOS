#include "drivers/e1000.h"

#include "arch/paging.h"
#include "mm/vmm.h"
#include "lib/string.h"
#include "lib/printf.h"

#define E1000_MMIO_SIZE 0x20000

// Device control / status
#define E1000_REG_CTRL   0x0000
#define E1000_REG_STATUS 0x0008
#define E1000_REG_IMS    0x00D0
#define E1000_REG_IMC    0x00D8
#define E1000_REG_ICR    0x00C0

// RX path
#define E1000_REG_RCTL   0x0100
#define E1000_REG_RDBAL  0x2800
#define E1000_REG_RDBAH  0x2804
#define E1000_REG_RDLEN  0x2808
#define E1000_REG_RDH    0x2810
#define E1000_REG_RDT    0x2818

// TX path
#define E1000_REG_TCTL   0x0400
#define E1000_REG_TIPG   0x0410
#define E1000_REG_TDBAL  0x3800
#define E1000_REG_TDBAH  0x3804
#define E1000_REG_TDLEN  0x3808
#define E1000_REG_TDH    0x3810
#define E1000_REG_TDT    0x3818

// MAC
#define E1000_REG_RAL0   0x5400
#define E1000_REG_RAH0   0x5404

// CTRL bits
#define E1000_CTRL_RST   (1U << 26)

// STATUS bits
#define E1000_STATUS_LU  (1U << 1)

// RCTL bits
#define E1000_RCTL_EN    (1U << 1)
#define E1000_RCTL_BAM   (1U << 15)
#define E1000_RCTL_SECRC (1U << 26)

// TCTL bits
#define E1000_TCTL_EN    (1U << 1)
#define E1000_TCTL_PSP   (1U << 3)
#define E1000_TCTL_CT_SHIFT   4
#define E1000_TCTL_COLD_SHIFT 12

// TX descriptor
#define E1000_TX_CMD_EOP  (1U << 0)
#define E1000_TX_CMD_IFCS (1U << 1)
#define E1000_TX_CMD_RS   (1U << 3)
#define E1000_TX_STATUS_DD (1U << 0)

// RX descriptor
#define E1000_RX_STATUS_DD (1U << 0)

static uint32_t e1000_read_reg(struct e1000_device *dev, uint32_t reg) {
    volatile uint32_t *p = (volatile uint32_t *)(dev->mmio + reg);
    return *p;
}

static void e1000_write_reg(struct e1000_device *dev, uint32_t reg, uint32_t value) {
    volatile uint32_t *p = (volatile uint32_t *)(dev->mmio + reg);
    *p = value;
    (void)e1000_read_reg(dev, E1000_REG_STATUS);
}

static uint64_t virt_to_phys(void *ptr) {
    return paging_get_phys(paging_get_kernel_pml4(), (uint64_t)ptr);
}

static int alloc_rx_tx_memory(struct e1000_device *dev) {
    dev->rx_descs = (struct e1000_rx_desc *)vmm_alloc_pages(1);
    dev->tx_descs = (struct e1000_tx_desc *)vmm_alloc_pages(1);
    if (!dev->rx_descs || !dev->tx_descs) return -1;

    memset(dev->rx_descs, 0, PAGE_SIZE);
    memset(dev->tx_descs, 0, PAGE_SIZE);

    for (int i = 0; i < E1000_RX_DESC_COUNT; i++) {
        dev->rx_buffers[i] = (uint8_t *)vmm_alloc_pages(1);
        if (!dev->rx_buffers[i]) return -1;
        memset(dev->rx_buffers[i], 0, PAGE_SIZE);

        dev->rx_descs[i].addr = virt_to_phys(dev->rx_buffers[i]);
        dev->rx_descs[i].status = 0;
    }

    for (int i = 0; i < E1000_TX_DESC_COUNT; i++) {
        dev->tx_buffers[i] = (uint8_t *)vmm_alloc_pages(1);
        if (!dev->tx_buffers[i]) return -1;
        memset(dev->tx_buffers[i], 0, PAGE_SIZE);

        dev->tx_descs[i].addr = virt_to_phys(dev->tx_buffers[i]);
        dev->tx_descs[i].status = E1000_TX_STATUS_DD;
    }

    return 0;
}

static int e1000_find_pci(struct pci_device *out_dev) {
    if (!out_dev) return -1;

    int count = pci_get_device_count();
    for (int i = 0; i < count; i++) {
        struct pci_device *d = pci_get_device(i);
        if (!d) continue;
        if (d->class_code != 0x02 || d->subclass != 0x00) continue;
        if (d->vendor_id != 0x8086) continue;
        *out_dev = *d;
        return 0;
    }
    return -1;
}

static uint64_t e1000_get_mmio_phys(const struct pci_device *pdev) {
    if (!pdev) return 0;

    uint32_t bar0 = pdev->bar[0];
    if (bar0 & 0x1) return 0; // I/O BAR not supported in this driver

    uint64_t phys = (uint64_t)(bar0 & ~0xFULL);
    if ((bar0 & 0x6) == 0x4) {
        phys |= ((uint64_t)pdev->bar[1]) << 32;
    }
    return phys;
}

static void e1000_enable_busmaster(const struct pci_device *pdev) {
    if (!pdev) return;
    uint32_t cmd = pci_read(pdev->bus, pdev->slot, pdev->func, 0x04);
    cmd |= (1U << 1); // Memory space enable
    cmd |= (1U << 2); // Bus master enable
    pci_write(pdev->bus, pdev->slot, pdev->func, 0x04, cmd);
}

static void e1000_reset(struct e1000_device *dev) {
    uint32_t ctrl = e1000_read_reg(dev, E1000_REG_CTRL);
    e1000_write_reg(dev, E1000_REG_CTRL, ctrl | E1000_CTRL_RST);

    for (int i = 0; i < 20000; i++) {
        if ((e1000_read_reg(dev, E1000_REG_CTRL) & E1000_CTRL_RST) == 0) break;
        io_wait();
    }
}

static void e1000_read_mac(struct e1000_device *dev) {
    uint32_t ral = e1000_read_reg(dev, E1000_REG_RAL0);
    uint32_t rah = e1000_read_reg(dev, E1000_REG_RAH0);

    dev->mac[0] = (uint8_t)(ral & 0xFF);
    dev->mac[1] = (uint8_t)((ral >> 8) & 0xFF);
    dev->mac[2] = (uint8_t)((ral >> 16) & 0xFF);
    dev->mac[3] = (uint8_t)((ral >> 24) & 0xFF);
    dev->mac[4] = (uint8_t)(rah & 0xFF);
    dev->mac[5] = (uint8_t)((rah >> 8) & 0xFF);
}

static int e1000_setup_rx(struct e1000_device *dev) {
    uint64_t rx_desc_phys = virt_to_phys(dev->rx_descs);
    if (!rx_desc_phys) return -1;

    e1000_write_reg(dev, E1000_REG_RDBAL, (uint32_t)(rx_desc_phys & 0xFFFFFFFFULL));
    e1000_write_reg(dev, E1000_REG_RDBAH, (uint32_t)(rx_desc_phys >> 32));
    e1000_write_reg(dev, E1000_REG_RDLEN, E1000_RX_DESC_COUNT * sizeof(struct e1000_rx_desc));
    e1000_write_reg(dev, E1000_REG_RDH, 0);
    e1000_write_reg(dev, E1000_REG_RDT, E1000_RX_DESC_COUNT - 1);
    dev->rx_cur = 0;

    uint32_t rctl = 0;
    rctl |= E1000_RCTL_EN;
    rctl |= E1000_RCTL_BAM;
    rctl |= E1000_RCTL_SECRC;
    e1000_write_reg(dev, E1000_REG_RCTL, rctl);
    return 0;
}

static int e1000_setup_tx(struct e1000_device *dev) {
    uint64_t tx_desc_phys = virt_to_phys(dev->tx_descs);
    if (!tx_desc_phys) return -1;

    e1000_write_reg(dev, E1000_REG_TDBAL, (uint32_t)(tx_desc_phys & 0xFFFFFFFFULL));
    e1000_write_reg(dev, E1000_REG_TDBAH, (uint32_t)(tx_desc_phys >> 32));
    e1000_write_reg(dev, E1000_REG_TDLEN, E1000_TX_DESC_COUNT * sizeof(struct e1000_tx_desc));
    e1000_write_reg(dev, E1000_REG_TDH, 0);
    e1000_write_reg(dev, E1000_REG_TDT, 0);

    uint32_t tctl = 0;
    tctl |= E1000_TCTL_EN;
    tctl |= E1000_TCTL_PSP;
    tctl |= (0x10U << E1000_TCTL_CT_SHIFT);
    tctl |= (0x40U << E1000_TCTL_COLD_SHIFT);
    e1000_write_reg(dev, E1000_REG_TCTL, tctl);
    e1000_write_reg(dev, E1000_REG_TIPG, 0x0060200A);
    return 0;
}

void e1000_update_link(struct e1000_device *dev) {
    if (!dev || !dev->present) return;
    dev->link_up = (e1000_read_reg(dev, E1000_REG_STATUS) & E1000_STATUS_LU) != 0;
}

int e1000_init(struct e1000_device *dev) {
    if (!dev) return -1;
    memset(dev, 0, sizeof(*dev));

    if (e1000_find_pci(&dev->pci) < 0) {
        kprintf("[NET] No Intel e1000-class adapter detected\n");
        return -1;
    }

    e1000_enable_busmaster(&dev->pci);

    uint64_t mmio_phys = e1000_get_mmio_phys(&dev->pci);
    if (!mmio_phys) {
        kprintf("[NET] e1000 has no MMIO BAR\n");
        return -1;
    }

    dev->mmio_size = E1000_MMIO_SIZE;
    dev->mmio = (volatile uint8_t *)vmm_map_phys(
        mmio_phys, dev->mmio_size, PTE_PRESENT | PTE_WRITABLE | PTE_NOCACHE
    );
    if (!dev->mmio) {
        kprintf("[NET] Failed to map e1000 MMIO\n");
        return -1;
    }

    e1000_reset(dev);

    // Disable interrupts; networking currently uses polling.
    e1000_write_reg(dev, E1000_REG_IMC, 0xFFFFFFFFU);
    e1000_write_reg(dev, E1000_REG_IMS, 0);
    (void)e1000_read_reg(dev, E1000_REG_ICR);

    if (alloc_rx_tx_memory(dev) < 0) {
        kprintf("[NET] Failed to allocate e1000 rings\n");
        return -1;
    }
    if (e1000_setup_rx(dev) < 0 || e1000_setup_tx(dev) < 0) {
        kprintf("[NET] Failed to setup e1000 rings\n");
        return -1;
    }

    e1000_read_mac(dev);
    e1000_update_link(dev);
    dev->present = true;

    kprintf("[NET] e1000 %02x:%02x.%u  MAC %02x:%02x:%02x:%02x:%02x:%02x  link=%s\n",
            dev->pci.bus, dev->pci.slot, dev->pci.func,
            dev->mac[0], dev->mac[1], dev->mac[2],
            dev->mac[3], dev->mac[4], dev->mac[5],
            dev->link_up ? "up" : "down");
    return 0;
}

int e1000_send(struct e1000_device *dev, const void *data, size_t len) {
    if (!dev || !dev->present || !data || len == 0) return -1;
    if (len > E1000_PKT_BUF_SIZE) return -1;

    uint32_t tail = e1000_read_reg(dev, E1000_REG_TDT) % E1000_TX_DESC_COUNT;
    struct e1000_tx_desc *desc = &dev->tx_descs[tail];

    if (!(desc->status & E1000_TX_STATUS_DD)) return -1;

    memcpy(dev->tx_buffers[tail], data, len);

    desc->length = (uint16_t)len;
    desc->cmd = E1000_TX_CMD_EOP | E1000_TX_CMD_IFCS | E1000_TX_CMD_RS;
    desc->status = 0;

    e1000_write_reg(dev, E1000_REG_TDT, (tail + 1) % E1000_TX_DESC_COUNT);

    for (int spin = 0; spin < 100000; spin++) {
        if (desc->status & E1000_TX_STATUS_DD) return 0;
        io_wait();
    }

    return -1;
}

int e1000_recv(struct e1000_device *dev, void *buf, size_t buf_sz, size_t *out_len) {
    if (!dev || !dev->present || !buf || !out_len) return -1;

    struct e1000_rx_desc *desc = &dev->rx_descs[dev->rx_cur];
    if (!(desc->status & E1000_RX_STATUS_DD)) {
        *out_len = 0;
        return 0;
    }

    size_t len = desc->length;
    if (len > buf_sz) len = buf_sz;
    memcpy(buf, dev->rx_buffers[dev->rx_cur], len);

    desc->status = 0;
    e1000_write_reg(dev, E1000_REG_RDT, dev->rx_cur);
    dev->rx_cur = (dev->rx_cur + 1) % E1000_RX_DESC_COUNT;

    *out_len = len;
    return 1;
}
