#pragma once
#include "include/types.h"

void keyboard_init(void);
void keyboard_process_scancode(uint8_t scancode);
char kbd_getchar(void);
int  kbd_has_key(void);
uint8_t kbd_get_scancode(void);
int  kbd_is_shift(void);
int  kbd_is_ctrl(void);
int  kbd_is_alt(void);
