#include "drivers/vbe.h"
#include "arch/paging.h"
#include "mm/vmm.h"
#include "mm/heap.h"
#include "lib/string.h"
#include "lib/printf.h"

static uint8_t *framebuffer;
static uint32_t *backbuffer;
static uint32_t fb_width, fb_height, fb_pitch, fb_bpp;
static uint32_t bb_pitch;
static int vbe_ready = 0;

void vbe_init(struct boot_info *boot) {
    if (!boot->vbe_available) {
        kprintf("VBE: Not available, using text mode\n");
        return;
    }

    fb_width  = boot->fb_width;
    fb_height = boot->fb_height;
    fb_pitch  = boot->fb_pitch;
    fb_bpp    = boot->fb_bpp;

    if (fb_bpp != 24 && fb_bpp != 32) {
        kprintf("VBE: Unsupported bpp=%d\n", fb_bpp);
        return;
    }

    bb_pitch = fb_width * sizeof(uint32_t);

    uint64_t fb_phys = boot->fb_addr_low | ((uint64_t)boot->fb_addr_high << 32);
    size_t fb_size = fb_pitch * fb_height;
    size_t bb_size = (size_t)bb_pitch * fb_height;

    // Map framebuffer into kernel virtual space
    framebuffer = (uint8_t *)vmm_map_phys(fb_phys, fb_size,
                                          PTE_PRESENT | PTE_WRITABLE | PTE_NOCACHE);
    if (!framebuffer) {
        kprintf("VBE: Failed to map framebuffer\n");
        return;
    }

    // Allocate back buffer
    size_t bb_pages = (bb_size + PAGE_SIZE - 1) / PAGE_SIZE;
    backbuffer = (uint32_t *)vmm_alloc_pages(bb_pages);
    if (!backbuffer) {
        kprintf("VBE: Failed to allocate back buffer\n");
        return;
    }

    // Clear framebuffer
    memset(backbuffer, 0, bb_size);

    vbe_ready = 1;
    vbe_swap_buffers();
    kprintf("VBE: %dx%dx%d framebuffer at %p\n",
            fb_width, fb_height, fb_bpp, framebuffer);
}

int vbe_available(void) { return vbe_ready; }

void vbe_put_pixel(int x, int y, uint32_t color) {
    if (!vbe_ready || x < 0 || y < 0 ||
        (uint32_t)x >= fb_width || (uint32_t)y >= fb_height) return;
    uint32_t *row = (uint32_t *)((uint8_t *)backbuffer + (size_t)y * bb_pitch);
    row[x] = color;
}

uint32_t vbe_get_pixel(int x, int y) {
    if (!vbe_ready || x < 0 || y < 0 ||
        (uint32_t)x >= fb_width || (uint32_t)y >= fb_height) return 0;
    uint32_t *row = (uint32_t *)((uint8_t *)backbuffer + (size_t)y * bb_pitch);
    return row[x];
}

void vbe_fill_rect(int x, int y, int w, int h, uint32_t color) {
    if (!vbe_ready) return;

    int x0 = x < 0 ? 0 : x;
    int y0 = y < 0 ? 0 : y;
    int x1 = x + w > (int)fb_width  ? (int)fb_width  : x + w;
    int y1 = y + h > (int)fb_height ? (int)fb_height : y + h;

    for (int row = y0; row < y1; row++) {
        uint32_t *p = (uint32_t *)((uint8_t *)backbuffer + (size_t)row * bb_pitch) + x0;
        for (int col = x0; col < x1; col++) {
            *p++ = color;
        }
    }
}

void vbe_blit(int x, int y, int w, int h, const uint32_t *pixels) {
    if (!vbe_ready || !pixels || w <= 0 || h <= 0) return;

    int x0 = x;
    int y0 = y;
    int x1 = x + w;
    int y1 = y + h;

    if (x1 <= 0 || y1 <= 0 || x0 >= (int)fb_width || y0 >= (int)fb_height) return;

    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > (int)fb_width) x1 = (int)fb_width;
    if (y1 > (int)fb_height) y1 = (int)fb_height;

    int src_x0 = x0 - x;
    int src_y0 = y0 - y;

    for (int row = y0; row < y1; row++) {
        uint32_t *dst = (uint32_t *)((uint8_t *)backbuffer + (size_t)row * bb_pitch);
        const uint32_t *src = pixels + (size_t)(src_y0 + (row - y0)) * (size_t)w;

        for (int col = x0; col < x1; col++) {
            uint32_t p = src[src_x0 + (col - x0)];
            if (p & 0xFF000000) { // Simple alpha check (non-zero = draw)
                dst[col] = p & 0x00FFFFFF;
            }
        }
    }
}

void vbe_swap_buffers(void) {
    if (!vbe_ready) return;

    if (fb_bpp == 32) {
        for (uint32_t y = 0; y < fb_height; y++) {
            uint8_t *dst = framebuffer + (size_t)y * fb_pitch;
            uint8_t *src = (uint8_t *)backbuffer + (size_t)y * bb_pitch;
            memcpy(dst, src, fb_width * sizeof(uint32_t));
        }
        return;
    }

    for (uint32_t y = 0; y < fb_height; y++) {
        uint8_t *dst = framebuffer + (size_t)y * fb_pitch;
        uint32_t *src = (uint32_t *)((uint8_t *)backbuffer + (size_t)y * bb_pitch);
        for (uint32_t x = 0; x < fb_width; x++) {
            uint32_t c = src[x];
            *dst++ = (uint8_t)(c & 0xFF);
            *dst++ = (uint8_t)((c >> 8) & 0xFF);
            *dst++ = (uint8_t)((c >> 16) & 0xFF);
        }
    }
}

void vbe_copy_rect(int dx, int dy, int sx, int sy, int w, int h) {
    if (!vbe_ready || w <= 0 || h <= 0) return;
    if (dx < 0 || dy < 0 || sx < 0 || sy < 0) return;
    if (dx + w > (int)fb_width || sx + w > (int)fb_width) return;
    if (dy + h > (int)fb_height || sy + h > (int)fb_height) return;

    // Use memmove semantics to support overlap safely.
    if (dy > sy) {
        for (int row = h - 1; row >= 0; row--) {
            uint32_t *dst = (uint32_t *)((uint8_t *)backbuffer + (size_t)(dy + row) * bb_pitch) + dx;
            uint32_t *src = (uint32_t *)((uint8_t *)backbuffer + (size_t)(sy + row) * bb_pitch) + sx;
            memmove(dst, src, (size_t)w * sizeof(uint32_t));
        }
    } else {
        for (int row = 0; row < h; row++) {
            uint32_t *dst = (uint32_t *)((uint8_t *)backbuffer + (size_t)(dy + row) * bb_pitch) + dx;
            uint32_t *src = (uint32_t *)((uint8_t *)backbuffer + (size_t)(sy + row) * bb_pitch) + sx;
            memmove(dst, src, (size_t)w * sizeof(uint32_t));
        }
    }
}

void vbe_scroll_up(int lines, uint32_t bg_color) {
    if (!vbe_ready) return;
    if (lines <= 0) return;
    if ((uint32_t)lines >= fb_height) {
        vbe_fill_rect(0, 0, (int)fb_width, (int)fb_height, bg_color);
        return;
    }

    size_t row_bytes = bb_pitch;
    memmove(backbuffer,
            (uint8_t *)backbuffer + (size_t)lines * row_bytes,
            (size_t)(fb_height - (uint32_t)lines) * row_bytes);
    vbe_fill_rect(0, (int)fb_height - lines, (int)fb_width, lines, bg_color);
}

uint32_t *vbe_get_framebuffer(void) { return (uint32_t *)framebuffer; }
uint32_t *vbe_get_backbuffer(void) { return backbuffer; }
uint32_t vbe_get_width(void) { return fb_width; }
uint32_t vbe_get_height(void) { return fb_height; }
uint32_t vbe_get_pitch(void) { return fb_pitch; }
uint32_t vbe_get_bpp(void) { return fb_bpp; }
