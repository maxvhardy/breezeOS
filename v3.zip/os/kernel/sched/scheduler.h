#pragma once
#include "arch/idt.h"

void scheduler_init(void);
void schedule(void);
void schedule_tick(struct registers *regs);

// Stats for task manager
uint32_t scheduler_get_context_switches(void);
uint32_t scheduler_get_uptime_ticks(void);
