#include "mm/vmm.h"
#include "mm/pmm.h"
#include "arch/paging.h"
#include "lib/string.h"

// Kernel virtual address allocator
// The bootloader only pre-maps the first 1GB in higher half using huge pages.
// Start dynamic mappings above that range to avoid colliding with huge-page entries.
#define VMM_KERNEL_HEAP_START 0xFFFF800040000000ULL
static uint64_t vmm_next_vaddr = VMM_KERNEL_HEAP_START;

void vmm_init(void) {
    vmm_next_vaddr = VMM_KERNEL_HEAP_START;
}

void *vmm_alloc_pages(size_t count) {
    if (count == 0) return NULL;

    uint64_t vaddr = vmm_next_vaddr;
    uint64_t *pml4 = paging_get_kernel_pml4();
    size_t mapped = 0;

    for (size_t i = 0; i < count; i++) {
        uint64_t phys = pmm_alloc_page();
        if (!phys) goto rollback;
        paging_map_page(pml4, vaddr + i * PAGE_SIZE, phys,
                        PTE_PRESENT | PTE_WRITABLE);
        uint64_t mapped_phys = paging_get_phys(pml4, vaddr + i * PAGE_SIZE);
        if ((mapped_phys & PTE_ADDR_MASK) != (phys & PTE_ADDR_MASK)) {
            pmm_free_page(phys);
            goto rollback;
        }
        memset((void *)(vaddr + i * PAGE_SIZE), 0, PAGE_SIZE);
        mapped++;
    }

    vmm_next_vaddr += count * PAGE_SIZE;
    return (void *)vaddr;

rollback:
    for (size_t i = 0; i < mapped; i++) {
        uint64_t va = vaddr + i * PAGE_SIZE;
        uint64_t phys = paging_get_phys(pml4, va);
        if (phys) {
            pmm_free_page(phys & PTE_ADDR_MASK);
            paging_unmap_page(pml4, va);
        }
    }
    return NULL;
}

void vmm_free_pages(void *virt, size_t count) {
    uint64_t *pml4 = paging_get_kernel_pml4();
    uint64_t vaddr = (uint64_t)virt;

    for (size_t i = 0; i < count; i++) {
        uint64_t phys = paging_get_phys(pml4, vaddr + i * PAGE_SIZE);
        if (phys) {
            pmm_free_page(phys & ~0xFFF);
            paging_unmap_page(pml4, vaddr + i * PAGE_SIZE);
        }
    }
}

void *vmm_map_phys(uint64_t phys, size_t size, uint64_t flags) {
    size_t pages = (size + PAGE_SIZE - 1) / PAGE_SIZE;
    uint64_t vaddr = vmm_next_vaddr;
    uint64_t *pml4 = paging_get_kernel_pml4();

    uint64_t phys_page = phys & ~(PAGE_SIZE - 1);
    uint64_t offset = phys & (PAGE_SIZE - 1);

    for (size_t i = 0; i < pages; i++) {
        paging_map_page(pml4, vaddr + i * PAGE_SIZE,
                        phys_page + i * PAGE_SIZE, flags);
    }

    vmm_next_vaddr += pages * PAGE_SIZE;
    return (void *)(vaddr + offset);
}

void vmm_unmap(void *virt, size_t size) {
    size_t pages = (size + PAGE_SIZE - 1) / PAGE_SIZE;
    uint64_t *pml4 = paging_get_kernel_pml4();
    uint64_t vaddr = (uint64_t)virt & ~(PAGE_SIZE - 1);

    for (size_t i = 0; i < pages; i++) {
        paging_unmap_page(pml4, vaddr + i * PAGE_SIZE);
    }
}

int vmm_map_user_page(uint64_t *pml4, uint64_t virt, uint64_t flags) {
    uint64_t phys = pmm_alloc_page();
    if (!phys) return -1;
    paging_map_page(pml4, virt, phys, flags | PTE_USER);
    uint64_t mapped_phys = paging_get_phys(pml4, virt & ~(PAGE_SIZE - 1));
    if ((mapped_phys & PTE_ADDR_MASK) != (phys & PTE_ADDR_MASK)) {
        pmm_free_page(phys);
        return -1;
    }
    memset(PHYS_TO_VIRT(phys), 0, PAGE_SIZE);
    return 0;
}

int vmm_map_user_pages(uint64_t *pml4, uint64_t virt, size_t count, uint64_t flags) {
    for (size_t i = 0; i < count; i++) {
        if (vmm_map_user_page(pml4, virt + i * PAGE_SIZE, flags) < 0) {
            for (size_t j = 0; j < i; j++) {
                uint64_t va = virt + j * PAGE_SIZE;
                uint64_t phys = paging_get_phys(pml4, va);
                if (phys) {
                    pmm_free_page(phys & PTE_ADDR_MASK);
                    paging_unmap_page(pml4, va);
                }
            }
            return -1;
        }
    }
    return 0;
}
