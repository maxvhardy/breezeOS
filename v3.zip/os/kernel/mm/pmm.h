#pragma once
#include "include/types.h"
#include "include/boot.h"

void pmm_init(struct boot_info *boot, struct e820_entry *mmap);
uint64_t pmm_alloc_page(void);
void pmm_free_page(uint64_t phys_addr);
uint64_t pmm_alloc_pages(size_t count);
void pmm_free_pages(uint64_t phys_addr, size_t count);
uint64_t pmm_get_total_memory(void);
uint64_t pmm_get_free_memory(void);
