#pragma once
#include "include/types.h"
#include "fs/vfs.h"
#include "arch/idt.h"

#define MAX_PROCESSES 64
#define KERNEL_STACK_SIZE (8 * PAGE_SIZE)
#define USER_STACK_SIZE   (256 * PAGE_SIZE)
#define USER_STACK_TOP    0x7FFFFFFFE000ULL
#define USER_HEAP_START   0x10000000ULL
#define USER_HEAP_GUARD   (16 * PAGE_SIZE)
#define USER_HEAP_LIMIT   (USER_STACK_TOP - USER_STACK_SIZE - USER_HEAP_GUARD)

// Process priorities (lower = higher priority)
#define PRIO_REALTIME  0
#define PRIO_HIGH      1
#define PRIO_NORMAL    2
#define PRIO_LOW       3
#define PRIO_IDLE      4
#define PRIO_LEVELS    5

// Signals
#define SIGTERM   1
#define SIGKILL   2
#define SIGCHLD   3
#define SIGUSR1   4
#define SIGUSR2   5
#define SIGSTOP   6
#define SIGCONT   7
#define NSIG      8

#define SIG_DFL   ((sig_handler_t)0)
#define SIG_IGN   ((sig_handler_t)1)

typedef void (*sig_handler_t)(int);

// Pipe constants
#define PIPE_BUF_SIZE  4096
#define MAX_PIPES      16

typedef enum {
    PROC_UNUSED = 0,
    PROC_READY,
    PROC_RUNNING,
    PROC_BLOCKED,
    PROC_SLEEPING,
    PROC_ZOMBIE,
    PROC_STOPPED
} proc_state_t;

struct pipe {
    uint8_t  buf[PIPE_BUF_SIZE];
    uint32_t read_pos;
    uint32_t write_pos;
    uint32_t count;
    int      readers;
    int      writers;
    int      in_use;
};

struct process {
    int pid;
    proc_state_t state;
    uint64_t *pml4;              // Page table root (virtual address)
    uint64_t kernel_rsp;         // Saved kernel stack pointer
    uint64_t kernel_stack_base;  // Base of kernel stack allocation
    uint64_t user_heap_end;      // Current end of user heap (for sbrk)
    uint64_t sleep_until;        // For sleep(), tick count to wake
    int exit_code;
    int parent_pid;
    char cwd[MAX_PATH];
    struct vfs_node *fds[MAX_FDS];
    char name[64];

    // Priority scheduling
    int priority;                // PRIO_REALTIME..PRIO_IDLE
    int base_priority;           // Original priority (before aging)
    uint32_t cpu_ticks;          // Ticks used in current epoch
    uint32_t total_ticks;        // Total CPU ticks used

    // Signals
    uint32_t sig_pending;        // Bitmask of pending signals
    sig_handler_t sig_handlers[NSIG];

    // Pipe file descriptors (index into global pipe table, -1 = not a pipe)
    int pipe_fd_pipe[MAX_FDS];   // Which pipe index, or -1
    int pipe_fd_end[MAX_FDS];    // 0 = read end, 1 = write end
};

void process_init(void);
struct process *process_current(void);
struct process *process_get(int pid);
int process_create_kernel(void (*entry)(void), const char *name);
int process_create_user(const char *path);
int process_fork(void);
int process_exec(const char *path);
void process_exit(int code);
int process_waitpid(int pid, int *status);
int64_t process_sbrk(struct process *proc, int64_t incr);
void process_sleep(uint64_t ms);
void process_set_current(int pid);
void process_reap_kernel_zombies(int skip_pid);

// Signals
int process_kill(int pid, int sig);
void process_check_signals(struct process *proc);
int process_signal(int pid, int sig, sig_handler_t handler);

// Pipes
int pipe_create(int fds[2]);
ssize_t pipe_read(int pipe_idx, void *buf, size_t count);
ssize_t pipe_write(int pipe_idx, const void *buf, size_t count);
void pipe_close_end(int pipe_idx, int end);

// Priority
void process_set_priority(int pid, int priority);
int process_get_priority(int pid);
