#include "sched/process.h"
#include "sched/scheduler.h"
#include "arch/paging.h"
#include "arch/gdt.h"
#include "arch/tss.h"
#include "mm/pmm.h"
#include "mm/vmm.h"
#include "mm/heap.h"
#include "lib/string.h"
#include "lib/printf.h"
#include "elf.h"
#include "gui/window.h"

static struct process processes[MAX_PROCESSES];
static int current_pid = -1;
static int next_pid = 1;

// Global pipe table
static struct pipe pipes[MAX_PIPES];

extern void context_switch(uint64_t *old_rsp, uint64_t new_rsp, uint64_t new_cr3);
extern void enter_usermode(uint64_t rip, uint64_t rsp, uint64_t rflags);

static int write_user_bytes(uint64_t *pml4, uint64_t dst, const void *src, size_t len) {
    if (!pml4 || !src) return -1;
    if (len == 0) return 0;

    const uint8_t *in = (const uint8_t *)src;
    while (len > 0) {
        uint64_t page_va = dst & ~(uint64_t)(PAGE_SIZE - 1);
        uint64_t page_off = dst & (uint64_t)(PAGE_SIZE - 1);
        uint64_t phys = paging_get_phys(pml4, page_va);
        if (!phys) return -1;

        size_t chunk = PAGE_SIZE - (size_t)page_off;
        if (chunk > len) chunk = len;

        uint8_t *kptr = (uint8_t *)(PHYS_TO_VIRT(phys & PTE_ADDR_MASK) + page_off);
        memcpy(kptr, in, chunk);

        dst += chunk;
        in += chunk;
        len -= chunk;
    }

    return 0;
}

static int setup_user_entry_stack(struct process *proc, const char *path, uint64_t *out_rsp) {
    if (!proc || !proc->pml4 || !out_rsp) return -1;

    const char *arg0 = "app";
    if (path && path[0]) {
        const char *slash = strrchr(path, '/');
        arg0 = (slash && slash[1]) ? slash + 1 : path;
    }

    char arg0_buf[64];
    strncpy(arg0_buf, arg0, sizeof(arg0_buf) - 1);
    arg0_buf[sizeof(arg0_buf) - 1] = '\0';
    size_t arg0_len = strlen(arg0_buf) + 1;

    uint64_t stack_bottom = USER_STACK_TOP - USER_STACK_SIZE;
    uint64_t arg0_addr = USER_STACK_TOP - arg0_len;
    if (arg0_addr < stack_bottom) return -1;

    if (write_user_bytes(proc->pml4, arg0_addr, arg0_buf, arg0_len) < 0) return -1;

    uint64_t stack_aligned = arg0_addr & ~(uint64_t)0xF;
    if (stack_aligned < stack_bottom + 4 * sizeof(uint64_t)) return -1;
    uint64_t entry_rsp = stack_aligned - 4 * sizeof(uint64_t);

    uint64_t frame[4];
    frame[0] = 1;         // argc
    frame[1] = arg0_addr; // argv[0]
    frame[2] = 0;         // argv[1] = NULL
    frame[3] = 0;         // envp[0] = NULL

    if (write_user_bytes(proc->pml4, entry_rsp, frame, sizeof(frame)) < 0) return -1;
    *out_rsp = entry_rsp;
    return 0;
}

void process_init(void) {
    memset(processes, 0, sizeof(processes));
    memset(pipes, 0, sizeof(pipes));

    // Create kernel idle process (pid 0)
    processes[0].pid = 0;
    processes[0].state = PROC_RUNNING;
    processes[0].pml4 = paging_get_kernel_pml4();
    processes[0].priority = PRIO_IDLE;
    processes[0].base_priority = PRIO_IDLE;
    strcpy(processes[0].cwd, "/");
    strcpy(processes[0].name, "idle");
    current_pid = 0;

    // Init pipe_fd_pipe to -1 for idle process
    for (int i = 0; i < MAX_FDS; i++) {
        processes[0].pipe_fd_pipe[i] = -1;
    }
}

struct process *process_current(void) {
    if (current_pid < 0 || current_pid >= MAX_PROCESSES) return NULL;
    return &processes[current_pid];
}

struct process *process_get(int pid) {
    if (pid < 0 || pid >= MAX_PROCESSES) return NULL;
    if (processes[pid].state == PROC_UNUSED) return NULL;
    return &processes[pid];
}

void process_set_current(int pid) {
    current_pid = pid;
}

void process_reap_kernel_zombies(int skip_pid) {
    for (int pid = 1; pid < MAX_PROCESSES; pid++) {
        if (pid == skip_pid) continue;

        struct process *p = process_get(pid);
        if (!p) continue;
        if (p->parent_pid != 0) continue;
        if (p->state != PROC_ZOMBIE) continue;

        if (p->pml4 != paging_get_kernel_pml4()) {
            paging_destroy_address_space(p->pml4);
        }
        if (p->kernel_stack_base) {
            vmm_free_pages((void *)p->kernel_stack_base,
                           KERNEL_STACK_SIZE / PAGE_SIZE);
        }
        memset(p, 0, sizeof(*p));
        p->state = PROC_UNUSED;
    }
}

static int alloc_pid(void) {
    for (int i = 0; i < MAX_PROCESSES; i++) {
        int pid = (next_pid + i) % MAX_PROCESSES;
        if (pid == 0) continue; // Skip pid 0
        if (processes[pid].state == PROC_UNUSED) {
            next_pid = pid + 1;
            return pid;
        }
    }
    return -1;
}

static int clone_user_page(uint64_t *dst_pml4, uint64_t virt, uint64_t src_entry) {
    uint64_t src_phys = src_entry & PTE_ADDR_MASK;
    uint64_t flags = src_entry & ~PTE_ADDR_MASK;

    uint64_t dst_phys = pmm_alloc_page();
    if (!dst_phys) return -1;

    memcpy(PHYS_TO_VIRT(dst_phys), PHYS_TO_VIRT(src_phys), PAGE_SIZE);
    paging_map_page(dst_pml4, virt, dst_phys, flags);
    return 0;
}

static int clone_user_address_space(uint64_t *src_pml4, uint64_t *dst_pml4) {
    for (int i = 0; i < 256; i++) {
        if (!(src_pml4[i] & PTE_PRESENT)) continue;

        uint64_t *src_pdpt = (uint64_t *)PHYS_TO_VIRT(src_pml4[i] & PTE_ADDR_MASK);
        for (int j = 0; j < 512; j++) {
            if (!(src_pdpt[j] & PTE_PRESENT)) continue;
            if (src_pdpt[j] & PTE_HUGE) {
                return -1; // 1GB huge user pages are unsupported here
            }

            uint64_t *src_pd = (uint64_t *)PHYS_TO_VIRT(src_pdpt[j] & PTE_ADDR_MASK);
            for (int k = 0; k < 512; k++) {
                if (!(src_pd[k] & PTE_PRESENT)) continue;

                uint64_t base_va = ((uint64_t)i << 39) |
                                   ((uint64_t)j << 30) |
                                   ((uint64_t)k << 21);

                if (src_pd[k] & PTE_HUGE) {
                    if (!(src_pd[k] & PTE_USER)) continue;

                    uint64_t src_base = src_pd[k] & PTE_ADDR_MASK;
                    uint64_t page_flags = (src_pd[k] & ~PTE_ADDR_MASK) & ~PTE_HUGE;

                    for (int page = 0; page < 512; page++) {
                        uint64_t va = base_va + (uint64_t)page * PAGE_SIZE;
                        uint64_t src_entry = (src_base + (uint64_t)page * PAGE_SIZE) | page_flags;
                        if (clone_user_page(dst_pml4, va, src_entry) < 0) {
                            return -1;
                        }
                    }
                    continue;
                }

                uint64_t *src_pt = (uint64_t *)PHYS_TO_VIRT(src_pd[k] & PTE_ADDR_MASK);
                for (int l = 0; l < 512; l++) {
                    uint64_t src_pte = src_pt[l];
                    if (!(src_pte & PTE_PRESENT)) continue;
                    if (!(src_pte & PTE_USER)) continue;

                    uint64_t va = base_va | ((uint64_t)l << 12);
                    if (clone_user_page(dst_pml4, va, src_pte) < 0) {
                        return -1;
                    }
                }
            }
        }
    }

    return 0;
}

int process_create_kernel(void (*entry)(void), const char *name) {
    int pid = alloc_pid();
    if (pid < 0) return -1;

    struct process *proc = &processes[pid];
    memset(proc, 0, sizeof(struct process));
    proc->pid = pid;
    proc->state = PROC_READY;
    proc->pml4 = paging_get_kernel_pml4();
    proc->parent_pid = current_pid;
    proc->priority = PRIO_NORMAL;
    proc->base_priority = PRIO_NORMAL;
    strcpy(proc->cwd, "/");
    strncpy(proc->name, name, sizeof(proc->name) - 1);

    // Init pipe fds
    for (int i = 0; i < MAX_FDS; i++) {
        proc->pipe_fd_pipe[i] = -1;
    }

    // Allocate kernel stack
    proc->kernel_stack_base = (uint64_t)vmm_alloc_pages(KERNEL_STACK_SIZE / PAGE_SIZE);
    if (!proc->kernel_stack_base) {
        proc->state = PROC_UNUSED;
        return -1;
    }

    // Set up initial kernel stack for context_switch
    uint64_t stack_top = proc->kernel_stack_base + KERNEL_STACK_SIZE;
    uint64_t *sp = (uint64_t *)stack_top;

    // context_switch expects: return address, then callee-saved regs + flags
    *--sp = (uint64_t)entry;  // Return address (RIP for ret)
    *--sp = 0;    // RBX
    *--sp = 0;    // RBP
    *--sp = 0;    // R12
    *--sp = 0;    // R13
    *--sp = 0;    // R14
    *--sp = 0;    // R15
    *--sp = 0x202; // RFLAGS (IF set)

    proc->kernel_rsp = (uint64_t)sp;

    return pid;
}

int process_create_user(const char *path) {
    int pid = alloc_pid();
    if (pid < 0) return -1;

    struct process *proc = &processes[pid];
    memset(proc, 0, sizeof(struct process));
    proc->pid = pid;
    proc->parent_pid = current_pid;
    proc->priority = PRIO_NORMAL;
    proc->base_priority = PRIO_NORMAL;
    strcpy(proc->cwd, "/");

    // Init pipe fds
    for (int i = 0; i < MAX_FDS; i++) {
        proc->pipe_fd_pipe[i] = -1;
    }

    // Extract filename for process name
    const char *name = strrchr(path, '/');
    strncpy(proc->name, name ? name + 1 : path, sizeof(proc->name) - 1);

    // Create address space
    proc->pml4 = paging_create_address_space();
    if (!proc->pml4) {
        proc->state = PROC_UNUSED;
        return -1;
    }

    // Load ELF binary
    uint64_t entry_point;
    if (elf_load(proc, path, &entry_point) < 0) {
        paging_destroy_address_space(proc->pml4);
        proc->state = PROC_UNUSED;
        kprintf("Failed to load ELF: %s\n", path);
        return -1;
    }

    // Set up user stack
    for (uint64_t i = 0; i < USER_STACK_SIZE / PAGE_SIZE; i++) {
        if (vmm_map_user_page(proc->pml4,
                              USER_STACK_TOP - USER_STACK_SIZE + i * PAGE_SIZE,
                              PTE_PRESENT | PTE_WRITABLE) < 0) {
            paging_destroy_address_space(proc->pml4);
            proc->state = PROC_UNUSED;
            return -1;
        }
    }

    uint64_t user_stack = USER_STACK_TOP;
    if (setup_user_entry_stack(proc, path, &user_stack) < 0) {
        paging_destroy_address_space(proc->pml4);
        proc->state = PROC_UNUSED;
        return -1;
    }

    // Set up user heap
    proc->user_heap_end = USER_HEAP_START;

    // Allocate kernel stack for this process
    proc->kernel_stack_base = (uint64_t)vmm_alloc_pages(KERNEL_STACK_SIZE / PAGE_SIZE);
    if (!proc->kernel_stack_base) {
        paging_destroy_address_space(proc->pml4);
        proc->state = PROC_UNUSED;
        return -1;
    }

    uint64_t kstack_top = proc->kernel_stack_base + KERNEL_STACK_SIZE;

    // Build an initial stack frame that enter_usermode will use
    uint64_t *sp = (uint64_t *)kstack_top;

    extern void user_process_trampoline(void);
    *--sp = (uint64_t)user_process_trampoline;
    *--sp = entry_point;          // RBX (saved, used as arg)
    *--sp = user_stack;           // RBP (saved, used as arg)
    *--sp = 0;                    // R12
    *--sp = 0;                    // R13
    *--sp = 0;                    // R14
    *--sp = 0;                    // R15
    *--sp = 0x202;                // RFLAGS

    proc->kernel_rsp = (uint64_t)sp;
    proc->state = PROC_READY;

    return pid;
}

// Trampoline function - called after context_switch for new user processes
void user_process_trampoline_c(uint64_t entry, uint64_t user_stack) {
    // Update TSS RSP0
    struct process *proc = process_current();
    gdt_set_tss_rsp0(proc->kernel_stack_base + KERNEL_STACK_SIZE);

    // Switch to user's address space
    paging_switch(proc->pml4);

    // Jump to user mode
    enter_usermode(entry, user_stack, 0x202);
}

int process_fork(void) {
    struct process *parent = process_current();
    if (!parent) return -1;

    int child_pid = alloc_pid();
    if (child_pid < 0) return -1;

    struct process *child = &processes[child_pid];
    memcpy(child, parent, sizeof(struct process));
    child->pid = child_pid;
    child->parent_pid = parent->pid;
    child->state = PROC_READY;
    child->cpu_ticks = 0;
    child->sig_pending = 0;

    // Create new address space (copy-on-write would be ideal, but we do full copy)
    child->pml4 = paging_create_address_space();
    if (!child->pml4) {
        child->state = PROC_UNUSED;
        return -1;
    }

    if (clone_user_address_space(parent->pml4, child->pml4) < 0) {
        paging_destroy_address_space(child->pml4);
        child->state = PROC_UNUSED;
        return -1;
    }

    // Allocate new kernel stack
    child->kernel_stack_base = (uint64_t)vmm_alloc_pages(KERNEL_STACK_SIZE / PAGE_SIZE);
    if (!child->kernel_stack_base) {
        paging_destroy_address_space(child->pml4);
        child->state = PROC_UNUSED;
        return -1;
    }

    // Copy kernel stack contents
    memcpy((void *)child->kernel_stack_base,
           (void *)parent->kernel_stack_base, KERNEL_STACK_SIZE);

    // Adjust RSP to point into new stack
    uint64_t rsp_offset = parent->kernel_rsp - parent->kernel_stack_base;
    child->kernel_rsp = child->kernel_stack_base + rsp_offset;

    // Copy file descriptors (simplified: share VFS nodes)
    for (int i = 0; i < MAX_FDS; i++) {
        child->fds[i] = parent->fds[i];
        // Increment pipe reference counts
        if (child->pipe_fd_pipe[i] >= 0) {
            int pi = child->pipe_fd_pipe[i];
            if (child->pipe_fd_end[i] == 0)
                pipes[pi].readers++;
            else
                pipes[pi].writers++;
        }
    }

    return child_pid;
}

int process_exec(const char *path) {
    struct process *proc = process_current();
    if (!proc) return -1;

    // Load new ELF
    uint64_t entry_point;
    if (elf_load(proc, path, &entry_point) < 0) return -1;

    uint64_t user_stack = USER_STACK_TOP;
    if (setup_user_entry_stack(proc, path, &user_stack) < 0) return -1;

    // Reset heap
    proc->user_heap_end = USER_HEAP_START;
    strncpy(proc->name, path, sizeof(proc->name) - 1);

    // Reset signals
    proc->sig_pending = 0;
    for (int i = 0; i < NSIG; i++) {
        proc->sig_handlers[i] = SIG_DFL;
    }

    // Jump to new entry point
    enter_usermode(entry_point, user_stack, 0x202);
    return 0; // Never reached
}

void process_exit(int code) {
    struct process *proc = process_current();
    if (!proc || proc->pid == 0) return;

    proc->exit_code = code;
    proc->state = PROC_ZOMBIE;

    // Close open files and pipes
    for (int i = 3; i < MAX_FDS; i++) {
        if (proc->fds[i]) {
            vfs_close(proc->fds[i]);
            proc->fds[i] = NULL;
        }
        if (proc->pipe_fd_pipe[i] >= 0) {
            pipe_close_end(proc->pipe_fd_pipe[i], proc->pipe_fd_end[i]);
            proc->pipe_fd_pipe[i] = -1;
        }
    }

    // Ensure user-owned GUI windows do not outlive the process.
    window_destroy_by_owner(proc->pid);

    // Send SIGCHLD to parent
    struct process *parent = process_get(proc->parent_pid);
    if (parent) {
        process_kill(proc->parent_pid, SIGCHLD);
        if (parent->state == PROC_BLOCKED) {
            parent->state = PROC_READY;
        }
    }

    // Reparent children to init (pid 1)
    for (int i = 1; i < MAX_PROCESSES; i++) {
        if (processes[i].state != PROC_UNUSED && processes[i].parent_pid == proc->pid) {
            processes[i].parent_pid = 1;
        }
    }
}

int process_waitpid(int pid, int *status) {
    struct process *child = process_get(pid);
    if (!child) return -1;

    while (child->state != PROC_ZOMBIE) {
        process_current()->state = PROC_BLOCKED;
        schedule();
    }

    if (status) *status = child->exit_code;

    // Free child resources
    if (child->pml4 != paging_get_kernel_pml4()) {
        paging_destroy_address_space(child->pml4);
    }
    if (child->kernel_stack_base) {
        vmm_free_pages((void *)child->kernel_stack_base,
                       KERNEL_STACK_SIZE / PAGE_SIZE);
    }
    child->state = PROC_UNUSED;
    return pid;
}

int64_t process_sbrk(struct process *proc, int64_t incr) {
    if (!proc || !proc->pml4) return -1;

    uint64_t old_end = proc->user_heap_end;
    if (incr == 0) return (int64_t)old_end;

    if (incr < 0) {
        uint64_t dec = (uint64_t)(-incr);
        if (dec > old_end - USER_HEAP_START) return -1;

        uint64_t new_end = old_end - dec;
        uint64_t old_page_end = (old_end + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1);
        uint64_t new_page_end = (new_end + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1);

        for (uint64_t addr = new_page_end; addr < old_page_end; addr += PAGE_SIZE) {
            uint64_t phys = paging_get_phys(proc->pml4, addr);
            if (phys) {
                pmm_free_page(phys & PTE_ADDR_MASK);
                paging_unmap_page(proc->pml4, addr);
            }
        }

        proc->user_heap_end = new_end;
        return (int64_t)old_end;
    }

    uint64_t add = (uint64_t)incr;
    if (old_end > USER_HEAP_LIMIT || add > USER_HEAP_LIMIT - old_end) {
        return -1;
    }

    uint64_t new_end = old_end + add;
    uint64_t start_page = (old_end + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1);
    uint64_t end_page = (new_end + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1);

    for (uint64_t addr = start_page; addr < end_page; addr += PAGE_SIZE) {
        if (paging_get_phys(proc->pml4, addr)) continue;
        if (vmm_map_user_page(proc->pml4, addr, PTE_PRESENT | PTE_WRITABLE) < 0) {
            for (uint64_t rollback = start_page; rollback < addr; rollback += PAGE_SIZE) {
                uint64_t phys = paging_get_phys(proc->pml4, rollback);
                if (phys) {
                    pmm_free_page(phys & PTE_ADDR_MASK);
                    paging_unmap_page(proc->pml4, rollback);
                }
            }
            return -1;
        }

    }

    proc->user_heap_end = new_end;
    return (int64_t)old_end;
}

void process_sleep(uint64_t ms) {
    extern uint64_t pit_get_ticks(void);
    struct process *proc = process_current();
    if (!proc) return;

    proc->sleep_until = pit_get_ticks() + (ms * 100) / 1000;
    proc->state = PROC_SLEEPING;
}

// ============================================================
// Signal support
// ============================================================

int process_kill(int pid, int sig) {
    if (sig < 0 || sig >= NSIG) return -1;

    // sig 0 = check if process exists
    if (sig == 0) {
        return process_get(pid) ? 0 : -1;
    }

    struct process *proc = process_get(pid);
    if (!proc) return -1;

    if (sig == SIGKILL) {
        // SIGKILL cannot be caught or ignored - terminate immediately
        proc->exit_code = 128 + sig;
        proc->state = PROC_ZOMBIE;
        window_destroy_by_owner(proc->pid);

        struct process *parent = process_get(proc->parent_pid);
        if (parent && parent->state == PROC_BLOCKED) {
            parent->state = PROC_READY;
        }
        return 0;
    }

    if (sig == SIGSTOP) {
        if (proc->state == PROC_RUNNING || proc->state == PROC_READY) {
            proc->state = PROC_STOPPED;
        }
        return 0;
    }

    if (sig == SIGCONT) {
        if (proc->state == PROC_STOPPED) {
            proc->state = PROC_READY;
        }
        return 0;
    }

    // Queue the signal
    proc->sig_pending |= (1 << sig);

    // Wake blocked/sleeping processes so they can handle signals
    if (proc->state == PROC_SLEEPING || proc->state == PROC_BLOCKED) {
        proc->state = PROC_READY;
    }

    return 0;
}

void process_check_signals(struct process *proc) {
    if (!proc || proc->sig_pending == 0) return;

    for (int sig = 1; sig < NSIG; sig++) {
        if (!(proc->sig_pending & (1 << sig))) continue;
        proc->sig_pending &= ~(1 << sig);

        sig_handler_t handler = proc->sig_handlers[sig];

        if (handler == SIG_IGN) {
            continue;
        }

        if (handler == SIG_DFL) {
            // Default action for most signals is to terminate
            switch (sig) {
                case SIGCHLD:
                    // Default: ignore
                    break;
                case SIGTERM:
                default:
                    // Default: terminate
                    proc->exit_code = 128 + sig;
                    proc->state = PROC_ZOMBIE;
                    window_destroy_by_owner(proc->pid);
                    return;
            }
        }
        // User signal handlers would require stack frame manipulation - not implemented yet
    }
}

int process_signal(int pid, int sig, sig_handler_t handler) {
    if (sig < 1 || sig >= NSIG) return -1;
    if (sig == SIGKILL || sig == SIGSTOP) return -1; // Cannot catch

    struct process *proc = process_get(pid);
    if (!proc) return -1;

    proc->sig_handlers[sig] = handler;
    return 0;
}

// ============================================================
// Pipe support
// ============================================================

int pipe_create(int fds[2]) {
    // Find a free pipe
    int pi = -1;
    for (int i = 0; i < MAX_PIPES; i++) {
        if (!pipes[i].in_use) { pi = i; break; }
    }
    if (pi < 0) return -1;

    struct process *proc = process_current();
    if (!proc) return -1;

    // Find two free fds
    int rfd = -1, wfd = -1;
    for (int i = 3; i < MAX_FDS; i++) {
        if (!proc->fds[i] && proc->pipe_fd_pipe[i] < 0) {
            if (rfd < 0) rfd = i;
            else if (wfd < 0) { wfd = i; break; }
        }
    }
    if (rfd < 0 || wfd < 0) return -1;

    memset(&pipes[pi], 0, sizeof(struct pipe));
    pipes[pi].in_use = 1;
    pipes[pi].readers = 1;
    pipes[pi].writers = 1;

    proc->pipe_fd_pipe[rfd] = pi;
    proc->pipe_fd_end[rfd] = 0; // read end
    proc->pipe_fd_pipe[wfd] = pi;
    proc->pipe_fd_end[wfd] = 1; // write end

    fds[0] = rfd;
    fds[1] = wfd;
    return 0;
}

ssize_t pipe_read(int pipe_idx, void *buf, size_t count) {
    if (pipe_idx < 0 || pipe_idx >= MAX_PIPES) return -1;
    struct pipe *p = &pipes[pipe_idx];
    if (!p->in_use) return -1;

    if (p->count == 0) {
        if (p->writers == 0) return 0; // EOF
        return 0; // No data available (non-blocking)
    }

    size_t to_read = count;
    if (to_read > p->count) to_read = p->count;

    uint8_t *dst = (uint8_t *)buf;
    for (size_t i = 0; i < to_read; i++) {
        dst[i] = p->buf[p->read_pos];
        p->read_pos = (p->read_pos + 1) % PIPE_BUF_SIZE;
    }
    p->count -= to_read;
    return (ssize_t)to_read;
}

ssize_t pipe_write(int pipe_idx, const void *buf, size_t count) {
    if (pipe_idx < 0 || pipe_idx >= MAX_PIPES) return -1;
    struct pipe *p = &pipes[pipe_idx];
    if (!p->in_use) return -1;

    if (p->readers == 0) return -1; // Broken pipe

    size_t to_write = count;
    size_t space = PIPE_BUF_SIZE - p->count;
    if (to_write > space) to_write = space;

    const uint8_t *src = (const uint8_t *)buf;
    for (size_t i = 0; i < to_write; i++) {
        p->buf[p->write_pos] = src[i];
        p->write_pos = (p->write_pos + 1) % PIPE_BUF_SIZE;
    }
    p->count += to_write;
    return (ssize_t)to_write;
}

void pipe_close_end(int pipe_idx, int end) {
    if (pipe_idx < 0 || pipe_idx >= MAX_PIPES) return;
    struct pipe *p = &pipes[pipe_idx];
    if (!p->in_use) return;

    if (end == 0) p->readers--;
    else p->writers--;

    if (p->readers <= 0 && p->writers <= 0) {
        p->in_use = 0;
    }
}

// ============================================================
// Priority support
// ============================================================

void process_set_priority(int pid, int priority) {
    struct process *proc = process_get(pid);
    if (!proc) return;
    if (priority < PRIO_REALTIME) priority = PRIO_REALTIME;
    if (priority > PRIO_IDLE) priority = PRIO_IDLE;
    proc->priority = priority;
    proc->base_priority = priority;
}

int process_get_priority(int pid) {
    struct process *proc = process_get(pid);
    if (!proc) return -1;
    return proc->priority;
}
