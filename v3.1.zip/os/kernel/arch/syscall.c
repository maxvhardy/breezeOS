#include "arch/syscall.h"
#include "arch/gdt.h"
#include "arch/paging.h"
#include "sched/process.h"
#include "sched/scheduler.h"
#include "fs/vfs.h"
#include "mm/heap.h"
#include "lib/string.h"
#include "lib/printf.h"
#include "gui/window.h"
#include "gui/event.h"
#include "drivers/vga.h"
#include "drivers/vbe.h"
#include "drivers/pit.h"
#include "elf.h"

// Per-CPU data for SYSCALL/SYSRET
struct cpu_data {
    uint64_t self;
    uint64_t kernel_rsp;
    uint64_t user_rsp;
    uint64_t current_task;
} ALIGNED(16);

static struct cpu_data cpu0;
static const uint64_t USER_VIRT_TOP = 0x0000800000000000ULL;
static volatile uint32_t syscall_preempt_depth = 0;
static volatile uint32_t syscall_resched_pending = 0;

void syscall_preempt_enter(void) {
    syscall_preempt_depth++;
}

void syscall_preempt_exit(void) {
    if (syscall_preempt_depth == 0) return;
    syscall_preempt_depth--;
}

int syscall_preempt_blocked(void) {
    return syscall_preempt_depth != 0;
}

void syscall_preempt_request_schedule(void) {
    syscall_resched_pending = 1;
}

int syscall_preempt_take_schedule_request(void) {
    if (!syscall_resched_pending) return 0;
    syscall_resched_pending = 0;
    return 1;
}

static bool user_range_mapped(struct process *proc, const void *ptr, size_t len) {
    if (!proc || !proc->pml4) return false;
    if (len == 0) return true;
    if (!ptr) return false;

    uint64_t start = (uint64_t)ptr;
    if (start >= USER_VIRT_TOP) return false;
    if (len > USER_VIRT_TOP - start) return false;

    uint64_t end = start + len - 1;
    if (end >= USER_VIRT_TOP) return false;

    uint64_t page = start & ~(uint64_t)(PAGE_SIZE - 1);
    uint64_t last = end & ~(uint64_t)(PAGE_SIZE - 1);

    while (1) {
        if (paging_get_phys(proc->pml4, page) == 0) return false;
        if (page == last) break;
        page += PAGE_SIZE;
    }

    return true;
}

static int copy_user_string(struct process *proc, const char *user_src,
                            char *dst, size_t dst_sz) {
    if (!dst || dst_sz == 0) return -1;
    dst[0] = '\0';

    if (!user_src) return 0;

    for (size_t i = 0; i < dst_sz - 1; i++) {
        const char *cur = user_src + i;
        if (!user_range_mapped(proc, cur, 1)) return -1;

        char ch = *cur;
        dst[i] = ch;
        if (ch == '\0') return 0;
    }

    dst[dst_sz - 1] = '\0';
    return -1;
}

static int normalize_path(const char *raw, char *out, size_t out_sz) {
    if (!raw || raw[0] != '/' || !out || out_sz < 2) return -1;

    char parts[32][MAX_NAME + 1];
    int part_count = 0;

    char comp[MAX_NAME + 1];
    int comp_len = 0;

    for (const char *p = raw;; p++) {
        char ch = *p;
        if (ch == '/' || ch == '\0') {
            if (comp_len > 0) {
                comp[comp_len] = '\0';
                if (strcmp(comp, ".") == 0) {
                    // Ignore.
                } else if (strcmp(comp, "..") == 0) {
                    if (part_count > 0) part_count--;
                } else {
                    if (part_count >= 32) return -1;
                    strncpy(parts[part_count], comp, MAX_NAME);
                    parts[part_count][MAX_NAME] = '\0';
                    part_count++;
                }
                comp_len = 0;
            }

            if (ch == '\0') break;
            continue;
        }

        if (comp_len >= MAX_NAME) return -1;
        comp[comp_len++] = ch;
    }

    out[0] = '/';
    out[1] = '\0';

    for (int i = 0; i < part_count; i++) {
        size_t len = strlen(out);
        size_t nlen = strlen(parts[i]);

        if (len > 1) {
            if (len + 1 >= out_sz) return -1;
            out[len++] = '/';
            out[len] = '\0';
        }

        if (len + nlen >= out_sz) return -1;
        memcpy(out + len, parts[i], nlen + 1);
    }

    return 0;
}

static int resolve_proc_path(struct process *proc, const char *path,
                             char *out, size_t out_sz) {
    if (!proc || !path || !out) return -1;
    if (path[0] == '\0') return -1;

    char raw[MAX_PATH * 2];
    if (path[0] == '/') {
        strncpy(raw, path, sizeof(raw) - 1);
        raw[sizeof(raw) - 1] = '\0';
    } else if (strcmp(proc->cwd, "/") == 0) {
        snprintf(raw, sizeof(raw), "/%s", path);
    } else {
        snprintf(raw, sizeof(raw), "%s/%s", proc->cwd, path);
    }

    return normalize_path(raw, out, out_sz);
}

void syscall_set_kernel_rsp(uint64_t rsp) {
    cpu0.kernel_rsp = rsp;
}

static int64_t sys_exit(struct registers *regs) {
    process_exit((int)regs->rdi);
    schedule();
    return 0;
}

static int64_t sys_write(struct registers *regs) {
    int fd = (int)regs->rdi;
    const char *buf = (const char *)regs->rsi;
    size_t count = regs->rdx;

    struct process *proc = process_current();
    if (!proc) return -1;
    if (count > 0 && !user_range_mapped(proc, buf, count)) return -1;

    if (fd == 1 || fd == 2) {
        // stdout/stderr -> VGA/VBE text output
        for (size_t i = 0; i < count; i++) {
            vga_putchar(buf[i]);
        }
        return (int64_t)count;
    }

    if (fd < 0 || fd >= MAX_FDS) return -1;

    // Check if this is a pipe write
    if (proc->pipe_fd_pipe[fd] >= 0 && proc->pipe_fd_end[fd] == 1) {
        return pipe_write(proc->pipe_fd_pipe[fd], buf, count);
    }

    if (!proc->fds[fd]) return -1;
    return vfs_write(proc->fds[fd], buf, count);
}

static int64_t sys_read(struct registers *regs) {
    int fd = (int)regs->rdi;
    char *buf = (char *)regs->rsi;
    size_t count = regs->rdx;

    struct process *proc = process_current();
    if (!proc) return -1;
    if (count > 0 && !user_range_mapped(proc, buf, count)) return -1;

    if (fd == 0) {
        // stdin -> keyboard buffer
        extern char kbd_getchar(void);
        for (size_t i = 0; i < count; i++) {
            char c = kbd_getchar();
            if (c == 0) return (int64_t)i;
            buf[i] = c;
            if (c == '\n') return (int64_t)(i + 1);
        }
        return (int64_t)count;
    }

    if (fd < 0 || fd >= MAX_FDS) return -1;

    // Check if this is a pipe read
    if (proc->pipe_fd_pipe[fd] >= 0 && proc->pipe_fd_end[fd] == 0) {
        return pipe_read(proc->pipe_fd_pipe[fd], buf, count);
    }

    if (!proc->fds[fd]) return -1;
    return vfs_read(proc->fds[fd], buf, count);
}

static int64_t sys_open(struct registers *regs) {
    const char *user_path = (const char *)regs->rsi;
    int flags = (int)regs->rdx;

    struct process *proc = process_current();
    if (!proc) return -1;

    char path_buf[MAX_PATH];
    char resolved[MAX_PATH];
    if (copy_user_string(proc, user_path, path_buf, sizeof(path_buf)) < 0) return -1;
    if (resolve_proc_path(proc, path_buf, resolved, sizeof(resolved)) < 0) return -1;

    // Find a free fd
    int fd = -1;
    for (int i = 3; i < MAX_FDS; i++) {
        if (!proc->fds[i] && proc->pipe_fd_pipe[i] < 0) { fd = i; break; }
    }
    if (fd < 0) return -1;

    struct vfs_node *node = vfs_open(resolved, flags);
    if (!node) return -1;

    proc->fds[fd] = node;
    return fd;
}

static int64_t sys_close(struct registers *regs) {
    int fd = (int)regs->rdi;
    struct process *proc = process_current();
    if (!proc || fd < 3 || fd >= MAX_FDS) return -1;

    // Close pipe end if applicable
    if (proc->pipe_fd_pipe[fd] >= 0) {
        pipe_close_end(proc->pipe_fd_pipe[fd], proc->pipe_fd_end[fd]);
        proc->pipe_fd_pipe[fd] = -1;
        return 0;
    }

    if (!proc->fds[fd]) return -1;
    vfs_close(proc->fds[fd]);
    proc->fds[fd] = NULL;
    return 0;
}

static void set_child_fork_return(struct registers *parent_regs, int child_pid) {
    struct process *parent = process_current();
    struct process *child = process_get(child_pid);
    if (!parent || !child) return;
    if (!parent->kernel_stack_base || !child->kernel_stack_base) return;

    uint64_t parent_regs_addr = (uint64_t)parent_regs;
    uint64_t parent_stack_top = parent->kernel_stack_base + KERNEL_STACK_SIZE;
    if (parent_regs_addr < parent->kernel_stack_base || parent_regs_addr >= parent_stack_top) return;

    uint64_t regs_offset = parent_regs_addr - parent->kernel_stack_base;
    struct registers *child_regs = (struct registers *)(child->kernel_stack_base + regs_offset);
    child_regs->rax = 0;
}

static int64_t sys_fork(struct registers *regs) {
    int child_pid = process_fork();
    if (child_pid > 0) {
        set_child_fork_return(regs, child_pid);
    }
    return child_pid;
}

static int64_t sys_exec(struct registers *regs) {
    struct process *proc = process_current();
    if (!proc) return -1;

    const char *user_path = (const char *)regs->rdi;
    char path_buf[MAX_PATH];
    char resolved[MAX_PATH];
    if (copy_user_string(proc, user_path, path_buf, sizeof(path_buf)) < 0) return -1;
    if (resolve_proc_path(proc, path_buf, resolved, sizeof(resolved)) < 0) return -1;
    return process_exec(resolved);
}

static int64_t sys_waitpid(struct registers *regs) {
    int pid = (int)regs->rdi;
    int *status = (int *)regs->rsi;
    struct process *proc = process_current();
    if (!proc) return -1;
    if (status && !user_range_mapped(proc, status, sizeof(*status))) return -1;

    if (pid == -1) {
        for (int i = 1; i < MAX_PROCESSES; i++) {
            struct process *p = process_get(i);
            if (!p) continue;
            if (p->parent_pid != proc->pid) continue;
            if (p->state != PROC_ZOMBIE) continue;
            return process_waitpid(i, status);
        }
        return -1;
    }
    return process_waitpid(pid, status);
}

static int64_t sys_getpid(struct registers *regs) {
    (void)regs;
    struct process *proc = process_current();
    return proc ? proc->pid : -1;
}

static int64_t sys_sbrk(struct registers *regs) {
    int64_t incr = (int64_t)regs->rdi;
    struct process *proc = process_current();
    if (!proc) return -1;
    return process_sbrk(proc, incr);
}

static int64_t sys_mkdir(struct registers *regs) {
    struct process *proc = process_current();
    if (!proc) return -1;

    const char *user_path = (const char *)regs->rdi;
    char path_buf[MAX_PATH];
    char resolved[MAX_PATH];
    if (copy_user_string(proc, user_path, path_buf, sizeof(path_buf)) < 0) return -1;
    if (resolve_proc_path(proc, path_buf, resolved, sizeof(resolved)) < 0) return -1;
    return vfs_mkdir(resolved);
}

static int64_t sys_rmdir(struct registers *regs) {
    struct process *proc = process_current();
    if (!proc) return -1;

    const char *user_path = (const char *)regs->rdi;
    char path_buf[MAX_PATH];
    char resolved[MAX_PATH];
    if (copy_user_string(proc, user_path, path_buf, sizeof(path_buf)) < 0) return -1;
    if (resolve_proc_path(proc, path_buf, resolved, sizeof(resolved)) < 0) return -1;
    return vfs_rmdir(resolved);
}

static int64_t sys_unlink(struct registers *regs) {
    struct process *proc = process_current();
    if (!proc) return -1;

    const char *user_path = (const char *)regs->rdi;
    char path_buf[MAX_PATH];
    char resolved[MAX_PATH];
    if (copy_user_string(proc, user_path, path_buf, sizeof(path_buf)) < 0) return -1;
    if (resolve_proc_path(proc, path_buf, resolved, sizeof(resolved)) < 0) return -1;
    return vfs_unlink(resolved);
}

static int64_t sys_chdir(struct registers *regs) {
    const char *user_path = (const char *)regs->rdi;
    struct process *proc = process_current();
    if (!proc) return -1;

    char path_buf[MAX_PATH];
    char resolved[MAX_PATH];
    if (copy_user_string(proc, user_path, path_buf, sizeof(path_buf)) < 0) return -1;
    if (resolve_proc_path(proc, path_buf, resolved, sizeof(resolved)) < 0) return -1;

    struct vfs_node *node = vfs_open(resolved, O_RDONLY);
    if (!node) return -1;
    if (node->type != VFS_DIRECTORY) {
        vfs_close(node);
        return -1;
    }
    vfs_close(node);

    strncpy(proc->cwd, resolved, sizeof(proc->cwd) - 1);
    proc->cwd[sizeof(proc->cwd) - 1] = '\0';
    return 0;
}

static int64_t sys_getcwd(struct registers *regs) {
    char *buf = (char *)regs->rdi;
    size_t size = regs->rsi;
    struct process *proc = process_current();
    if (!proc) return -1;
    if (!buf || size == 0) return -1;
    if (!user_range_mapped(proc, buf, size)) return -1;
    strncpy(buf, proc->cwd, size - 1);
    buf[size - 1] = '\0';
    return (int64_t)(uint64_t)buf;
}

static int64_t sys_readdir(struct registers *regs) {
    int fd = (int)regs->rdi;
    struct dirent *ent = (struct dirent *)regs->rsi;
    struct process *proc = process_current();
    if (!proc) return -1;
    if (!ent || !user_range_mapped(proc, ent, sizeof(*ent))) return -1;
    if (fd < 0 || fd >= MAX_FDS || !proc->fds[fd]) return -1;
    return vfs_readdir(proc->fds[fd], ent);
}

static int64_t sys_stat(struct registers *regs) {
    const char *user_path = (const char *)regs->rdi;
    struct stat *st = (struct stat *)regs->rsi;
    struct process *proc = process_current();
    if (!proc) return -1;
    if (!st || !user_range_mapped(proc, st, sizeof(*st))) return -1;

    char path_buf[MAX_PATH];
    char resolved[MAX_PATH];
    if (copy_user_string(proc, user_path, path_buf, sizeof(path_buf)) < 0) return -1;
    if (resolve_proc_path(proc, path_buf, resolved, sizeof(resolved)) < 0) return -1;

    return vfs_stat(resolved, st);
}

static int64_t sys_yield(struct registers *regs) {
    (void)regs;
    schedule();
    return 0;
}

static int64_t sys_sleep(struct registers *regs) {
    uint64_t ms = regs->rdi;
    process_sleep(ms);
    schedule();
    return 0;
}

static int64_t sys_getfb(struct registers *regs) {
    struct process *proc = process_current();
    if (!proc) return -1;

    uint32_t *info = (uint32_t *)regs->rdi;
    if (!user_range_mapped(proc, info, 4 * sizeof(uint32_t))) return -1;

    info[0] = vbe_get_width();
    info[1] = vbe_get_height();
    info[2] = vbe_get_pitch();
    info[3] = vbe_get_bpp();
    return 0;
}

static int64_t sys_win_create(struct registers *regs) {
    struct process *proc = process_current();
    if (!proc) return -1;

    int x = (int)regs->rdi;
    int y = (int)regs->rsi;
    int w = (int)regs->rdx;
    int h = (int)regs->r10;
    const char *user_title = (const char *)regs->r8;

    char title_buf[64];
    const char *title = NULL;
    if (user_title) {
        if (copy_user_string(proc, user_title, title_buf, sizeof(title_buf)) == 0) {
            title = title_buf;
        }
    }

    return window_create(x, y, w, h, title);
}

static int64_t sys_win_destroy(struct registers *regs) {
    struct process *proc = process_current();
    if (!proc) return -1;

    int wid = (int)regs->rdi;
    struct window *win = window_get(wid);
    if (!win) return -1;
    if (win->owner_pid != proc->pid) return -1;

    window_destroy(wid);
    return 0;
}

static int64_t sys_win_update(struct registers *regs) {
    struct process *proc = process_current();
    if (!proc) return -1;

    int wid = (int)regs->rdi;
    uint32_t *pixels = (uint32_t *)regs->rsi;
    if (!pixels) return -1;

    struct window *win = window_get(wid);
    if (!win || !win->framebuffer) return -1;
    if (win->owner_pid != proc->pid) return -1;
    if (win->width <= 0 || win->height <= 0) return -1;

    size_t pixel_count = (size_t)win->width * (size_t)win->height;
    if (pixel_count / (size_t)win->width != (size_t)win->height) return -1;
    if (pixel_count > ((size_t)-1) / sizeof(uint32_t)) return -1;
    size_t fb_size = pixel_count * sizeof(uint32_t);

    if (!user_range_mapped(proc, pixels, fb_size)) return -1;
    return window_update_buffer(wid, pixels);
}

static int64_t sys_win_event(struct registers *regs) {
    struct process *proc = process_current();
    if (!proc) return -1;

    struct gui_event *user_ev = (struct gui_event *)regs->rdi;
    if (!user_range_mapped(proc, user_ev, sizeof(struct gui_event))) return -1;

    struct gui_event ev;
    int ret = gui_event_poll_for_owner(proc->pid, &ev);
    if (ret > 0) {
        *user_ev = ev;
    } else {
        user_ev->type = GUI_EVENT_NONE;
    }
    return ret;
}

static int64_t sys_dup2(struct registers *regs) {
    int oldfd = (int)regs->rdi;
    int newfd = (int)regs->rsi;
    struct process *proc = process_current();
    if (!proc) return -1;
    if (oldfd < 0 || oldfd >= MAX_FDS || newfd < 0 || newfd >= MAX_FDS) return -1;

    // Close newfd if it's open
    if (proc->fds[newfd]) {
        vfs_close(proc->fds[newfd]);
        proc->fds[newfd] = NULL;
    }
    if (proc->pipe_fd_pipe[newfd] >= 0) {
        pipe_close_end(proc->pipe_fd_pipe[newfd], proc->pipe_fd_end[newfd]);
        proc->pipe_fd_pipe[newfd] = -1;
    }

    // Copy oldfd to newfd
    if (proc->pipe_fd_pipe[oldfd] >= 0) {
        proc->pipe_fd_pipe[newfd] = proc->pipe_fd_pipe[oldfd];
        proc->pipe_fd_end[newfd] = proc->pipe_fd_end[oldfd];
        // Increment reference count
        int pi = proc->pipe_fd_pipe[oldfd];
        if (proc->pipe_fd_end[oldfd] == 0) {
            extern ssize_t pipe_read(int, void*, size_t); // for pipe access
            // Increment readers via direct access - pipes are in process.c
            // We just track it via the fd table, actual ref counting in pipe_close_end
        }
    } else {
        proc->fds[newfd] = proc->fds[oldfd]; // Share the VFS node
    }

    return newfd;
}

static int64_t sys_pipe(struct registers *regs) {
    int *user_fds = (int *)regs->rdi;
    struct process *proc = process_current();
    if (!proc) return -1;
    if (!user_range_mapped(proc, user_fds, 2 * sizeof(int))) return -1;

    int fds[2];
    int ret = pipe_create(fds);
    if (ret < 0) return -1;

    user_fds[0] = fds[0];
    user_fds[1] = fds[1];
    return 0;
}

static int64_t sys_lseek(struct registers *regs) {
    int fd = (int)regs->rdi;
    int64_t offset = (int64_t)regs->rsi;
    int whence = (int)regs->rdx;
    struct process *proc = process_current();
    if (!proc || fd < 0 || fd >= MAX_FDS || !proc->fds[fd]) return -1;
    return vfs_lseek(proc->fds[fd], offset, whence);
}

static int64_t sys_fstat(struct registers *regs) {
    int fd = (int)regs->rdi;
    struct stat *st = (struct stat *)regs->rsi;
    struct process *proc = process_current();
    if (!proc) return -1;
    if (!st || !user_range_mapped(proc, st, sizeof(*st))) return -1;
    if (fd < 0 || fd >= MAX_FDS || !proc->fds[fd]) return -1;

    st->inode = proc->fds[fd]->inode;
    st->type = proc->fds[fd]->type;
    st->size = proc->fds[fd]->size;
    st->blocks = 0;
    st->created = 0;
    st->modified = 0;
    return 0;
}

static int64_t sys_ticks(struct registers *regs) {
    (void)regs;
    // PIT is configured at 100 Hz in this kernel, so each tick is 10 ms.
    return (int64_t)(pit_get_ticks() * 10ULL);
}

static int64_t sys_kill(struct registers *regs) {
    int pid = (int)regs->rdi;
    int sig = (int)regs->rsi;
    return process_kill(pid, sig);
}

static int64_t sys_getppid(struct registers *regs) {
    (void)regs;
    struct process *proc = process_current();
    if (!proc) return -1;
    return proc->parent_pid;
}

static int64_t sys_rename(struct registers *regs) {
    struct process *proc = process_current();
    if (!proc) return -1;

    const char *user_old = (const char *)regs->rdi;
    const char *user_new = (const char *)regs->rsi;

    char old_buf[MAX_PATH], new_buf[MAX_PATH];
    char old_resolved[MAX_PATH], new_resolved[MAX_PATH];
    if (copy_user_string(proc, user_old, old_buf, sizeof(old_buf)) < 0) return -1;
    if (copy_user_string(proc, user_new, new_buf, sizeof(new_buf)) < 0) return -1;
    if (resolve_proc_path(proc, old_buf, old_resolved, sizeof(old_resolved)) < 0) return -1;
    if (resolve_proc_path(proc, new_buf, new_resolved, sizeof(new_resolved)) < 0) return -1;

    return vfs_rename(old_resolved, new_resolved);
}

static int64_t sys_truncate(struct registers *regs) {
    struct process *proc = process_current();
    if (!proc) return -1;

    const char *user_path = (const char *)regs->rdi;
    uint32_t length = (uint32_t)regs->rsi;

    char path_buf[MAX_PATH], resolved[MAX_PATH];
    if (copy_user_string(proc, user_path, path_buf, sizeof(path_buf)) < 0) return -1;
    if (resolve_proc_path(proc, path_buf, resolved, sizeof(resolved)) < 0) return -1;

    return vfs_truncate(resolved, length);
}

static int64_t sys_getprio(struct registers *regs) {
    int pid = (int)regs->rdi;
    if (pid == 0) {
        struct process *proc = process_current();
        if (!proc) return -1;
        pid = proc->pid;
    }
    return process_get_priority(pid);
}

static int64_t sys_setprio(struct registers *regs) {
    int pid = (int)regs->rdi;
    int prio = (int)regs->rsi;
    struct process *proc = process_current();
    if (!proc) return -1;
    if (pid == 0) pid = proc->pid;
    process_set_priority(pid, prio);
    return 0;
}

typedef int64_t (*syscall_fn)(struct registers *);

static syscall_fn syscall_table[SYSCALL_COUNT] = {
    [SYS_EXIT]        = sys_exit,
    [SYS_WRITE]       = sys_write,
    [SYS_READ]        = sys_read,
    [SYS_OPEN]        = sys_open,
    [SYS_CLOSE]       = sys_close,
    [SYS_FORK]        = sys_fork,
    [SYS_EXEC]        = sys_exec,
    [SYS_WAITPID]     = sys_waitpid,
    [SYS_GETPID]      = sys_getpid,
    [SYS_SBRK]        = sys_sbrk,
    [SYS_MKDIR]       = sys_mkdir,
    [SYS_RMDIR]       = sys_rmdir,
    [SYS_UNLINK]      = sys_unlink,
    [SYS_CHDIR]       = sys_chdir,
    [SYS_GETCWD]      = sys_getcwd,
    [SYS_READDIR]     = sys_readdir,
    [SYS_STAT]        = sys_stat,
    [SYS_YIELD]       = sys_yield,
    [SYS_SLEEP]       = sys_sleep,
    [SYS_GETFB]       = sys_getfb,
    [SYS_WIN_CREATE]  = sys_win_create,
    [SYS_WIN_DESTROY] = sys_win_destroy,
    [SYS_WIN_UPDATE]  = sys_win_update,
    [SYS_WIN_EVENT]   = sys_win_event,
    [SYS_DUP2]        = sys_dup2,
    [SYS_PIPE]        = sys_pipe,
    [SYS_LSEEK]       = sys_lseek,
    [SYS_FSTAT]       = sys_fstat,
    [SYS_TICKS]       = sys_ticks,
    [SYS_KILL]        = sys_kill,
    [SYS_GETPPID]     = sys_getppid,
    [SYS_RENAME]      = sys_rename,
    [SYS_TRUNCATE]    = sys_truncate,
    [SYS_GETPRIO]     = sys_getprio,
    [SYS_SETPRIO]     = sys_setprio,
};

// Called from syscall_entry.asm
void syscall_handler_c(struct registers *regs) {
    uint64_t num = regs->rax;
    if (num < SYSCALL_COUNT && syscall_table[num]) {
        regs->rax = (uint64_t)syscall_table[num](regs);
    } else {
        regs->rax = (uint64_t)-1;
    }
}

void syscall_init(void) {
    // Set up SYSCALL/SYSRET MSRs
    // IA32_STAR: SYSCALL CS/SS in bits [47:32], SYSRET CS/SS in bits [63:48]
    uint64_t star = ((uint64_t)GDT_USER_CODE32 << 48) | ((uint64_t)GDT_KERNEL_CODE << 32);
    wrmsr(0xC0000081, star);

    // IA32_LSTAR: SYSCALL entry point
    wrmsr(0xC0000082, (uint64_t)syscall_entry);

    // IA32_FMASK: mask interrupts on SYSCALL entry
    wrmsr(0xC0000084, 0x200); // mask IF

    // Enable SYSCALL/SYSRET in IA32_EFER
    uint64_t efer = rdmsr(0xC0000080);
    efer |= 1; // SCE (System Call Extensions)
    wrmsr(0xC0000080, efer);

    // Set up GS base for per-CPU data
    cpu0.self = (uint64_t)&cpu0;
    cpu0.current_task = 0;
    // Temporary fallback stack until the scheduler sets per-process kernel_rsp.
    __asm__ volatile("mov %%rsp, %0" : "=r"(cpu0.kernel_rsp));
    wrmsr(0xC0000101, (uint64_t)&cpu0); // IA32_GS_BASE (kernel)
    wrmsr(0xC0000102, 0);               // IA32_KERNEL_GS_BASE (will be swapped)
}
