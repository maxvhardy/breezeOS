#include "drivers/mouse.h"
#include "drivers/pic.h"
#include "drivers/keyboard.h"
#include "arch/idt.h"
#include "lib/printf.h"

#define PS2_STATUS_OUTPUT_FULL 0x01
#define PS2_STATUS_INPUT_FULL  0x02
#define PS2_STATUS_AUX         0x20
#define PS2_MOUSE_ACK          0xFA
#define PS2_MOUSE_SELFTEST_OK  0xAA

static volatile int mouse_x = 512;
static volatile int mouse_y = 384;
static volatile int mouse_buttons = 0;
static volatile int mouse_max_x = 1023;
static volatile int mouse_max_y = 767;

static uint8_t mouse_cycle = 0;
static uint8_t mouse_bytes[3];

static int mouse_wait_input(void) {
    int timeout = 100000;
    while (timeout-- > 0) {
        if (!(inb(0x64) & PS2_STATUS_INPUT_FULL)) return 1;
    }
    return 0;
}

static int mouse_read_data(uint8_t *status_out, uint8_t *data_out) {
    int timeout = 100000;
    while (timeout-- > 0) {
        uint8_t status = inb(0x64);
        if (status & PS2_STATUS_OUTPUT_FULL) {
            uint8_t data = inb(0x60);
            if (status_out) *status_out = status;
            if (data_out) *data_out = data;
            return 1;
        }
    }
    return 0;
}

static void mouse_flush_output(void) {
    int timeout = 100000;
    while (timeout-- > 0) {
        uint8_t status = inb(0x64);
        if (!(status & PS2_STATUS_OUTPUT_FULL)) break;
        uint8_t data = inb(0x60);
        if (!(status & PS2_STATUS_AUX)) {
            keyboard_process_scancode(data);
        }
    }
}

static int mouse_write(uint8_t val) {
    if (!mouse_wait_input()) return 0;
    outb(0x64, 0xD4);  // Tell controller we're writing to mouse
    if (!mouse_wait_input()) return 0;
    outb(0x60, val);
    return 1;
}

static int mouse_read_aux_byte(uint8_t *out) {
    for (int i = 0; i < 32; i++) {
        uint8_t status = 0, data = 0;
        if (!mouse_read_data(&status, &data)) return 0;
        if (status & PS2_STATUS_AUX) {
            *out = data;
            return 1;
        }
        keyboard_process_scancode(data);
    }
    return 0;
}

static int mouse_expect_ack(void) {
    for (int i = 0; i < 8; i++) {
        uint8_t data = 0;
        if (!mouse_read_aux_byte(&data)) return 0;
        if (data == PS2_MOUSE_ACK) return 1;
    }
    return 0;
}

static void clamp_mouse(void) {
    if (mouse_x < 0) mouse_x = 0;
    if (mouse_y < 0) mouse_y = 0;
    if (mouse_x > mouse_max_x) mouse_x = mouse_max_x;
    if (mouse_y > mouse_max_y) mouse_y = mouse_max_y;
}

static void mouse_process_byte(uint8_t data) {
    mouse_bytes[mouse_cycle] = data;

    switch (mouse_cycle) {
        case 0:
            // First byte always has bit 3 set on valid PS/2 packets.
            if (data & 0x08) {
                mouse_cycle = 1;
            }
            break;
        case 1:
            mouse_cycle = 2;
            break;
        case 2: {
            mouse_cycle = 0;

            mouse_buttons = mouse_bytes[0] & 0x07;
            if (mouse_bytes[0] & 0xC0) break; // X/Y overflow, drop packet

            int dx = (int8_t)mouse_bytes[1];
            int dy = (int8_t)mouse_bytes[2];

            mouse_x += dx;
            mouse_y -= dy; // Y is inverted in screen space
            clamp_mouse();
            break;
        }
    }
}

static void mouse_drain_controller(int max_bytes) {
    for (int i = 0; i < max_bytes; i++) {
        uint8_t status = inb(0x64);
        if (!(status & PS2_STATUS_OUTPUT_FULL)) break;

        uint8_t data = inb(0x60);
        if (status & PS2_STATUS_AUX) {
            mouse_process_byte(data);
        } else {
            keyboard_process_scancode(data);
        }
    }
}

static void mouse_handler(struct registers *regs) {
    (void)regs;
    mouse_drain_controller(32);
}

void mouse_init(void) {
    mouse_cycle = 0;
    mouse_buttons = 0;

    // Disable both PS/2 ports while reconfiguring the controller.
    if (mouse_wait_input()) outb(0x64, 0xA7); // Disable mouse port
    if (mouse_wait_input()) outb(0x64, 0xAD); // Disable keyboard port
    mouse_flush_output();

    // Enable auxiliary device and IRQ routing.
    if (!mouse_wait_input()) return;
    outb(0x64, 0xA8);

    if (mouse_wait_input()) outb(0x64, 0x20); // Read controller config
    uint8_t status = 0, data = 0;
    if (mouse_read_data(&status, &data)) {
        data |= 0x03;      // Enable IRQ1 + IRQ12
        data &= ~0x20;     // Enable mouse clock (second port)
        if (mouse_wait_input()) outb(0x64, 0x60); // Write config
        if (mouse_wait_input()) outb(0x60, data);
    } else {
        kprintf("[MOUSE] Warning: failed to read controller config\n");
    }

    if (mouse_wait_input()) outb(0x64, 0xAE); // Re-enable keyboard port

    // Reset mouse device and consume BAT/device ID response.
    if (!mouse_write(0xFF) || !mouse_expect_ack()) {
        kprintf("[MOUSE] Warning: no ACK for reset\n");
    } else {
        uint8_t selftest = 0;
        if (!mouse_read_aux_byte(&selftest) || selftest != PS2_MOUSE_SELFTEST_OK) {
            kprintf("[MOUSE] Warning: mouse self-test missing/failed (0x%x)\n", selftest);
        }
        uint8_t device_id = 0;
        if (!mouse_read_aux_byte(&device_id)) {
            kprintf("[MOUSE] Warning: no mouse device ID\n");
        }
    }

    // Set default settings.
    if (!mouse_write(0xF6) || !mouse_expect_ack()) {
        kprintf("[MOUSE] Warning: no ACK for reset defaults\n");
    }

    // Enable packet streaming.
    if (!mouse_write(0xF4) || !mouse_expect_ack()) {
        kprintf("[MOUSE] Warning: no ACK for enable reporting\n");
    }

    // Drain anything left in the controller buffers before enabling IRQ12.
    mouse_drain_controller(32);

    // Register handler and unmask IRQ12.
    isr_register_handler(44, mouse_handler);
    pic_clear_mask(IRQ_MOUSE);
}

int mouse_get_x(void) { return mouse_x; }
int mouse_get_y(void) { return mouse_y; }
int mouse_get_buttons(void) { return mouse_buttons; }

void mouse_poll(void) {
    // Poll fallback keeps cursor responsive even when IRQ12 is dropped.
    uint64_t rflags;
    __asm__ volatile("pushfq; pop %0" : "=r"(rflags));
    cli();
    mouse_drain_controller(64);
    if (rflags & (1ULL << 9)) sti();
}

void mouse_set_bounds(int width, int height) {
    if (width <= 0 || height <= 0) return;
    mouse_max_x = width - 1;
    mouse_max_y = height - 1;
    clamp_mouse();
}

void mouse_set_position(int x, int y) {
    mouse_x = x;
    mouse_y = y;
    clamp_mouse();
}
