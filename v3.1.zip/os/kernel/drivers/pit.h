#pragma once
#include "include/types.h"

#define PIT_FREQ 1193182
#define PIT_HZ   100    // 100 Hz = 10ms per tick

void pit_init(void);
uint64_t pit_get_ticks(void);
void pit_sleep(uint64_t ms);
