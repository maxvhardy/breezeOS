#pragma once
#include "include/types.h"

#define GUI_EVENT_NONE       0
#define GUI_EVENT_KEY_PRESS  1
#define GUI_EVENT_KEY_RELEASE 2
#define GUI_EVENT_MOUSE_MOVE 3
#define GUI_EVENT_MOUSE_DOWN 4
#define GUI_EVENT_MOUSE_UP   5
#define GUI_EVENT_WIN_CLOSE  6
#define GUI_EVENT_WIN_FOCUS  7
#define GUI_EVENT_REPAINT    8

struct gui_event {
    uint32_t type;
    uint32_t window_id;
    int32_t  x, y;
    uint32_t keycode;
    uint32_t buttons;
};

#define EVENT_QUEUE_SIZE 256

void gui_event_init(void);
void gui_event_push(struct gui_event *ev);
int  gui_event_poll(struct gui_event *ev);
int  gui_event_poll_for_owner(int owner_pid, struct gui_event *ev);
void gui_event_discard_window(uint32_t window_id);
int  gui_event_has_events(void);
