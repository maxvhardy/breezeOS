#include "fs/simplefs.h"
#include "drivers/ata.h"
#include "drivers/pit.h"
#include "mm/heap.h"
#include "lib/string.h"
#include "lib/printf.h"

static uint32_t fs_start_lba;
static struct sfs_superblock sb;

// ============================================================
// Block cache (LRU)
// ============================================================

struct cache_entry {
    uint32_t block;
    uint8_t  data[SFS_BLOCK_SIZE];
    uint8_t  valid;
    uint8_t  dirty;
    uint32_t access_tick;
};

static struct cache_entry block_cache[SFS_CACHE_SIZE];
static uint32_t cache_tick = 0;
static uint32_t cache_hits = 0;
static uint32_t cache_misses = 0;

static void cache_init(void) {
    memset(block_cache, 0, sizeof(block_cache));
}

static int disk_read_block(uint32_t block, void *buf) {
    uint32_t lba = fs_start_lba + block * SFS_SECTORS_PER_BLOCK;
    return ata_read_sectors(lba, SFS_SECTORS_PER_BLOCK, buf);
}

static int disk_write_block(uint32_t block, const void *buf) {
    uint32_t lba = fs_start_lba + block * SFS_SECTORS_PER_BLOCK;
    return ata_write_sectors(lba, SFS_SECTORS_PER_BLOCK, buf);
}

static struct cache_entry *cache_find(uint32_t block) {
    for (int i = 0; i < SFS_CACHE_SIZE; i++) {
        if (block_cache[i].valid && block_cache[i].block == block) {
            block_cache[i].access_tick = ++cache_tick;
            cache_hits++;
            return &block_cache[i];
        }
    }
    return NULL;
}

static struct cache_entry *cache_evict(void) {
    int lru = 0;
    uint32_t oldest = ~0U;
    for (int i = 0; i < SFS_CACHE_SIZE; i++) {
        if (!block_cache[i].valid) return &block_cache[i];
        if (block_cache[i].access_tick < oldest) {
            oldest = block_cache[i].access_tick;
            lru = i;
        }
    }
    // Flush dirty block before eviction
    struct cache_entry *e = &block_cache[lru];
    if (e->dirty) {
        disk_write_block(e->block, e->data);
        e->dirty = 0;
    }
    return e;
}

static int sfs_read_block(uint32_t block, void *buf) {
    struct cache_entry *e = cache_find(block);
    if (e) {
        memcpy(buf, e->data, SFS_BLOCK_SIZE);
        return 0;
    }
    cache_misses++;

    // Read from disk and cache it
    e = cache_evict();
    if (disk_read_block(block, e->data) < 0) return -1;
    e->block = block;
    e->valid = 1;
    e->dirty = 0;
    e->access_tick = ++cache_tick;
    memcpy(buf, e->data, SFS_BLOCK_SIZE);
    return 0;
}

static int sfs_write_block(uint32_t block, const void *buf) {
    // Write-through + cache update
    if (disk_write_block(block, buf) < 0) return -1;

    struct cache_entry *e = cache_find(block);
    if (e) {
        memcpy(e->data, buf, SFS_BLOCK_SIZE);
        e->dirty = 0;
    } else {
        e = cache_evict();
        memcpy(e->data, buf, SFS_BLOCK_SIZE);
        e->block = block;
        e->valid = 1;
        e->dirty = 0;
        e->access_tick = ++cache_tick;
    }
    return 0;
}

// Invalidate a cache entry (for freed blocks)
static void cache_invalidate(uint32_t block) {
    for (int i = 0; i < SFS_CACHE_SIZE; i++) {
        if (block_cache[i].valid && block_cache[i].block == block) {
            block_cache[i].valid = 0;
            block_cache[i].dirty = 0;
            return;
        }
    }
}

// ============================================================
// Timestamp helper
// ============================================================

static uint64_t sfs_now(void) {
    return pit_get_ticks() * 10; // ticks * 10 = milliseconds
}

// ============================================================
// Inode operations
// ============================================================

static int sfs_read_inode(uint32_t inum, struct sfs_inode *inode) {
    uint32_t inodes_per_block = SFS_BLOCK_SIZE / SFS_INODE_SIZE;
    uint32_t block = sb.inode_start + inum / inodes_per_block;
    uint32_t offset = (inum % inodes_per_block) * SFS_INODE_SIZE;

    uint8_t block_buf[SFS_BLOCK_SIZE];
    if (sfs_read_block(block, block_buf) < 0) return -1;
    memcpy(inode, block_buf + offset, sizeof(struct sfs_inode));
    return 0;
}

static int sfs_write_inode(uint32_t inum, const struct sfs_inode *inode) {
    uint32_t inodes_per_block = SFS_BLOCK_SIZE / SFS_INODE_SIZE;
    uint32_t block = sb.inode_start + inum / inodes_per_block;
    uint32_t offset = (inum % inodes_per_block) * SFS_INODE_SIZE;

    uint8_t block_buf[SFS_BLOCK_SIZE];
    if (sfs_read_block(block, block_buf) < 0) return -1;
    memcpy(block_buf + offset, inode, sizeof(struct sfs_inode));
    return sfs_write_block(block, block_buf);
}

// ============================================================
// Block allocation / freeing
// ============================================================

static uint32_t sfs_total_data_blocks(void) {
    if (sb.total_blocks <= sb.data_start) return 0;
    return sb.total_blocks - sb.data_start;
}

static uint32_t sfs_alloc_block(void) {
    if (sb.free_blocks == 0) return 0;

    uint8_t bmap[SFS_BLOCK_SIZE];
    uint32_t total_data_blocks = sfs_total_data_blocks();
    for (uint32_t b = 0; b < sb.bitmap_blocks; b++) {
        uint32_t block_base = b * SFS_BLOCK_SIZE * 8;
        if (block_base >= total_data_blocks) break;

        if (sfs_read_block(sb.bitmap_start + b, bmap) < 0) return 0;
        for (uint32_t i = 0; i < SFS_BLOCK_SIZE; i++) {
            if (bmap[i] == 0xFF) continue;
            for (int bit = 0; bit < 8; bit++) {
                uint32_t rel = block_base + i * 8 + (uint32_t)bit;
                if (rel >= total_data_blocks) break;
                if (bmap[i] & (1 << bit)) continue;

                bmap[i] |= (1 << bit);
                if (sfs_write_block(sb.bitmap_start + b, bmap) < 0) return 0;
                if (sb.free_blocks > 0) sb.free_blocks--;
                return sb.data_start + rel;
            }
        }
    }
    return 0;
}

static void sfs_free_block(uint32_t block_num) {
    if (block_num < sb.data_start || block_num >= sb.total_blocks) return;
    uint32_t rel = block_num - sb.data_start;
    uint32_t total_data_blocks = sfs_total_data_blocks();
    if (rel >= total_data_blocks) return;

    uint32_t bmap_block = rel / (SFS_BLOCK_SIZE * 8);
    uint32_t bmap_byte = (rel % (SFS_BLOCK_SIZE * 8)) / 8;
    uint32_t bmap_bit = rel % 8;
    if (bmap_block >= sb.bitmap_blocks) return;

    uint8_t bmap[SFS_BLOCK_SIZE];
    if (sfs_read_block(sb.bitmap_start + bmap_block, bmap) < 0) return;
    if (!(bmap[bmap_byte] & (1 << bmap_bit))) return;

    bmap[bmap_byte] &= ~(1 << bmap_bit);
    if (sfs_write_block(sb.bitmap_start + bmap_block, bmap) < 0) return;
    cache_invalidate(block_num);
    if (sb.free_blocks < total_data_blocks) sb.free_blocks++;
}

static uint32_t sfs_alloc_inode(void) {
    struct sfs_inode inode;
    for (uint32_t i = 1; i < sb.total_inodes; i++) {
        if (sfs_read_inode(i, &inode) < 0) return 0;
        if (inode.type == SFS_TYPE_FREE) {
            if (sb.free_inodes > 0) sb.free_inodes--;
            return i;
        }
    }
    return 0;
}

// ============================================================
// Block pointer management (direct + indirect + double indirect)
// ============================================================

static uint32_t sfs_get_block_ptr(struct sfs_inode *inode, uint32_t block_index) {
    // Direct blocks
    if (block_index < SFS_DIRECT_BLOCKS) {
        return inode->direct[block_index];
    }
    block_index -= SFS_DIRECT_BLOCKS;

    // Single indirect
    if (block_index < SFS_PTRS_PER_BLOCK) {
        if (!inode->indirect) return 0;
        uint32_t ptrs[SFS_PTRS_PER_BLOCK];
        if (sfs_read_block(inode->indirect, ptrs) < 0) return 0;
        return ptrs[block_index];
    }
    block_index -= SFS_PTRS_PER_BLOCK;

    // Double indirect
    if (block_index < SFS_PTRS_PER_BLOCK * SFS_PTRS_PER_BLOCK) {
        if (!inode->dindirect) return 0;
        uint32_t l1_ptrs[SFS_PTRS_PER_BLOCK];
        if (sfs_read_block(inode->dindirect, l1_ptrs) < 0) return 0;

        uint32_t l1_index = block_index / SFS_PTRS_PER_BLOCK;
        uint32_t l2_index = block_index % SFS_PTRS_PER_BLOCK;

        if (!l1_ptrs[l1_index]) return 0;
        uint32_t l2_ptrs[SFS_PTRS_PER_BLOCK];
        if (sfs_read_block(l1_ptrs[l1_index], l2_ptrs) < 0) return 0;
        return l2_ptrs[l2_index];
    }

    return 0; // File too large
}

static int sfs_set_block_ptr(struct sfs_inode *inode, uint32_t block_index, uint32_t block_num) {
    // Direct blocks
    if (block_index < SFS_DIRECT_BLOCKS) {
        inode->direct[block_index] = block_num;
        return 0;
    }
    block_index -= SFS_DIRECT_BLOCKS;

    // Single indirect
    if (block_index < SFS_PTRS_PER_BLOCK) {
        if (!inode->indirect) {
            if (block_num == 0) return 0;
            inode->indirect = sfs_alloc_block();
            if (!inode->indirect) return -1;
            uint8_t zeros[SFS_BLOCK_SIZE];
            memset(zeros, 0, SFS_BLOCK_SIZE);
            if (sfs_write_block(inode->indirect, zeros) < 0) return -1;
        }
        uint32_t ptrs[SFS_PTRS_PER_BLOCK];
        if (sfs_read_block(inode->indirect, ptrs) < 0) return -1;
        ptrs[block_index] = block_num;
        if (sfs_write_block(inode->indirect, ptrs) < 0) return -1;
        return 0;
    }
    block_index -= SFS_PTRS_PER_BLOCK;

    // Double indirect
    if (block_index < SFS_PTRS_PER_BLOCK * SFS_PTRS_PER_BLOCK) {
        if (!inode->dindirect) {
            if (block_num == 0) return 0;
            inode->dindirect = sfs_alloc_block();
            if (!inode->dindirect) return -1;
            uint8_t zeros[SFS_BLOCK_SIZE];
            memset(zeros, 0, SFS_BLOCK_SIZE);
            if (sfs_write_block(inode->dindirect, zeros) < 0) return -1;
        }

        uint32_t l1_ptrs[SFS_PTRS_PER_BLOCK];
        if (sfs_read_block(inode->dindirect, l1_ptrs) < 0) return -1;

        uint32_t l1_index = block_index / SFS_PTRS_PER_BLOCK;
        uint32_t l2_index = block_index % SFS_PTRS_PER_BLOCK;

        if (!l1_ptrs[l1_index]) {
            if (block_num == 0) return 0;
            l1_ptrs[l1_index] = sfs_alloc_block();
            if (!l1_ptrs[l1_index]) return -1;
            uint8_t zeros[SFS_BLOCK_SIZE];
            memset(zeros, 0, SFS_BLOCK_SIZE);
            if (sfs_write_block(l1_ptrs[l1_index], zeros) < 0) return -1;
            if (sfs_write_block(inode->dindirect, l1_ptrs) < 0) return -1;
        }

        uint32_t l2_ptrs[SFS_PTRS_PER_BLOCK];
        if (sfs_read_block(l1_ptrs[l1_index], l2_ptrs) < 0) return -1;
        l2_ptrs[l2_index] = block_num;
        if (sfs_write_block(l1_ptrs[l1_index], l2_ptrs) < 0) return -1;
        return 0;
    }

    return -1; // File too large
}

// Free all data blocks for an inode (including indirect/dindirect metadata)
static void sfs_free_all_blocks(struct sfs_inode *inode) {
    // Free direct blocks
    for (uint32_t i = 0; i < SFS_DIRECT_BLOCKS; i++) {
        if (inode->direct[i]) {
            sfs_free_block(inode->direct[i]);
            inode->direct[i] = 0;
        }
    }

    // Free single indirect
    if (inode->indirect) {
        uint32_t ptrs[SFS_PTRS_PER_BLOCK];
        sfs_read_block(inode->indirect, ptrs);
        for (uint32_t i = 0; i < SFS_PTRS_PER_BLOCK; i++) {
            if (ptrs[i]) sfs_free_block(ptrs[i]);
        }
        sfs_free_block(inode->indirect);
        inode->indirect = 0;
    }

    // Free double indirect
    if (inode->dindirect) {
        uint32_t l1_ptrs[SFS_PTRS_PER_BLOCK];
        sfs_read_block(inode->dindirect, l1_ptrs);
        for (uint32_t i = 0; i < SFS_PTRS_PER_BLOCK; i++) {
            if (!l1_ptrs[i]) continue;
            uint32_t l2_ptrs[SFS_PTRS_PER_BLOCK];
            sfs_read_block(l1_ptrs[i], l2_ptrs);
            for (uint32_t j = 0; j < SFS_PTRS_PER_BLOCK; j++) {
                if (l2_ptrs[j]) sfs_free_block(l2_ptrs[j]);
            }
            sfs_free_block(l1_ptrs[i]);
        }
        sfs_free_block(inode->dindirect);
        inode->dindirect = 0;
    }

    inode->blocks = 0;
}

// ============================================================
// Path resolution
// ============================================================

static uint32_t sfs_resolve_path(const char *path) {
    if (!path || path[0] != '/') return 0;
    if (path[0] == '/' && path[1] == '\0') return sb.root_inode;

    uint32_t current = sb.root_inode;
    char component[MAX_NAME + 1];
    const char *p = path + 1;

    while (*p) {
        int i = 0;
        while (*p && *p != '/' && i < MAX_NAME) {
            component[i++] = *p++;
        }
        component[i] = '\0';
        if (*p == '/') p++;
        if (i == 0) continue;

        struct sfs_inode dir_inode;
        sfs_read_inode(current, &dir_inode);
        if (dir_inode.type != SFS_TYPE_DIR) return 0;

        int found = 0;
        uint32_t num_entries = dir_inode.size / SFS_DIRENT_SIZE;
        uint32_t entries_read = 0;
        for (uint32_t bi = 0; entries_read < num_entries; bi++) {
            uint32_t blk = sfs_get_block_ptr(&dir_inode, bi);
            if (!blk) break;

            struct sfs_dirent dirents[SFS_BLOCK_SIZE / SFS_DIRENT_SIZE];
            sfs_read_block(blk, dirents);

            uint32_t per_block = SFS_BLOCK_SIZE / SFS_DIRENT_SIZE;
            for (uint32_t j = 0; j < per_block && entries_read < num_entries; j++, entries_read++) {
                if (dirents[j].inode && strcmp(dirents[j].name, component) == 0) {
                    current = dirents[j].inode;
                    found = 1;
                    break;
                }
            }
            if (found) break;
        }
        if (!found) return 0;
    }
    return current;
}

static void sfs_split_path(const char *path, char *parent, char *name) {
    strcpy(parent, path);
    char *last = strrchr(parent, '/');
    if (last == parent) {
        strcpy(name, parent + 1);
        parent[1] = '\0';
    } else if (last) {
        strcpy(name, last + 1);
        *last = '\0';
    } else {
        strcpy(name, path);
        strcpy(parent, "/");
    }
}

// ============================================================
// VFS operations
// ============================================================

static ssize_t sfs_vfs_read(struct vfs_node *node, void *buf, size_t count) {
    struct sfs_inode inode;
    sfs_read_inode(node->inode, &inode);

    if (node->offset >= inode.size) return 0;
    if (node->offset + count > inode.size) count = inode.size - node->offset;

    size_t read = 0;
    uint8_t tmp[SFS_BLOCK_SIZE];

    while (read < count) {
        uint32_t block_index = (node->offset + read) / SFS_BLOCK_SIZE;
        uint32_t block_offset = (node->offset + read) % SFS_BLOCK_SIZE;
        uint32_t blk = sfs_get_block_ptr(&inode, block_index);
        if (!blk) {
            memset(tmp, 0, SFS_BLOCK_SIZE);
        } else if (sfs_read_block(blk, tmp) < 0) {
            break;
        }

        size_t to_copy = SFS_BLOCK_SIZE - block_offset;
        if (to_copy > count - read) to_copy = count - read;
        memcpy((uint8_t *)buf + read, tmp + block_offset, to_copy);
        read += to_copy;
    }

    node->offset += read;
    return (ssize_t)read;
}

static ssize_t sfs_vfs_write(struct vfs_node *node, const void *buf, size_t count) {
    struct sfs_inode inode;
    sfs_read_inode(node->inode, &inode);

    if (node->flags & O_APPEND) {
        node->offset = inode.size;
    }

    size_t written = 0;
    uint8_t tmp[SFS_BLOCK_SIZE];

    while (written < count) {
        uint32_t block_index = (node->offset + written) / SFS_BLOCK_SIZE;
        uint32_t block_offset = (node->offset + written) % SFS_BLOCK_SIZE;
        uint32_t blk = sfs_get_block_ptr(&inode, block_index);

        if (!blk) {
            blk = sfs_alloc_block();
            if (!blk) break;
            if (sfs_set_block_ptr(&inode, block_index, blk) < 0) {
                sfs_free_block(blk);
                break;
            }
            inode.blocks++;
            memset(tmp, 0, SFS_BLOCK_SIZE);
        } else {
            if (sfs_read_block(blk, tmp) < 0) break;
        }

        size_t to_copy = SFS_BLOCK_SIZE - block_offset;
        if (to_copy > count - written) to_copy = count - written;
        memcpy(tmp + block_offset, (const uint8_t *)buf + written, to_copy);
        if (sfs_write_block(blk, tmp) < 0) break;
        written += to_copy;
    }

    node->offset += written;
    if (node->offset > inode.size) {
        inode.size = node->offset;
    }
    inode.modified = sfs_now();
    node->size = inode.size;
    sfs_write_inode(node->inode, &inode);

    return (ssize_t)written;
}

static int sfs_vfs_open(struct vfs_node *node, int flags) {
    const char *path = node->name;
    uint32_t inum = sfs_resolve_path(path);

    if (!inum && (flags & O_CREAT)) {
        char parent[MAX_PATH], name[MAX_NAME + 1];
        sfs_split_path(path, parent, name);

        uint32_t parent_inum = sfs_resolve_path(parent);
        if (!parent_inum) return -1;

        inum = sfs_alloc_inode();
        if (!inum) return -1;

        struct sfs_inode new_inode;
        memset(&new_inode, 0, sizeof(new_inode));
        new_inode.type = SFS_TYPE_FILE;
        new_inode.created = sfs_now();
        new_inode.modified = new_inode.created;
        new_inode.permissions = 0644;
        sfs_write_inode(inum, &new_inode);

        // Add entry to parent directory
        struct sfs_inode parent_inode;
        sfs_read_inode(parent_inum, &parent_inode);

        struct sfs_dirent entry;
        memset(&entry, 0, sizeof(entry));
        entry.inode = inum;
        entry.type = SFS_TYPE_FILE;
        entry.name_len = strlen(name);
        strncpy(entry.name, name, SFS_DIRENT_SIZE - 6);

        uint32_t num_entries = parent_inode.size / SFS_DIRENT_SIZE;
        uint32_t target_block_index = num_entries / (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE);
        uint32_t target_offset = (num_entries % (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE)) * SFS_DIRENT_SIZE;

        uint32_t blk = sfs_get_block_ptr(&parent_inode, target_block_index);
        if (!blk) {
            blk = sfs_alloc_block();
            if (!blk) return -1;
            if (sfs_set_block_ptr(&parent_inode, target_block_index, blk) < 0) {
                sfs_free_block(blk);
                return -1;
            }
            parent_inode.blocks++;
            uint8_t zeros[SFS_BLOCK_SIZE];
            memset(zeros, 0, SFS_BLOCK_SIZE);
            if (sfs_write_block(blk, zeros) < 0) return -1;
        }

        uint8_t dir_buf[SFS_BLOCK_SIZE];
        if (sfs_read_block(blk, dir_buf) < 0) return -1;
        memcpy(dir_buf + target_offset, &entry, SFS_DIRENT_SIZE);
        if (sfs_write_block(blk, dir_buf) < 0) return -1;

        parent_inode.size += SFS_DIRENT_SIZE;
        parent_inode.modified = sfs_now();
        sfs_write_inode(parent_inum, &parent_inode);
    }

    if (!inum) return -1;

    struct sfs_inode inode;
    sfs_read_inode(inum, &inode);

    node->inode = inum;
    node->type = inode.type;
    node->size = inode.size;
    node->offset = 0;

    if (flags & O_TRUNC) {
        sfs_free_all_blocks(&inode);
        inode.size = 0;
        inode.modified = sfs_now();
        sfs_write_inode(inum, &inode);
        node->size = 0;
    }

    return 0;
}

static void sfs_vfs_close(struct vfs_node *node) {
    (void)node;
}

static int sfs_vfs_readdir(struct vfs_node *node, struct dirent *entry) {
    struct sfs_inode inode;
    sfs_read_inode(node->inode, &inode);

    if (inode.type != SFS_TYPE_DIR) return -1;

    uint32_t num_entries = inode.size / SFS_DIRENT_SIZE;
    while (node->dir_index < num_entries) {
        uint32_t block_index = node->dir_index / (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE);
        uint32_t entry_in_block = node->dir_index % (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE);

        uint32_t blk = sfs_get_block_ptr(&inode, block_index);
        if (!blk) return -1;

        struct sfs_dirent dirents[SFS_BLOCK_SIZE / SFS_DIRENT_SIZE];
        sfs_read_block(blk, dirents);

        node->dir_index++;

        if (dirents[entry_in_block].inode) {
            entry->inode = dirents[entry_in_block].inode;
            entry->type = dirents[entry_in_block].type;
            strncpy(entry->name, dirents[entry_in_block].name, MAX_NAME);
            entry->name[MAX_NAME] = '\0';
            return 0;
        }
    }
    return -1;
}

static int sfs_vfs_mkdir(const char *path) {
    char parent[MAX_PATH], name[MAX_NAME + 1];
    sfs_split_path(path, parent, name);

    uint32_t parent_inum = sfs_resolve_path(parent);
    if (!parent_inum) return -1;

    if (sfs_resolve_path(path)) return -1;

    uint32_t inum = sfs_alloc_inode();
    if (!inum) return -1;

    struct sfs_inode new_inode;
    memset(&new_inode, 0, sizeof(new_inode));
    new_inode.type = SFS_TYPE_DIR;
    new_inode.size = 0;
    new_inode.created = sfs_now();
    new_inode.modified = new_inode.created;
    new_inode.permissions = 0755;
    sfs_write_inode(inum, &new_inode);

    struct sfs_inode parent_inode;
    sfs_read_inode(parent_inum, &parent_inode);

    struct sfs_dirent entry;
    memset(&entry, 0, sizeof(entry));
    entry.inode = inum;
    entry.type = SFS_TYPE_DIR;
    entry.name_len = strlen(name);
    strncpy(entry.name, name, SFS_DIRENT_SIZE - 6);

    uint32_t num_entries = parent_inode.size / SFS_DIRENT_SIZE;
    uint32_t bi = num_entries / (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE);
    uint32_t off = (num_entries % (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE)) * SFS_DIRENT_SIZE;

    uint32_t blk = sfs_get_block_ptr(&parent_inode, bi);
    if (!blk) {
        blk = sfs_alloc_block();
        if (!blk) return -1;
        if (sfs_set_block_ptr(&parent_inode, bi, blk) < 0) {
            sfs_free_block(blk);
            return -1;
        }
        parent_inode.blocks++;
        uint8_t z[SFS_BLOCK_SIZE];
        memset(z, 0, SFS_BLOCK_SIZE);
        if (sfs_write_block(blk, z) < 0) return -1;
    }

    uint8_t dbuf[SFS_BLOCK_SIZE];
    if (sfs_read_block(blk, dbuf) < 0) return -1;
    memcpy(dbuf + off, &entry, SFS_DIRENT_SIZE);
    if (sfs_write_block(blk, dbuf) < 0) return -1;

    parent_inode.size += SFS_DIRENT_SIZE;
    parent_inode.modified = sfs_now();
    sfs_write_inode(parent_inum, &parent_inode);
    return 0;
}

static int sfs_vfs_rmdir(const char *path) {
    uint32_t inum = sfs_resolve_path(path);
    if (!inum) return -1;

    struct sfs_inode inode;
    sfs_read_inode(inum, &inode);
    if (inode.type != SFS_TYPE_DIR) return -1;
    if (inode.size > 0) return -1;

    char parent[MAX_PATH], name[MAX_NAME + 1];
    sfs_split_path(path, parent, name);
    uint32_t parent_inum = sfs_resolve_path(parent);
    if (!parent_inum) return -1;

    struct sfs_inode parent_inode;
    sfs_read_inode(parent_inum, &parent_inode);

    uint32_t num_entries = parent_inode.size / SFS_DIRENT_SIZE;
    for (uint32_t i = 0; i < num_entries; i++) {
        uint32_t bi = i / (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE);
        uint32_t ei = i % (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE);
        uint32_t blk = sfs_get_block_ptr(&parent_inode, bi);
        if (!blk) continue;

        struct sfs_dirent dirents[SFS_BLOCK_SIZE / SFS_DIRENT_SIZE];
        sfs_read_block(blk, dirents);

        if (dirents[ei].inode == inum) {
            memset(&dirents[ei], 0, SFS_DIRENT_SIZE);
            sfs_write_block(blk, dirents);
            break;
        }
    }

    inode.type = SFS_TYPE_FREE;
    sfs_write_inode(inum, &inode);
    sb.free_inodes++;
    return 0;
}

static int sfs_vfs_unlink(const char *path) {
    uint32_t inum = sfs_resolve_path(path);
    if (!inum) return -1;

    struct sfs_inode inode;
    sfs_read_inode(inum, &inode);
    if (inode.type != SFS_TYPE_FILE) return -1;

    sfs_free_all_blocks(&inode);

    char parent[MAX_PATH], name[MAX_NAME + 1];
    sfs_split_path(path, parent, name);
    uint32_t parent_inum = sfs_resolve_path(parent);
    if (!parent_inum) return -1;

    struct sfs_inode parent_inode;
    sfs_read_inode(parent_inum, &parent_inode);

    uint32_t num_entries = parent_inode.size / SFS_DIRENT_SIZE;
    for (uint32_t i = 0; i < num_entries; i++) {
        uint32_t bi = i / (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE);
        uint32_t ei = i % (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE);
        uint32_t blk = sfs_get_block_ptr(&parent_inode, bi);
        if (!blk) continue;

        struct sfs_dirent dirents[SFS_BLOCK_SIZE / SFS_DIRENT_SIZE];
        sfs_read_block(blk, dirents);

        if (dirents[ei].inode == inum) {
            memset(&dirents[ei], 0, SFS_DIRENT_SIZE);
            sfs_write_block(blk, dirents);
            break;
        }
    }

    inode.type = SFS_TYPE_FREE;
    sfs_write_inode(inum, &inode);
    sb.free_inodes++;
    return 0;
}

static int sfs_vfs_rename(const char *oldpath, const char *newpath) {
    uint32_t inum = sfs_resolve_path(oldpath);
    if (!inum) return -1;

    // Check newpath doesn't exist
    if (sfs_resolve_path(newpath)) return -1;

    // Remove from old parent
    char old_parent[MAX_PATH], old_name[MAX_NAME + 1];
    sfs_split_path(oldpath, old_parent, old_name);
    uint32_t old_parent_inum = sfs_resolve_path(old_parent);
    if (!old_parent_inum) return -1;

    struct sfs_inode old_parent_inode;
    sfs_read_inode(old_parent_inum, &old_parent_inode);

    uint32_t num_entries = old_parent_inode.size / SFS_DIRENT_SIZE;
    for (uint32_t i = 0; i < num_entries; i++) {
        uint32_t bi = i / (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE);
        uint32_t ei = i % (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE);
        uint32_t blk = sfs_get_block_ptr(&old_parent_inode, bi);
        if (!blk) continue;

        struct sfs_dirent dirents[SFS_BLOCK_SIZE / SFS_DIRENT_SIZE];
        sfs_read_block(blk, dirents);

        if (dirents[ei].inode == inum) {
            memset(&dirents[ei], 0, SFS_DIRENT_SIZE);
            sfs_write_block(blk, dirents);
            break;
        }
    }

    // Add to new parent
    char new_parent[MAX_PATH], new_name[MAX_NAME + 1];
    sfs_split_path(newpath, new_parent, new_name);
    uint32_t new_parent_inum = sfs_resolve_path(new_parent);
    if (!new_parent_inum) return -1;

    struct sfs_inode new_parent_inode;
    sfs_read_inode(new_parent_inum, &new_parent_inode);

    struct sfs_inode file_inode;
    sfs_read_inode(inum, &file_inode);

    struct sfs_dirent entry;
    memset(&entry, 0, sizeof(entry));
    entry.inode = inum;
    entry.type = file_inode.type;
    entry.name_len = strlen(new_name);
    strncpy(entry.name, new_name, SFS_DIRENT_SIZE - 6);

    uint32_t nentries = new_parent_inode.size / SFS_DIRENT_SIZE;
    uint32_t bi = nentries / (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE);
    uint32_t off = (nentries % (SFS_BLOCK_SIZE / SFS_DIRENT_SIZE)) * SFS_DIRENT_SIZE;

    uint32_t blk = sfs_get_block_ptr(&new_parent_inode, bi);
    if (!blk) {
        blk = sfs_alloc_block();
        if (!blk) return -1;
        if (sfs_set_block_ptr(&new_parent_inode, bi, blk) < 0) {
            sfs_free_block(blk);
            return -1;
        }
        new_parent_inode.blocks++;
        uint8_t z[SFS_BLOCK_SIZE];
        memset(z, 0, SFS_BLOCK_SIZE);
        if (sfs_write_block(blk, z) < 0) return -1;
    }

    uint8_t dbuf[SFS_BLOCK_SIZE];
    if (sfs_read_block(blk, dbuf) < 0) return -1;
    memcpy(dbuf + off, &entry, SFS_DIRENT_SIZE);
    if (sfs_write_block(blk, dbuf) < 0) return -1;

    new_parent_inode.size += SFS_DIRENT_SIZE;
    new_parent_inode.modified = sfs_now();
    sfs_write_inode(new_parent_inum, &new_parent_inode);

    file_inode.modified = sfs_now();
    sfs_write_inode(inum, &file_inode);
    return 0;
}

static int sfs_vfs_truncate(const char *path, uint32_t length) {
    uint32_t inum = sfs_resolve_path(path);
    if (!inum) return -1;

    struct sfs_inode inode;
    sfs_read_inode(inum, &inode);
    if (inode.type != SFS_TYPE_FILE) return -1;

    if (length == 0) {
        sfs_free_all_blocks(&inode);
        inode.size = 0;
    } else if (length < inode.size) {
        // Free blocks beyond new length
        uint32_t new_blocks = (length + SFS_BLOCK_SIZE - 1) / SFS_BLOCK_SIZE;
        uint32_t old_blocks = (inode.size + SFS_BLOCK_SIZE - 1) / SFS_BLOCK_SIZE;
        for (uint32_t i = new_blocks; i < old_blocks; i++) {
            uint32_t blk = sfs_get_block_ptr(&inode, i);
            if (blk) {
                sfs_free_block(blk);
                sfs_set_block_ptr(&inode, i, 0);
                inode.blocks--;
            }
        }
        inode.size = length;
    }
    // If length > inode.size, we just update the size (sparse file)
    else {
        inode.size = length;
    }

    inode.modified = sfs_now();
    sfs_write_inode(inum, &inode);
    return 0;
}

static int sfs_vfs_chmod(const char *path, uint32_t mode) {
    uint32_t inum = sfs_resolve_path(path);
    if (!inum) return -1;

    struct sfs_inode inode;
    sfs_read_inode(inum, &inode);
    inode.permissions = mode;
    inode.modified = sfs_now();
    sfs_write_inode(inum, &inode);
    return 0;
}

static int sfs_vfs_stat(const char *path, struct stat *st) {
    uint32_t inum = sfs_resolve_path(path);
    if (!inum) return -1;

    struct sfs_inode inode;
    sfs_read_inode(inum, &inode);

    st->inode = inum;
    st->type = inode.type;
    st->size = inode.size;
    st->blocks = inode.blocks;
    st->created = inode.created;
    st->modified = inode.modified;
    return 0;
}

static int64_t sfs_vfs_lseek(struct vfs_node *node, int64_t offset, int whence) {
    struct sfs_inode inode;
    sfs_read_inode(node->inode, &inode);

    int64_t new_offset;
    switch (whence) {
        case SEEK_SET: new_offset = offset; break;
        case SEEK_CUR: new_offset = (int64_t)node->offset + offset; break;
        case SEEK_END: new_offset = (int64_t)inode.size + offset; break;
        default: return -1;
    }
    if (new_offset < 0) return -1;
    node->offset = (uint64_t)new_offset;
    return new_offset;
}

static struct vfs_ops sfs_ops = {
    .read    = sfs_vfs_read,
    .write   = sfs_vfs_write,
    .open    = sfs_vfs_open,
    .close   = sfs_vfs_close,
    .readdir = sfs_vfs_readdir,
    .mkdir   = sfs_vfs_mkdir,
    .rmdir   = sfs_vfs_rmdir,
    .unlink  = sfs_vfs_unlink,
    .stat    = sfs_vfs_stat,
    .lseek   = sfs_vfs_lseek,
    .rename   = sfs_vfs_rename,
    .truncate = sfs_vfs_truncate,
    .chmod    = sfs_vfs_chmod,
};

void simplefs_init(uint32_t start_lba) {
    fs_start_lba = start_lba;
    cache_init();

    uint8_t sb_buf[SFS_BLOCK_SIZE];
    if (sfs_read_block(0, sb_buf) < 0) {
        kprintf("SimpleFS: Failed to read superblock\n");
        return;
    }
    memcpy(&sb, sb_buf, sizeof(sb));

    if (sb.magic != SFS_MAGIC) {
        kprintf("SimpleFS: Invalid magic: 0x%x\n", sb.magic);
        return;
    }

    kprintf("SimpleFS: %d blocks (%d free), %d inodes (%d free), root=%d\n",
            sb.total_blocks, sb.free_blocks, sb.total_inodes, sb.free_inodes, sb.root_inode);
    kprintf("SimpleFS: Block cache: %d entries\n", SFS_CACHE_SIZE);

    vfs_register_fs(&sfs_ops);
}

// ============================================================
// Info accessors for sysinfo / task manager
// ============================================================

uint32_t simplefs_get_total_blocks(void) { return sb.total_blocks; }
uint32_t simplefs_get_free_blocks(void)  { return sb.free_blocks; }
uint32_t simplefs_get_total_inodes(void) { return sb.total_inodes; }
uint32_t simplefs_get_free_inodes(void)  { return sb.free_inodes; }
uint32_t simplefs_get_cache_hits(void)   { return cache_hits; }
uint32_t simplefs_get_cache_misses(void) { return cache_misses; }
