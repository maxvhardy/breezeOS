#include "libc/stdio.h"
#include "libc/stdlib.h"
#include "libc/string.h"
#include "libc/unistd.h"

#define INPUT_BUF_SIZE 256
#define MAX_ARGS 16

static char cwd[MAX_PATH];

static void print_prompt(void) {
    getcwd(cwd, sizeof(cwd));
    printf("\033[32m%s\033[0m$ ", cwd);
}

// Read a line of input with basic editing
static int read_line(char *buf, int max) {
    int pos = 0;
    while (pos < max - 1) {
        char c;
        ssize_t n = read(STDIN_FILENO, &c, 1);
        if (n <= 0) {
            yield();
            continue;
        }
        if (c == '\n' || c == '\r') {
            buf[pos] = '\0';
            putchar('\n');
            return pos;
        }
        if (c == '\b' || c == 127) {
            if (pos > 0) {
                pos--;
                printf("\b \b");
            }
            continue;
        }
        if (c >= 32) {
            buf[pos++] = c;
            putchar(c);
        }
    }
    buf[pos] = '\0';
    return pos;
}

// Parse command line into argv
static int parse_args(char *line, char *argv[]) {
    int argc = 0;
    char *p = line;

    while (*p && argc < MAX_ARGS - 1) {
        // Skip whitespace
        while (*p == ' ' || *p == '\t') p++;
        if (*p == '\0') break;

        argv[argc++] = p;

        // Find end of argument
        while (*p && *p != ' ' && *p != '\t') p++;
        if (*p) *p++ = '\0';
    }
    argv[argc] = NULL;
    return argc;
}

static int has_suffix(const char *path, const char *suffix) {
    size_t plen = strlen(path);
    size_t slen = strlen(suffix);
    if (plen < slen) return 0;
    return strcmp(path + plen - slen, suffix) == 0;
}

static void try_exec_with_exe_fallback(const char *path, const char *raw_cmd) {
    exec(path);

    char alt[MAX_PATH];
    size_t plen = strlen(path);

    if (!has_suffix(path, ".exe")) {
        if (plen + 4 < sizeof(alt)) {
            memcpy(alt, path, plen);
            memcpy(alt + plen, ".exe", 5);
            exec(alt);
        }
    } else if (plen > 4 && plen - 4 < sizeof(alt)) {
        memcpy(alt, path, plen - 4);
        alt[plen - 4] = '\0';
        exec(alt);
    }

    printf("shell: '%s' not found\n", raw_cmd);
}

// Built-in commands

static void cmd_help(void) {
    printf("DoorOS Shell - Built-in commands:\n");
    printf("  help          - Show this help message\n");
    printf("  cd <dir>      - Change directory\n");
    printf("  pwd           - Print working directory\n");
    printf("  ls [dir]      - List directory contents\n");
    printf("  cat <file>    - Display file contents\n");
    printf("  echo <text>   - Print text\n");
    printf("  mkdir <dir>   - Create directory\n");
    printf("  rmdir <dir>   - Remove directory\n");
    printf("  rm <file>     - Remove file\n");
    printf("  touch <file>  - Create empty file\n");
    printf("  stat <path>   - Show file/dir info\n");
    printf("  clear         - Clear screen\n");
    printf("  pid           - Show current PID\n");
    printf("  uptime        - Show system uptime\n");
    printf("  exit          - Exit shell\n");
}

static void cmd_cd(int argc, char *argv[]) {
    const char *path = argc > 1 ? argv[1] : "/";
    if (chdir(path) < 0) {
        printf("cd: cannot change to '%s'\n", path);
    }
}

static void cmd_pwd(void) {
    char buf[MAX_PATH];
    if (getcwd(buf, sizeof(buf))) {
        printf("%s\n", buf);
    } else {
        printf("pwd: error getting cwd\n");
    }
}

static void cmd_ls(int argc, char *argv[]) {
    const char *path = argc > 1 ? argv[1] : ".";

    // Build absolute path if relative
    char fullpath[MAX_PATH];
    if (path[0] == '/') {
        strncpy(fullpath, path, MAX_PATH - 1);
    } else if (strcmp(path, ".") == 0) {
        getcwd(fullpath, sizeof(fullpath));
    } else {
        getcwd(fullpath, sizeof(fullpath));
        if (fullpath[strlen(fullpath) - 1] != '/') {
            strcat(fullpath, "/");
        }
        strcat(fullpath, path);
    }

    int fd = open(fullpath, O_RDONLY);
    if (fd < 0) {
        printf("ls: cannot open '%s'\n", fullpath);
        return;
    }

    struct dirent entry;
    int count = 0;
    while (readdir(fd, &entry) == 0) {
        char type_ch = entry.type == 2 ? 'd' : '-';
        printf("  %c  %s\n", type_ch, entry.name);
        count++;
    }

    if (count == 0) {
        printf("  (empty directory)\n");
    }

    close(fd);
}

static void cmd_cat(int argc, char *argv[]) {
    if (argc < 2) {
        printf("cat: missing filename\n");
        return;
    }

    int fd = open(argv[1], O_RDONLY);
    if (fd < 0) {
        printf("cat: cannot open '%s'\n", argv[1]);
        return;
    }

    char buf[512];
    ssize_t n;
    while ((n = read(fd, buf, sizeof(buf))) > 0) {
        write(STDOUT_FILENO, buf, n);
    }
    close(fd);
}

static void cmd_echo(int argc, char *argv[]) {
    for (int i = 1; i < argc; i++) {
        if (i > 1) putchar(' ');
        printf("%s", argv[i]);
    }
    putchar('\n');
}

static void cmd_mkdir_cmd(int argc, char *argv[]) {
    if (argc < 2) {
        printf("mkdir: missing directory name\n");
        return;
    }
    if (mkdir(argv[1]) < 0) {
        printf("mkdir: cannot create '%s'\n", argv[1]);
    }
}

static void cmd_rmdir_cmd(int argc, char *argv[]) {
    if (argc < 2) {
        printf("rmdir: missing directory name\n");
        return;
    }
    if (rmdir(argv[1]) < 0) {
        printf("rmdir: cannot remove '%s'\n", argv[1]);
    }
}

static void cmd_rm(int argc, char *argv[]) {
    if (argc < 2) {
        printf("rm: missing filename\n");
        return;
    }
    if (unlink(argv[1]) < 0) {
        printf("rm: cannot remove '%s'\n", argv[1]);
    }
}

static void cmd_touch(int argc, char *argv[]) {
    if (argc < 2) {
        printf("touch: missing filename\n");
        return;
    }
    int fd = open(argv[1], O_CREAT | O_WRONLY);
    if (fd < 0) {
        printf("touch: cannot create '%s'\n", argv[1]);
        return;
    }
    close(fd);
}

static void cmd_stat_cmd(int argc, char *argv[]) {
    if (argc < 2) {
        printf("stat: missing path\n");
        return;
    }
    struct stat st;
    if (stat(argv[1], &st) < 0) {
        printf("stat: cannot stat '%s'\n", argv[1]);
        return;
    }
    printf("  inode:  %u\n", st.inode);
    printf("  type:   %s\n", st.type == 2 ? "directory" : "file");
    printf("  size:   %u bytes\n", st.size);
    printf("  blocks: %u\n", st.blocks);
}

static void cmd_clear(void) {
    // Send ANSI clear sequence (may not be fully supported)
    printf("\033[2J\033[H");
}

int main(void) {
    printf("\n");
    printf("  =============================================\n");
    printf("  |         DoorOS Shell v0.1                 |\n");
    printf("  |             Build: DoorOS                 |\n");
    printf("  |   Type 'help' for available commands      |\n");
    printf("  =============================================\n");
    printf("\n");

    char input[INPUT_BUF_SIZE];

    while (1) {
        print_prompt();

        int len = read_line(input, sizeof(input));
        if (len <= 0) continue;

        char *argv[MAX_ARGS];
        int argc = parse_args(input, argv);
        if (argc == 0) continue;

        // Match built-in commands
        if (strcmp(argv[0], "help") == 0) {
            cmd_help();
        } else if (strcmp(argv[0], "cd") == 0) {
            cmd_cd(argc, argv);
        } else if (strcmp(argv[0], "pwd") == 0) {
            cmd_pwd();
        } else if (strcmp(argv[0], "ls") == 0) {
            cmd_ls(argc, argv);
        } else if (strcmp(argv[0], "cat") == 0) {
            cmd_cat(argc, argv);
        } else if (strcmp(argv[0], "echo") == 0) {
            cmd_echo(argc, argv);
        } else if (strcmp(argv[0], "mkdir") == 0) {
            cmd_mkdir_cmd(argc, argv);
        } else if (strcmp(argv[0], "rmdir") == 0) {
            cmd_rmdir_cmd(argc, argv);
        } else if (strcmp(argv[0], "rm") == 0) {
            cmd_rm(argc, argv);
        } else if (strcmp(argv[0], "touch") == 0) {
            cmd_touch(argc, argv);
        } else if (strcmp(argv[0], "stat") == 0) {
            cmd_stat_cmd(argc, argv);
        } else if (strcmp(argv[0], "clear") == 0) {
            cmd_clear();
        } else if (strcmp(argv[0], "pid") == 0) {
            printf("PID: %d\n", getpid());
        } else if (strcmp(argv[0], "uptime") == 0) {
            printf("(uptime info not available from user space)\n");
        } else if (strcmp(argv[0], "exit") == 0) {
            printf("Goodbye!\n");
            exit(0);
        } else {
            // Try to execute as external program
            char path[MAX_PATH];
            if (argv[0][0] == '/') {
                strncpy(path, argv[0], MAX_PATH - 1);
                path[MAX_PATH - 1] = '\0';
            } else {
                snprintf(path, sizeof(path), "/bin/%s", argv[0]);
            }

            int pid = fork();
            if (pid == 0) {
                try_exec_with_exe_fallback(path, argv[0]);
                exit(1);
            } else if (pid > 0) {
                int status;
                waitpid(pid, &status);
            } else {
                printf("shell: fork failed\n");
            }
        }
    }

    return 0;
}
