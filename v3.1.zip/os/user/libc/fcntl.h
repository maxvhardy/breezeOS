#pragma once

#include "stdio.h"

int open(const char *path, int flags, ...);
int close(int fd);
