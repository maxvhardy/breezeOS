#include "unistd.h"

int usleep(unsigned int usec) {
    uint64_t ms = (uint64_t)(usec / 1000U);
    if ((usec % 1000U) != 0U) ms++;
    sleep(ms);
    return 0;
}

unsigned int sleep_seconds(unsigned int seconds) {
    sleep((uint64_t)seconds * 1000ULL);
    return 0;
}
