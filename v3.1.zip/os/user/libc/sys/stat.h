#pragma once

#include "../stdio.h"

#define st_size size
#define st_mode type
