#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "doomdef.h"
#include "m_misc.h"
#include "i_video.h"
#include "i_sound.h"
#include "d_net.h"
#include "g_game.h"
#include "i_system.h"

static int mb_used = 4;
static int64_t i_basetime_ms = -1;
static ticcmd_t emptycmd;

void I_Tactile(int on, int off, int total) {
    (void)on;
    (void)off;
    (void)total;
}

ticcmd_t *I_BaseTiccmd(void) {
    return &emptycmd;
}

byte *I_ZoneBase(int *size) {
    if (!size) return NULL;
    for (int mb = mb_used; mb >= 2; mb--) {
        int bytes = mb * 1024 * 1024;
        byte *zone = (byte *)malloc((size_t)bytes);
        if (!zone) continue;
        mb_used = mb;
        *size = bytes;
        return zone;
    }

    *size = 0;
    return NULL;
}

int I_GetTime(void) {
    int64_t now_ms = ticks();
    if (i_basetime_ms < 0) {
        i_basetime_ms = now_ms;
    }

    int64_t elapsed_ms = now_ms - i_basetime_ms;
    return (int)((elapsed_ms * TICRATE) / 1000);
}

void I_Init(void) {
    I_InitSound();
}

void I_Quit(void) {
    D_QuitNetGame();
    I_ShutdownSound();
    I_ShutdownMusic();
    M_SaveDefaults();
    I_ShutdownGraphics();
    exit(0);
}

void I_WaitVBL(int count) {
    if (count <= 0) return;
    sleep((uint64_t)count * 1000ULL / 70ULL);
}

void I_BeginRead(void) {
}

void I_EndRead(void) {
}

byte *I_AllocLow(int length) {
    if (length <= 0) return NULL;

    byte *mem = (byte *)malloc((size_t)length);
    if (mem) {
        memset(mem, 0, (size_t)length);
    }
    return mem;
}

extern boolean demorecording;

void I_Error(char *error, ...) {
    va_list argptr;

    va_start(argptr, error);
    fprintf(stderr, "Error: ");
    vfprintf(stderr, error, argptr);
    fprintf(stderr, "\n");
    va_end(argptr);

    if (demorecording) {
        G_CheckDemoStatus();
    }

    D_QuitNetGame();
    I_ShutdownGraphics();
    exit(-1);
}
