// DoorOS entrypoint for the official id Software DOOM source tree.

#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#include "doomdef.h"
#include "m_argv.h"
#include "d_main.h"

static int has_iwad_magic(const char *path) {
    if (!path || !path[0]) return 0;

    struct stat st;
    if (stat(path, &st) != 0 || st.size < 1024) return 0;

    int fd = open(path, O_RDONLY);
    if (fd < 0) return 0;

    unsigned char magic[4];
    ssize_t n = read(fd, magic, sizeof(magic));
    close(fd);

    if (n != (ssize_t)sizeof(magic)) return 0;
    if (magic[0] == 'I' && magic[1] == 'W' && magic[2] == 'A' && magic[3] == 'D') return 1;
    if (magic[0] == 'P' && magic[1] == 'W' && magic[2] == 'A' && magic[3] == 'D') return 1;
    return 0;
}

static int setup_wad_directory(void) {
    static const char *candidates[] = {
        "/bin/doom1.wad",
        "/bin/DOOM1.WAD",
        "/bin/doom2.wad",
        "/bin/DOOM2.WAD",
        "/bin/doom.wad",
        "/bin/DOOM.WAD",
        "/bin/freedoom1.wad",
        "/bin/FREEDOOM1.WAD",
        "/bin/freedoom2.wad",
        "/bin/FREEDOOM2.WAD",
        "/doom1.wad",
        "/doom2.wad",
        "/doom.wad",
    };

    for (size_t i = 0; i < sizeof(candidates) / sizeof(candidates[0]); i++) {
        if (!has_iwad_magic(candidates[i])) continue;

        if (strncmp(candidates[i], "/bin/", 5) == 0) {
            if (chdir("/bin") == 0) {
                return 0;
            }
        }

        if (chdir("/") == 0) {
            return 0;
        }
    }

    return -1;
}

int main(int argc, char **argv) {
    if (setup_wad_directory() < 0) {
        printf("doom: missing IWAD in /bin (expected doom1.wad/doom2.wad)\\n");
        return 1;
    }

    myargc = argc;
    myargv = argv;
    D_DoomMain();
    return 0;
}
