use crate::rust_driver_traits::{Driver, DriverError};

pub struct VbeFramebuffer {
    pub width: u32,
    pub height: u32,
    pub pitch: u32,
    pub bpp: u32,
    pub phys_addr: u64,
}

impl VbeFramebuffer {
    pub const fn empty() -> Self {
        Self {
            width: 0,
            height: 0,
            pitch: 0,
            bpp: 0,
            phys_addr: 0,
        }
    }
}

impl Driver for VbeFramebuffer {
    fn name(&self) -> &'static str {
        "vbe-fb"
    }

    fn init(&mut self) -> Result<(), DriverError> {
        if self.width == 0 || self.height == 0 || self.bpp == 0 {
            return Err(DriverError::BadState);
        }
        Ok(())
    }
}
