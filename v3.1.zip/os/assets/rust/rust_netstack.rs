#![no_std]

use core::cmp::min;

pub const ETH_TYPE_IPV4: u16 = 0x0800;
pub const ETH_TYPE_ARP: u16 = 0x0806;
pub const IP_PROTO_ICMP: u8 = 1;

#[derive(Copy, Clone, Eq, PartialEq)]
pub struct MacAddr(pub [u8; 6]);

impl MacAddr {
    pub const fn broadcast() -> Self {
        Self([0xFF; 6])
    }

    pub const fn zero() -> Self {
        Self([0; 6])
    }
}

#[derive(Copy, Clone)]
pub struct EthernetHeader {
    pub dst: MacAddr,
    pub src: MacAddr,
    pub eth_type: u16,
}

impl EthernetHeader {
    pub const LEN: usize = 14;

    pub fn encode(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < Self::LEN {
            return None;
        }

        out[0..6].copy_from_slice(&self.dst.0);
        out[6..12].copy_from_slice(&self.src.0);
        out[12] = (self.eth_type >> 8) as u8;
        out[13] = (self.eth_type & 0xFF) as u8;
        Some(Self::LEN)
    }
}

#[derive(Copy, Clone)]
pub struct ArpPacket {
    pub oper: u16,
    pub sender_mac: MacAddr,
    pub sender_ip: [u8; 4],
    pub target_mac: MacAddr,
    pub target_ip: [u8; 4],
}

impl ArpPacket {
    pub const LEN: usize = 28;

    pub fn encode(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < Self::LEN {
            return None;
        }

        // HTYPE=1 (ethernet), PTYPE=0x0800 (IPv4), HLEN=6, PLEN=4.
        out[0] = 0;
        out[1] = 1;
        out[2] = 0x08;
        out[3] = 0x00;
        out[4] = 6;
        out[5] = 4;
        out[6] = (self.oper >> 8) as u8;
        out[7] = (self.oper & 0xFF) as u8;
        out[8..14].copy_from_slice(&self.sender_mac.0);
        out[14..18].copy_from_slice(&self.sender_ip);
        out[18..24].copy_from_slice(&self.target_mac.0);
        out[24..28].copy_from_slice(&self.target_ip);
        Some(Self::LEN)
    }
}

#[derive(Copy, Clone)]
pub struct Ipv4Header {
    pub total_len: u16,
    pub ttl: u8,
    pub protocol: u8,
    pub src: [u8; 4],
    pub dst: [u8; 4],
    pub ident: u16,
}

impl Ipv4Header {
    pub const LEN: usize = 20;

    pub fn encode(&self, out: &mut [u8]) -> Option<usize> {
        if out.len() < Self::LEN {
            return None;
        }

        out[0] = 0x45; // version + IHL
        out[1] = 0x00; // DSCP/ECN
        out[2] = (self.total_len >> 8) as u8;
        out[3] = (self.total_len & 0xFF) as u8;
        out[4] = (self.ident >> 8) as u8;
        out[5] = (self.ident & 0xFF) as u8;
        out[6] = 0x40; // don't fragment
        out[7] = 0x00;
        out[8] = self.ttl;
        out[9] = self.protocol;
        out[10] = 0;
        out[11] = 0;
        out[12..16].copy_from_slice(&self.src);
        out[16..20].copy_from_slice(&self.dst);

        let csum = checksum16(&out[..Self::LEN]);
        out[10] = (csum >> 8) as u8;
        out[11] = (csum & 0xFF) as u8;
        Some(Self::LEN)
    }
}

#[derive(Copy, Clone)]
pub struct IcmpEcho {
    pub kind: u8,
    pub code: u8,
    pub ident: u16,
    pub seq: u16,
}

impl IcmpEcho {
    pub const LEN: usize = 8;

    pub fn encode_with_payload(&self, payload: &[u8], out: &mut [u8]) -> Option<usize> {
        let need = Self::LEN + payload.len();
        if out.len() < need {
            return None;
        }

        out[0] = self.kind;
        out[1] = self.code;
        out[2] = 0;
        out[3] = 0;
        out[4] = (self.ident >> 8) as u8;
        out[5] = (self.ident & 0xFF) as u8;
        out[6] = (self.seq >> 8) as u8;
        out[7] = (self.seq & 0xFF) as u8;
        out[8..need].copy_from_slice(payload);

        let csum = checksum16(&out[..need]);
        out[2] = (csum >> 8) as u8;
        out[3] = (csum & 0xFF) as u8;
        Some(need)
    }
}

pub fn checksum16(data: &[u8]) -> u16 {
    let mut sum: u32 = 0;
    let mut i = 0;

    while i + 1 < data.len() {
        let word = ((data[i] as u16) << 8) | data[i + 1] as u16;
        sum += word as u32;
        i += 2;
    }

    if i < data.len() {
        sum += ((data[i] as u16) << 8) as u32;
    }

    while (sum >> 16) != 0 {
        sum = (sum & 0xFFFF) + (sum >> 16);
    }

    !(sum as u16)
}

#[derive(Copy, Clone)]
struct ArpEntry {
    valid: bool,
    ip: [u8; 4],
    mac: MacAddr,
    ttl: u16,
}

impl ArpEntry {
    const fn empty() -> Self {
        Self {
            valid: false,
            ip: [0; 4],
            mac: MacAddr::zero(),
            ttl: 0,
        }
    }
}

pub struct ArpTable {
    entries: [ArpEntry; 16],
    replace_idx: usize,
}

impl ArpTable {
    pub const fn new() -> Self {
        Self {
            entries: [ArpEntry::empty(); 16],
            replace_idx: 0,
        }
    }

    pub fn insert(&mut self, ip: [u8; 4], mac: MacAddr, ttl: u16) {
        for i in 0..self.entries.len() {
            if self.entries[i].valid && self.entries[i].ip == ip {
                self.entries[i].mac = mac;
                self.entries[i].ttl = ttl;
                return;
            }
        }

        let idx = self.replace_idx % self.entries.len();
        self.entries[idx] = ArpEntry {
            valid: true,
            ip,
            mac,
            ttl,
        };
        self.replace_idx = (self.replace_idx + 1) % self.entries.len();
    }

    pub fn lookup(&self, ip: [u8; 4]) -> Option<MacAddr> {
        for i in 0..self.entries.len() {
            if self.entries[i].valid && self.entries[i].ip == ip {
                return Some(self.entries[i].mac);
            }
        }
        None
    }

    pub fn tick(&mut self) {
        for i in 0..self.entries.len() {
            if !self.entries[i].valid {
                continue;
            }
            if self.entries[i].ttl > 0 {
                self.entries[i].ttl -= 1;
            }
            if self.entries[i].ttl == 0 {
                self.entries[i].valid = false;
            }
        }
    }
}

pub struct RustNetstack {
    pub mac: MacAddr,
    pub ip: [u8; 4],
    pub gateway: [u8; 4],
    pub netmask: [u8; 4],
    arp: ArpTable,
    ident: u16,
    seq: u16,
}

impl RustNetstack {
    pub const fn new(mac: MacAddr, ip: [u8; 4], gateway: [u8; 4], netmask: [u8; 4]) -> Self {
        Self {
            mac,
            ip,
            gateway,
            netmask,
            arp: ArpTable::new(),
            ident: 1,
            seq: 1,
        }
    }

    pub fn arp_insert(&mut self, ip: [u8; 4], mac: MacAddr) {
        self.arp.insert(ip, mac, 300);
    }

    pub fn next_hop_mac(&self, dst_ip: [u8; 4]) -> Option<MacAddr> {
        let same_subnet = (self.ip[0] & self.netmask[0]) == (dst_ip[0] & self.netmask[0])
            && (self.ip[1] & self.netmask[1]) == (dst_ip[1] & self.netmask[1])
            && (self.ip[2] & self.netmask[2]) == (dst_ip[2] & self.netmask[2])
            && (self.ip[3] & self.netmask[3]) == (dst_ip[3] & self.netmask[3]);

        if same_subnet {
            self.arp.lookup(dst_ip)
        } else {
            self.arp.lookup(self.gateway)
        }
    }

    pub fn build_arp_request(&self, target_ip: [u8; 4], out: &mut [u8]) -> Option<usize> {
        if out.len() < EthernetHeader::LEN + ArpPacket::LEN {
            return None;
        }

        let eth = EthernetHeader {
            dst: MacAddr::broadcast(),
            src: self.mac,
            eth_type: ETH_TYPE_ARP,
        };
        let arp = ArpPacket {
            oper: 1,
            sender_mac: self.mac,
            sender_ip: self.ip,
            target_mac: MacAddr::zero(),
            target_ip,
        };

        let mut off = 0;
        off += eth.encode(&mut out[off..])?;
        off += arp.encode(&mut out[off..])?;
        Some(off)
    }

    pub fn build_icmp_echo(
        &mut self,
        dst_mac: MacAddr,
        dst_ip: [u8; 4],
        payload: &[u8],
        out: &mut [u8],
    ) -> Option<usize> {
        let payload_len = min(payload.len(), 64);
        let icmp_len = IcmpEcho::LEN + payload_len;
        let ip_len = Ipv4Header::LEN + icmp_len;
        let frame_len = EthernetHeader::LEN + ip_len;

        if out.len() < frame_len {
            return None;
        }

        let eth = EthernetHeader {
            dst: dst_mac,
            src: self.mac,
            eth_type: ETH_TYPE_IPV4,
        };

        let ip = Ipv4Header {
            total_len: ip_len as u16,
            ttl: 64,
            protocol: IP_PROTO_ICMP,
            src: self.ip,
            dst: dst_ip,
            ident: self.ident,
        };

        self.ident = self.ident.wrapping_add(1);

        let icmp = IcmpEcho {
            kind: 8,
            code: 0,
            ident: 0xD00D,
            seq: self.seq,
        };
        self.seq = self.seq.wrapping_add(1);

        let mut off = 0;
        off += eth.encode(&mut out[off..])?;
        off += ip.encode(&mut out[off..])?;
        off += icmp.encode_with_payload(&payload[..payload_len], &mut out[off..])?;
        Some(off)
    }
}
