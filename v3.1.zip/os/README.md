# DoorOS (x86_64)

## Prerequisites

- NASM
- GCC (x86_64-elf cross-compiler or system GCC)
- GNU Make
- QEMU
- `qemu-img` (for VDI/VMDK conversion)

Ubuntu/Debian:
```bash
sudo apt install nasm gcc make qemu-system-x86 qemu-utils
```

## Build

```bash
make
```

`make` now also compiles Rust artifacts into:

- `build/rust/dooros_rust_drivers.rlib`
- `build/rust/dooros_rust_netstack.rlib`

You can run just the compiler pipeline with:

```bash
make compiler
```

## LLVM C Compiler (User Programs)

Build a DoorOS user ELF with LLVM/Clang:

```bash
make llvm-c SRC=user/hello.c OUT=build/user/hello.elf
```

Defaults:
- `LLVM_CC=clang`
- `LLVM_LD=ld.lld`

You can override them, for example:

```bash
make llvm-c LLVM_CC=clang LLVM_LD=ld.lld SRC=user/hello.c OUT=build/user/hello.elf
```

Backward-compatible alias:

```bash
make llvm-user SRC=user/hello.c OUT=build/user/hello.elf
```

## LLVM Rust Compiler (Library Artifacts)

Build a Rust artifact with Rust's LLVM backend:

```bash
make llvm-rust SRC=assets/rust/rust_netstack.rs OUT=build/rust/custom_netstack.rlib
```

Optional:

```bash
make llvm-rust SRC=assets/rust/rust_netstack.rs OUT=build/rust/custom_netstack.rlib LLVM_RUST_CRATE_TYPE=rlib
```

## `.exe` Launch Support

DoorOS keeps ELF binaries as the executable format, but supports `.exe` names:

- `mkfs` adds `/bin/<name>.exe` aliases for each built `/bin/<name>` ELF.
- Both shells try fallback launch paths:
  - `foo` -> `foo.exe`
  - `foo.exe` -> `foo`

This provides practical `.exe` launching without a PE/Windows loader.

## Networking (e1000 Ethernet)

QEMU run targets include an Intel e1000 NIC (`-nic user,model=e1000`).

In GUI Terminal:
- `ifconfig` (or `ipconfig`) shows link, MAC, IPv4, mask, gateway.
- `ping [ip]` sends ICMP echo (defaults to gateway if no IP is given).

Example:

```text
ping 10.0.2.2
```

## DOOM (Official Source)

`make` now builds `/bin/doom` from the official id Software DOOM source (`https://github.com/id-Software/DOOM`, `linuxdoom-1.10`) with DoorOS platform shims.
Launch it from the DoorOS UI DOOM icon or from terminal with `doom`.

For playable DOOM, provide a real IWAD (any of these names are accepted in `/bin`: `freedoom1.wad`, `freedoom2.wad`, `freedm.wad`, `doom1.wad`, `doom.wad`, `doom2.wad`):

1. Place an IWAD at `assets/doom1.wad` (or `assets/DOOM1.WAD`), then run `make`.
2. Or let `make` try downloading from `DOOM_WAD_URL`.

If no IWAD is available, build still succeeds with a placeholder `freedoom1.wad`, but `/bin/doom` will print a missing-IWAD message and exit.

## Filesystem Size

The SimpleFS image size is configurable at build time:

```bash
make FS_TOTAL_BLOCKS=16128
```

`FS_TOTAL_BLOCKS` is measured in 4 KiB blocks. The default is `16128` blocks (about 63 MiB), and mkfs now supports direct + indirect + double-indirect file pointers for much larger files.

You can also move filesystem placement if needed:

```bash
make FS_START_SECTOR=2048
```

The stage2 bootloader now receives this value at build time and passes it to the kernel boot info.

## Rust Driver + Netstack Files In FS

The filesystem image now includes Rust driver skeleton files in `/bin`:

- `rust_drivers.md`
- `rust_driver_traits.rs`
- `rust_driver_e1000.rs`
- `rust_driver_vbe.rs`
- `rust_driver_ps2kbd.rs`
- `rust_driver_memory.rs`
- `rust_drivers_lib.rs`
- `rust_netstack.rs`
- `rust_netstack.md`
- `dooros_rust_drivers.rlib` (compiled artifact)
- `dooros_rust_netstack.rlib` (compiled artifact)

Use the desktop `Rust Docs` icon to open the notes file in the editor.

## Macrohard Edit 2.0

The GUI editor is now branded **Macrohard Edit 2.0**.

Terminal command support:

- `EDIT <file>` opens a file in Macrohard Edit.
- `EDIT WRITE <file> <text...>` overwrites/creates a file with text.
- `EDIT APPEND <file> <text...>` appends text to a file.
- `EDIT RENAME <old> <new>` renames a file/path.

## Settings Panel

Open `Macrohard FreedomBlock` from Launchpad/Dock (or run `settings` in the GUI terminal) to tweak:

1. Wallpaper theme
2. Window corner roundness
3. UI chrome style

## Run In QEMU (Normal)

```bash
make run
```

This is the normal run target and does NOT start paused.
If the guest crashes, QEMU will stop instead of reboot-looping (`-no-reboot -no-shutdown`).

## Run In QEMU (Headless)

```bash
make run-headless
```

## Debug In QEMU (Starts Paused)

```bash
make debug
```

`make debug` intentionally uses `-S` and starts paused for GDB.

## VirtualBox Disk (VDI)

Generate a VirtualBox disk:

```bash
make vdi
```

`make vdi` emits a fixed-size VDI for better VirtualBox compatibility.

Use `build/os.vdi` as the VM hard disk in VirtualBox.
Create a VM as `Other/Unknown (64-bit)`, set RAM to 256 MB+, and boot from that disk.
Do not attach this project as a CD/DVD ISO. The bootloader expects an MBR hard disk.
Attach the disk to an **IDE controller** (PIIX3/PIIX4). The current kernel ATA path is legacy IDE, not AHCI/SATA.

## VMDK Disk (Optional)

```bash
make vmdk
```

Outputs `build/os.vmdk`.

## Clean

```bash
make clean
```
