/*
 * mkfs - Create a SimpleFS filesystem image
 *
 * Usage: mkfs <output.img> [elf_file1 elf_file2 ...]
 *
 * Creates a SimpleFS image with:
 *   - Superblock at block 0
 *   - Block bitmap
 *   - Inode table
 *   - Root directory "/"
 *   - /bin/ directory containing the provided ELF programs
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#define SFS_MAGIC       0x53465321
#define SFS_BLOCK_SIZE  4096
#define SFS_INODE_SIZE  128
#define SFS_DIRENT_SIZE 64
#define SFS_MAX_INODES  2048
#define SFS_DIRECT_BLOCKS 10

#define SFS_TYPE_FREE 0
#define SFS_TYPE_FILE 1
#define SFS_TYPE_DIR  2

// Total filesystem size: 32MB (8192 blocks)
#define FS_TOTAL_BLOCKS 8192

#pragma pack(push, 1)

struct sfs_superblock {
    uint32_t magic;
    uint32_t version;
    uint32_t block_size;
    uint32_t total_blocks;
    uint32_t total_inodes;
    uint32_t bitmap_start;
    uint32_t bitmap_blocks;
    uint32_t inode_start;
    uint32_t inode_blocks;
    uint32_t data_start;
    uint32_t root_inode;
    uint32_t free_blocks;
    uint32_t free_inodes;
    uint8_t  padding[460];
};

struct sfs_inode {
    uint32_t type;
    uint32_t size;
    uint32_t blocks;
    uint32_t uid;
    uint32_t gid;
    uint32_t permissions;
    uint64_t created;
    uint64_t modified;
    uint32_t direct[SFS_DIRECT_BLOCKS];
    uint32_t indirect;
    uint32_t dindirect;
    uint8_t  padding[8];
};

struct sfs_dirent {
    uint32_t inode;
    uint8_t  name_len;
    uint8_t  type;
    char     name[SFS_DIRENT_SIZE - 6];
};

#pragma pack(pop)

static uint8_t *disk;  // Entire filesystem image in memory
static struct sfs_superblock *sb;
static uint32_t next_data_block;

static void write_block(uint32_t block, const void *data) {
    memcpy(disk + block * SFS_BLOCK_SIZE, data, SFS_BLOCK_SIZE);
}

static void read_block(uint32_t block, void *data) {
    memcpy(data, disk + block * SFS_BLOCK_SIZE, SFS_BLOCK_SIZE);
}

static uint32_t alloc_block(void) {
    if (next_data_block >= sb->total_blocks) {
        fprintf(stderr, "mkfs: out of blocks\n");
        exit(1);
    }

    uint32_t block = next_data_block++;

    // Set bitmap bit
    uint32_t rel = block - sb->data_start;
    uint32_t bmap_block = rel / (SFS_BLOCK_SIZE * 8);
    uint32_t bmap_byte = (rel % (SFS_BLOCK_SIZE * 8)) / 8;
    uint32_t bmap_bit = rel % 8;

    uint8_t bmap[SFS_BLOCK_SIZE];
    read_block(sb->bitmap_start + bmap_block, bmap);
    bmap[bmap_byte] |= (1 << bmap_bit);
    write_block(sb->bitmap_start + bmap_block, bmap);

    sb->free_blocks--;
    return block;
}

static void write_inode(uint32_t inum, const struct sfs_inode *inode) {
    uint32_t inodes_per_block = SFS_BLOCK_SIZE / SFS_INODE_SIZE;
    uint32_t block = sb->inode_start + inum / inodes_per_block;
    uint32_t offset = (inum % inodes_per_block) * SFS_INODE_SIZE;

    uint8_t buf[SFS_BLOCK_SIZE];
    read_block(block, buf);
    memcpy(buf + offset, inode, sizeof(struct sfs_inode));
    write_block(block, buf);
}

static uint32_t alloc_inode(void) {
    static uint32_t next_inode = 1;
    if (next_inode >= sb->total_inodes) {
        fprintf(stderr, "mkfs: out of inodes\n");
        exit(1);
    }
    sb->free_inodes--;
    return next_inode++;
}

static void add_dir_entry(struct sfs_inode *dir_inode, uint32_t dir_inum,
                          const char *name, uint32_t child_inum, uint8_t type) {
    uint32_t num_entries = dir_inode->size / SFS_DIRENT_SIZE;
    uint32_t entries_per_block = SFS_BLOCK_SIZE / SFS_DIRENT_SIZE;
    uint32_t block_index = num_entries / entries_per_block;
    uint32_t entry_offset = (num_entries % entries_per_block) * SFS_DIRENT_SIZE;

    // Get or allocate block
    uint32_t blk;
    if (block_index < SFS_DIRECT_BLOCKS) {
        blk = dir_inode->direct[block_index];
        if (!blk) {
            blk = alloc_block();
            dir_inode->direct[block_index] = blk;
            dir_inode->blocks++;
            // Zero out new block
            uint8_t zeros[SFS_BLOCK_SIZE];
            memset(zeros, 0, SFS_BLOCK_SIZE);
            write_block(blk, zeros);
        }
    } else {
        fprintf(stderr, "mkfs: directory too large\n");
        exit(1);
    }

    // Write entry
    uint8_t buf[SFS_BLOCK_SIZE];
    read_block(blk, buf);

    struct sfs_dirent *entry = (struct sfs_dirent *)(buf + entry_offset);
    memset(entry, 0, SFS_DIRENT_SIZE);
    entry->inode = child_inum;
    entry->type = type;
    entry->name_len = strlen(name);
    strncpy(entry->name, name, SFS_DIRENT_SIZE - 6);

    write_block(blk, buf);

    dir_inode->size += SFS_DIRENT_SIZE;
    write_inode(dir_inum, dir_inode);
}

static uint32_t create_file(const char *filepath) {
    FILE *f = fopen(filepath, "rb");
    if (!f) {
        fprintf(stderr, "mkfs: cannot open '%s'\n", filepath);
        return 0;
    }

    // Get file size
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);

    // Allocate inode
    uint32_t inum = alloc_inode();
    struct sfs_inode inode;
    memset(&inode, 0, sizeof(inode));
    inode.type = SFS_TYPE_FILE;
    inode.size = (uint32_t)size;
    inode.permissions = 0755;

    // Write file data
    uint8_t buf[SFS_BLOCK_SIZE];
    uint32_t block_index = 0;
    long remaining = size;

    while (remaining > 0) {
        memset(buf, 0, SFS_BLOCK_SIZE);
        size_t to_read = remaining > SFS_BLOCK_SIZE ? SFS_BLOCK_SIZE : (size_t)remaining;
        if (fread(buf, 1, to_read, f) != to_read) {
            fprintf(stderr, "mkfs: short read on '%s'\n", filepath);
        }

        uint32_t blk = alloc_block();
        write_block(blk, buf);

        if (block_index < SFS_DIRECT_BLOCKS) {
            inode.direct[block_index] = blk;
        } else if (block_index < SFS_DIRECT_BLOCKS + SFS_BLOCK_SIZE / 4) {
            // Indirect block
            if (!inode.indirect) {
                inode.indirect = alloc_block();
                uint8_t zeros[SFS_BLOCK_SIZE];
                memset(zeros, 0, SFS_BLOCK_SIZE);
                write_block(inode.indirect, zeros);
            }
            uint32_t ptrs[SFS_BLOCK_SIZE / 4];
            read_block(inode.indirect, ptrs);
            ptrs[block_index - SFS_DIRECT_BLOCKS] = blk;
            write_block(inode.indirect, ptrs);
        } else {
            fprintf(stderr, "mkfs: file too large: %s\n", filepath);
            break;
        }

        inode.blocks++;
        block_index++;
        remaining -= to_read;
    }

    fclose(f);
    write_inode(inum, &inode);
    return inum;
}

static const char *basename(const char *path) {
    const char *last = strrchr(path, '/');
    return last ? last + 1 : path;
}

static char *strip_extension(char *name) {
    char *dot = strrchr(name, '.');
    if (dot && strcmp(dot, ".elf") == 0) *dot = '\0';
    return name;
}

static int has_extension(const char *name, const char *ext) {
    size_t nlen = strlen(name);
    size_t elen = strlen(ext);
    if (nlen < elen) return 0;
    return strcmp(name + nlen - elen, ext) == 0;
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <output.img> [file1 file2 ...]\n", argv[0]);
        return 1;
    }

    const char *outfile = argv[1];

    // Allocate entire filesystem image in memory
    size_t fs_size = (size_t)FS_TOTAL_BLOCKS * SFS_BLOCK_SIZE;
    disk = calloc(1, fs_size);
    if (!disk) {
        fprintf(stderr, "mkfs: cannot allocate %zu bytes\n", fs_size);
        return 1;
    }

    // Calculate layout
    uint32_t bitmap_blocks = (FS_TOTAL_BLOCKS + SFS_BLOCK_SIZE * 8 - 1) / (SFS_BLOCK_SIZE * 8);
    uint32_t inode_blocks = (SFS_MAX_INODES * SFS_INODE_SIZE + SFS_BLOCK_SIZE - 1) / SFS_BLOCK_SIZE;
    uint32_t data_start = 1 + bitmap_blocks + inode_blocks; // superblock + bitmap + inodes

    // Initialize superblock
    sb = (struct sfs_superblock *)disk;
    sb->magic = SFS_MAGIC;
    sb->version = 1;
    sb->block_size = SFS_BLOCK_SIZE;
    sb->total_blocks = FS_TOTAL_BLOCKS;
    sb->total_inodes = SFS_MAX_INODES;
    sb->bitmap_start = 1;
    sb->bitmap_blocks = bitmap_blocks;
    sb->inode_start = 1 + bitmap_blocks;
    sb->inode_blocks = inode_blocks;
    sb->data_start = data_start;
    sb->root_inode = 1;
    sb->free_blocks = FS_TOTAL_BLOCKS - data_start;
    sb->free_inodes = SFS_MAX_INODES - 1; // Reserve inode 0

    next_data_block = data_start;

    printf("SimpleFS Image Creator\n");
    printf("  Total blocks:  %u\n", sb->total_blocks);
    printf("  Bitmap blocks: %u (start: %u)\n", sb->bitmap_blocks, sb->bitmap_start);
    printf("  Inode blocks:  %u (start: %u)\n", sb->inode_blocks, sb->inode_start);
    printf("  Data start:    %u\n", sb->data_start);

    // Create root directory (inode 1)
    uint32_t root_inum = alloc_inode();
    struct sfs_inode root_inode;
    memset(&root_inode, 0, sizeof(root_inode));
    root_inode.type = SFS_TYPE_DIR;
    root_inode.permissions = 0755;
    write_inode(root_inum, &root_inode);

    // Create /bin directory
    uint32_t bin_inum = alloc_inode();
    struct sfs_inode bin_inode;
    memset(&bin_inode, 0, sizeof(bin_inode));
    bin_inode.type = SFS_TYPE_DIR;
    bin_inode.permissions = 0755;
    write_inode(bin_inum, &bin_inode);

    // Add /bin to root
    add_dir_entry(&root_inode, root_inum, "bin", bin_inum, SFS_TYPE_DIR);

    // Add user programs to /bin
    for (int i = 2; i < argc; i++) {
        const char *filepath = argv[i];
        char base_name[64];
        char name[64];
        strncpy(base_name, basename(filepath), sizeof(base_name) - 1);
        base_name[sizeof(base_name) - 1] = '\0';
        strncpy(name, base_name, sizeof(name) - 1);
        name[sizeof(name) - 1] = '\0';
        int add_exe_alias = has_extension(base_name, ".elf");
        strip_extension(name); // Remove .elf extension

        printf("  Adding /bin/%s from %s\n", name, filepath);

        uint32_t file_inum = create_file(filepath);
        if (file_inum) {
            add_dir_entry(&bin_inode, bin_inum, name, file_inum, SFS_TYPE_FILE);
            if (add_exe_alias) {
                char exe_name[64];
                size_t name_len = strlen(name);
                size_t exe_len = name_len + 4; // ".exe"
                if (exe_len + 1 <= sizeof(exe_name) && exe_len < SFS_DIRENT_SIZE - 6) {
                    memcpy(exe_name, name, name_len);
                    memcpy(exe_name + name_len, ".exe", 5);
                    add_dir_entry(&bin_inode, bin_inum, exe_name, file_inum, SFS_TYPE_FILE);
                }
            }
        }
    }

    // Write final superblock
    uint8_t sb_block[SFS_BLOCK_SIZE];
    memset(sb_block, 0, SFS_BLOCK_SIZE);
    memcpy(sb_block, sb, sizeof(struct sfs_superblock));
    write_block(0, sb_block);

    printf("  Free blocks:   %u\n", sb->free_blocks);
    printf("  Free inodes:   %u\n", sb->free_inodes);

    // Write to file
    FILE *out = fopen(outfile, "wb");
    if (!out) {
        fprintf(stderr, "mkfs: cannot create '%s'\n", outfile);
        free(disk);
        return 1;
    }
    fwrite(disk, 1, fs_size, out);
    fclose(out);

    printf("  Output: %s (%zu bytes)\n", outfile, fs_size);
    free(disk);
    return 0;
}
