#pragma once

#include "include/types.h"

void net_init(void);
void net_poll(void);

bool net_is_ready(void);
bool net_is_link_up(void);

const uint8_t *net_get_mac(void);
const uint8_t *net_get_ip(void);
const uint8_t *net_get_gateway(void);
const uint8_t *net_get_netmask(void);

int net_parse_ipv4(const char *text, uint8_t out_ip[4]);
void net_format_ipv4(const uint8_t ip[4], char *buf, size_t buf_sz);
void net_format_mac(const uint8_t mac[6], char *buf, size_t buf_sz);

int net_ping(const uint8_t dst_ip[4], uint32_t timeout_ms, uint32_t *out_rtt_ms);
