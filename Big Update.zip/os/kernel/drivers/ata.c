#include "drivers/ata.h"
#include "lib/printf.h"

#define ATA_DATA(base)     (base + 0)
#define ATA_ERROR(base)    (base + 1)
#define ATA_SECT_CNT(base) (base + 2)
#define ATA_LBA_LO(base)   (base + 3)
#define ATA_LBA_MID(base)  (base + 4)
#define ATA_LBA_HI(base)   (base + 5)
#define ATA_DRIVE(base)    (base + 6)
#define ATA_STATUS(base)   (base + 7)
#define ATA_CMD(base)      (base + 7)

#define ATA_STATUS_BSY  0x80
#define ATA_STATUS_DRDY 0x40
#define ATA_STATUS_DRQ  0x08
#define ATA_STATUS_ERR  0x01

#define ATA_CMD_READ    0x20
#define ATA_CMD_WRITE   0x30
#define ATA_CMD_IDENTIFY 0xEC

static uint16_t ata_base = ATA_PRIMARY_IO;
static int ata_present = 0;

static void ata_wait_bsy(void) {
    while (inb(ATA_STATUS(ata_base)) & ATA_STATUS_BSY);
}

static void ata_wait_drq(void) {
    while (!(inb(ATA_STATUS(ata_base)) & ATA_STATUS_DRQ));
}

static int ata_wait_ready(void) {
    for (int i = 0; i < 100000; i++) {
        uint8_t status = inb(ATA_STATUS(ata_base));
        if (status & ATA_STATUS_ERR) return -1;
        if (!(status & ATA_STATUS_BSY) && (status & ATA_STATUS_DRDY)) return 0;
    }
    return -1;
}

void ata_init(void) {
    // Soft reset
    outb(ATA_PRIMARY_CTRL, 0x04);
    io_wait(); io_wait(); io_wait(); io_wait();
    outb(ATA_PRIMARY_CTRL, 0x00);

    // Select master drive
    outb(ATA_DRIVE(ata_base), 0xA0);
    io_wait();

    // Check if drive exists
    uint8_t status = inb(ATA_STATUS(ata_base));
    if (status == 0xFF || status == 0x00) {
        kprintf("ATA: No drive found on primary master\n");
        return;
    }

    // IDENTIFY command
    outb(ATA_DRIVE(ata_base), 0xA0);
    outb(ATA_SECT_CNT(ata_base), 0);
    outb(ATA_LBA_LO(ata_base), 0);
    outb(ATA_LBA_MID(ata_base), 0);
    outb(ATA_LBA_HI(ata_base), 0);
    outb(ATA_CMD(ata_base), ATA_CMD_IDENTIFY);

    status = inb(ATA_STATUS(ata_base));
    if (status == 0) {
        kprintf("ATA: Drive does not exist\n");
        return;
    }

    ata_wait_bsy();

    // Check for non-ATA drive
    if (inb(ATA_LBA_MID(ata_base)) || inb(ATA_LBA_HI(ata_base))) {
        kprintf("ATA: Not an ATA drive\n");
        return;
    }

    // Wait for DRQ or ERR
    while (1) {
        status = inb(ATA_STATUS(ata_base));
        if (status & ATA_STATUS_ERR) {
            kprintf("ATA: IDENTIFY error\n");
            return;
        }
        if (status & ATA_STATUS_DRQ) break;
    }

    // Read identify data
    uint16_t identify[256];
    for (int i = 0; i < 256; i++) {
        identify[i] = inw(ATA_DATA(ata_base));
    }

    uint32_t sectors = identify[60] | ((uint32_t)identify[61] << 16);
    kprintf("ATA: Drive found, %u sectors (%u MB)\n",
            sectors, sectors / 2048);

    ata_present = 1;
}

int ata_read_sectors(uint32_t lba, uint8_t count, void *buf) {
    if (!ata_present) return -1;

    ata_wait_bsy();

    // LBA28 mode
    outb(ATA_DRIVE(ata_base), 0xE0 | ((lba >> 24) & 0x0F));
    outb(ATA_SECT_CNT(ata_base), count);
    outb(ATA_LBA_LO(ata_base), lba & 0xFF);
    outb(ATA_LBA_MID(ata_base), (lba >> 8) & 0xFF);
    outb(ATA_LBA_HI(ata_base), (lba >> 16) & 0xFF);
    outb(ATA_CMD(ata_base), ATA_CMD_READ);

    uint16_t *ptr = (uint16_t *)buf;
    for (int s = 0; s < count; s++) {
        ata_wait_bsy();
        if (ata_wait_ready() < 0) return -1;
        ata_wait_drq();

        for (int i = 0; i < 256; i++) {
            *ptr++ = inw(ATA_DATA(ata_base));
        }
    }
    return 0;
}

int ata_write_sectors(uint32_t lba, uint8_t count, const void *buf) {
    if (!ata_present) return -1;

    ata_wait_bsy();

    outb(ATA_DRIVE(ata_base), 0xE0 | ((lba >> 24) & 0x0F));
    outb(ATA_SECT_CNT(ata_base), count);
    outb(ATA_LBA_LO(ata_base), lba & 0xFF);
    outb(ATA_LBA_MID(ata_base), (lba >> 8) & 0xFF);
    outb(ATA_LBA_HI(ata_base), (lba >> 16) & 0xFF);
    outb(ATA_CMD(ata_base), ATA_CMD_WRITE);

    const uint16_t *ptr = (const uint16_t *)buf;
    for (int s = 0; s < count; s++) {
        ata_wait_bsy();
        ata_wait_drq();

        for (int i = 0; i < 256; i++) {
            outw(ATA_DATA(ata_base), *ptr++);
        }

        // Flush cache
        outb(ATA_CMD(ata_base), 0xE7);
        ata_wait_bsy();
    }
    return 0;
}
