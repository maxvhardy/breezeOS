#pragma once
#include "include/types.h"
#include "include/boot.h"

void vbe_init(struct boot_info *boot);
int  vbe_available(void);
void vbe_put_pixel(int x, int y, uint32_t color);
uint32_t vbe_get_pixel(int x, int y);
void vbe_fill_rect(int x, int y, int w, int h, uint32_t color);
void vbe_blit(int x, int y, int w, int h, const uint32_t *pixels);
void vbe_scroll_up(int lines, uint32_t bg_color);
uint32_t *vbe_get_framebuffer(void);
uint32_t *vbe_get_backbuffer(void);
void vbe_swap_buffers(void);
void vbe_copy_rect(int dx, int dy, int sx, int sy, int w, int h);

uint32_t vbe_get_width(void);
uint32_t vbe_get_height(void);
uint32_t vbe_get_pitch(void);
uint32_t vbe_get_bpp(void);

// RGB color helper
static inline uint32_t rgb(uint8_t r, uint8_t g, uint8_t b) {
    return (r << 16) | (g << 8) | b;
}
