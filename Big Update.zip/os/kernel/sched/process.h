#pragma once
#include "include/types.h"
#include "fs/vfs.h"
#include "arch/idt.h"

#define MAX_PROCESSES 64
#define KERNEL_STACK_SIZE (8 * PAGE_SIZE)
#define USER_STACK_SIZE   (16 * PAGE_SIZE)
#define USER_STACK_TOP    0x7FFFFFFFE000ULL
#define USER_HEAP_START   0x10000000ULL

typedef enum {
    PROC_UNUSED = 0,
    PROC_READY,
    PROC_RUNNING,
    PROC_BLOCKED,
    PROC_SLEEPING,
    PROC_ZOMBIE
} proc_state_t;

struct process {
    int pid;
    proc_state_t state;
    uint64_t *pml4;              // Page table root (virtual address)
    uint64_t kernel_rsp;         // Saved kernel stack pointer
    uint64_t kernel_stack_base;  // Base of kernel stack allocation
    uint64_t user_heap_end;      // Current end of user heap (for sbrk)
    uint64_t sleep_until;        // For sleep(), tick count to wake
    int exit_code;
    int parent_pid;
    char cwd[MAX_PATH];
    struct vfs_node *fds[MAX_FDS];
    char name[64];
};

void process_init(void);
struct process *process_current(void);
struct process *process_get(int pid);
int process_create_kernel(void (*entry)(void), const char *name);
int process_create_user(const char *path);
int process_fork(void);
int process_exec(const char *path);
void process_exit(int code);
int process_waitpid(int pid, int *status);
int64_t process_sbrk(struct process *proc, int64_t incr);
void process_sleep(uint64_t ms);
void process_set_current(int pid);
void process_reap_kernel_zombies(int skip_pid);
