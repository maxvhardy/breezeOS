#include "sched/scheduler.h"
#include "sched/process.h"
#include "arch/gdt.h"
#include "arch/tss.h"
#include "arch/paging.h"
#include "arch/syscall.h"
#include "drivers/pit.h"
#include "lib/printf.h"

extern void context_switch(uint64_t *old_rsp, uint64_t new_rsp, uint64_t new_cr3);

static int scheduler_ready = 0;
static uint64_t time_slice_ticks = 5; // Switch every 5 ticks (50ms)
static uint64_t tick_counter = 0;

void scheduler_init(void) {
    scheduler_ready = 1;
}

static int find_next_task(int current) {
    // Round-robin: find next READY process
    for (int i = 1; i <= MAX_PROCESSES; i++) {
        int pid = (current + i) % MAX_PROCESSES;
        struct process *p = process_get(pid);
        if (p && p->state == PROC_READY) {
            return pid;
        }
    }
    return 0; // Fall back to idle process
}

static void wake_sleeping(void) {
    uint64_t now = pit_get_ticks();
    for (int i = 0; i < MAX_PROCESSES; i++) {
        struct process *p = process_get(i);
        if (p && p->state == PROC_SLEEPING && now >= p->sleep_until) {
            p->state = PROC_READY;
        }
    }
}

void schedule(void) {
    if (!scheduler_ready) return;

    wake_sleeping();

    struct process *current = process_current();
    if (!current) return;

    // Prevent unbounded zombie buildup for GUI-launched apps (parent pid 0).
    process_reap_kernel_zombies(current->pid);

    int next_pid = find_next_task(current->pid);
    if (next_pid == current->pid) return; // No switch needed

    struct process *next = process_get(next_pid);
    if (!next) return;

    // Mark states
    if (current->state == PROC_RUNNING) {
        current->state = PROC_READY;
    }
    next->state = PROC_RUNNING;
    process_set_current(next_pid);

    // Update TSS RSP0 for the new process
    gdt_set_tss_rsp0(next->kernel_stack_base + KERNEL_STACK_SIZE);
    // SYSCALL entry uses this as its kernel stack pointer.
    syscall_set_kernel_rsp(next->kernel_stack_base + KERNEL_STACK_SIZE);

    // Perform context switch
    uint64_t new_cr3 = 0;
    if (next->pml4 != current->pml4) {
        new_cr3 = VIRT_TO_PHYS((uint64_t)next->pml4);
    }
    context_switch(&current->kernel_rsp, next->kernel_rsp, new_cr3);
}

void schedule_tick(struct registers *regs) {
    (void)regs;
    if (!scheduler_ready) return;

    tick_counter++;
    if (tick_counter >= time_slice_ticks) {
        tick_counter = 0;
        schedule();
    }
}
