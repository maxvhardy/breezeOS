#include "gui/desktop.h"
#include "gui/font.h"
#include "include/types.h"

struct desktop_theme {
    uint32_t top;
    uint32_t bottom;
    uint32_t blob_a;
    uint32_t blob_b;
    uint32_t title;
};

static const struct desktop_theme desktop_themes[] = {
    {0x0B1A2A, 0x122A44, 0x2B7CFF, 0x3CC6A9, 0xB4CCDF}, // Midnight
    {0x10211B, 0x1D3A34, 0x61D095, 0x2A7F62, 0xC6E6D9}, // Aurora
    {0x261611, 0x4A2319, 0xE98C3B, 0xB94B3D, 0xF3D0B7}, // Copper
};

static int desktop_theme_id = 0;

static uint32_t blend_color(uint32_t c1, uint32_t c2, int t, int max) {
    if (max <= 0) return c1;
    int r1 = (c1 >> 16) & 0xFF, g1 = (c1 >> 8) & 0xFF, b1 = c1 & 0xFF;
    int r2 = (c2 >> 16) & 0xFF, g2 = (c2 >> 8) & 0xFF, b2 = c2 & 0xFF;
    int r = r1 + (r2 - r1) * t / max;
    int g = g1 + (g2 - g1) * t / max;
    int b = b1 + (b2 - b1) * t / max;
    return ((uint32_t)(r & 0xFF) << 16) | ((uint32_t)(g & 0xFF) << 8) | (uint32_t)(b & 0xFF);
}

static uint32_t alpha_blend(uint32_t bg, uint32_t fg, int alpha) {
    int br = (bg >> 16) & 0xFF;
    int bg_g = (bg >> 8) & 0xFF;
    int bb = bg & 0xFF;
    int fr = (fg >> 16) & 0xFF;
    int fg_g = (fg >> 8) & 0xFF;
    int fb = fg & 0xFF;

    int r = (fr * alpha + br * (255 - alpha)) / 255;
    int g = (fg_g * alpha + bg_g * (255 - alpha)) / 255;
    int b = (fb * alpha + bb * (255 - alpha)) / 255;
    return ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
}

static void draw_blob(uint32_t *buf, int width, int height,
                      int cx, int cy, int radius,
                      uint32_t color, int alpha_max) {
    if (radius <= 0 || alpha_max <= 0) return;

    int r2 = radius * radius;
    int y0 = cy - radius;
    int y1 = cy + radius;
    int x0 = cx - radius;
    int x1 = cx + radius;

    for (int y = y0; y <= y1; y++) {
        if (y < 0 || y >= height) continue;
        int dy = y - cy;
        for (int x = x0; x <= x1; x++) {
            if (x < 0 || x >= width) continue;
            int dx = x - cx;
            int d2 = dx * dx + dy * dy;
            if (d2 > r2) continue;

            int a = (alpha_max * (r2 - d2)) / r2;
            uint32_t bg = buf[y * width + x];
            buf[y * width + x] = alpha_blend(bg, color, a);
        }
    }
}

void desktop_init(void) {
}

void desktop_render(uint32_t *buf, int width, int height) {
    const struct desktop_theme *theme = &desktop_themes[desktop_theme_id];

    // Full-screen gradient (menu bar + dock render on top later)
    for (int y = 0; y < height; y++) {
        uint32_t color = blend_color(theme->top, theme->bottom, y, height);
        for (int x = 0; x < width; x++) {
            buf[y * width + x] = color;
        }
    }

    // Subtle atmosphere blobs.
    draw_blob(buf, width, height, width / 4, height / 3, height / 3, theme->blob_a, 78);
    draw_blob(buf, width, height, (width * 3) / 4, (height * 2) / 3, height / 3, theme->blob_b, 64);

    // Subtle centered OS name
    const char *title = "DoorOS";
    int title_w = font_string_width(title);
    int tx = (width - title_w) / 2;
    int ty = height / 2 - 16;
    if (tx < 0) tx = 0;
    if (ty < 0) ty = 0;
    if (tx >= width) tx = width - 1;
    if (ty >= height) ty = height - 1;
    uint32_t title_bg = buf[ty * width + tx];
    font_draw_string(buf, width, height, tx, ty, title, theme->title, title_bg);
}

void desktop_handle_mouse(int x, int y, int buttons) {
    (void)x; (void)y; (void)buttons;
}

void desktop_handle_key(uint32_t keycode) {
    (void)keycode;
}

void desktop_set_theme(int theme_id) {
    if (theme_id < 0 || theme_id >= (int)(sizeof(desktop_themes) / sizeof(desktop_themes[0]))) {
        return;
    }
    desktop_theme_id = theme_id;
}

int desktop_get_theme(void) {
    return desktop_theme_id;
}

int desktop_get_theme_count(void) {
    return (int)(sizeof(desktop_themes) / sizeof(desktop_themes[0]));
}
