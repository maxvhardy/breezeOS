#pragma once
#include "include/types.h"

void vmm_init(void);

// Map virtual pages in kernel space
void *vmm_alloc_pages(size_t count);
void vmm_free_pages(void *virt, size_t count);

// Map a physical address range into kernel virtual space
void *vmm_map_phys(uint64_t phys, size_t size, uint64_t flags);
void vmm_unmap(void *virt, size_t size);

// Map pages into user process address space
int vmm_map_user_page(uint64_t *pml4, uint64_t virt, uint64_t flags);
int vmm_map_user_pages(uint64_t *pml4, uint64_t virt, size_t count, uint64_t flags);
