#include "mm/pmm.h"
#include "lib/string.h"
#include "lib/printf.h"

// Bitmap-based physical page allocator
// Each bit represents one 4KB page

#define MAX_MEMORY   (256ULL * 1024 * 1024)  // Support up to 256MB
#define MAX_PAGES    (MAX_MEMORY / PAGE_SIZE)
#define BITMAP_SIZE  (MAX_PAGES / 8)

static uint8_t bitmap[BITMAP_SIZE];
static uint64_t total_pages;
static uint64_t used_pages;
static uint64_t total_memory;

static inline void bitmap_set(uint64_t page) {
    bitmap[page / 8] |= (1 << (page % 8));
}

static inline void bitmap_clear(uint64_t page) {
    bitmap[page / 8] &= ~(1 << (page % 8));
}

static inline int bitmap_test(uint64_t page) {
    return bitmap[page / 8] & (1 << (page % 8));
}

void pmm_init(struct boot_info *boot, struct e820_entry *mmap) {
    (void)boot;

    // Mark all pages as used initially
    memset(bitmap, 0xFF, sizeof(bitmap));
    total_pages = 0;
    used_pages = 0;
    total_memory = 0;

    // Free pages marked as usable in E820 map
    uint32_t mmap_count = boot->mmap_count;
    for (uint32_t i = 0; i < mmap_count; i++) {
        if (mmap[i].type != E820_USABLE) continue;

        uint64_t base = mmap[i].base;
        uint64_t length = mmap[i].length;
        uint64_t end = base + length;

        if (end > MAX_MEMORY) end = MAX_MEMORY;
        if (base >= MAX_MEMORY) continue;

        // Align base up, end down to page boundaries
        base = (base + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1);
        end = end & ~(PAGE_SIZE - 1);

        for (uint64_t addr = base; addr < end; addr += PAGE_SIZE) {
            uint64_t page = addr / PAGE_SIZE;
            if (page < MAX_PAGES) {
                bitmap_clear(page);
                total_pages++;
            }
        }

        total_memory += length;
    }
    // Reserve first 2MB (BIOS, bootloader, kernel area)
    for (uint64_t page = 0; page < 512; page++) {
        if (!bitmap_test(page)) {
            bitmap_set(page);
            total_pages--;
        }
    }
    // Reserve kernel area (1MB to kernel end)
    // The kernel_phys_end symbol tells us where the kernel ends
    extern char _kernel_phys_end[];
    uint64_t kernel_end = (uint64_t)_kernel_phys_end;
    if (kernel_end < 0x200000) kernel_end = 0x200000; // at least 2MB

    // Round up to page boundary
    kernel_end = (kernel_end + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1);
    for (uint64_t addr = 0x100000; addr < kernel_end; addr += PAGE_SIZE) {
        uint64_t page = addr / PAGE_SIZE;
        if (page < MAX_PAGES && !bitmap_test(page)) {
            bitmap_set(page);
            total_pages--;
        }
    }
    used_pages = 0;
    for (uint64_t i = 0; i < MAX_PAGES; i++) {
        if (bitmap_test(i)) used_pages++;
    }
    kprintf("PMM: %llu MB total, %llu pages free\n",
            total_memory / (1024*1024), total_pages);
}

uint64_t pmm_alloc_page(void) {
    for (uint64_t i = 0; i < MAX_PAGES / 8; i++) {
        if (bitmap[i] == 0xFF) continue;

        for (int bit = 0; bit < 8; bit++) {
            if (!(bitmap[i] & (1 << bit))) {
                uint64_t page = i * 8 + bit;
                bitmap_set(page);
                used_pages++;
                return page * PAGE_SIZE;
            }
        }
    }
    return 0; // Out of memory
}

void pmm_free_page(uint64_t phys_addr) {
    uint64_t page = phys_addr / PAGE_SIZE;
    if (page < MAX_PAGES && bitmap_test(page)) {
        bitmap_clear(page);
        used_pages--;
    }
}

uint64_t pmm_alloc_pages(size_t count) {
    // Find contiguous free pages
    size_t found = 0;
    uint64_t start = 0;

    for (uint64_t i = 0; i < MAX_PAGES; i++) {
        if (bitmap_test(i)) {
            found = 0;
            start = i + 1;
        } else {
            found++;
            if (found == count) {
                // Allocate them
                for (uint64_t j = start; j < start + count; j++) {
                    bitmap_set(j);
                    used_pages++;
                }
                return start * PAGE_SIZE;
            }
        }
    }
    return 0;
}

void pmm_free_pages(uint64_t phys_addr, size_t count) {
    for (size_t i = 0; i < count; i++) {
        pmm_free_page(phys_addr + i * PAGE_SIZE);
    }
}

uint64_t pmm_get_total_memory(void) { return total_memory; }
uint64_t pmm_get_free_memory(void) { return (MAX_PAGES - used_pages) * PAGE_SIZE; }
