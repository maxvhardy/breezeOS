#include "mm/heap.h"
#include "mm/vmm.h"
#include "lib/string.h"

// Simple linked-list heap allocator with first-fit strategy

struct heap_block {
    size_t size;         // Size of data area (not including header)
    int free;
    struct heap_block *next;
    struct heap_block *prev;
    uint64_t magic;      // 0xDEADBEEF for corruption detection
};

#define HEAP_MAGIC  0xDEADBEEFULL
#define HEAP_HEADER sizeof(struct heap_block)
#define ALIGN16(x)  (((x) + 15) & ~15)
#define INITIAL_HEAP_PAGES 64  // 256KB initial heap

static struct heap_block *heap_start;
static struct heap_block *heap_end;

static int blocks_adjacent(struct heap_block *left, struct heap_block *right) {
    if (!left || !right) return 0;
    uint8_t *left_end = (uint8_t *)left + HEAP_HEADER + left->size;
    return left_end == (uint8_t *)right;
}

void heap_init(void) {
    void *mem = vmm_alloc_pages(INITIAL_HEAP_PAGES);
    if (!mem) return;

    heap_start = (struct heap_block *)mem;
    heap_start->size = INITIAL_HEAP_PAGES * PAGE_SIZE - HEAP_HEADER;
    heap_start->free = 1;
    heap_start->next = NULL;
    heap_start->prev = NULL;
    heap_start->magic = HEAP_MAGIC;
    heap_end = heap_start;
}

static void heap_expand(size_t min_size) {
    size_t pages = (min_size + HEAP_HEADER + PAGE_SIZE - 1) / PAGE_SIZE;
    if (pages < 16) pages = 16;

    void *mem = vmm_alloc_pages(pages);
    if (!mem) return;

    struct heap_block *new_block = (struct heap_block *)mem;
    new_block->size = pages * PAGE_SIZE - HEAP_HEADER;
    new_block->free = 1;
    new_block->next = NULL;
    new_block->prev = heap_end;
    new_block->magic = HEAP_MAGIC;

    if (!heap_end) {
        heap_start = new_block;
        heap_end = new_block;
        return;
    }

    heap_end->next = new_block;
    heap_end = new_block;

    // If virtual memory happened to grow contiguously and tail is free, fuse now.
    if (new_block->prev && new_block->prev->free &&
        new_block->prev->magic == HEAP_MAGIC &&
        blocks_adjacent(new_block->prev, new_block)) {
        new_block->prev->size += HEAP_HEADER + new_block->size;
        new_block->prev->next = NULL;
        heap_end = new_block->prev;
    }
}

static void split_block(struct heap_block *block, size_t size) {
    if (block->size < size + HEAP_HEADER + 32) return; // Don't split tiny blocks

    struct heap_block *new_block = (struct heap_block *)((uint8_t *)block + HEAP_HEADER + size);
    new_block->size = block->size - size - HEAP_HEADER;
    new_block->free = 1;
    new_block->next = block->next;
    new_block->prev = block;
    new_block->magic = HEAP_MAGIC;

    if (block->next) block->next->prev = new_block;
    else heap_end = new_block;
    block->next = new_block;
    block->size = size;
}

static void merge_free_blocks(struct heap_block *block) {
    if (!block || block->magic != HEAP_MAGIC) return;

    // Merge with next
    while (block->next && block->next->free && block->next->magic == HEAP_MAGIC &&
           blocks_adjacent(block, block->next)) {
        struct heap_block *next = block->next;
        block->size += HEAP_HEADER + next->size;
        block->next = next->next;
        if (next->next) next->next->prev = block;
        else heap_end = block;
    }

    // Merge with prev
    if (block->prev && block->prev->free && block->prev->magic == HEAP_MAGIC &&
        blocks_adjacent(block->prev, block)) {
        struct heap_block *prev = block->prev;
        prev->size += HEAP_HEADER + block->size;
        prev->next = block->next;
        if (block->next) block->next->prev = prev;
        else heap_end = prev;
    }
}

void *kmalloc(size_t size) {
    if (size == 0) return NULL;
    size = ALIGN16(size);

    struct heap_block *block = heap_start;
    while (block) {
        if (block->free && block->magic == HEAP_MAGIC && block->size >= size) {
            split_block(block, size);
            block->free = 0;
            return (void *)((uint8_t *)block + HEAP_HEADER);
        }
        block = block->next;
    }

    // No suitable block found, expand heap
    heap_expand(size);

    // Try again from the end
    block = heap_end;
    if (block && block->free && block->magic == HEAP_MAGIC && block->size >= size) {
        split_block(block, size);
        block->free = 0;
        return (void *)((uint8_t *)block + HEAP_HEADER);
    }

    return NULL; // Truly out of memory
}

void kfree(void *ptr) {
    if (!ptr) return;

    struct heap_block *block = (struct heap_block *)((uint8_t *)ptr - HEAP_HEADER);
    if (block->magic != HEAP_MAGIC) return; // Corrupted or invalid

    block->free = 1;
    merge_free_blocks(block);
}

void *kcalloc(size_t count, size_t size) {
    if (count != 0 && size > ((size_t)-1) / count) return NULL;
    size_t total = count * size;
    void *ptr = kmalloc(total);
    if (ptr) memset(ptr, 0, total);
    return ptr;
}

void *krealloc(void *ptr, size_t size) {
    if (!ptr) return kmalloc(size);
    if (size == 0) { kfree(ptr); return NULL; }

    struct heap_block *block = (struct heap_block *)((uint8_t *)ptr - HEAP_HEADER);
    if (block->magic != HEAP_MAGIC) return NULL;

    size = ALIGN16(size);
    if (block->size >= size) return ptr;

    void *new_ptr = kmalloc(size);
    if (!new_ptr) return NULL;
    memcpy(new_ptr, ptr, block->size);
    kfree(ptr);
    return new_ptr;
}
