#pragma once
#include "include/types.h"

// GDT Selectors
#define GDT_NULL        0x00
#define GDT_KERNEL_CODE 0x08
#define GDT_KERNEL_DATA 0x10
#define GDT_USER_CODE32 0x18
#define GDT_USER_DATA   0x20
#define GDT_USER_CODE64 0x28
#define GDT_TSS         0x30

#define GDT_ENTRIES 9  // null, kcode, kdata, ucode32, udata, ucode64, tss(2), spare

struct gdt_entry {
    uint16_t limit_low;
    uint16_t base_low;
    uint8_t  base_mid;
    uint8_t  access;
    uint8_t  granularity;
    uint8_t  base_high;
} PACKED;

struct gdt_ptr {
    uint16_t limit;
    uint64_t base;
} PACKED;

struct tss_entry_64 {
    uint16_t limit_low;
    uint16_t base_low;
    uint8_t  base_mid;
    uint8_t  access;
    uint8_t  granularity;
    uint8_t  base_high;
    uint32_t base_upper;
    uint32_t reserved;
} PACKED;

void gdt_init(void);
void gdt_set_tss_rsp0(uint64_t rsp0);

// Defined in assembly
extern void gdt_flush(uint64_t gdtr);
extern void tss_flush(uint16_t sel);
