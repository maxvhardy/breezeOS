#include "arch/gdt.h"
#include "arch/tss.h"
#include "lib/string.h"

static struct gdt_entry gdt[GDT_ENTRIES] ALIGNED(16);
static struct gdt_ptr   gdtr;
struct tss tss ALIGNED(16);

static void gdt_set_entry(int i, uint32_t base, uint32_t limit,
                           uint8_t access, uint8_t gran) {
    gdt[i].base_low    = base & 0xFFFF;
    gdt[i].base_mid    = (base >> 16) & 0xFF;
    gdt[i].base_high   = (base >> 24) & 0xFF;
    gdt[i].limit_low   = limit & 0xFFFF;
    gdt[i].access      = access;
    gdt[i].granularity = ((limit >> 16) & 0x0F) | (gran & 0xF0);
}

void gdt_init(void) {
    memset(&tss, 0, sizeof(tss));
    tss.iomap_base = sizeof(tss);

    // Null descriptor
    gdt_set_entry(0, 0, 0, 0, 0);

    // Kernel Code 64-bit (0x08) - ring 0
    gdt_set_entry(1, 0, 0xFFFFF, 0x9A, 0xA0);

    // Kernel Data (0x10) - ring 0
    gdt_set_entry(2, 0, 0xFFFFF, 0x92, 0xC0);

    // User Code 32-bit (0x18) - ring 3 (for SYSRET compatibility)
    gdt_set_entry(3, 0, 0xFFFFF, 0xFA, 0xC0);

    // User Data (0x20) - ring 3
    gdt_set_entry(4, 0, 0xFFFFF, 0xF2, 0xC0);

    // User Code 64-bit (0x28) - ring 3
    gdt_set_entry(5, 0, 0xFFFFF, 0xFA, 0xA0);

    // TSS descriptor (0x30) - 16 bytes (spans entries 6 and 7)
    uint64_t tss_addr = (uint64_t)&tss;
    uint32_t tss_size = sizeof(tss) - 1;

    struct tss_entry_64 *tss_desc = (struct tss_entry_64 *)&gdt[6];
    tss_desc->limit_low   = tss_size & 0xFFFF;
    tss_desc->base_low    = tss_addr & 0xFFFF;
    tss_desc->base_mid    = (tss_addr >> 16) & 0xFF;
    tss_desc->access      = 0x89; // Present, 64-bit TSS available
    tss_desc->granularity = (tss_size >> 16) & 0x0F;
    tss_desc->base_high   = (tss_addr >> 24) & 0xFF;
    tss_desc->base_upper  = (tss_addr >> 32) & 0xFFFFFFFF;
    tss_desc->reserved    = 0;

    // Load GDT
    gdtr.limit = sizeof(gdt) - 1;
    gdtr.base  = (uint64_t)&gdt;
    gdt_flush((uint64_t)&gdtr);
    tss_flush(GDT_TSS);
}

void gdt_set_tss_rsp0(uint64_t rsp0) {
    tss.rsp0 = rsp0;
}
