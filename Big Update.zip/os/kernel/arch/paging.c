#include "arch/paging.h"
#include "mm/pmm.h"
#include "lib/string.h"

static uint64_t *kernel_pml4;

static uint64_t *get_or_create_table(uint64_t *table, int index, uint64_t flags) {
    if (table[index] & PTE_PRESENT) {
        return (uint64_t *)PHYS_TO_VIRT(table[index] & PTE_ADDR_MASK);
    }
    uint64_t phys = pmm_alloc_page();
    if (!phys) return NULL;
    memset(PHYS_TO_VIRT(phys), 0, PAGE_SIZE);
    table[index] = phys | flags;
    return (uint64_t *)PHYS_TO_VIRT(phys);
}

void paging_map_page(uint64_t *pml4, uint64_t virt, uint64_t phys, uint64_t flags) {
    uint64_t *pdpt = get_or_create_table(pml4, PML4_INDEX(virt), PTE_PRESENT | PTE_WRITABLE | (flags & PTE_USER));
    if (!pdpt) return;
    uint64_t *pd = get_or_create_table(pdpt, PDPT_INDEX(virt), PTE_PRESENT | PTE_WRITABLE | (flags & PTE_USER));
    if (!pd) return;
    uint64_t *pt = get_or_create_table(pd, PD_INDEX(virt), PTE_PRESENT | PTE_WRITABLE | (flags & PTE_USER));
    if (!pt) return;
    pt[PT_INDEX(virt)] = (phys & PTE_ADDR_MASK) | flags;
    invlpg(virt);
}

void paging_unmap_page(uint64_t *pml4, uint64_t virt) {
    uint64_t *pdpt, *pd, *pt;

    if (!(pml4[PML4_INDEX(virt)] & PTE_PRESENT)) return;
    pdpt = (uint64_t *)PHYS_TO_VIRT(pml4[PML4_INDEX(virt)] & PTE_ADDR_MASK);

    if (!(pdpt[PDPT_INDEX(virt)] & PTE_PRESENT)) return;
    pd = (uint64_t *)PHYS_TO_VIRT(pdpt[PDPT_INDEX(virt)] & PTE_ADDR_MASK);

    if (!(pd[PD_INDEX(virt)] & PTE_PRESENT)) return;
    pt = (uint64_t *)PHYS_TO_VIRT(pd[PD_INDEX(virt)] & PTE_ADDR_MASK);

    pt[PT_INDEX(virt)] = 0;
    invlpg(virt);
}

uint64_t paging_get_phys(uint64_t *pml4, uint64_t virt) {
    if (!(pml4[PML4_INDEX(virt)] & PTE_PRESENT)) return 0;
    uint64_t *pdpt = (uint64_t *)PHYS_TO_VIRT(pml4[PML4_INDEX(virt)] & PTE_ADDR_MASK);

    if (!(pdpt[PDPT_INDEX(virt)] & PTE_PRESENT)) return 0;
    uint64_t *pd = (uint64_t *)PHYS_TO_VIRT(pdpt[PDPT_INDEX(virt)] & PTE_ADDR_MASK);

    if (pd[PD_INDEX(virt)] & PTE_HUGE) {
        return (pd[PD_INDEX(virt)] & PTE_ADDR_MASK) + (virt & 0x1FFFFF);
    }

    if (!(pd[PD_INDEX(virt)] & PTE_PRESENT)) return 0;
    uint64_t *pt = (uint64_t *)PHYS_TO_VIRT(pd[PD_INDEX(virt)] & PTE_ADDR_MASK);

    if (!(pt[PT_INDEX(virt)] & PTE_PRESENT)) return 0;
    return (pt[PT_INDEX(virt)] & PTE_ADDR_MASK) + (virt & 0xFFF);
}

void paging_init(void) {
    // Use the bootloader's PML4 initially, then rebuild it properly
    // The bootloader set up PML4 at 0x70000 with identity + higher half
    // We allocate a new PML4 and set up proper mappings

    kernel_pml4 = (uint64_t *)PHYS_TO_VIRT(read_cr3() & PTE_ADDR_MASK);
}

uint64_t *paging_create_address_space(void) {
    uint64_t phys = pmm_alloc_page();
    if (!phys) return NULL;

    uint64_t *new_pml4 = (uint64_t *)PHYS_TO_VIRT(phys);
    memset(new_pml4, 0, PAGE_SIZE);

    // Copy kernel half (entries 256-511) from kernel PML4
    for (int i = 256; i < 512; i++) {
        new_pml4[i] = kernel_pml4[i];
    }

    return new_pml4;
}

void paging_destroy_address_space(uint64_t *pml4) {
    // Free user-space page tables (entries 0-255)
    for (int i = 0; i < 256; i++) {
        if (!(pml4[i] & PTE_PRESENT)) continue;
        uint64_t *pdpt = (uint64_t *)PHYS_TO_VIRT(pml4[i] & PTE_ADDR_MASK);

        for (int j = 0; j < 512; j++) {
            if (!(pdpt[j] & PTE_PRESENT)) continue;
            uint64_t *pd = (uint64_t *)PHYS_TO_VIRT(pdpt[j] & PTE_ADDR_MASK);

            for (int k = 0; k < 512; k++) {
                if (!(pd[k] & PTE_PRESENT) || (pd[k] & PTE_HUGE)) continue;
                uint64_t *pt = (uint64_t *)PHYS_TO_VIRT(pd[k] & PTE_ADDR_MASK);

                for (int l = 0; l < 512; l++) {
                    if (pt[l] & PTE_PRESENT) {
                        pmm_free_page(pt[l] & PTE_ADDR_MASK);
                    }
                }
                pmm_free_page(pd[k] & PTE_ADDR_MASK);
            }
            pmm_free_page(pdpt[j] & PTE_ADDR_MASK);
        }
        pmm_free_page(pml4[i] & PTE_ADDR_MASK);
    }

    pmm_free_page(VIRT_TO_PHYS((uint64_t)pml4));
}

void paging_switch(uint64_t *pml4) {
    write_cr3(VIRT_TO_PHYS((uint64_t)pml4));
}

uint64_t *paging_get_kernel_pml4(void) {
    return kernel_pml4;
}
