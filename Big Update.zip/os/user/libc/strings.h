#pragma once

#include "string.h"

#define bzero(ptr, n) memset((ptr), 0, (n))
