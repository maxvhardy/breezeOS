#pragma once

#include "syscall.h"

void exit(int code);
int fork(void);
int exec(const char *path);
int waitpid(int pid, int *status);
int getpid(void);
void *sbrk(int64_t incr);
void yield(void);
void sleep(uint64_t ms);

void *malloc(size_t size);
void free(void *ptr);
void *calloc(size_t nmemb, size_t size);
void *realloc(void *ptr, size_t size);

int abs(int v);
long labs(long v);
double atof(const char *s);

char *getenv(const char *name);
int putenv(char *string);
int system(const char *command);
void abort(void);

int atexit(void (*func)(void));
