#include "math.h"

#define PI 3.14159265358979323846
#define HALF_PI 1.57079632679489661923
#define TWO_PI 6.28318530717958647692

static double wrap_pi(double x) {
    while (x > PI) x -= TWO_PI;
    while (x < -PI) x += TWO_PI;
    return x;
}

double fabs(double x) {
    return x < 0.0 ? -x : x;
}

float fabsf(float x) {
    return x < 0.0f ? -x : x;
}

double sin(double x) {
    x = wrap_pi(x);

    // 7th-order taylor approximation around 0.
    double x2 = x * x;
    double term = x;
    double res = term;

    term *= -x2 / (2.0 * 3.0);
    res += term;
    term *= -x2 / (4.0 * 5.0);
    res += term;
    term *= -x2 / (6.0 * 7.0);
    res += term;
    term *= -x2 / (8.0 * 9.0);
    res += term;

    return res;
}

double cos(double x) {
    return sin(x + HALF_PI);
}

double tan(double x) {
    double c = cos(x);
    if (c > -1e-9 && c < 1e-9) {
        return (x >= 0.0) ? 1e9 : -1e9;
    }
    return sin(x) / c;
}

double atan(double x) {
    int neg = 0;
    if (x < 0.0) {
        neg = 1;
        x = -x;
    }

    double r;
    if (x > 1.0) {
        r = HALF_PI - (x / (x * x + 0.28));
    } else {
        r = x / (1.0 + 0.28 * x * x);
    }

    return neg ? -r : r;
}
