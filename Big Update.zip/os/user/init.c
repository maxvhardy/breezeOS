#include "libc/stdio.h"
#include "libc/stdlib.h"
#include "libc/string.h"

int main(void) {
    printf("DoorOS init process started (PID %d)\n", getpid());

    // Launch the shell
    int shell_pid = fork();
    if (shell_pid == 0) {
        // Child process - exec shell
        exec("/bin/shell");
        printf("init: failed to exec /bin/shell\n");
        exit(1);
    }

    if (shell_pid < 0) {
        printf("init: fork failed\n");
        exit(1);
    }

    printf("init: started shell (PID %d)\n", shell_pid);

    // Init process loops forever, restarting shell if it dies
    while (1) {
        int status;
        int pid = waitpid(shell_pid, &status);
        if (pid == shell_pid) {
            printf("init: shell exited with status %d, restarting...\n", status);
            sleep(500);

            shell_pid = fork();
            if (shell_pid == 0) {
                exec("/bin/shell");
                printf("init: failed to restart shell\n");
                exit(1);
            }
        } else {
            sleep(100);
        }
    }

    return 0;
}
