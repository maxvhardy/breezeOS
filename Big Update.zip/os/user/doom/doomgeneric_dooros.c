#include "doomkeys.h"
#include "doomgeneric.h"

#include "libc/stdio.h"
#include "libc/stdlib.h"
#include "libc/string.h"

struct gui_event {
    uint32_t type;
    uint32_t window_id;
    int32_t x;
    int32_t y;
    uint32_t keycode;
    uint32_t buttons;
};

#define GUI_EVENT_KEY_PRESS  1
#define GUI_EVENT_WIN_CLOSE  6

#define DG_SYS_TICKS 28

static int g_window_id = -1;
static int g_running = 1;

#define KEYQ_CAP 256
struct key_event {
    int pressed;
    unsigned char key;
};

static struct key_event keyq[KEYQ_CAP];
static int keyq_r = 0;
static int keyq_w = 0;

static int win_create(int x, int y, int w, int h, const char *title) {
    return (int)syscall5(SYS_WIN_CREATE,
                         (uint64_t)x, (uint64_t)y,
                         (uint64_t)w, (uint64_t)h,
                         (uint64_t)title);
}

static void win_destroy(int wid) {
    syscall1(SYS_WIN_DESTROY, (uint64_t)wid);
}

static int win_update(int wid, uint32_t *pixels) {
    return (int)syscall2(SYS_WIN_UPDATE, (uint64_t)wid, (uint64_t)pixels);
}

static int win_event(struct gui_event *ev) {
    return (int)syscall1(SYS_WIN_EVENT, (uint64_t)ev);
}

static void keyq_push(int pressed, unsigned char key) {
    int next = (keyq_w + 1) % KEYQ_CAP;
    if (next == keyq_r) {
        keyq_r = (keyq_r + 1) % KEYQ_CAP;
    }

    keyq[keyq_w].pressed = pressed;
    keyq[keyq_w].key = key;
    keyq_w = next;
}

static int keyq_pop(int *pressed, unsigned char *key) {
    if (keyq_r == keyq_w) return 0;

    *pressed = keyq[keyq_r].pressed;
    *key = keyq[keyq_r].key;
    keyq_r = (keyq_r + 1) % KEYQ_CAP;
    return 1;
}

static unsigned char map_key(uint32_t keycode) {
    unsigned char c = (unsigned char)keycode;

    if (c >= 'A' && c <= 'Z') c = (unsigned char)(c - 'A' + 'a');

    switch (c) {
        case 27:  return KEY_ESCAPE;
        case '\r':
        case '\n': return KEY_ENTER;
        case '\t': return KEY_TAB;
        case '\b':
        case 127: return KEY_BACKSPACE;

        // Movement mappings tuned for this keyboard input model.
        case 'w': return KEY_UPARROW;
        case 's': return KEY_DOWNARROW;
        case 'a': return KEY_LEFTARROW;
        case 'd': return KEY_RIGHTARROW;
        case 'q': return KEY_STRAFE_L;
        case 'e': return KEY_STRAFE_R;
        case ' ': return KEY_USE;
        case 'f': return KEY_FIRE;

        default:
            return c;
    }
}

static void pump_events(void) {
    struct gui_event ev;
    int guard = 0;

    while (guard++ < 256 && win_event(&ev) == 1) {
        if ((int)ev.window_id != g_window_id) continue;

        if (ev.type == GUI_EVENT_WIN_CLOSE) {
            g_running = 0;
            keyq_push(1, KEY_ESCAPE);
            keyq_push(0, KEY_ESCAPE);
            continue;
        }

        if (ev.type == GUI_EVENT_KEY_PRESS) {
            unsigned char key = map_key(ev.keycode);
            if (key) {
                // Kernel currently reports key-press events only.
                // Emit a synthetic keyup immediately so Doom key state stays consistent.
                keyq_push(1, key);
                keyq_push(0, key);
            }
        }
    }
}

static int has_iwad_magic(const char *path) {
    if (!path || !path[0]) return 0;

    struct stat st;
    if (stat(path, &st) != 0 || st.size < 1024) return 0;

    int fd = open(path, O_RDONLY);
    if (fd < 0) return 0;

    unsigned char magic[4];
    ssize_t n = read(fd, magic, sizeof(magic));
    close(fd);
    if (n != (ssize_t)sizeof(magic)) return 0;

    if (magic[0] == 'I' && magic[1] == 'W' && magic[2] == 'A' && magic[3] == 'D') return 1;
    if (magic[0] == 'P' && magic[1] == 'W' && magic[2] == 'A' && magic[3] == 'D') return 1;
    return 0;
}

static const char *find_iwad(void) {
    static const char *candidates[] = {
        "/bin/doom1.wad",
        "/bin/DOOM1.WAD",
        "/bin/freedoom1.wad",
        "/bin/FREEDOOM1.WAD",
        "/bin/freedoom2.wad",
        "/bin/FREEDOOM2.WAD",
        "/bin/freedm.wad",
        "/bin/FREEDM.WAD",
        "/bin/doom.wad",
        "/bin/DOOM.WAD",
        "/bin/doom2.wad",
        "/bin/DOOM2.WAD",
        "/doom1.wad",
        "/freedoom1.wad",
        "/freedoom2.wad",
        "/freedm.wad",
        "/doom.wad",
        "/doom2.wad",
        "DOOM1.WAD",
        "DOOM2.WAD",
        "DOOM.WAD",
        "freedoom1.wad",
        "FREEDOOM1.WAD",
        "freedoom2.wad",
        "FREEDOOM2.WAD",
        "freedm.wad",
        "FREEDM.WAD",
        "doom1.wad",
        "doom.wad",
        "doom2.wad",
    };

    for (size_t i = 0; i < sizeof(candidates) / sizeof(candidates[0]); i++) {
        if (has_iwad_magic(candidates[i])) {
            return candidates[i];
        }
    }

    return NULL;
}

void DG_Init(void) {
    g_window_id = win_create(48, 30, DOOMGENERIC_RESX, DOOMGENERIC_RESY, "DOOM - DoorOS");
    if (g_window_id < 0) {
        printf("doom: failed to create window\n");
        exit(1);
    }

    keyq_r = 0;
    keyq_w = 0;
    g_running = 1;
}

void DG_DrawFrame(void) {
    if (g_window_id >= 0) {
        win_update(g_window_id, (uint32_t *)DG_ScreenBuffer);
    }
    pump_events();
}

void DG_SleepMs(uint32_t ms) {
    sleep(ms);
}

uint32_t DG_GetTicksMs(void) {
    // Millisecond uptime from kernel PIT clock.
    return (uint32_t)syscall0(DG_SYS_TICKS);
}

int DG_GetKey(int *pressed, unsigned char *doomKey) {
    if (!pressed || !doomKey) return 0;

    if (!keyq_pop(pressed, doomKey)) {
        pump_events();
        if (!keyq_pop(pressed, doomKey)) {
            return 0;
        }
    }

    return 1;
}

void DG_SetWindowTitle(const char *title) {
    (void)title;
}

int main(void) {
    const char *iwad = find_iwad();
    if (!iwad) {
        printf("doom: missing IWAD (looked in /bin and cwd)\\n");
        printf("doom: add /bin/doom1.wad, /bin/freedoom1.wad, or /bin/doom2.wad\\n");
        return 1;
    }

    printf("doom: using IWAD %s\\n", iwad);
    char *argv[] = {"doom", "-iwad", (char *)iwad, NULL};
    doomgeneric_Create(3, argv);

    while (g_running) {
        doomgeneric_Tick();
        DG_SleepMs(1);
    }

    if (g_window_id >= 0) {
        win_destroy(g_window_id);
        g_window_id = -1;
    }

    return 0;
}
