#include "libc/stdio.h"
#include "libc/stdlib.h"
#include "libc/string.h"

// GUI syscall event layout
struct gui_event {
    uint32_t type;
    uint32_t window_id;
    int32_t  x, y;
    uint32_t keycode;
    uint32_t buttons;
};

#define GUI_EVENT_NONE       0
#define GUI_EVENT_KEY_PRESS  1
#define GUI_EVENT_WIN_CLOSE  6

#define WIN_W  480
#define WIN_H  300

#define MAP_W 16
#define MAP_H 16
#define FIXED_ONE 1024

#define FOV_UNITS 64   // 64/256 of full circle ~= 90 degrees
#define MOVE_STEP 96
#define TURN_STEP 6

static const char world_map[MAP_H][MAP_W + 1] = {
    "################",
    "#..............#",
    "#..###.........#",
    "#..#...........#",
    "#..#....####...#",
    "#..#....#..#...#",
    "#..###..#..#...#",
    "#.......#..#...#",
    "#.......#..#...#",
    "#.......#..#...#",
    "#..####.#..#...#",
    "#..#....#..#...#",
    "#..#....####...#",
    "#..#...........#",
    "#..............#",
    "################",
};

static uint32_t framebuf[WIN_W * WIN_H];
static int32_t sin_lut[256];
static int32_t cos_lut[256];

static int player_x = 3 * FIXED_ONE;
static int player_y = 3 * FIXED_ONE;
static int player_a = 0;

static int win_create(int x, int y, int w, int h, const char *title) {
    return (int)syscall5(SYS_WIN_CREATE,
                         (uint64_t)x, (uint64_t)y,
                         (uint64_t)w, (uint64_t)h,
                         (uint64_t)title);
}

static void win_destroy(int wid) {
    syscall1(SYS_WIN_DESTROY, (uint64_t)wid);
}

static int win_update(int wid, uint32_t *pixels) {
    return (int)syscall2(SYS_WIN_UPDATE, (uint64_t)wid, (uint64_t)pixels);
}

static int win_event(struct gui_event *ev) {
    return (int)syscall1(SYS_WIN_EVENT, (uint64_t)ev);
}

static int abs_i(int x) {
    return (x < 0) ? -x : x;
}

static int clamp_i(int x, int lo, int hi) {
    if (x < lo) return lo;
    if (x > hi) return hi;
    return x;
}

static int is_wall_at(int fx, int fy) {
    int mx = fx / FIXED_ONE;
    int my = fy / FIXED_ONE;

    if (mx < 0 || my < 0 || mx >= MAP_W || my >= MAP_H) return 1;
    return world_map[my][mx] == '#';
}

static void try_move(int dx, int dy) {
    int nx = player_x + dx;
    int ny = player_y + dy;

    // Slide along walls.
    if (!is_wall_at(nx, player_y)) player_x = nx;
    if (!is_wall_at(player_x, ny)) player_y = ny;
}

static void init_trig(void) {
    // 256-step circle, iterative rotation by ~1.40625 degrees each step.
    // cos(theta)=1023/1024, sin(theta)=25/1024 (approx).
    int cx = FIXED_ONE;
    int sy = 0;

    for (int i = 0; i < 256; i++) {
        cos_lut[i] = cx;
        sin_lut[i] = sy;

        int next_cx = (cx * 1023 - sy * 25) / FIXED_ONE;
        int next_sy = (sy * 1023 + cx * 25) / FIXED_ONE;
        cx = next_cx;
        sy = next_sy;

        // Keep vectors bounded to avoid drift explosion.
        if ((i & 31) == 31) {
            int mag = abs_i(cx) + abs_i(sy);
            if (mag > 0) {
                cx = (cx * FIXED_ONE) / mag * 2;
                sy = (sy * FIXED_ONE) / mag * 2;
            }
        }
    }
}

static void draw_column(int x, int top, int bottom, uint32_t wall_color) {
    if (top < 0) top = 0;
    if (bottom >= WIN_H) bottom = WIN_H - 1;

    for (int y = 0; y < top; y++) {
        uint32_t sky = 0x1A2A4A + ((uint32_t)y << 8);
        framebuf[y * WIN_W + x] = sky;
    }

    for (int y = top; y <= bottom; y++) {
        framebuf[y * WIN_W + x] = wall_color;
    }

    for (int y = bottom + 1; y < WIN_H; y++) {
        uint32_t floor = 0x2A1A10 + ((uint32_t)(y - WIN_H / 2) << 4);
        framebuf[y * WIN_W + x] = floor;
    }
}

static void render_scene(void) {
    for (int x = 0; x < WIN_W; x++) {
        int ray_offset = ((x - WIN_W / 2) * FOV_UNITS) / WIN_W;
        int ray_a = (player_a + ray_offset) & 0xFF;

        int dir_x = cos_lut[ray_a];
        int dir_y = sin_lut[ray_a];

        int hit = 0;
        int dist = 8;
        int side = 0;

        for (; dist < 8192; dist += 16) {
            int rx = player_x + (dir_x * dist) / FIXED_ONE;
            int ry = player_y + (dir_y * dist) / FIXED_ONE;

            int mx = rx / FIXED_ONE;
            int my = ry / FIXED_ONE;
            if (mx < 0 || my < 0 || mx >= MAP_W || my >= MAP_H) {
                hit = 1;
                break;
            }

            if (world_map[my][mx] == '#') {
                int cell_x = rx & (FIXED_ONE - 1);
                int cell_y = ry & (FIXED_ONE - 1);
                side = (cell_x < 64 || cell_x > 960) ? 1 : ((cell_y < 64 || cell_y > 960) ? 2 : 0);
                hit = 1;
                break;
            }
        }

        if (!hit) dist = 8192;

        int corrected = dist;
        int wall_h = (WIN_H * 180) / (corrected + 1);
        wall_h = clamp_i(wall_h, 2, WIN_H);

        int top = (WIN_H / 2) - (wall_h / 2);
        int bottom = top + wall_h;

        int shade = 255 - (dist / 40);
        shade = clamp_i(shade, 24, 255);

        uint32_t wall_color;
        if (side == 1) {
            wall_color = ((uint32_t)shade << 16) | ((uint32_t)(shade / 2) << 8) | (uint32_t)(shade / 3);
        } else if (side == 2) {
            wall_color = ((uint32_t)(shade / 2) << 16) | ((uint32_t)shade << 8) | (uint32_t)(shade / 3);
        } else {
            wall_color = ((uint32_t)shade << 16) | ((uint32_t)(shade * 3 / 4) << 8) | (uint32_t)(shade / 4);
        }

        draw_column(x, top, bottom, wall_color);
    }

    // Simple minimap overlay (top-left)
    for (int my = 0; my < MAP_H; my++) {
        for (int mx = 0; mx < MAP_W; mx++) {
            uint32_t c = (world_map[my][mx] == '#') ? 0x202020 : 0x909090;
            for (int y = 0; y < 4; y++) {
                for (int x = 0; x < 4; x++) {
                    int px = 8 + mx * 4 + x;
                    int py = 8 + my * 4 + y;
                    if (px < WIN_W && py < WIN_H) framebuf[py * WIN_W + px] = c;
                }
            }
        }
    }

    int ppx = 8 + (player_x / (FIXED_ONE / 4));
    int ppy = 8 + (player_y / (FIXED_ONE / 4));
    for (int dy = -1; dy <= 1; dy++) {
        for (int dx = -1; dx <= 1; dx++) {
            int px = ppx + dx;
            int py = ppy + dy;
            if (px >= 0 && px < WIN_W && py >= 0 && py < WIN_H) {
                framebuf[py * WIN_W + px] = 0xFF0000;
            }
        }
    }
}

static void handle_key(uint32_t keycode) {
    char c = (char)keycode;

    if (c == 'a') {
        player_a = (player_a - TURN_STEP) & 0xFF;
    } else if (c == 'd') {
        player_a = (player_a + TURN_STEP) & 0xFF;
    } else if (c == 'w') {
        int dx = (cos_lut[player_a] * MOVE_STEP) / FIXED_ONE;
        int dy = (sin_lut[player_a] * MOVE_STEP) / FIXED_ONE;
        try_move(dx, dy);
    } else if (c == 's') {
        int dx = (cos_lut[player_a] * MOVE_STEP) / FIXED_ONE;
        int dy = (sin_lut[player_a] * MOVE_STEP) / FIXED_ONE;
        try_move(-dx, -dy);
    } else if (c == 'q') {
        // Strafe left
        int la = (player_a - 64) & 0xFF;
        int dx = (cos_lut[la] * MOVE_STEP) / FIXED_ONE;
        int dy = (sin_lut[la] * MOVE_STEP) / FIXED_ONE;
        try_move(dx, dy);
    } else if (c == 'e') {
        // Strafe right
        int ra = (player_a + 64) & 0xFF;
        int dx = (cos_lut[ra] * MOVE_STEP) / FIXED_ONE;
        int dy = (sin_lut[ra] * MOVE_STEP) / FIXED_ONE;
        try_move(dx, dy);
    }
}

int main(void) {
    printf("doomgeneric: starting DoorOS port...\n");
    printf("controls: W/S move, A/D turn, Q/E strafe\n");

    init_trig();

    int wid = win_create(72, 48, WIN_W, WIN_H, "DoomGeneric - DoorOS");
    if (wid < 0) {
        printf("doomgeneric: failed to create window\n");
        return 1;
    }

    int running = 1;
    while (running) {
        struct gui_event ev;
        int event_guard = 0;
        while (event_guard++ < 64 && win_event(&ev) == 1) {
            if ((int)ev.window_id != wid) continue;

            if (ev.type == GUI_EVENT_WIN_CLOSE) {
                running = 0;
                break;
            }

            if (ev.type == GUI_EVENT_KEY_PRESS) {
                if (ev.keycode == 27) {
                    running = 0;
                    break;
                }
                handle_key(ev.keycode);
            }
        }

        render_scene();
        win_update(wid, framebuf);
        sleep(16);
    }

    win_destroy(wid);
    printf("doomgeneric: exited\n");
    return 0;
}
